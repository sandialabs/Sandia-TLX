﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using Vis = Microsoft.Office.Interop.Visio;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in
{
    public partial class CtaRibbon
    {
        //private bool _developerMode = false;
        //public bool DeveloperMode
        //{
        //    get
        //    {
        //        return _developerMode;
        //    }
        //    set
        //    {
        //        _developerMode = value;
        //        _updateDeveloperControlStates(_developerMode);
        //    }
        //}

        private void CtaRibbon_Load(object sender, RibbonUIEventArgs e)
        {
            _updateDeveloperControlStates(Solution.IsDeveloperMode);

            // TODO: this is a weird place to set this, but the solution
            // needs to know how to refresh the Ribbon...
            Solution.UpdateRibbonUI = this.UpdateRibbonUI;

            // Note: RibbonMenus are read-only at run-time:
            // Note: Gallery.Buttons is read-only at run-time:

            // Replace the separator buttons with real separators:
            //for (int i = menu_TodoFunctions.Items.Count - 1; i > 0; i--)
            //{
            //    RibbonControl c = menu_TodoFunctions.Items[i];
            //    var b = c as RibbonButton;
            //    if (b != null)
            //    {
            //        if (b.Label == "——————————")
            //            b.Visible = false;
            //            //menu_TodoFunctions.Items.RemoveAt(i);
            //        //Microsoft.Office.Tools.Ribbon.RibbonButton
            //        //Microsoft.Office.Tools.Ribbon.RibbonSeparator;
            //    }
            //}

            // Re-label the "Apply Visual" Buttons:
            _updateDataGraphicButtonLabels();
        }

        public void UpdateRibbonUI()
        {
            _updateDataGraphicButtonLabels();
            _updateDeveloperControlStates(Solution.IsDeveloperMode);
        }

        private void _updateDataGraphicButtonLabels()
        {
            _configApplyDataGraphicButton(button_applyVisual01, Solution.CustomDataGraphicName01); // SolutionStrings.DataGraphicName01);
            _configApplyDataGraphicButton(button_applyVisual02, Solution.CustomDataGraphicName02); //  SolutionStrings.DataGraphicName02);
            _configApplyDataGraphicButton(button_applyVisual03, Solution.CustomDataGraphicName03); //  SolutionStrings.DataGraphicName03);
            _configApplyDataGraphicButton(button_applyVisual04, Solution.CustomDataGraphicName04); //  SolutionStrings.DataGraphicName04);
        }

        private void _configApplyDataGraphicButton( 
            RibbonButton btn, string dataGraphicName)
        {
            // Don't mess with empty strings.
            // TODO: just hide these buttons?
            if (String.IsNullOrEmpty(dataGraphicName))
            {
                btn.Enabled = false;
                return;
            }

            btn.Enabled = true;

            string sLabel, sTag;
            sLabel = "Apply: " + dataGraphicName;
            sTag = dataGraphicName;

            btn.Label = sLabel;
            btn.Tag = sTag;
        }
        private void _updateDeveloperControlStates(bool isDevMode)
        {
            // Most of this ribbon's controls are for developer/design mode only:
            this.menu_DataGraphics.Visible = isDevMode;
            this.button_AddCtaConnector.Visible = isDevMode;
            this.button_AddCognitiveTask.Visible = isDevMode;
            this.button_AddObservableTask.Visible = isDevMode;
            this.button_Help.Visible = isDevMode;
            this.menu_TodoFunctions.Visible = isDevMode;
        }

        private void button_showTaskForm_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ShowTliPanel();
        }


        private void button_AddCtaConnector_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.AddShape_Connector();
        }
        private void button_AddCognitiveTask_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.AddShape_CognitiveTask();
        }
        private void button_AddObservableTask_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.AddShape_ObservableTask();
        }

        //private void button_UpdateConnColors_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.UpdateConnectorColorReferences();
        //}

        private void groupCta_DialogLauncherClick(object sender, RibbonControlEventArgs e)
        {
            Commands.ShowOptionsForm();
        }

        private void button_refreshProgressBars_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.RefreshProgressBars(null);
        }

        #region "Issues and Highlighting"
        private void button_highlightAllIssues_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.HighlightAllIssues();
        }
        private void button_highlightDisconnections_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.HighlightDisconnections();
        }
        private void button_highlightDuplicates_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.HighlightTasksWithDuplicateDescriptions();
        }
        private void button_deleteHighlights_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ClearIssueHighlights();
        }
        #endregion "Issues and Highlighting"

        #region "Reports" 
        private void button_reportFlowOrder_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportFlowOrder(true, true);
        }        
        private void button_reportFlowOrder_Cog_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportFlowOrder(true, false);
        }
        private void button_reportFlowOrder_Obs_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportFlowOrder(false, true);
        }

        private void button_reportUnused_Cog_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportUnusedTasks(true, false);
        }

        private void button_reportUnused_Obs_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportUnusedTasks(false, true);
        }
        #endregion "Reports" 

        #region "Apply Data Graphics Visualizations"


        private void button_applyDataGraphic_Click(object sender, RibbonControlEventArgs e)
        {
            // For the most part, the button label just needs to end
            // with the name of a data graphic that is in the active
            // document. The solution code will attempt to find that
            // DG and apply it to cognitive, observable or both types
            // of shapes.

            var btn = sender as RibbonButton;
            if (btn == null) return;

            if (btn == button_clearDataGraphics)
            {
                Commands.ApplyDataGraphics_None();
            }
            // ----------------------------------------------------------------
            else if (btn == button_applyVisual_AllItemsRated)
            {
                Commands.ApplyDataGraphics_AllItemsRated();
            }
            else if (btn == button_applyVisualAverageRating)
            {
                Commands.ApplyDataGraphics_AverageRating();
            }
            // ----------------------------------------------------------------
            else
            {
                // Try and apply the data graphic, identifying the DG by
                // the text on the button. All of the data graphic buttons
                // start with "Apply: ", then the name of the data graphic
                // follows. The solution code will look for "Task", "Cog",
                // "Obs", "Cognitive", "Observable" chunks of text in order
                // to decide which shapes should receive the data graphic.

                const string prefix = "Apply: ";
                string s = btn.Label;
                if (s.StartsWith(prefix))
                {
                    s = s.Substring(prefix.Length);
                }

                Commands.ApplyDataGraphics_FromDgName(s);
            }

        }


        //private void button_applyVisual_AllItemsRated_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_AllItemsRated();
        //}
        //private void button_applyVisualAverageRating_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_AverageRating();
        //}

        //private void button_applyVisual01_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_FromButtonTag((string)button_applyVisual01.Tag);
        //}

        //private void button_applyVisual02_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_FromButtonTag((string)button_applyVisual02.Tag);
        //}

        //private void button_applyVisual03_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_FromButtonTag((string)button_applyVisual03.Tag);
        //}

        //private void button_applyVisual04_Click(object sender, RibbonControlEventArgs e)
        //{
        //    Commands.ApplyDataGraphics_FromButtonTag((string)button_applyVisual04.Tag);
        //}


        #endregion "Apply Data Graphics Visualizations"

        private void button_updateCategories_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.UpdateCategoriesAndConnectorColors();
        }

        private void button_viewCurrentData_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.UpdateCategoriesAndConnectorColors();
            Commands.ViewCurrentData();
        }


        private void button_SaveToExcel_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.UpdateCategoriesAndConnectorColors();

            Commands.SaveToExcel();
        }

        private void button_NewCtaDiagram_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.NewCtaDiagram();
        }

        private void button_checkExcelFile_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.CheckDataSource();
        }

        private void button_ViewCurrentDataFile_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ViewDataSource();
        }

        private void button_dropMany_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.AddShape_Many();
        }
        private void button_Help_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ShowHelp();
        }

        private void button_reportUnusedTasks_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ReportUnusedTasks(true, true);
        }

        private void button_gotoConfigPage_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.GotoConfigPage();
        }

        private void button_refreshShapesFromData_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.RefreshShapesFromData();
        }

        private void button_ClearAllRatingsOnPage_Click(object sender, RibbonControlEventArgs e)
        {
            Commands.ClearAllRatingValues();
        }
    }
}
