﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in
{
    partial class CtaRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public CtaRibbon()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Microsoft.Office.Tools.Ribbon.RibbonDialogLauncher ribbonDialogLauncherImpl1 = this.Factory.CreateRibbonDialogLauncher();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtaRibbon));
            this.tab2 = this.Factory.CreateRibbonTab();
            this.groupCta = this.Factory.CreateRibbonGroup();
            this.button_showTaskForm = this.Factory.CreateRibbonButton();
            this.button_refreshProgressBars = this.Factory.CreateRibbonButton();
            this.button_SaveToExcel = this.Factory.CreateRibbonButton();
            this.menu_DataGraphics = this.Factory.CreateRibbonMenu();
            this.button_clearDataGraphics = this.Factory.CreateRibbonButton();
            this.separator1 = this.Factory.CreateRibbonSeparator();
            this.button_applyVisual_AllItemsRated = this.Factory.CreateRibbonButton();
            this.button_applyVisualAverageRating = this.Factory.CreateRibbonButton();
            this.separator2 = this.Factory.CreateRibbonSeparator();
            this.button_applyVisual_Cog_MentalDemand = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Cog_PhysicalDemand = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Cog_TemporalDemand = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Cog_Performance = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Cog_Effort = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Cog_Frustration = this.Factory.CreateRibbonButton();
            this.separator3 = this.Factory.CreateRibbonSeparator();
            this.button_applyVisual_Obs_Importance = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Obs_Difficulty = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Obs_Duration = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Obs_Frequency = this.Factory.CreateRibbonButton();
            this.button_applyVisual_Obs_Complexity = this.Factory.CreateRibbonButton();
            this.separator4 = this.Factory.CreateRibbonSeparator();
            this.button_applyVisual01 = this.Factory.CreateRibbonButton();
            this.button_applyVisual02 = this.Factory.CreateRibbonButton();
            this.button_applyVisual03 = this.Factory.CreateRibbonButton();
            this.button_applyVisual04 = this.Factory.CreateRibbonButton();
            this.menu_TodoFunctions = this.Factory.CreateRibbonMenu();
            this.button_NewCtaDiagram = this.Factory.CreateRibbonButton();
            this.button_gotoConfigPage = this.Factory.CreateRibbonButton();
            this.button_separator01 = this.Factory.CreateRibbonButton();
            this.button_viewCurrentData = this.Factory.CreateRibbonButton();
            this.button_checkExcelFile = this.Factory.CreateRibbonButton();
            this.button_ViewCurrentDataFile = this.Factory.CreateRibbonButton();
            this.button_refreshShapesFromData = this.Factory.CreateRibbonButton();
            this.button_ClearAllRatingsOnPage = this.Factory.CreateRibbonButton();
            this.button_separator02 = this.Factory.CreateRibbonButton();
            this.button_updateCategoriesAndConnColors = this.Factory.CreateRibbonButton();
            this.button_dropMany = this.Factory.CreateRibbonButton();
            this.button_separator03 = this.Factory.CreateRibbonButton();
            this.button_highlightAllIssues = this.Factory.CreateRibbonButton();
            this.button_highlightDuplicates = this.Factory.CreateRibbonButton();
            this.button_highlightDisconnections = this.Factory.CreateRibbonButton();
            this.button_deleteAllHighlights = this.Factory.CreateRibbonButton();
            this.button_separator04 = this.Factory.CreateRibbonButton();
            this.button_reportFlowOrder = this.Factory.CreateRibbonButton();
            this.button_reportFlowOrder_Cog = this.Factory.CreateRibbonButton();
            this.button_reportFlowOrder_Obs = this.Factory.CreateRibbonButton();
            this.button_separator05 = this.Factory.CreateRibbonButton();
            this.button_reportUnusedTasks = this.Factory.CreateRibbonButton();
            this.button_reportUnused_Cog = this.Factory.CreateRibbonButton();
            this.button_reportUnused_Obs = this.Factory.CreateRibbonButton();
            this.button_AddCognitiveTask = this.Factory.CreateRibbonButton();
            this.button_AddObservableTask = this.Factory.CreateRibbonButton();
            this.button_AddCtaConnector = this.Factory.CreateRibbonButton();
            this.button_Help = this.Factory.CreateRibbonButton();
            this.tab2.SuspendLayout();
            this.groupCta.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab2
            // 
            this.tab2.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
            this.tab2.ControlId.OfficeId = "TabHome";
            this.tab2.Groups.Add(this.groupCta);
            this.tab2.Label = "TabHome";
            this.tab2.Name = "tab2";
            // 
            // groupCta
            // 
            this.groupCta.DialogLauncher = ribbonDialogLauncherImpl1;
            this.groupCta.Items.Add(this.button_showTaskForm);
            this.groupCta.Items.Add(this.button_refreshProgressBars);
            this.groupCta.Items.Add(this.button_SaveToExcel);
            this.groupCta.Items.Add(this.menu_DataGraphics);
            this.groupCta.Items.Add(this.menu_TodoFunctions);
            this.groupCta.Items.Add(this.button_AddCognitiveTask);
            this.groupCta.Items.Add(this.button_AddObservableTask);
            this.groupCta.Items.Add(this.button_AddCtaConnector);
            this.groupCta.Items.Add(this.button_Help);
            this.groupCta.Label = "CTA";
            this.groupCta.Name = "groupCta";
            this.groupCta.Position = this.Factory.RibbonPosition.AfterOfficeId("GroupEditing");
            this.groupCta.DialogLauncherClick += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.groupCta_DialogLauncherClick);
            // 
            // button_showTaskForm
            // 
            this.button_showTaskForm.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_showTaskForm.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.tli_pane;
            this.button_showTaskForm.Label = "Show TLX Pane";
            this.button_showTaskForm.Name = "button_showTaskForm";
            this.button_showTaskForm.OfficeImageId = "NewIssueTrackerTool";
            this.button_showTaskForm.ShowImage = true;
            this.button_showTaskForm.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_showTaskForm_Click);
            // 
            // button_refreshProgressBars
            // 
            this.button_refreshProgressBars.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_refreshProgressBars.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.progress_bars;
            this.button_refreshProgressBars.Label = "Update Progress";
            this.button_refreshProgressBars.Name = "button_refreshProgressBars";
            this.button_refreshProgressBars.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_refreshProgressBars.ScreenTip = "Update Progress Bar Shapes";
            this.button_refreshProgressBars.ShowImage = true;
            this.button_refreshProgressBars.SuperTip = "Update all progress bar shapes on the diagram page to show the percentage of task" +
    "s that have been fully rated.";
            this.button_refreshProgressBars.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_refreshProgressBars_Click);
            // 
            // button_SaveToExcel
            // 
            this.button_SaveToExcel.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_SaveToExcel.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.SaveToExcel;
            this.button_SaveToExcel.Label = "Save Data";
            this.button_SaveToExcel.Name = "button_SaveToExcel";
            this.button_SaveToExcel.OfficeImageId = "SaveAsExcelTemplate";
            this.button_SaveToExcel.ScreenTip = "Save Data to Excel";
            this.button_SaveToExcel.ShowImage = true;
            this.button_SaveToExcel.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_SaveToExcel_Click);
            // 
            // menu_DataGraphics
            // 
            this.menu_DataGraphics.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.menu_DataGraphics.Items.Add(this.button_clearDataGraphics);
            this.menu_DataGraphics.Items.Add(this.separator1);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_AllItemsRated);
            this.menu_DataGraphics.Items.Add(this.button_applyVisualAverageRating);
            this.menu_DataGraphics.Items.Add(this.separator2);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_MentalDemand);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_PhysicalDemand);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_TemporalDemand);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_Performance);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_Effort);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Cog_Frustration);
            this.menu_DataGraphics.Items.Add(this.separator3);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Obs_Importance);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Obs_Difficulty);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Obs_Duration);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Obs_Frequency);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual_Obs_Complexity);
            this.menu_DataGraphics.Items.Add(this.separator4);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual01);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual02);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual03);
            this.menu_DataGraphics.Items.Add(this.button_applyVisual04);
            this.menu_DataGraphics.Label = "Data Graphics";
            this.menu_DataGraphics.Name = "menu_DataGraphics";
            this.menu_DataGraphics.OfficeImageId = "DataGraphicsGalleryVisio";
            this.menu_DataGraphics.ShowImage = true;
            // 
            // button_clearDataGraphics
            // 
            this.button_clearDataGraphics.Label = "Clear Data Graphics";
            this.button_clearDataGraphics.Name = "button_clearDataGraphics";
            this.button_clearDataGraphics.OfficeImageId = "RemoveDataGraphic";
            this.button_clearDataGraphics.ShowImage = true;
            this.button_clearDataGraphics.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // separator1
            // 
            this.separator1.Name = "separator1";
            // 
            // button_applyVisual_AllItemsRated
            // 
            this.button_applyVisual_AllItemsRated.Label = "All Items Rated";
            this.button_applyVisual_AllItemsRated.Name = "button_applyVisual_AllItemsRated";
            this.button_applyVisual_AllItemsRated.ShowImage = true;
            this.button_applyVisual_AllItemsRated.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisualAverageRating
            // 
            this.button_applyVisualAverageRating.Label = "Average Rating";
            this.button_applyVisualAverageRating.Name = "button_applyVisualAverageRating";
            this.button_applyVisualAverageRating.ShowImage = true;
            this.button_applyVisualAverageRating.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // separator2
            // 
            this.separator2.Name = "separator2";
            // 
            // button_applyVisual_Cog_MentalDemand
            // 
            this.button_applyVisual_Cog_MentalDemand.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.DataGraphics_Cog;
            this.button_applyVisual_Cog_MentalDemand.Label = "Apply: DG - Cognitive Mental Demand";
            this.button_applyVisual_Cog_MentalDemand.Name = "button_applyVisual_Cog_MentalDemand";
            this.button_applyVisual_Cog_MentalDemand.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_MentalDemand.ShowImage = true;
            this.button_applyVisual_Cog_MentalDemand.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Cog_PhysicalDemand
            // 
            this.button_applyVisual_Cog_PhysicalDemand.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Cog_PhysicalDemand.Image")));
            this.button_applyVisual_Cog_PhysicalDemand.Label = "Apply: DG - Cognitive Physical Demand";
            this.button_applyVisual_Cog_PhysicalDemand.Name = "button_applyVisual_Cog_PhysicalDemand";
            this.button_applyVisual_Cog_PhysicalDemand.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_PhysicalDemand.ShowImage = true;
            this.button_applyVisual_Cog_PhysicalDemand.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Cog_TemporalDemand
            // 
            this.button_applyVisual_Cog_TemporalDemand.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Cog_TemporalDemand.Image")));
            this.button_applyVisual_Cog_TemporalDemand.Label = "Apply: DG - Cognitive Temporal Demand";
            this.button_applyVisual_Cog_TemporalDemand.Name = "button_applyVisual_Cog_TemporalDemand";
            this.button_applyVisual_Cog_TemporalDemand.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_TemporalDemand.ShowImage = true;
            this.button_applyVisual_Cog_TemporalDemand.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Cog_Performance
            // 
            this.button_applyVisual_Cog_Performance.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Cog_Performance.Image")));
            this.button_applyVisual_Cog_Performance.Label = "Apply: DG - Cognitive Performance";
            this.button_applyVisual_Cog_Performance.Name = "button_applyVisual_Cog_Performance";
            this.button_applyVisual_Cog_Performance.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_Performance.ShowImage = true;
            this.button_applyVisual_Cog_Performance.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Cog_Effort
            // 
            this.button_applyVisual_Cog_Effort.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Cog_Effort.Image")));
            this.button_applyVisual_Cog_Effort.Label = "Apply: DG - Cognitive Effort";
            this.button_applyVisual_Cog_Effort.Name = "button_applyVisual_Cog_Effort";
            this.button_applyVisual_Cog_Effort.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_Effort.ShowImage = true;
            this.button_applyVisual_Cog_Effort.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Cog_Frustration
            // 
            this.button_applyVisual_Cog_Frustration.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Cog_Frustration.Image")));
            this.button_applyVisual_Cog_Frustration.Label = "Apply: DG - Cognitive Frustration";
            this.button_applyVisual_Cog_Frustration.Name = "button_applyVisual_Cog_Frustration";
            this.button_applyVisual_Cog_Frustration.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Cog_Frustration.ShowImage = true;
            this.button_applyVisual_Cog_Frustration.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // separator3
            // 
            this.separator3.Name = "separator3";
            // 
            // button_applyVisual_Obs_Importance
            // 
            this.button_applyVisual_Obs_Importance.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.DataGraphics_Obs;
            this.button_applyVisual_Obs_Importance.Label = "Apply: DG - Observable Importance";
            this.button_applyVisual_Obs_Importance.Name = "button_applyVisual_Obs_Importance";
            this.button_applyVisual_Obs_Importance.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Obs_Importance.ShowImage = true;
            this.button_applyVisual_Obs_Importance.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Obs_Difficulty
            // 
            this.button_applyVisual_Obs_Difficulty.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Obs_Difficulty.Image")));
            this.button_applyVisual_Obs_Difficulty.Label = "Apply: DG - Observable Difficulty";
            this.button_applyVisual_Obs_Difficulty.Name = "button_applyVisual_Obs_Difficulty";
            this.button_applyVisual_Obs_Difficulty.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Obs_Difficulty.ShowImage = true;
            this.button_applyVisual_Obs_Difficulty.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Obs_Duration
            // 
            this.button_applyVisual_Obs_Duration.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Obs_Duration.Image")));
            this.button_applyVisual_Obs_Duration.Label = "Apply: DG - Observable Duration";
            this.button_applyVisual_Obs_Duration.Name = "button_applyVisual_Obs_Duration";
            this.button_applyVisual_Obs_Duration.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Obs_Duration.ShowImage = true;
            this.button_applyVisual_Obs_Duration.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Obs_Frequency
            // 
            this.button_applyVisual_Obs_Frequency.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Obs_Frequency.Image")));
            this.button_applyVisual_Obs_Frequency.Label = "Apply: DG - Observable Frequency";
            this.button_applyVisual_Obs_Frequency.Name = "button_applyVisual_Obs_Frequency";
            this.button_applyVisual_Obs_Frequency.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Obs_Frequency.ShowImage = true;
            this.button_applyVisual_Obs_Frequency.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual_Obs_Complexity
            // 
            this.button_applyVisual_Obs_Complexity.Image = ((System.Drawing.Image)(resources.GetObject("button_applyVisual_Obs_Complexity.Image")));
            this.button_applyVisual_Obs_Complexity.Label = "Apply: DG - Observable Complexity";
            this.button_applyVisual_Obs_Complexity.Name = "button_applyVisual_Obs_Complexity";
            this.button_applyVisual_Obs_Complexity.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual_Obs_Complexity.ShowImage = true;
            this.button_applyVisual_Obs_Complexity.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // separator4
            // 
            this.separator4.Name = "separator4";
            // 
            // button_applyVisual01
            // 
            this.button_applyVisual01.Label = "Apply Visual 01";
            this.button_applyVisual01.Name = "button_applyVisual01";
            this.button_applyVisual01.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual01.ShowImage = true;
            this.button_applyVisual01.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual02
            // 
            this.button_applyVisual02.Label = "Apply Visual 02";
            this.button_applyVisual02.Name = "button_applyVisual02";
            this.button_applyVisual02.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual02.ShowImage = true;
            this.button_applyVisual02.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual03
            // 
            this.button_applyVisual03.Label = "Apply Visual 03";
            this.button_applyVisual03.Name = "button_applyVisual03";
            this.button_applyVisual03.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual03.ShowImage = true;
            this.button_applyVisual03.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // button_applyVisual04
            // 
            this.button_applyVisual04.Label = "Apply Visual 04";
            this.button_applyVisual04.Name = "button_applyVisual04";
            this.button_applyVisual04.OfficeImageId = "DataGraphicsGalleryVisio";
            this.button_applyVisual04.ShowImage = true;
            this.button_applyVisual04.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_applyDataGraphic_Click);
            // 
            // menu_TodoFunctions
            // 
            this.menu_TodoFunctions.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.menu_TodoFunctions.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.SNL_Logo;
            this.menu_TodoFunctions.Items.Add(this.button_NewCtaDiagram);
            this.menu_TodoFunctions.Items.Add(this.button_gotoConfigPage);
            this.menu_TodoFunctions.Items.Add(this.button_separator01);
            this.menu_TodoFunctions.Items.Add(this.button_viewCurrentData);
            this.menu_TodoFunctions.Items.Add(this.button_checkExcelFile);
            this.menu_TodoFunctions.Items.Add(this.button_ViewCurrentDataFile);
            this.menu_TodoFunctions.Items.Add(this.button_refreshShapesFromData);
            this.menu_TodoFunctions.Items.Add(this.button_ClearAllRatingsOnPage);
            this.menu_TodoFunctions.Items.Add(this.button_separator02);
            this.menu_TodoFunctions.Items.Add(this.button_updateCategoriesAndConnColors);
            this.menu_TodoFunctions.Items.Add(this.button_dropMany);
            this.menu_TodoFunctions.Items.Add(this.button_separator03);
            this.menu_TodoFunctions.Items.Add(this.button_highlightAllIssues);
            this.menu_TodoFunctions.Items.Add(this.button_highlightDuplicates);
            this.menu_TodoFunctions.Items.Add(this.button_highlightDisconnections);
            this.menu_TodoFunctions.Items.Add(this.button_deleteAllHighlights);
            this.menu_TodoFunctions.Items.Add(this.button_separator04);
            this.menu_TodoFunctions.Items.Add(this.button_reportFlowOrder);
            this.menu_TodoFunctions.Items.Add(this.button_reportFlowOrder_Cog);
            this.menu_TodoFunctions.Items.Add(this.button_reportFlowOrder_Obs);
            this.menu_TodoFunctions.Items.Add(this.button_separator05);
            this.menu_TodoFunctions.Items.Add(this.button_reportUnusedTasks);
            this.menu_TodoFunctions.Items.Add(this.button_reportUnused_Cog);
            this.menu_TodoFunctions.Items.Add(this.button_reportUnused_Obs);
            this.menu_TodoFunctions.Label = "Functions";
            this.menu_TodoFunctions.Name = "menu_TodoFunctions";
            this.menu_TodoFunctions.ShowImage = true;
            // 
            // button_NewCtaDiagram
            // 
            this.button_NewCtaDiagram.Label = "New CTA Diagram";
            this.button_NewCtaDiagram.Name = "button_NewCtaDiagram";
            this.button_NewCtaDiagram.OfficeImageId = "NewNotebookMenu";
            this.button_NewCtaDiagram.ShowImage = true;
            this.button_NewCtaDiagram.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_NewCtaDiagram_Click);
            // 
            // button_gotoConfigPage
            // 
            this.button_gotoConfigPage.Label = "Go to config Page";
            this.button_gotoConfigPage.Name = "button_gotoConfigPage";
            this.button_gotoConfigPage.OfficeImageId = "CurrentViewSettings";
            this.button_gotoConfigPage.ShowImage = true;
            this.button_gotoConfigPage.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_gotoConfigPage_Click);
            // 
            // button_separator01
            // 
            this.button_separator01.Enabled = false;
            this.button_separator01.Label = "——————————";
            this.button_separator01.Name = "button_separator01";
            this.button_separator01.ShowImage = true;
            // 
            // button_viewCurrentData
            // 
            this.button_viewCurrentData.Label = "View Current Data...";
            this.button_viewCurrentData.Name = "button_viewCurrentData";
            this.button_viewCurrentData.ShowImage = true;
            this.button_viewCurrentData.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_viewCurrentData_Click);
            // 
            // button_checkExcelFile
            // 
            this.button_checkExcelFile.Label = "Check Excel File";
            this.button_checkExcelFile.Name = "button_checkExcelFile";
            this.button_checkExcelFile.OfficeImageId = "GroupInkCreate";
            this.button_checkExcelFile.ShowImage = true;
            this.button_checkExcelFile.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_checkExcelFile_Click);
            // 
            // button_ViewCurrentDataFile
            // 
            this.button_ViewCurrentDataFile.Label = "View Current Data File...";
            this.button_ViewCurrentDataFile.Name = "button_ViewCurrentDataFile";
            this.button_ViewCurrentDataFile.OfficeImageId = "MicrosoftExcel";
            this.button_ViewCurrentDataFile.ShowImage = true;
            this.button_ViewCurrentDataFile.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_ViewCurrentDataFile_Click);
            // 
            // button_refreshShapesFromData
            // 
            this.button_refreshShapesFromData.Label = "Refresh Rating Values...";
            this.button_refreshShapesFromData.Name = "button_refreshShapesFromData";
            this.button_refreshShapesFromData.OfficeImageId = "RefreshMeetingDetails";
            this.button_refreshShapesFromData.ScreenTip = "Refresh Shape Data Fields from Data File";
            this.button_refreshShapesFromData.ShowImage = true;
            this.button_refreshShapesFromData.SuperTip = "Refreshes the data in all task shapes on the page with corresponding data in the " +
    "Excel data file (if matching Descriptions are found.)";
            this.button_refreshShapesFromData.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_refreshShapesFromData_Click);
            // 
            // button_ClearAllRatingsOnPage
            // 
            this.button_ClearAllRatingsOnPage.Label = "Clear Rating Values...";
            this.button_ClearAllRatingsOnPage.Name = "button_ClearAllRatingsOnPage";
            this.button_ClearAllRatingsOnPage.OfficeImageId = "ClearAll";
            this.button_ClearAllRatingsOnPage.ScreenTip = "Clear All Rating Values for All Task Shapes on Page";
            this.button_ClearAllRatingsOnPage.ShowImage = true;
            this.button_ClearAllRatingsOnPage.SuperTip = "Clears all ratings in all task shapes on the current page. This prepares a docume" +
    "nt for use by an end-user.";
            this.button_ClearAllRatingsOnPage.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_ClearAllRatingsOnPage_Click);
            // 
            // button_separator02
            // 
            this.button_separator02.Enabled = false;
            this.button_separator02.Label = "——————————";
            this.button_separator02.Name = "button_separator02";
            this.button_separator02.ShowImage = true;
            // 
            // button_updateCategoriesAndConnColors
            // 
            this.button_updateCategoriesAndConnColors.Label = "Update Categories && Connector Colors";
            this.button_updateCategoriesAndConnColors.Name = "button_updateCategoriesAndConnColors";
            this.button_updateCategoriesAndConnColors.OfficeImageId = "RefreshMeetingDetails";
            this.button_updateCategoriesAndConnColors.ScreenTip = "Update Layer and Container Categores and Connector Colors";
            this.button_updateCategoriesAndConnColors.ShowImage = true;
            this.button_updateCategoriesAndConnColors.SuperTip = "Updates shape categories based on layers and containers, and links connector colo" +
    "rs to the colors of shapes they are glued to.";
            this.button_updateCategoriesAndConnColors.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_updateCategories_Click);
            // 
            // button_dropMany
            // 
            this.button_dropMany.Label = "Add Multiple Tasks...";
            this.button_dropMany.Name = "button_dropMany";
            this.button_dropMany.OfficeImageId = "ShapesDuplicate";
            this.button_dropMany.ScreenTip = "Add Many Tasks at Once";
            this.button_dropMany.ShowImage = true;
            this.button_dropMany.SuperTip = "Add multiple cognitive and observable task shapes from the data source in one ope" +
    "ration.";
            this.button_dropMany.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_dropMany_Click);
            // 
            // button_separator03
            // 
            this.button_separator03.Enabled = false;
            this.button_separator03.Label = "——————————";
            this.button_separator03.Name = "button_separator03";
            this.button_separator03.ShowImage = true;
            // 
            // button_highlightAllIssues
            // 
            this.button_highlightAllIssues.Label = "Highlight All Issues";
            this.button_highlightAllIssues.Name = "button_highlightAllIssues";
            this.button_highlightAllIssues.OfficeImageId = "InkSelectHighlighter";
            this.button_highlightAllIssues.ShowImage = true;
            this.button_highlightAllIssues.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_highlightAllIssues_Click);
            // 
            // button_highlightDuplicates
            // 
            this.button_highlightDuplicates.Label = "Highlight Duplicate-description Shapes";
            this.button_highlightDuplicates.Name = "button_highlightDuplicates";
            this.button_highlightDuplicates.OfficeImageId = "GroupInkPens";
            this.button_highlightDuplicates.ShowImage = true;
            this.button_highlightDuplicates.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_highlightDuplicates_Click);
            // 
            // button_highlightDisconnections
            // 
            this.button_highlightDisconnections.Label = "Highlight Disconnections";
            this.button_highlightDisconnections.Name = "button_highlightDisconnections";
            this.button_highlightDisconnections.OfficeImageId = "InkTool";
            this.button_highlightDisconnections.ShowImage = true;
            this.button_highlightDisconnections.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_highlightDisconnections_Click);
            // 
            // button_deleteAllHighlights
            // 
            this.button_deleteAllHighlights.Label = "Delete All Issue Highlights";
            this.button_deleteAllHighlights.Name = "button_deleteAllHighlights";
            this.button_deleteAllHighlights.OfficeImageId = "GroupPrintPreviewPreview";
            this.button_deleteAllHighlights.ShowImage = true;
            this.button_deleteAllHighlights.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_deleteHighlights_Click);
            // 
            // button_separator04
            // 
            this.button_separator04.Enabled = false;
            this.button_separator04.Label = "——————————";
            this.button_separator04.Name = "button_separator04";
            this.button_separator04.ShowImage = true;
            // 
            // button_reportFlowOrder
            // 
            this.button_reportFlowOrder.Label = "Report Flow Order";
            this.button_reportFlowOrder.Name = "button_reportFlowOrder";
            this.button_reportFlowOrder.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportFlowOrder.ShowImage = true;
            this.button_reportFlowOrder.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportFlowOrder_Click);
            // 
            // button_reportFlowOrder_Cog
            // 
            this.button_reportFlowOrder_Cog.Label = "Report Flow Order (Cognitive Tasks)";
            this.button_reportFlowOrder_Cog.Name = "button_reportFlowOrder_Cog";
            this.button_reportFlowOrder_Cog.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportFlowOrder_Cog.ShowImage = true;
            this.button_reportFlowOrder_Cog.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportFlowOrder_Cog_Click);
            // 
            // button_reportFlowOrder_Obs
            // 
            this.button_reportFlowOrder_Obs.Label = "Report Flow Order (Observable Tasks)";
            this.button_reportFlowOrder_Obs.Name = "button_reportFlowOrder_Obs";
            this.button_reportFlowOrder_Obs.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportFlowOrder_Obs.ShowImage = true;
            this.button_reportFlowOrder_Obs.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportFlowOrder_Obs_Click);
            // 
            // button_separator05
            // 
            this.button_separator05.Enabled = false;
            this.button_separator05.Label = "——————————";
            this.button_separator05.Name = "button_separator05";
            this.button_separator05.ShowImage = true;
            // 
            // button_reportUnusedTasks
            // 
            this.button_reportUnusedTasks.Label = "Report Unused Tasks";
            this.button_reportUnusedTasks.Name = "button_reportUnusedTasks";
            this.button_reportUnusedTasks.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportUnusedTasks.ShowImage = true;
            this.button_reportUnusedTasks.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportUnusedTasks_Click);
            // 
            // button_reportUnused_Cog
            // 
            this.button_reportUnused_Cog.Label = "Report Unused Cognitive Tasks";
            this.button_reportUnused_Cog.Name = "button_reportUnused_Cog";
            this.button_reportUnused_Cog.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportUnused_Cog.ShowImage = true;
            this.button_reportUnused_Cog.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportUnused_Cog_Click);
            // 
            // button_reportUnused_Obs
            // 
            this.button_reportUnused_Obs.Label = "Report Unused Observable Tasks";
            this.button_reportUnused_Obs.Name = "button_reportUnused_Obs";
            this.button_reportUnused_Obs.OfficeImageId = "PivotTableDoNotRepeatItemLabels";
            this.button_reportUnused_Obs.ShowImage = true;
            this.button_reportUnused_Obs.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_reportUnused_Obs_Click);
            // 
            // button_AddCognitiveTask
            // 
            this.button_AddCognitiveTask.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_AddCognitiveTask.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.cog_task;
            this.button_AddCognitiveTask.Label = "Cognitive";
            this.button_AddCognitiveTask.Name = "button_AddCognitiveTask";
            this.button_AddCognitiveTask.OfficeImageId = "ShapeStar";
            this.button_AddCognitiveTask.ScreenTip = "Add Cognitive Task Shape";
            this.button_AddCognitiveTask.ShowImage = true;
            this.button_AddCognitiveTask.SuperTip = "Add Cognitive Task Shape";
            this.button_AddCognitiveTask.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_AddCognitiveTask_Click);
            // 
            // button_AddObservableTask
            // 
            this.button_AddObservableTask.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_AddObservableTask.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.obs_task;
            this.button_AddObservableTask.Label = "Observable";
            this.button_AddObservableTask.Name = "button_AddObservableTask";
            this.button_AddObservableTask.OfficeImageId = "DrawFilledRectangle";
            this.button_AddObservableTask.ScreenTip = "Add Observable Task Shape";
            this.button_AddObservableTask.ShowImage = true;
            this.button_AddObservableTask.SuperTip = "Add Observable Task Shape";
            this.button_AddObservableTask.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_AddObservableTask_Click);
            // 
            // button_AddCtaConnector
            // 
            this.button_AddCtaConnector.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_AddCtaConnector.Image = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Resources.conn_no_arrow;
            this.button_AddCtaConnector.Label = "Connector";
            this.button_AddCtaConnector.Name = "button_AddCtaConnector";
            this.button_AddCtaConnector.ShowImage = true;
            this.button_AddCtaConnector.SuperTip = "Add Connector Shape";
            this.button_AddCtaConnector.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_AddCtaConnector_Click);
            // 
            // button_Help
            // 
            this.button_Help.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.button_Help.Label = "Help";
            this.button_Help.Name = "button_Help";
            this.button_Help.OfficeImageId = "Help";
            this.button_Help.ShowImage = true;
            this.button_Help.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.button_Help_Click);
            // 
            // CtaRibbon
            // 
            this.Name = "CtaRibbon";
            this.RibbonType = "Microsoft.Visio.Drawing";
            this.Tabs.Add(this.tab2);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.CtaRibbon_Load);
            this.tab2.ResumeLayout(false);
            this.tab2.PerformLayout();
            this.groupCta.ResumeLayout(false);
            this.groupCta.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab2;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup groupCta;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_showTaskForm;
        internal Microsoft.Office.Tools.Ribbon.RibbonMenu menu_TodoFunctions;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_checkExcelFile;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_highlightDuplicates;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_highlightDisconnections;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_ViewCurrentDataFile;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportFlowOrder_Obs;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportFlowOrder;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportFlowOrder_Cog;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportUnused_Obs;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportUnused_Cog;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_refreshProgressBars;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_deleteAllHighlights;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_separator01;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_separator02;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_separator03;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_AddCtaConnector;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_AddCognitiveTask;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_AddObservableTask;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_highlightAllIssues;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_separator04;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_updateCategoriesAndConnColors;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_viewCurrentData;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_SaveToExcel;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_separator05;
        internal Microsoft.Office.Tools.Ribbon.RibbonMenu menu_DataGraphics;

        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_MentalDemand;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_PhysicalDemand;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_TemporalDemand;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_Performance;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_Effort;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Cog_Frustration;

        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Obs_Importance;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Obs_Difficulty;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Obs_Duration;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Obs_Frequency;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_Obs_Complexity;


        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual04;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual03;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual02;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual01;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_clearDataGraphics;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_NewCtaDiagram;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisual_AllItemsRated;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_applyVisualAverageRating;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator2;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator3;
        internal Microsoft.Office.Tools.Ribbon.RibbonSeparator separator4;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_Help;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_dropMany;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_reportUnusedTasks;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_gotoConfigPage;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_refreshShapesFromData;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button_ClearAllRatingsOnPage;
    }

    partial class ThisRibbonCollection
    {
        internal CtaRibbon CtaRibbon
        {
            get { return this.GetRibbon<CtaRibbon>(); }
        }
    }
}
