﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace SnlWpf
{
    /// <summary>
    /// Interaction logic for RatingsSlider.xaml
    /// </summary>
    public partial class RatingsSliderControl : UserControl
    {

        public string RatingValueText
        {
            get { return (string)this.GetValue(RatingValueTextProperty); }
            set { this.SetValue(RatingValueTextProperty, value); }
        }
        public static readonly DependencyProperty RatingValueTextProperty =
              DependencyProperty.Register("RatingValueText",
              typeof(string), typeof(RatingsSliderControl),
              new PropertyMetadata(null, RatingValueTextChanged, RatingValueTextCoerce)
              );

        private static bool _bUpdatingValuesFromText = false;

        static void RatingValueTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var inst = (RatingsSliderControl)d;

            _bUpdatingValuesFromText = true;

            string sVal = (string)e.NewValue;
            if (String.IsNullOrEmpty(sVal))
            {
                if(inst.RatingValue != null)
                    inst.SetValue(RatingValueProperty, null);
                if (inst.IsNotApplicable != null)
                    inst.SetValue(IsNotApplicableProperty, null);

                _updateIsNotSet(inst, null, null);
            }
            else
            {                
                double dVal;
                if (Double.TryParse(sVal, out dVal))
                {
                    if(inst.RatingValue != dVal)
                        inst.SetValue(RatingValueProperty, dVal);
                    if(inst.IsNotApplicable != false)
                        inst.SetValue(IsNotApplicableProperty, false);

                    _updateIsNotSet(inst, dVal, false);
                }
                else
                {
                    // Not number and not null = N/A!
                    if(inst.RatingValue != null)
                        inst.SetValue(RatingValueProperty, null);
                    if(inst.IsNotApplicable != true)
                        inst.SetValue(IsNotApplicableProperty, true);

                    _updateIsNotSet(inst, null, true);
                }
            }
            
            _bUpdatingValuesFromText = false;

            // Determine if the text is a number or N/A or NA.
            // If it's a number, the set the RatingValue, if it's
            // N/A, set IsNotSet...blah blah

            // We want to set to IsNotSetProperty to false
            // if both RatingsValue and IsNotApplicable
            // are null.
            //var inst = (RatingsSliderControl)d;
            //_updateIsNotSet(inst, (double?)e.NewValue, inst.IsNotApplicable);
        }
        private static object RatingValueTextCoerce(DependencyObject d, object baseValue)
        {
            return baseValue; 

            // Null is ok, return it:
            //if (baseValue == null) return null;

            //// Otherwise box the RatingValue between the min and max:
            //var inst = (RatingsSliderControl)d;
            //double min, max, val;
            //min = inst.MinimumValue;
            //max = inst.MaximumValue;
            //val = (double)baseValue;
            //val = Math.Min(max, Math.Max(min, val));

            //return val;
        }




        [Description("Is Not Set."),
         Category("User Control Properties")]
        public bool IsNotSet
        {
            get { return (bool)this.GetValue(IsNotSetProperty); }
            //set { this.SetValue(IsNotSetProperty, value); }
        }
        public static readonly DependencyProperty IsNotSetProperty =
              DependencyProperty.Register("IsNotSet",
              typeof(bool), typeof(RatingsSliderControl), 
              new PropertyMetadata(true)
              );

        private static void _updateIsNotSet(
                RatingsSliderControl inst, double? RatingValue, bool? IsNAValue)
        {
            // This proc is called from RatingValueChanged and 
            // IsNotApplicableChanged procedurs.
               
            // We want to set to IsNotSetProperty to false
            // if both RatingsValue and IsNotApplicable
            // are null.

            bool bIsNotSet_New = (RatingValue == null) &&
                                (IsNAValue == null);

            bool bIsNotSet_Curr = (bool)inst.GetValue(IsNotSetProperty);
            if (bIsNotSet_Curr != bIsNotSet_New)
                inst.SetValue(IsNotSetProperty, bIsNotSet_New);
        }

        [Description("The slider's value, clipped to whole-number values."),
         Category("User Control Properties")]
        public double? RatingValue
        {
            get
            {             
                return (double?)this.GetValue(RatingValueProperty);
            }
            set
            {
                this.SetValue(RatingValueProperty, value);
            }
        }
        public static readonly DependencyProperty RatingValueProperty =
            DependencyProperty.Register("RatingValue",
            typeof(double?),
            typeof(RatingsSliderControl),
            new PropertyMetadata(null, RatingValueChanged, RatingValueCoerce)
            );

        static void RatingValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (_bUpdatingValuesFromText) return;

            // We want to set to IsNotSetProperty to false
            // if both RatingsValue and IsNotApplicable
            // are null.
            var inst = (RatingsSliderControl)d;
            _updateIsNotSet(inst, (double?)e.NewValue, inst.IsNotApplicable);

            double? val = inst.RatingValue;
            if(val != null)
                inst.SetValue(RatingValueTextProperty, val.ToString());
        }
        private static object RatingValueCoerce(DependencyObject d, object baseValue)
        {
            // Null is ok, return it:
            if (baseValue == null) return null;

            // Otherwise box the RatingValue between the min and max:
            var inst = (RatingsSliderControl)d;
            double min, max, val;
            min = inst.MinimumValue;
            max = inst.MaximumValue;
            val = (double)baseValue;
            val = Math.Min(max, Math.Max(min, val));
            
            return val;
        }

        [Description("Is Not Applicable."),
         Category("User Control Properties")]
        public bool? IsNotApplicable
        {
            get { return (bool?)this.GetValue(IsNotApplicableProperty); }
            set { this.SetValue(IsNotApplicableProperty, value); }
        }
        public static readonly DependencyProperty IsNotApplicableProperty =
              DependencyProperty.Register("IsNotApplicable",
              typeof(bool?), typeof(RatingsSliderControl),
              new PropertyMetadata(null, IsNotApplicableChanged, IsNotApplicableCoerce)
              );

        static void IsNotApplicableChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (_bUpdatingValuesFromText) return;

            bool? valNew = (bool?)e.NewValue;

            // Update this.IsNotSet so the background color changes:
            var inst = (RatingsSliderControl)d;
            _updateIsNotSet(inst, inst.RatingValue, valNew);

            // Update the text value so that the check box 
            // and/or ratings value change:
            if(valNew == null)
            {
                if( ! String.IsNullOrEmpty(inst.RatingValueText) )
                    inst.SetValue(RatingValueTextProperty, String.Empty);
            }
            else if(valNew == false)
            {
                if (inst.RatingValueText != "-1")
                    inst.SetValue(RatingValueTextProperty, "-1");
            }
            else
            {
                if(inst.RatingValueText != "N/A")
                    inst.SetValue(RatingValueTextProperty, "N/A");
            }
            //bool? val = inst.IsNotApplicable;
            //if (val != null)           
            //    inst.SetValue(RatingValueTextProperty, "N/A");

            //var inst = (RatingsSliderControl)d;
            //_updateIsNotSet(inst, (double?)e.NewValue, inst.IsNotApplicable);

            //double? val = inst.RatingValue;
            //if (val != null)
            //    inst.SetValue(RatingValueTextProperty, val.ToString());
        }
        private static object IsNotApplicableCoerce(DependencyObject d, object baseValue)
        {
            // We want to reverse the logic of a tri-state
            // CheckBox by taking the first click from null
            // and returning true instead of false. Also, if
            // the user clicks the slider first, then NA needs
            // to go to false.

            bool? val = (bool?)baseValue;
            var inst = (RatingsSliderControl)d;
            if(inst.IsNotApplicable == null &&
               inst.RatingValue == null)
            {
                return true;
            }
            return baseValue;
        }




        [Description("Minimum Value."),
         Category("User Control Properties")]
        public double MinimumValue
        {
            get { return (double)this.GetValue(MinimumValueProperty); }
            set { this.SetValue(MinimumValueProperty, value); }
        }
        public static readonly DependencyProperty MinimumValueProperty =
              DependencyProperty.Register("MinimumValue",
              typeof(double), typeof(RatingsSliderControl),
              new PropertyMetadata(0.0));

        [Description("Maximum Value."),
         Category("User Control Properties")]
        public double MaximumValue
        {
            get { return (double)this.GetValue(MaximumValueProperty); }
            set { this.SetValue(MaximumValueProperty, value); }
        }
        public static readonly DependencyProperty MaximumValueProperty =
              DependencyProperty.Register("MaximumValue",
              typeof(double), typeof(RatingsSliderControl),
              new PropertyMetadata(10.0));

        [Description("Maximum Value."),
         Category("User Control Properties")]
        public double TickFrequency
        {
            get { return (double)this.GetValue(TickFrequencyProperty); }
            set { this.SetValue(TickFrequencyProperty, value); }
        }
        public static readonly DependencyProperty TickFrequencyProperty =
              DependencyProperty.Register("TickFrequency",
              typeof(double), typeof(RatingsSliderControl),
              new PropertyMetadata(1.0));



        [Description("The task name."), 
         Category("User Control Properties")]
        public string TaskName
        {
            get { return (string)this.GetValue(TaskNameProperty); }
            set { this.SetValue(TaskNameProperty, value); }
        }
        public static readonly DependencyProperty TaskNameProperty =
              DependencyProperty.Register("TaskName",
              typeof(string), typeof(RatingsSliderControl),
              new PropertyMetadata((string)"Task Name"));

        [Description("The task description."),
         Category("User Control Properties")]
        public string TaskDescription
        {
            get { return (string)this.GetValue(TaskDescriptionProperty); }
            set { this.SetValue(TaskDescriptionProperty, value); }
        }
        public static readonly DependencyProperty TaskDescriptionProperty =
              DependencyProperty.Register("TaskDescription",
              typeof(string), typeof(RatingsSliderControl),
              new PropertyMetadata((string)"Task Description"));

        [Description("The task label for the low-value end of the scale."),
         Category("User Control Properties")]
        public string TaskLowValueLabel
        {
            get { return (string)this.GetValue(TaskLowValueLabelProperty); }
            set { this.SetValue(TaskLowValueLabelProperty, value); }
        }
        public static readonly DependencyProperty TaskLowValueLabelProperty =
              DependencyProperty.Register("TaskLowValueLabel",
              typeof(string), typeof(RatingsSliderControl),
              new PropertyMetadata((string)"Low Value"));

        [Description("The task label for the high-value end of the scale."),
         Category("User Control Properties")]
        public string TaskHighValueLabel
        {
            get { return (string)this.GetValue(TaskHighValueLabelProperty); }
            set { this.SetValue(TaskHighValueLabelProperty, value); }
        }
        public static readonly DependencyProperty TaskHighValueLabelProperty =
              DependencyProperty.Register("TaskHighValueLabel",
              typeof(string), typeof(RatingsSliderControl),
              new PropertyMetadata((string)"High Value"));




        public RatingsSliderControl()
        {
            InitializeComponent();
        }

        private void sliderTaskRating_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Debug.WriteLine("Rating changed: " + e.NewValue);

            // Uncheck N/A if it is checked!
            //if (CheckBox_NA.IsChecked == true)
            CheckBox_NA.IsChecked = false;
        }

        // TODO: also, some sort of yellow styling for
        // unrated tasks. That means nothing's been set,
        // which means we probably need a nullable value
        // for the rating as well as for N/A.

        // TODO: there should probably be some sort of data-binding
        // for setting the opacities, since we've got to worry about
        // initial values as well.
        private void CheckBox_NA_Checked(object sender, RoutedEventArgs e)
        {
            _setOpacitiesReCheckbox(0.25, 1.0);
        }
        private void CheckBox_NA_Unchecked(object sender, RoutedEventArgs e)
        {
            _setOpacitiesReCheckbox(1.0, 0.25);
        }

        private void userControl_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            //Debug.WriteLine("userControl_MouseDoubleClick");
            this.RatingValueText = "";
        }

        private void CheckBox_NA_Indeterminate(object sender, RoutedEventArgs e)
        {
            _setOpacitiesReCheckbox(1.0, 0.25);
        }

        private void _setOpacitiesReCheckbox(
            double opTextBoxes, double opCheckBox)
        {
            // It was easier to do this in code than to use
            // some sort of data-binding in the XAML, because
            // we are cherry-picking three text boxes and a slider:
            if(tbRatingValue != null ) tbRatingValue.Opacity = opTextBoxes;
            if (tbHighRatingName != null) tbHighRatingName.Opacity = opTextBoxes;
            if (tbLowRatingName != null) tbLowRatingName.Opacity = opTextBoxes;
            if (sliderTaskRating != null) sliderTaskRating.Opacity = opTextBoxes;
            if (CheckBox_NA != null) CheckBox_NA.Opacity = opCheckBox;
        }
    }
}
