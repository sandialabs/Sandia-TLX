﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnlWpf
{

    // We could probably just create one big bag of
    // cog and obs properties, then only write the 
    // ones that matter back to the shape...

    class TaskData
    {
    }

    public class CognitiveData : INotifyPropertyChanged
    {
        //if(_dcCog == null)
        //{
        //    _dcCog = new object[2];
        //    _dcCog[0] = new { MentalDemand = "50", PhysicalDemand = "N/A", TemporalDemand = "10", Performance = "90", Effort = "", Frustration = "-1000" };
        //    _dcCog[1] = new { MentalDemand = "", PhysicalDemand = "", TemporalDemand = "", Performance = "", Effort = "", Frustration = "" };
        //}

        // Boiler-plate - could even be in a base class
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
        protected bool SetField<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }


        //MentalDemand = "50", PhysicalDemand = "N/A", TemporalDemand = "10", Performance = "90", Effort = "", Frustration = "-1000"
        private string _mentalDemand = String.Empty;
        public string MentalDemand
        {
            get { return _mentalDemand; }
            set { SetField(ref _mentalDemand, value, "MentalDemand"); }
        }

        private string _physicalDemand = String.Empty;
        public string PhysicalDemand
        {
            get { return _physicalDemand; }
            set { SetField(ref _physicalDemand, value, "PhysicalDemand"); }
        }

        private string _temporalDemand = String.Empty;
        public string TemporalDemand
        {
            get { return _temporalDemand; }
            set { SetField(ref _temporalDemand, value, "TemporalDemand"); }
        }

        private string _performance = String.Empty;
        public string Performance
        {
            get { return _performance; }
            set { SetField(ref _performance, value, "Performance"); }
        }

        // Effort
        private string _effort = String.Empty;
        public string Effort
        {
            get { return _effort; }
            set { SetField(ref _effort, value, "Effort"); }
        }

        // Frustration
        private string _frustration = String.Empty;
        public string Frustration
        {
            get { return _frustration; }
            set { SetField(ref _frustration, value, "Frustration"); }
        }

        // Interface stuff:
        //public string ID { get; set; }
        //public string Category { get; set; }

        // Note: using INotifyPropertyChanged allows the binding of
        // LisView items to collapse and expand based on various 
        // criteria.
        //private bool _isSearchMatch = true;
        //public bool IsSearchMatch
        //{
        //    get { return _isSearchMatch; }
        //    set { SetField(ref _isSearchMatch, value, "IsSearchMatch"); }
        //}

        public CognitiveData()
        {
        }



        //public bool IsAnyMatch(string searchText)
        //{
        //    if (_containsCaseInsensitive(this.ID, searchText)) return true;
        //    return false;
        //}

        //private bool _containsCaseInsensitive(string containerText, string searchText)
        //{
        //    return (containerText.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
        //}

    }
}
