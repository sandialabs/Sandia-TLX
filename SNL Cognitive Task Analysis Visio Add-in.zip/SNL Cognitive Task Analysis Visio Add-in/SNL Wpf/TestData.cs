﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnlWpf.TestData 
{
    //class TestData
    //{
    //}
    //ObservableCollection
    public class TestNumberDescItems : List<TestNumberDescItem>
    {
        public string TaskType { get; set; }

        public TestNumberDescItems()
        {
            // public enum TaskTypes { Other, CognitiveTask, ObservableTask }
            //this.TaskType = "CognitiveTask";
            this.TaskType = "ObservableTask";

            for (int i = 0; i < 8; i++)
            {
                string index = (i+1).ToString("00");
                this.Add(new TestNumberDescItem() {
                    Number = index,
                    Description = this.TaskType + " " + index
                });
            }
        }
    }
    public class TestNumberDescItem
    {
        public string Number { get; set; }
        public string Description { get; set; }
        //public ICommand CancelCommand { get; private set; }
        public TestNumberDescItem()
        {
            //this.Percentage = 60;
            //this.Message = "Computation progress";
            //this.CancelCommand = null;
        }
    }
    //public class ProgressReportSample1
    //{
    //    public int Percentage { get; private set; }
    //    public string Message { get; private set; }
    //    public ICommand CancelCommand { get; private set; }
    //    public ProgressReportSample1()
    //    {
    //        this.Percentage = 60;
    //        this.Message = "Computation progress";
    //        this.CancelCommand = null;
    //    }
    //}
}
