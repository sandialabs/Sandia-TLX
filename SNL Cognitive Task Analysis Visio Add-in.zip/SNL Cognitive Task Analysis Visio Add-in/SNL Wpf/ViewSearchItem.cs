﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnlWpf
{
    public class ViewSearchItem : INotifyPropertyChanged 
    {
        // Boiler-plate - could even be in a base class
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
        protected bool SetField<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        // Interface stuff:
        public string ID { get; set; }
        public string Category { get; set; }


        // Note: using INotifyPropertyChanged allows the binding of
        // LisView items to collapse and expand based on various 
        // criteria.
        private bool _isSearchMatch = true;
        public bool IsSearchMatch
        {
            get { return _isSearchMatch; }
            set { SetField(ref _isSearchMatch, value, "IsSearchMatch"); }
        }

        public ViewSearchItem(string id, string category)
        {
            this.ID = id;
            this.Category = category;
        }

        #region Search/Match Code


        // TODO: maybe handle OR or AND using commas?
        public bool IsAnyMatch(string searchText)
        {
            if (_containsCaseInsensitive(this.ID, searchText)) return true;
            return false;
        }

        private bool _containsCaseInsensitive(string containerText, string searchText)
        {
            return (containerText.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);
        }
        #endregion

    }
}
