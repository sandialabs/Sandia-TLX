﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Effects;

namespace SnlWpf
{
    /// <summary>
    /// Interaction logic for TliControl.xaml
    /// </summary>
    public partial class TliControl : UserControl //UserControl or Window
    {
        // Events to send to the outside world:
        //public event EventHandler CognitiveTask_Click =  null;
        //public event EventHandler ObservableTask_Click = null;
        //public event EventHandler Connector_Click = null;
        //public event EventHandler ChangeTaskItem_Click = null;

        //public string Caption { get; set; }

        public string Caption2
        {
            get
            {
                return (String)this.GetValue(CaptionProperty);
            }
            set
            {
                this.SetValue(CaptionProperty, value);
            }
        }
        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption2",
            typeof(string),
            typeof(TliControl));



        //public ViewSearchItem SelectedSearchItem
        //{
        //    get
        //    {
        //        return (ViewSearchItem)this.GetValue(SelectedSearchItemProperty);
        //    }
        //    set
        //    {
        //        this.SetValue(SelectedSearchItemProperty, value);
        //    }
        //}
        //public static readonly DependencyProperty SelectedSearchItemProperty =
        //    DependencyProperty.Register("SelectedSearchItem",
        //    typeof(ViewSearchItem),
        //    typeof(TliControl));

        public CognitiveData _dcCog = null;

        public TliControl()
        {
            InitializeComponent();

            _dcCog = new CognitiveData();
            this.DataContext = _dcCog;           
        }

        private void Button_ClearRatings_Cog_Click(object sender, RoutedEventArgs e)
        {
            // Set all "value text" to nothing to null-out the control:
            this.rsCog_Effort.RatingValueText = String.Empty;
            this.rsCog_Frustration.RatingValueText = String.Empty;
            this.rsCog_MentalDemand.RatingValueText = String.Empty;
            this.rsCog_Performance.RatingValueText = String.Empty;
            this.rsCog_PhysicalDemand.RatingValueText = String.Empty;
            this.rsCog_TemporalDemand.RatingValueText = String.Empty;
            this.rsCog_Enjoyment.RatingValueText = String.Empty;
        }

        private void Button_AllRatingsNa_Cog_Click(object sender, RoutedEventArgs e)
        {
            // Set all IsNotApplicable values to true:
            this.rsCog_Effort.IsNotApplicable = true;
            this.rsCog_Frustration.IsNotApplicable = true;
            this.rsCog_MentalDemand.IsNotApplicable = true;
            this.rsCog_Performance.IsNotApplicable = true;
            this.rsCog_PhysicalDemand.IsNotApplicable = true;
            this.rsCog_TemporalDemand.IsNotApplicable = true;
            this.rsCog_Enjoyment.IsNotApplicable = true;
        }

        private void Button_ClearRatings_Obs_Click(object sender, RoutedEventArgs e)
        {
            this.rsObs_Complexity.RatingValueText = String.Empty;
            this.rsObs_Difficulty.RatingValueText = String.Empty;
            this.rsObs_Duration.RatingValueText = String.Empty;
            this.rsObs_Frequency.RatingValueText = String.Empty;
            this.rsObs_Importance.RatingValueText = String.Empty;
            this.rsObs_Enjoyment.RatingValueText = String.Empty;
        }

        private void Button_AllRatingsNa_Obs_Click(object sender, RoutedEventArgs e)
        {
            this.rsObs_Complexity.IsNotApplicable = true;
            this.rsObs_Difficulty.IsNotApplicable = true;
            this.rsObs_Duration.IsNotApplicable = true;
            this.rsObs_Frequency.IsNotApplicable = true;
            this.rsObs_Importance.IsNotApplicable = true;
            this.rsObs_Enjoyment.IsNotApplicable = true;
        }


        // HACK
        // We need to change the caption of the Visio panel when 
        // the selection is changed. There's probably a nice WPF way
        // to do this, but I can't figure it out.
        //
        // SO, we'll trap the tab control's selection changed event,
        // build a new caption, then raise an event. The UI.PanelForm
        // will catch this event, and raise another similar event that the
        // DockedWindowManager/PanelFrame can then use to tell the Visio
        // docked window that encases the whole shebang that it's 
        // caption should update.
        public event CaptionChangedEventHandler CaptionChanged = null;
        public delegate void CaptionChangedEventHandler(object sender, string caption);
        private void tabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Note: these strings are solution-specific, and really shouldn't
            // be in this class.
            TabControl tc = e.Source as TabControl;
            if (tc == null) return;
            if(this.TabItem_CognitiveTask.IsSelected)
            {
                CaptionChanged(this, "TLX Ratings");
            }
            else if (this.TabItem_ObservableTask.IsSelected)
            {
                CaptionChanged(this, "Factor Ratings");
            }
            else
            {
                CaptionChanged(this, "Select a Task");
            }
        }


        //private void TextBox_Search_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    string searchText = TextBox_Search.Text;

        //    foreach(var itm in _vsisCognitiveIds)
        //    {
        //        itm.IsSearchMatch = itm.IsAnyMatch(searchText);
        //    }

        //    foreach (var itm in _vsisObservableIds)
        //    {
        //        itm.IsSearchMatch = itm.IsAnyMatch(searchText);
        //    }
        //}

        //private void buttonAddConnector_Click(object sender, RoutedEventArgs e)
        //{
        //    if (this.Connector_Click != null)
        //        Connector_Click(sender, e);
        //}
        //private void buttonAddCognitiveTask_Click(object sender, RoutedEventArgs e)
        //{
        //    if (this.CognitiveTask_Click != null)
        //        CognitiveTask_Click(sender, e);            
        //}        
        //private void buttonAddObservableTask_Click(object sender, RoutedEventArgs e)
        //{
        //    if (this.ObservableTask_Click != null)
        //        ObservableTask_Click(sender, e);
        //}

    }

}
