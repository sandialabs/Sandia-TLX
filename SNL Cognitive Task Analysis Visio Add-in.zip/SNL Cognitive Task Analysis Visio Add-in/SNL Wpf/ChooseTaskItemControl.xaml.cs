﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SnlWpf
{
    /// <summary>
    /// Interaction logic for ChooseNumberDescForm.xaml
    /// </summary>
    public partial class ChooseTaskItemControl : UserControl
    {
        public event EventHandler OnButtonCancel_Click = null;
        public event EventHandler OnButtonOk_Click = null;
        //public event EventHandler Connector_Click = null;
        //public event EventHandler ChangeTaskItem_Click = null;

        public string Description { get; private set; }
        public string Number { get; private set; }

        public ChooseTaskItemControl()
        {
            InitializeComponent();
        }

        private void ListView_TaskItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var o = ListView_TaskItems.SelectedItem;
            if (o == null)
            {
                this.Number = String.Empty;
                this.Description = String.Empty;
                this.TextBox_SelectedDescription.Text = String.Empty;
                return;
            }

            try
            {
                string s = o.GetType().GetProperty("Description").GetValue(o).ToString();
                this.TextBox_SelectedDescription.Text = s;
            }
            catch (Exception)
            {
                this.Number = String.Empty;
                this.Description = String.Empty;
                this.TextBox_SelectedDescription.Text = String.Empty;
            }
           
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e)
        {
            this.Description = this.TextBox_SelectedDescription.Text;

            if (this.OnButtonOk_Click != null)
                OnButtonOk_Click(sender, e);
        }

        private void Button_Cancel_Click(object sender, RoutedEventArgs e)
        {
            if (this.OnButtonCancel_Click != null)
                OnButtonCancel_Click(sender, e);
        }
    }
}
