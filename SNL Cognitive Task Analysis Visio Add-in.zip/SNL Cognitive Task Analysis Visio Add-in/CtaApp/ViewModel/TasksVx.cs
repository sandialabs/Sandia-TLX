﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    // Note: the "Vx" suffix is supposed to stand for Visio
    // and Excel. When the add-in is running, these two data
    // reservoirs have to be used in concert, on top of the
    // pure data of CognitiveTask and ObservableTask objects. 

    // A List/Collection would be nice...should it be a List or
    // a Dictionary...we could maintain a list of duplicate shape ids
    // and Excel ids or something...

    //public class TasksVx // Collections of CogVx and TaskVx objects
    //{
    //    private List<CogTaskVx> _cogTasks = null;
    //    private List<ObsTaskVx> _obsTasks = null;

    //    public List<CogTaskVx> CognitiveTasksVx { get { return _cogTasks; } }
    //    public List<ObsTaskVx> ObservableTasksVx { get { return _obsTasks; } }

    //    public int CognitiveCount { get { return _cogTasks.Count; } }
    //    public int ObservableCount { get { return _obsTasks.Count; } }
    //    public int TotalCount { get { return this.CognitiveCount + this.ObservableCount; } }
    //    public TasksVx()
    //    {
    //        _cogTasks = new List<CogTaskVx>();
    //        _obsTasks = new List<ObsTaskVx>();
    //    }
    //    public List<string> Categories_Cog_Unique_Sorted
    //    {
    //        get
    //        {
    //            var list = _cogTasks.Select(t => t.Category).Distinct().ToList<string>();
    //            list.Sort();
    //            return list;
    //        }
    //    }
    //    public List<string> Categories_Obs_Unique_Sorted
    //    {
    //        get
    //        {
    //            var list = _obsTasks.Select(t => t.Category).Distinct().ToList<string>();
    //            list.Sort();
    //            return list;
    //        }
    //    }
    //    public List<string> Descriptions_Cog_Unique_Sorted(bool includeInVisioItems)
    //    {
    //        var list = _cogTasks.FindAll(t => (t.IsInVisio == includeInVisioItems))
    //            .Select(t => t.Description).Distinct().ToList<string>();
    //        list.Sort();
    //        return list;
    //    }
    //    public List<string> Descriptions_Obs_Unique_Sorted(bool includeInVisioItems)
    //    {
    //        var list = _obsTasks.FindAll(t => (t.IsInVisio == includeInVisioItems))
    //            .Select(t => t.Description).Distinct().ToList<string>();
    //        list.Sort();
    //        return list;
    //    }
    //    public void Add(CogTaskVx item)
    //    {
    //        _cogTasks.Add(item);
    //        if (item.IsInVisio)
    //        {

    //        }
    //        else
    //        {

    //        }
    //    }
    //    public void Add(ObsTaskVx item)
    //    {
    //        _obsTasks.Add(item);
    //        if (item.IsInVisio)
    //        {

    //        }
    //        else
    //        {

    //        }
    //    }

    //    public void DebugDump()
    //    {
    //        Debug.WriteLine("----- Cognitive Tasks --------------------");
    //        foreach (var c in _cogTasks)
    //            Debug.WriteLine(c.ToString());
    //        Debug.WriteLine("----- Observable Tasks -------------------");
    //        foreach (var o in _obsTasks)
    //            Debug.WriteLine(o.ToString());
    //    }


    //    public CogTaskVx FirstCogByDescOrNull(string desc)
    //    {
    //        return _cogTasks.FirstOrDefault(t => String.Compare(t.Description, desc, true) == 0);
    //    }
    //    public ObsTaskVx FirstObsByDescOrNull(string desc)
    //    {
    //        return _obsTasks.FirstOrDefault(t => String.Compare(t.Description, desc, true) == 0);
    //    }

    //    // Get the new data:
    //    // TODO: create "Add" methods in TasksVx AddExcelTask...

    //    public void AddTask_FromExcel(object task)
    //    {
    //        // If a task already exists, just set the IsInExcel bit, otherwise add it...
    //        Type typ = task.GetType();
    //        if (typ == typeof(CogTaskVx))
    //        {
    //            CogTaskVx t = task as CogTaskVx;
    //            string desc = t.Description;
    //            if (String.IsNullOrEmpty(desc)) return;

    //            var matches = _cogTasks.TakeWhile(c => (String.Compare(desc, c.Description, true) == 0));
    //            if (matches.Count() > 0)
    //            {
    //                foreach (var m in matches) m.IsInExcel = true;
    //            }
    //            else
    //            {
    //                _cogTasks.Add(t);
    //            }
    //        }
    //        else if (typ == typeof(ObsTaskVx))
    //        {
    //            ObsTaskVx t = task as ObsTaskVx;
    //            string desc = t.Description;
    //            if (String.IsNullOrEmpty(desc)) return;

    //            var matches = _obsTasks.TakeWhile(o => (String.Compare(desc, o.Description, true) == 0));
    //            if (matches.Count() > 0)
    //            {
    //                foreach (var m in matches) m.IsInExcel = true;
    //            }
    //            else
    //            {
    //                _obsTasks.Add(t);
    //            }
    //        }
    //    }

    //    public void AddTask_FromVisio(object task)
    //    {
    //        // If a task already exists, set the IsInVisio bit, and
    //        // overwrite the data with the Visio data

    //        // TODO Finish AddTask_FromVisio code below here:

    //        Type typ = task.GetType();
    //        if (typ == typeof(CogTaskVx))
    //        {
    //            CogTaskVx t = task as CogTaskVx;
    //            string desc = t.Description;
    //            if (String.IsNullOrEmpty(desc)) return;

    //            var matches = _cogTasks.TakeWhile(c => (String.Compare(desc, c.Description, true) == 0));
    //            if (matches.Count() > 0)
    //            {
    //                // TODO: Overwrite the Excel data with the Visio data...?
    //                // We won't overwrite Task Number, Description or...?
    //                foreach (var m in matches) m.IsInExcel = true;
    //            }
    //            else
    //            {
    //                // Simply add the task to the collection:
    //                _cogTasks.Add(t);
    //            }
    //        }
    //        else if (typ == typeof(ObsTaskVx))
    //        {
    //            ObsTaskVx t = task as ObsTaskVx;
    //            string desc = t.Description;
    //            if (String.IsNullOrEmpty(desc)) return;

    //            var matches = _obsTasks.TakeWhile(o => (String.Compare(desc, o.Description, true) == 0));
    //            if (matches.Count() > 0)
    //            {
    //                // TODO: Overwrite the Excel data with the Visio data...?
    //                foreach (var m in matches) m.IsInExcel = true;
    //            }
    //            else
    //            {
    //                // Simply add the task to the collection:
    //                _obsTasks.Add(t);
    //            }
    //        }
    //    }
    //}

    //public class CogVxCollection
    //{
    //    // Ideas: 
    //    // ContainsID, ContainsDesc, ContainsIdAndDesc, Contains_AbsoluteDuplicate
    //    // Allow for unnumbered/undesc'd tasks - allows for a count of TODOs
    //    // Get unique descriptions
    //    // Get unique Categories
    //}
    //public class ObsVxCollection
    //{

    //}
    //public interface ITaskVx
    //{
    //    // This needs multiple "falses"
    //    // Same id, different data
    //    // Same id, different name
    //    // Everything the same
    //    // false

    //    //bool Equals { get; }
    //    bool IsChanged { get; set; }
    //    bool IsNew { get; set; }
    //    bool IsRenamed { get; set; }
    //    bool IsInExcel { get; set; }
    //    bool IsInVisio { get; set; }

    //    //public object Shape or ShapeID or something IsRenamed { get; set; }
    //}

    //public class CogTaskVx : Data.CognitiveTask, ITaskVx
    //{
    //    //public bool Equals(CogTaskVx otherTask) { return true; }

    //    public bool IsChanged { get; set; }
    //    public bool IsNew { get; set; }
    //    public bool IsRenamed { get; set; }
    //    public bool IsInExcel { get; set; }
    //    public bool IsInVisio { get; set; }

    //    public override string ToString()
    //    {
    //        return this.TaskNumber + ": " + this.Description;
    //    }
    //}

    //public class ObsTaskVx : Data.ObservableTask
    //{
    //    public bool IsChanged { get; set; }
    //    public bool IsNew { get; set; }
    //    public bool IsRenamed { get; set; }
    //    public bool IsInExcel { get; set; }
    //    public bool IsInVisio { get; set; }

    //    public override string ToString()
    //    {
    //        return this.TaskNumber + ": " + this.Description;
    //    }
    //}
}
