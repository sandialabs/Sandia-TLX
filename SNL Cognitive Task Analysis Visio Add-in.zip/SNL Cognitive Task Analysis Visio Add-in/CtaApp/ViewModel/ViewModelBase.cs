﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    // Pasted from DJPs Validation Explorer
    /// <summary>
    /// Base class for all classes which act as data source for user interface elements.
    /// This class implements the INotifyPropertyChanged interface
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        #region Properties
        Dispatcher _modelDispatcher;
        /// <summary>
        /// A Dispatcher object associated with the current view model. This can be used to access the UI thread
        /// from other threads (using Dispatcher.Invoke or Dispatcher.BeginInvoke)
        /// </summary>
        public Dispatcher ModelDispatcher
        {
            get
            {
                return _modelDispatcher;
            }
            set
            {
                _modelDispatcher = value;
                OnPropertyChanged("ModelDispatcher");
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// Default constructor that initializes the Dispatcher depen
        /// </summary>
        public ViewModelBase()
        {
            if (System.Windows.Application.Current != null)
            {
                ModelDispatcher = System.Windows.Application.Current.Dispatcher;
            }
            else
            {
                ModelDispatcher = Dispatcher.CurrentDispatcher;
            }
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler eventHandlers = this.PropertyChanged;
            if (eventHandlers != null)
            {
                VerifyPropertyName(propertyName);
                HandlePropertyChanged(propertyName);
                eventHandlers(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        /// <summary>
        /// Called by OnPropertyChanged so that inheriting classes have a chance to do something when a 
        /// property changes
        /// </summary>
        /// <param name="propertyName">Property name</param>
        protected virtual void HandlePropertyChanged(string propertyName)
        { }

        /// <summary>
        /// Verifies the name of the property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        private void VerifyPropertyName(string propertyName)
        {
            if (TypeDescriptor.GetProperties(this)[propertyName] == null)
            {
                string msg = string.Format(CultureInfo.CurrentCulture, "Invalid property name : {0}", propertyName);
                throw new ArgumentOutOfRangeException("propertyName", msg);
            }
        }
        #endregion

        #region Events

        /// <summary>
        /// Occurs when [property changed].
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

    }

    //#region "INotifyPropertyChanged stuff"

    //public event PropertyChangedEventHandler PropertyChanged;

    //protected virtual void OnPropertyChanged(string propertyName)
    //{
    //    PropertyChangedEventHandler handler = PropertyChanged;
    //    if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
    //}
    //protected bool SetField<T>(ref T field, T value, string propertyName)
    //{
    //    if (EqualityComparer<T>.Default.Equals(field, value)) return false;
    //    field = value;
    //    OnPropertyChanged(propertyName);
    //    return true;
    //}
    //#endregion "INotifyPropertyChanged stuff"
}
