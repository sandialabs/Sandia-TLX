﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class VisioWriter
    {
        public static void UpdateTaskShapeFromData(
            View.Shape_Task taskShape, 
            Data.Task taskData, 
            bool setDescription)
        {
            var typdata = taskData.GetType();
            var typshp = taskShape.GetType();

            if (typshp == typeof(View.Shape_Cognitive) )
            {
                if (typdata != typeof(Data.CognitiveTask)) return;
                
                var shpCog = taskShape as View.Shape_Cognitive;
                var dataCog = taskData as Data.CognitiveTask;

                shpCog.Category = dataCog.Category;

                if (setDescription)
                    shpCog.Description = dataCog.Description;

                shpCog.Effort = dataCog.Effort;
                shpCog.Frustration = dataCog.Frustration;

                shpCog.MentalDemand = dataCog.MentalDemand;
                shpCog.Performance = dataCog.Performance;
                shpCog.PhysicalDemand = dataCog.PhysicalDemand;
                shpCog.TemporalDemand = dataCog.TemporalDemand;
                shpCog.Enjoyment = dataCog.Enjoyment;

                //shpCog.Set_Category_Container() dataCog.Category_Container;
                //shpCog.Set_Category_Layer() = dataCog.Category_Layer;
                //shpCog.TaskNumber = dataCog.TaskNumber;                
            }
            else if (typshp == typeof(View.Shape_Observable) )
            {
                if (typdata != typeof(Data.ObservableTask)) return;

                var shpObs = taskShape as View.Shape_Observable;
                var dataObs = taskData as Data.ObservableTask;

                shpObs.Category = dataObs.Category;
                shpObs.Complexity = dataObs.Complexity;

                if (setDescription)
                    shpObs.Description = dataObs.Description;

                shpObs.Difficulty = dataObs.Difficulty;
                shpObs.Duration = dataObs.Duration;
                shpObs.Frequency = dataObs.Frequency;
                shpObs.Importance = dataObs.Importance;
                shpObs.Enjoyment = dataObs.Enjoyment;
                //shpObs.TaskNumber = dataObs.TaskNumber;

                //shpObs.Set_Category_Container()
                //shpObs.Set_Category_Layer();

            }
        }
    }
}
