﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VALEX = Visguy.VisAddinLib.ExcelData;
//using Visguy.VisAddinLib.Extensions;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class ExcelWriter
    {
        public ExcelWriter() { }
        
        public void Write(string pathToExcelFile, Data.TaskSet taskset)
        {
            // TODO: we have to provide some way of providing an old-key/new-key
            // when doing the Update code...to handle key renames. Also, check
            // if a key is renamed to an existing name...

            var colsCogs = Data.CognitiveTask.ColumnNames_ForWrite();
            var ewdCogs = new VALEX.ExcelWriteData("Description", colsCogs);

            foreach(var t in taskset.CognitiveTasks)
            {
                var dict = _getCognitiveDict_OrNull((Data.CognitiveTask)t);

                if (t.IsInVisio && t.IsInExcel)
                {
                    // This is a (potentially) changed record:
                    
                    // TODO: handle any potential Description renames:
                    if( ! String.IsNullOrEmpty(t.OldDescription) &&
                        t.OldDescription != t.Description)
                    {
                        // TODO: handle any potential Description renames.
                    }

                    ewdCogs.AddDataRow_Update(dict);

                }
                else if(t.IsInVisio && ! t.IsInExcel)
                {
                    // This is a new record:
                    ewdCogs.AddDataRow_Insert(dict);
                }
                
            }

            var colsObs = Data.ObservableTask.ColumnNames_ForWrite();
            var ewdObs = new VALEX.ExcelWriteData("Description", colsObs);

            foreach (var t in taskset.ObservableTasks)
            {
                var dict = _getObservableDict_OrNull((Data.ObservableTask)t);

                if (t.IsInVisio && t.IsInExcel)
                {
                    // This is a (potentially) changed record:

                    // TODO: handle any potential Description renames:
                    if (!String.IsNullOrEmpty(t.OldDescription) &&
                        t.OldDescription != t.Description)
                    {
                        // TODO: handle any potential Description renames.
                    }

                    ewdObs.AddDataRow_Update(dict);

                }
                else if (t.IsInVisio && !t.IsInExcel)
                {
                    // This is a new record:
                    ewdObs.AddDataRow_Insert(dict);
                }

            }

            //var colsObs = Data.ObservableTask.ColumnNames_ForWrite();            
            //var dObs = new VALEX.ExcelWriteData("Description", colsObs);

            // TODO: try-catch...
            VALEX.ExcelData.WriteDataToExcel(pathToExcelFile, SolutionStrings.ExcelTableName_Cognitive, ewdCogs);
            VALEX.ExcelData.WriteDataToExcel(pathToExcelFile, SolutionStrings.ExcelTableName_Observable, ewdObs);

            //VALEX.ExcelData.WriteDataToExcel(pathToExcelFile, SolutionStrings.ExcelTableName_Observable, dObs);


            // TODO: ExcelWriter.Write....

            // Whoever calls this...
            //
            // TODO: about Description renames:
            // Shape_s will have an OldName property. If this is not empty, then
            // we will find Excel records by the old name, then update with the new name.
            //
            // After saving the latest data from the Excel + Visio mishmash, all shapes need to
            // have their "Old Name" property zeroed out.

            // Check Excel file
            // Build Updates for both task types
            //   Data.Task t; 
            //   t.IsRenamed t.OldDescription
            //   View.Shape_Task ts;
            //   ts.OldDescription
            // Build inserts for both task types
            // Write the data!

            // We use the VALEX namespace to define for each record/shape:
            // - A list of column names
            // - A list of column values
            // Then we create a List<List<string>> for the sets of column names and values
            // and pass that to VALEX.
            // TODO: make a more manageable object in VALEX
            // ExcelWriteSet
            //  .AddInsert( List<string> colNames, List<string> colValues )
            //  .AddUpdate( List<string> colNames, List<string> colValues )
            // Then
            // VALEX.Write(ExcelWriteSet newdata)...

            // Check each task for the 
            // Build inserts
            // We have no facility for delete
            //


        }

        private Dictionary<string,string> _getCognitiveDict_OrNull(Data.CognitiveTask task)
        {
            var dict = new Dictionary<string, string>();

            dict.Add(nameof(task.Description), task.Description);

            dict.Add(nameof(task.Category), task.Category);
            dict.Add(nameof(task.Category_Container), task.Category_Container);
            dict.Add(nameof(task.Category_Layer), task.Category_Layer);
            dict.Add(nameof(task.Category_NearestObservableTask), task.Category_NearestObservableTask);

            //dict.Add(nameof(task.Effort), _stringFromNullShort(task.Effort));
            //dict.Add(nameof(task.Frustration), task.Frustration.Value); // _stringFromNullShort(task.Frustration.Value));
            //dict.Add("Mental Demand", _stringFromNullShort(task.MentalDemand));
            //dict.Add(nameof(task.Performance), _stringFromNullShort(task.Performance));
            //dict.Add("Physical Demand", _stringFromNullShort(task.PhysicalDemand));
            //dict.Add("Temporal Demand", _stringFromNullShort(task.TemporalDemand));

            dict.Add(nameof(task.Effort), task.Effort.Value);
            dict.Add(nameof(task.Frustration), task.Frustration.Value); 
            dict.Add("Mental Demand", task.MentalDemand.Value);
            dict.Add(nameof(task.Performance), task.Performance.Value);
            dict.Add("Physical Demand", task.PhysicalDemand.Value);
            dict.Add("Temporal Demand", task.TemporalDemand.Value);
            dict.Add(nameof(task.Enjoyment), task.Enjoyment.Value);

            //string oldDesc = task.OldDescription;

            return dict;

            //dict.Add(nameof(task.OldDescription), _stringFromNullShort(task.Effort));

            //if (vshp.IsNoDescription) return null;

            ////_stringFromNullShort

            //var dataCog = new Data.CognitiveTask();

            //dataCog.Description = vshp.Description;
            //dataCog.OldDescription = vshp.OldDescription;

            //dataCog.Category = vshp.Category;
            //dataCog.Category_Container = vshp.Category_Container;
            //dataCog.Category_Layer = vshp.Category_Layer;
            //dataCog.Category_NearestObservableTask = vshp.Cat_NearestObservableTask;

            //dataCog.TaskNumber = vshp.TaskNumber;

            //dataCog.Effort = vshp.Effort;
            //dataCog.Frustration = vshp.Frustration;
            //dataCog.MentalDemand = vshp.MentalDemand;
            //dataCog.Performance = vshp.Performance;
            //dataCog.PhysicalDemand = vshp.PhysicalDemand;
            //dataCog.TemporalDemand = vshp.TemporalDemand;

            ////c.IsChanged = false;
            ////c.IsInExcel = true;
            //dataCog.IsInVisio = true;
            ////c.IsRenamed = false;

            //return dataCog;
        }
        private Dictionary<string, string> _getObservableDict_OrNull(Data.ObservableTask task)
        {
            var dict = new Dictionary<string, string>();

            dict.Add(nameof(task.Description), task.Description);
            //dict.Add(nameof(task.TaskNumber), _stringFromNullShort(task.TaskNumber));

            dict.Add(nameof(task.Category), task.Category);
            dict.Add(nameof(task.Category_Container), task.Category_Container);
            dict.Add(nameof(task.Category_Layer), task.Category_Layer);

            //dict.Add(nameof(task.Complexity), _stringFromNullShort(task.Complexity));
            //dict.Add(nameof(task.Difficulty), _stringFromNullShort(task.Difficulty));
            //dict.Add(nameof(task.Duration), _stringFromNullShort(task.Duration));
            //dict.Add(nameof(task.Frequency), _stringFromNullShort(task.Frequency));
            //dict.Add(nameof(task.Importance), _stringFromNullShort(task.Importance));

            dict.Add(nameof(task.Complexity), task.Complexity.Value);
            dict.Add(nameof(task.Difficulty), task.Difficulty.Value);
            dict.Add(nameof(task.Duration), task.Duration.Value);
            dict.Add(nameof(task.Frequency), task.Frequency.Value);
            dict.Add(nameof(task.Importance), task.Importance.Value);
            dict.Add(nameof(task.Enjoyment), task.Enjoyment.Value);

            //string oldDesc = task.OldDescription;

            return dict;
        }
        private string _stringFromNullShort(short? value)
        {
            if (value == null) return String.Empty;
            return value.ToString();
        }
        private void _sampleWriteCode()
        {

            string pathXl =
    @"C:\D\Source\Customer Projects\SNL\SNL Cognitive Task Analysis Visio Add-in\CtaApp\Content\Sample CTA Data-Test 1.xlsx";

            // Dump file exists, and full path:
            bool bFileExists = File.Exists(pathXl);
            Debug.WriteLine("Data file exists? ");

            // Temp: try the file on the Desktop:
            // No difference, still get the "Operation must use an updateable query." error...
            //pathXl = @"C:\Users\green\Desktop\Cognitive and Observable Tasks (500).xlsx";

            if (!bFileExists) return;
            Debug.WriteLine(pathXl);


            // Try to update multiple rows:
            //_updateMultipleRows(pathXl, "Cognitive Tasks$"); <-- this here sample code 

            string filepath = pathXl;
            string tablename = SolutionStrings.ExcelTableName_Cognitive; // "Cognitive Tasks$";
            //string tablename = SolutionStrings.ExcelTableName_Observable; // "Observable Tasks$";

            List<string> keys = new List<string>() { "Description", "Description", "Description" };
            List<string> keyVals = new List<string>() { "Cog Numba 3", "Cog Numba 4", "Cog Numba 5" };

            List<string> colNames1 = new List<string>() { "Category", "Category_Layer", "Physical Demand", "Effort" };
            List<string> colVals1 = new List<string>() { "Cat 3", "Update 3", "30", "30" };

            List<string> colNames2 = new List<string>() { "Category", "Category_Layer", "Physical Demand", "Effort" };
            List<string> colVals2 = new List<string>() { "Cat 4", "Update 4", "40", "40" };

            List<string> colNames3 = new List<string>() { "Category", "Category_Layer", "Physical Demand", "Effort" };
            List<string> colVals3 = new List<string>() { "Cat 5", "Update 5", "50", "60" };

            List<List<string>> colNameArrays = new List<List<string>>() { colNames1, colNames2, colNames3 };
            List<List<string>> colValArrays = new List<List<string>>() { colVals1, colVals2, colVals3 };

            bool success = VALEX.ExcelData.UpdateMultipleRows(filepath, tablename,
                keys, keyVals, colNameArrays, colValArrays);

            //VALEX.InsertRow() <-- TODO: InsertMultipleRows

            if (success == false)
            {
                Debug.WriteLine("An error occurred!");
                Debug.WriteLine(VALEX.ExcelData.LastError);
            }
        }

    }
}
