﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class InteractionViewModel : ViewModelBase
    {
        //private bool _isCognitiveTaskSelected = false;
        //public bool IsCognitiveTaskSelected
        //{
        //    get { return _isCognitiveTaskSelected; }
        //    set { SetField(ref _isCognitiveTaskSelected, value, "IsCognitiveTaskSelected"); }
        //}
        //private bool _isObservableTaskSelected = false;
        //public bool IsObservableTaskSelected
        //{
        //    get { return _isObservableTaskSelected; }
        //    set { SetField(ref _isObservableTaskSelected, value, "IsObservableTaskSelected"); }
        //}
        //private bool _isNoTaskSelected = false;
        //public bool IsNoTaskSelected
        //{
        //    get { return _isNoTaskSelected; }
        //    set { SetField(ref _isNoTaskSelected, value, "IsNoTaskSelected"); }
        //}


        //// Something about the Task ID and Text/Description?

        //#region "Cognitive Task Notifiable Properties"

        //private string _mentalDemand = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string MentalDemand
        //{
        //    get { return _mentalDemand; }
        //    set { SetField(ref _mentalDemand, value, "MentalDemand"); }
        //}

        //private string _physicalDemand = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string PhysicalDemand
        //{
        //    get { return _physicalDemand; }
        //    set { SetField(ref _physicalDemand, value, "PhysicalDemand"); }
        //}

        //private string _temporalDemand = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string TemporalDemand
        //{
        //    get { return _temporalDemand; }
        //    set { SetField(ref _temporalDemand, value, "TemporalDemand"); }
        //}

        //private string _performance = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string Performance
        //{
        //    get { return _performance; }
        //    set { SetField(ref _performance, value, "Performance"); }
        //}

        //// Effort
        //private string _effort = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string Effort
        //{
        //    get { return _effort; }
        //    set { SetField(ref _effort, value, "Effort"); }
        //}

        //// Frustration
        //private string _frustration = String.Empty;
        ///// <summary>
        ///// Cognitive, 1-100
        ///// </summary>
        //public string Frustration
        //{
        //    get { return _frustration; }
        //    set { SetField(ref _frustration, value, "Frustration"); }
        //}
        //#endregion

        //#region "Observable Task Notifiable Properties"

        //private string _importance = String.Empty;
        ///// <summary>
        ///// Observable, 1-5
        ///// </summary>
        //public string Importance
        //{
        //    get { return _importance; }
        //    set { SetField(ref _importance, value, "Importance"); }
        //}

        //private string _difficulty = String.Empty;
        ///// <summary>
        ///// Observable, 1-5
        ///// </summary>
        //public string Difficulty
        //{
        //    get { return _difficulty; }
        //    set { SetField(ref _difficulty, value, "Difficulty"); }
        //}

        //private string _duration = String.Empty;
        ///// <summary>
        ///// Observable, 1-5
        ///// </summary>
        //public string Duration
        //{
        //    get { return _duration; }
        //    set { SetField(ref _duration, value, "Duration"); }
        //}

        //private string _frequency = String.Empty;
        ///// <summary>
        ///// Observable, 1-5
        ///// </summary>
        //public string Frequency
        //{
        //    get { return _frequency; }
        //    set { SetField(ref _frequency, value, "Frequency"); }
        //}

        //// Effort
        //private string _complexity = String.Empty;
        ///// <summary>
        ///// Observable, 1-5
        ///// </summary>
        //public string Complexity
        //{
        //    get { return _complexity; }
        //    set { SetField(ref _complexity, value, "Complexity"); }
        //}

        //#endregion

    }
}
