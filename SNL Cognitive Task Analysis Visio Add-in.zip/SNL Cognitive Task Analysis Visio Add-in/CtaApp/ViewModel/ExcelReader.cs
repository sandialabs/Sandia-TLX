﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using ED = Visguy.VisAddinLib.ExcelData.ExcelData;
using System.Data;
using Visguy.VisAddinLib.Extensions;
using SSC = SNL_Cognitive_Task_Analysis_Visio_Add_in.SolutionStrings;
//using SNL_Cognitive_Task_Analysis_Visio_Add_in.Data;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class ExcelReader
    {
        public void CheckTablesAndColumns(string pathToExcelFile,
            out bool cogTableExists, out bool cogColumnsExist, out string missingCogColsCsv,
            out bool obsTableExists, out bool obsColumnsExist, out string missingObsColsCsv)
        {
            missingCogColsCsv = String.Empty;
            missingObsColsCsv = String.Empty;

            var tsandcs = ED.GetTableAndColumnNames(pathToExcelFile);

            cogTableExists = tsandcs.ContainsKey(SSC.ExcelTableName_Cognitive) ||
                             tsandcs.ContainsKey("'" + SSC.ExcelTableName_Cognitive + "'");
            obsTableExists = tsandcs.ContainsKey(SSC.ExcelTableName_Observable) ||
                             tsandcs.ContainsKey("'" + SSC.ExcelTableName_Observable + "'");


            List<string> colsCog, colsObs;

            if (cogTableExists)
            {
                colsCog = null;
                if (tsandcs.ContainsKey(SSC.ExcelTableName_Cognitive))
                {
                    colsCog = tsandcs[SSC.ExcelTableName_Cognitive];
                }
                else if (tsandcs.ContainsKey("'" + SSC.ExcelTableName_Cognitive + "'"))
                {
                    colsCog = tsandcs["'" + SSC.ExcelTableName_Cognitive + "'"];
                }

                if (colsCog == null)
                {
                    cogColumnsExist = false; // we shouldn't encounter this...
                }
                else
                {
                    var missingCogCols =
                        colsCog.MissingItemsFromCsvList_CaseInsensitive(SSC.ColumnNames_Cognitive);
                    cogColumnsExist = (missingCogCols.Count == 0);
                    if (cogColumnsExist == false)
                        missingCogColsCsv = String.Join(",", missingCogCols);
                }
            }
            else
            {
                cogColumnsExist = false;
            }

            if (obsTableExists)
            {
                colsObs = null;
                if (tsandcs.ContainsKey(SSC.ExcelTableName_Observable))
                {
                    colsObs = tsandcs[SSC.ExcelTableName_Observable];
                }
                else if (tsandcs.ContainsKey("'" + SSC.ExcelTableName_Observable + "'"))
                {
                    colsObs = tsandcs["'" + SSC.ExcelTableName_Observable + "'"];
                }

                if (colsObs == null)
                {
                    obsColumnsExist = false; // we shouldn't encounter this...
                }
                else
                {
                    var missingObsCols =
                        colsObs.MissingItemsFromCsvList_CaseInsensitive(SSC.ColumnNames_Observable);
                    obsColumnsExist = (missingObsCols.Count == 0);

                    if (obsColumnsExist == false)
                        missingObsColsCsv = String.Join(",", missingObsCols);
                }
            }
            else
            {
                obsColumnsExist = false;
            }

            // TODO: report the data counts for each table?

        }

        // TODO: get rid of this routine and use UpdateTasks...
        public void GetTasks(string pathToExcelFile,
            out List<Data.CognitiveTask> cogs, out List<Data.ObservableTask> obs)
        {
            // TODO: reject stuff?
            // TODO: parameterize table names and column names?

            //Debug.WriteLine(String.Join("\n" , ED.GetTableNames(pathToExcelFile).ToArray()));

            // TODO: use Data.TaskList objects instead?

            cogs = new List<Data.CognitiveTask>();
            obs = new List<Data.ObservableTask>();

            var cs = new List<Data.CognitiveTask>();
            try
            {
                var dtCogs = ED.GetDataTable(pathToExcelFile, SSC.ExcelTableName_Cognitive);
                _populateCogs(cogs, dtCogs);

                var dtObs = ED.GetDataTable(pathToExcelFile, SSC.ExcelTableName_Observable);
                _populateObs(obs, dtObs);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                //throw;
            }
        }

        public void UpdateTasks(string pathToExcelFile,
            ref Data.TaskSet taskset)
        {
            // Remove the Excel data from the collections:
            _clearExcelTasks(taskset);

            // Re-read the data from Excel:
            List<Data.CognitiveTask> cogs = null;
            List<Data.ObservableTask> obs = null;

            _getTasksFromExcel(pathToExcelFile, out cogs, out obs);

            // Add them to the tasks object:            
            foreach (var cog in cogs) taskset.Add(cog, true, false);
            foreach (var ob in obs) taskset.Add(ob, true, false);
        }


        private void _getTasksFromExcel(string pathToExcelFile,
            out List<Data.CognitiveTask> cogs,
            out List<Data.ObservableTask> obs)
        {
            cogs = new List<Data.CognitiveTask>();
            obs = new List<Data.ObservableTask>();
            try
            {
                var dtCogs = ED.GetDataTable(pathToExcelFile, SSC.ExcelTableName_Cognitive);
                _populateCogs(cogs, dtCogs);

                var dtObs = ED.GetDataTable(pathToExcelFile, SSC.ExcelTableName_Observable);
                _populateObs(obs, dtObs);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                //throw;
            }
        }

        /// <summary>
        /// Gets a CogTaskVx object from a DataRow object. If 
        /// "Description" is empty, then null is returned.
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        private Data.CognitiveTask _getCogTaskFromDataRow_OrNull(DataRow dr)
        {
            var c = new Data.CognitiveTask();

            c.Description = _getString(dr["Description"]);
            if (String.IsNullOrEmpty(c.Description)) return null;

            c.Category = _getString(dr["Category"]);
            c.Category_Container = _getString(dr["Category_Container"]);
            c.Category_Layer = _getString(dr["Category_Layer"]);
            c.Category_NearestObservableTask = _getString(dr["Category_NearestObservableTask"]);

            c.TaskNumber = _getString(dr["Task Number"]);

            c.Effort = _getRatingCog(dr["Effort"]);
            c.Frustration = _getRatingCog(dr["Frustration"]); // _getNShort(dr["Frustration"]);
            c.MentalDemand = _getRatingCog(dr["Mental Demand"]);
            c.Performance = _getRatingCog(dr["Performance"]);
            c.PhysicalDemand = _getRatingCog(dr["Physical Demand"]);
            c.TemporalDemand = _getRatingCog(dr["Temporal Demand"]);
            c.Enjoyment = _getRatingCog(dr["Enjoyment"]);

            //c.IsChanged = false;
            c.IsInExcel = true;
            //c.IsInVisio = false;
            //c.IsRenamed = false;

            return c;
        }

        /// Gets a ObsTaskVx object from a DataRow object. If
        /// "Description" is empty, then null is returned.
        private Data.ObservableTask _getObsTaskFromDataRow_OrNull(DataRow dr)
        {
            var o = new Data.ObservableTask();

            o.Description = _getString(dr["Description"]);
            if (String.IsNullOrEmpty(o.Description)) return null;

            o.Category = _getString(dr["Category"]);
            o.Category_Container = _getString(dr["Category_Container"]);
            o.Category_Layer = _getString(dr["Category_Layer"]);

            o.TaskNumber = _getString(dr["Task Number"]);


            //o.Complexity = _getNShort(dr["Complexity"]);
            //o.Difficulty = _getNShort(dr["Difficulty"]);
            //o.Duration = _getNShort(dr["Duration"]);
            //o.Frequency = _getNShort(dr["Frequency"]);
            //o.Importance = _getNShort(dr["Importance"]);
            o.Complexity = _getRatingObs(dr["Complexity"]);
            o.Difficulty = _getRatingObs(dr["Difficulty"]);
            o.Duration = _getRatingObs(dr["Duration"]);
            o.Frequency = _getRatingObs(dr["Frequency"]);
            o.Importance = _getRatingObs(dr["Importance"]);
            o.Enjoyment = _getRatingObs(dr["Enjoyment"]);

            //c.IsChanged = false;
            o.IsInExcel = true;
            //c.IsInVisio = false;
            //c.IsRenamed = false;

            return o;
        }

        /// <summary>
        /// Removes all Excel-only tasks, and sets the IsInExcel flag
        /// to false for tasks that exist in Visio.
        /// </summary>
        /// <param name="tasks"></param>
        private void _clearExcelTasks(Data.TaskSet taskset)
        {
            var cogs = taskset.CognitiveTasks;
            if (cogs.Count > 0)
            {
                for (int i = cogs.Count - 1; i <= 0; i--)
                {
                    var c = cogs[i];
                    if (c.IsInExcel)
                    {
                        if (!c.IsInVisio)
                        {
                            cogs.RemoveAt(i);
                        }
                        else
                        {
                            c.IsInExcel = false;
                        }
                    }
                }
            }

            var obs = taskset.ObservableTasks;
            if (obs.Count > 0)
            {
                for (int i = obs.Count - 1; i <= 0; i--)
                {
                    var o = obs[i];
                    if (o.IsInExcel)
                    {
                        if (!o.IsInVisio)
                        {
                            obs.RemoveAt(i);
                        }
                        else
                        {
                            o.IsInExcel = false;
                        }
                    }
                }
            }
        }
        private void _populateCogs(List<Data.CognitiveTask> cogs, DataTable dt)
        {
            // Columns:
            // Task Number,Description,Category,Category_Layer,Category_Container,Category_NearestObservableTask,
            // Mental Demand,Physical Demand,Temporal Demand,Performance,Effort,Frustration
            // See: SSC.ColumnNames_Cognitive
            foreach (DataRow dr in dt.Rows)
            {
                var c = _getCogTaskFromDataRow_OrNull(dr);
                if (c != null) cogs.Add(c);
            }
        }
        private void _populateObs(List<Data.ObservableTask> obs, DataTable dt)
        {
            // Columns:
            // Task Number,Category,Category_Container,Category_Layer,Complexity,Difficulty,Duration,Frequency,Importance
            // See: SSC.ColumnNames_Observable
            foreach (DataRow dr in dt.Rows)
            {
                var o = _getObsTaskFromDataRow_OrNull(dr);
                if (o != null) obs.Add(o);
            }
        }
        private string _getString(object datarowValue)
        {
            if (datarowValue == System.DBNull.Value) return String.Empty;
            if (datarowValue == null) return String.Empty;
            return Convert.ToString(datarowValue);
        }
        private short? _getNShort(object datarowValue)
        {
            if (datarowValue == System.DBNull.Value) return null;
            if (datarowValue == null) return null;
            return Convert.ToInt16(datarowValue);
        }

        private Data.RatingCog _getRatingCog(object datarowValue)
        {
            var r = new Data.RatingCog();
            if (datarowValue == System.DBNull.Value)
            {
                r.ToNull();
            }
            else if (datarowValue == null)
            {
                r.ToNull();
            }
            else
            {
                r.Value = datarowValue.ToString();
            }
            return r;
        }
        private Data.RatingObs _getRatingObs(object datarowValue)
        {
            var r = new Data.RatingObs();
            if (datarowValue == System.DBNull.Value)
            {
                r.ToNull();
            }
            else if (datarowValue == null)
            {
                r.ToNull();
            }
            else
            {
                r.Value = datarowValue.ToString();
            }
            return r;
        }
    }


}
