﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class VisioReader
    {
        public void UpdateTasks(Vis.Page visPg,
            ref Data.TaskSet taskset)
        {
            // Remove the Visio data from the collections:
            _clearVisioTasks(taskset);

            // Re-read the data from Excel:
            List<Data.CognitiveTask> cogs = null;
            List<Data.ObservableTask> obs = null;

            _getTasksFromVisio(visPg, out cogs, out obs);

            // Add them to the tasks object:            
            foreach (var cog in cogs) taskset.Add(cog, false, true);
            foreach (var ob in obs) taskset.Add(ob, false, true);
        }

        /// <summary>
        /// Removes all Visio-only tasks, and sets the IsInExcel flag
        /// to false for tasks that exist in Visio.
        /// </summary>
        /// <param name="tasks"></param>
        private void _clearVisioTasks(Data.TaskSet taskset)
        {
            var cogs = taskset.CognitiveTasks;
            for (int i = cogs.Count - 1; i >= 0; i--)
            {
                var c = cogs[i];
                if (c.IsInVisio)
                {
                    if (!c.IsInExcel)
                    {
                        cogs.RemoveAt(i);
                    }
                    else
                    {
                        c.IsInVisio = false;
                    }
                }
            }

            var obs = taskset.ObservableTasks;
            for (int i = obs.Count - 1; i >= 0; i--)
            {
                var o = obs[i];
                if (o.IsInVisio)
                {
                    if (!o.IsInExcel)
                    {
                        obs.RemoveAt(i);
                    }
                    else
                    {
                        o.IsInVisio = false;
                    }
                }
            }
        }

        private void _getTasksFromVisio(Vis.Page visPg,
            out List<Data.CognitiveTask> cogs,
            out List<Data.ObservableTask> obs)
        {
            var vpg = new View.Page_Diagram(visPg);

            cogs = new List<Data.CognitiveTask>();
            obs = new List<Data.ObservableTask>();

            var vcogs = vpg.GetCognitiveShapes();
            _populateCogs(cogs, vcogs);

            var vobs = vpg.GetObservableShapes();
            _populateObs(obs, vobs);
        }

        private Data.CognitiveTask _getCogTaskTxFromTaskShape_OrNull(View.Shape_Cognitive vshp)
        {
            if (vshp.IsNoDescription) return null;

            var dataCog = new Data.CognitiveTask();

            dataCog.Description = vshp.Description;
            dataCog.OldDescription = vshp.OldDescription;

            dataCog.Category = vshp.Category;
            dataCog.Category_Container = vshp.Category_Container;
            dataCog.Category_Layer = vshp.Category_Layer;
            dataCog.Category_NearestObservableTask = vshp.Cat_NearestObservableTask;

            dataCog.TaskNumber = vshp.TaskNumber;

            dataCog.Effort = vshp.Effort;
            dataCog.Frustration = vshp.Frustration;
            dataCog.MentalDemand = vshp.MentalDemand;
            dataCog.Performance = vshp.Performance;
            dataCog.PhysicalDemand = vshp.PhysicalDemand;
            dataCog.TemporalDemand = vshp.TemporalDemand;
            dataCog.Enjoyment = vshp.Enjoyment;

            //c.IsChanged = false;
            //c.IsInExcel = true;
            dataCog.IsInVisio = true;
            //c.IsRenamed = false;

            return dataCog;
        }
        private Data.ObservableTask _getObsTaskTxFromTaskShape_OrNull(View.Shape_Observable vshp)
        {
            if (vshp.IsNoDescription) return null;

            var dataObs = new Data.ObservableTask();

            dataObs.Description = vshp.Description;
            dataObs.OldDescription = vshp.OldDescription;

            dataObs.Category = vshp.Category;
            dataObs.Category_Container = vshp.Category_Container;
            dataObs.Category_Layer = vshp.Category_Layer;

            dataObs.TaskNumber = vshp.TaskNumber;

            dataObs.Complexity = vshp.Complexity;
            dataObs.Difficulty = vshp.Difficulty;
            dataObs.Duration = vshp.Duration;
            dataObs.Frequency = vshp.Frequency;
            dataObs.Importance = vshp.Importance;
            dataObs.Enjoyment = vshp.Enjoyment;

            //o.IsChanged = false;
            //o.IsInExcel = true;
            dataObs.IsInVisio = true;
            //o.IsRenamed = false;

            return dataObs;
        }

        private void _populateCogs(List<Data.CognitiveTask> cogs, List<View.Shape_Cognitive> vshps)
        {
            // Columns:
            // Task Number,Description,Category,Category_Layer,Category_Container,Category_NearestObservableTask,
            // Mental Demand,Physical Demand,Temporal Demand,Performance,Effort,Frustration
            // See: SSC.ColumnNames_Cognitive
            foreach (var vshp in vshps)
            {
                var c = _getCogTaskTxFromTaskShape_OrNull(vshp);
                if (c != null) cogs.Add(c);
            }
        }
        private void _populateObs(List<Data.ObservableTask> obs, List<View.Shape_Observable> vshps)
        {
            // Columns:
            // Task Number,Category,Category_Container,Category_Layer,Complexity,Difficulty,Duration,Frequency,Importance
            // See: SSC.ColumnNames_Observable
            foreach (var vshp in vshps)
            {
                var o = _getObsTaskTxFromTaskShape_OrNull(vshp);
                if (o != null) obs.Add(o);
            }
        }
    }
}
