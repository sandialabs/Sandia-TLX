﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.ComponentModel;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class ViewModel : INotifyPropertyChanged
    {
        // Active Window
        // Active Page
        // Active doc
        // Selected Shape -> None of interest or too many, 1 Cog, 1 Obs

        // Commands for add connector, add cog, add obs

        // Way to rename or create a name for an item

        // Visio events will update the selected shape property, I guess
        // The panel will react to these changes, if it is active...

        //c.CellChanged += CellChanged_PropImportance;

        //private Vis. .CellChangedEventHandler evt = null;

        // TODO: these events could be moved to the View.Shape_ classes
        // probably...

        #region "INotifyPropertyChanged stuff"
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
        protected bool SetField<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
        #endregion "INotifyPropertyChanged stuff"

        // I don't know if this is correct...
        #region "Cognitive & Observable Task Notifiable Properties"
        private string _description = String.Empty;
        public string Description
        {
            get { return _description; }
            set { SetField(ref _description, value, "Description"); }
        }
        private string _enjoyment = String.Empty;
        public string Enjoyment
        {
            get { return _enjoyment; }
            set { SetField(ref _enjoyment, value, "Enjoyment"); }
        }

        private string _mentalDemand = String.Empty;
        public string MentalDemand
        {
            get { return _mentalDemand; }
            set { SetField(ref _mentalDemand, value, "MentalDemand"); }
        }

        private string _physicalDemand = String.Empty;
        public string PhysicalDemand
        {
            get { return _physicalDemand; }
            set { SetField(ref _physicalDemand, value, "PhysicalDemand"); }
        }

        private string _temporalDemand = String.Empty;
        public string TemporalDemand
        {
            get { return _temporalDemand; }
            set { SetField(ref _temporalDemand, value, "TemporalDemand"); }
        }

        private string _performance = String.Empty;
        public string Performance
        {
            get { return _performance; }
            set { SetField(ref _performance, value, "Performance"); }
        }

        // Effort
        private string _effort = String.Empty;
        public string Effort
        {
            get { return _effort; }
            set { SetField(ref _effort, value, "Effort"); }
        }

        // Frustration
        private string _frustration = String.Empty;
        public string Frustration
        {
            get { return _frustration; }
            set { SetField(ref _frustration, value, "Frustration"); }
        }
        #endregion


        // Generic task stuff:
        // Prop.TaskNumber
        // Prop.Description
        private Vis.Cell _visCell_Task_Description = null;
        private Vis.Cell _visCell_Task_PropEnjoyment = null;

        //"Prop.Importance,Prop.Difficulty,Prop.Duration,Prop.Frequency,Prop.Complexity";
        private Vis.Cell _visCell_Cog_PropMentalDemand = null;
        private Vis.Cell _visCell_Cog_PropPhysicalDemand = null;
        private Vis.Cell _visCell_Cog_PropTemporalDemand = null;
        private Vis.Cell _visCell_Cog_PropPerformance = null;
        private Vis.Cell _visCell_Cog_PropEffort = null;
        private Vis.Cell _visCell_Cog_PropFrustration = null;
        //private Vis.Cell _visCell_Cog_PropEnjoyment = null;
        //_visCell_Cog_PropMentalDemand 
        //_visCell_Cog_PropPhysicalDemand
        //_visCell_Cog_PropTemporalDemand
        //_visCell_Cog_PropPerformance 
        //_visCell_Cog_PropEffort 
        //_visCell_Cog_PropFrustration 

        private Vis.Cell _visCell_Obs_PropImportance = null;
        private Vis.Cell _visCell_Obs_PropDifficulty = null;
        private Vis.Cell _visCell_Obs_PropDuration = null;
        private Vis.Cell _visCell_Obs_PropFrequency = null;
        private Vis.Cell _visCell_Obs_PropComplexity = null;
        //private Vis.Cell _visCell_Obs_PropEnjoyment = null;

        private string PropCellList_Cognitive = "Prop.Description,Prop.MentalDemand,Prop.PhysicalDemand,Prop.TemporalDemand,Prop.Performance,Prop.Effort,Prop.Frustration,Prop.Enjoyment"; 
        private string PropCellList_Observable = "Prop.Description,Prop.Importance,Prop.Difficulty,Prop.Duration,Prop.Frequency,Prop.Complexity,Prop.Enjoyment"; 

        public void SetShapeToView(Vis.Shape visShp)
        {

            // Deregister all events...
            _deregisterCellChangedEvent(ref _visCell_Task_Description);
            _deregisterCellChangedEvent(ref _visCell_Task_PropEnjoyment);

            _deregisterCellChangedEvent(ref _visCell_Cog_PropMentalDemand);
            _deregisterCellChangedEvent(ref _visCell_Cog_PropPhysicalDemand);
            _deregisterCellChangedEvent(ref _visCell_Cog_PropTemporalDemand);
            _deregisterCellChangedEvent(ref _visCell_Cog_PropPerformance);
            _deregisterCellChangedEvent(ref _visCell_Cog_PropEffort);
            _deregisterCellChangedEvent(ref _visCell_Cog_PropFrustration);
            

            _deregisterCellChangedEvent(ref _visCell_Obs_PropImportance);
            _deregisterCellChangedEvent(ref _visCell_Obs_PropDifficulty);
            _deregisterCellChangedEvent(ref _visCell_Obs_PropDuration);
            _deregisterCellChangedEvent(ref _visCell_Obs_PropFrequency);
            _deregisterCellChangedEvent(ref _visCell_Obs_PropComplexity);

            if (visShp == null) return;

            // Get rid of old events...
            if (View.VisioSolutionHelpers.IsCognitiveShape(visShp))
            {
                _updateCellEvents(visShp, PropCellList_Cognitive);
            }
            else if (View.VisioSolutionHelpers.IsObservableShape(visShp))
            {
                _updateCellEvents(visShp, PropCellList_Observable);
            }   

        }

        private void _updateCellEvents(Vis.Shape visShp, string csvCellList)
        {
            foreach(string cellname in csvCellList.Split(','))
            {
                _updateCellEvent(visShp, cellname);
            }
//_visCell_Cog_PropImportance
//_visCell_Cog_PropDifficulty
//_visCell_Cog_PropDuration 
//_visCell_Cog_PropFrequency 
//_visCell_Cog_PropComplexity
        }

        private void _updateCellEvent(Vis.Shape visShp, string cellname)
        {
            Vis.Cell visCell = visShp.CellOrNull(cellname);
            //Vis.Cell visEventCell = null;
            if (visCell == null) return;

            //_visCell_Cog_PropMentalDemand 
            //_visCell_Cog_PropPhysicalDemand
            //_visCell_Cog_PropTemporalDemand
            //_visCell_Cog_PropPerformance 
            //_visCell_Cog_PropEffort 
            //_visCell_Cog_PropFrustration 

            if (cellname == "Prop.Description")
            {
                _deregisterCellChangedEvent(ref _visCell_Task_Description);
                _visCell_Cog_PropMentalDemand = visCell;
                _registerCellChangedEvent(ref _visCell_Task_Description);
            }
            else if (cellname == "Prop.Enjoyment")
            {
                _deregisterCellChangedEvent(ref _visCell_Task_PropEnjoyment);
                _visCell_Cog_PropMentalDemand = visCell;
                _registerCellChangedEvent(ref _visCell_Task_PropEnjoyment);
            }
            // ----------------------------------------
            else if (cellname == "Prop.MentalDemand")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropMentalDemand);
                _visCell_Cog_PropMentalDemand = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropMentalDemand);
            }
            else if (cellname == "Prop.PhysicalDemand")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropPhysicalDemand);
                _visCell_Cog_PropPhysicalDemand = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropPhysicalDemand);
            }
            else if (cellname == "Prop.TemporalDemand")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropTemporalDemand);
                _visCell_Cog_PropTemporalDemand = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropTemporalDemand);
            }
            else if (cellname == "Prop.Performance")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropPerformance);
                _visCell_Cog_PropPerformance = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropPerformance);
            }
            else if (cellname == "Prop.Effort")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropEffort);
                _visCell_Cog_PropEffort = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropEffort);
            }
            else if (cellname == "Prop.Frustration")
            {
                _deregisterCellChangedEvent(ref _visCell_Cog_PropFrustration);
                _visCell_Cog_PropFrustration = visCell;
                _registerCellChangedEvent(ref _visCell_Cog_PropFrustration);
            }
            // ----------------------------------------
            else if (cellname == "Prop.Importance")
            {
                _deregisterCellChangedEvent(ref _visCell_Obs_PropImportance);
                _visCell_Obs_PropImportance = visCell;
                _registerCellChangedEvent(ref _visCell_Obs_PropImportance);
            }
            else if (cellname == "Prop.Difficulty")
            {
                //visEventCell = _visCell_Obs_PropDifficulty;
                _deregisterCellChangedEvent(ref _visCell_Obs_PropDifficulty);
                _visCell_Obs_PropDifficulty = visCell;
                _registerCellChangedEvent(ref _visCell_Obs_PropDifficulty);
            }
            else if (cellname == "Prop.Duration")
            {
                //visEventCell = _visCell_Obs_PropDuration;
                _deregisterCellChangedEvent(ref _visCell_Obs_PropDuration);
                _visCell_Obs_PropDuration = visCell;
                _registerCellChangedEvent(ref _visCell_Obs_PropDuration);
            }
            else if (cellname == "Prop.Frequency")
            {
                //visEventCell = _visCell_Obs_PropFrequency;
                _deregisterCellChangedEvent(ref _visCell_Obs_PropFrequency);
                _visCell_Obs_PropFrequency = visCell;
                _registerCellChangedEvent(ref _visCell_Obs_PropFrequency);
            }
            else if (cellname == "Prop.Complexity")
            {
                //visEventCell = _visCell_Obs_PropComplexity;
                _deregisterCellChangedEvent(ref _visCell_Obs_PropComplexity);
                _visCell_Obs_PropComplexity = visCell;
                _registerCellChangedEvent(ref _visCell_Obs_PropComplexity);
            }
            else
            { 

            }

            // De-register the old event:
            //if (visEventCell != null)
            //    visEventCell.CellChanged -= CellChanged;

            //visEventCell = visCell;
            //visEventCell.CellChanged += CellChanged;

        }

        private void _deregisterCellChangedEvent(ref Vis.Cell visCell)
        {
            if (visCell == null) return;
            visCell.CellChanged -= CellChanged;
            visCell = null;
        }
        private void _registerCellChangedEvent(ref Vis.Cell visCell)
        {
            if (visCell == null) return;
            visCell.CellChanged += CellChanged;
        }

        private void CellChanged(Vis.Cell Cell)
        {
            if (Cell.Stat == (short)Vis.VisStatCodes.visStatDeleted) return;
            Debug.WriteLine("CellChanged: " + Cell.Name + " to " + Cell.ResultStrNoCast() + " (" + Cell.FormulaU + ")");

            // Now we would step through the cell names and do some sort of
            // Notify Property Changed thingamagic that can be data-bound to...

        }
    }
}
