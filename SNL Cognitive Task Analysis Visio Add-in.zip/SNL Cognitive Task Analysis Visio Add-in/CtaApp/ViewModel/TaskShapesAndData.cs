﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Vis = Microsoft.Office.Interop.Visio;
//using System.Diagnostics;
//using VL = Visguy.VisAddinLib;
//using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel
{
    public class TaskShapesAndData
    {
        //public static void UpdateTaskShapeFromData(
        //    View.Shape_Task taskShape, object taskVxData, bool setDescription) 
        //{
        //    if (taskShape.GetType() == typeof(View.Shape_Cognitive))
        //    {
        //        if(taskVxData.GetType() == typeof(CogTaskVx))
        //        {
        //            var cshp = taskShape as View.Shape_Cognitive;
        //            var cogvx = taskVxData as CogTaskVx;

        //            cshp.Category = cogvx.Category;

        //            if(setDescription)
        //                cshp.Description = cogvx.Description;

        //            cshp.Effort = cogvx.Effort;
        //            cshp.Frustration = cogvx.Frustration;
        //            cshp.MentalDemand = cogvx.MentalDemand;
        //            cshp.Performance = cogvx.Performance;
        //            cshp.PhysicalDemand = cogvx.PhysicalDemand;
        //            cshp.TemporalDemand = cogvx.TemporalDemand;
        //            //cshp.Set_Category_Container() cogvx.Category_Container;
        //            //cshp.Set_Category_Layer() = cogvx.Category_Layer;
        //            //cshp.TaskNumber = cogvx.TaskNumber;
        //        }
        //    }
        //    else if (taskShape.GetType() == typeof(View.Shape_Observable))
        //    {
        //        if(taskVxData.GetType() == typeof(ObsTaskVx))
        //        {
        //            var oshp = taskShape as View.Shape_Observable;
        //            var obsvx = taskVxData as ObsTaskVx;

        //            oshp.Category = obsvx.Category;
        //            oshp.Complexity = obsvx.Complexity;

        //            if (setDescription)
        //                oshp.Description = obsvx.Description;

        //            oshp.Difficulty = obsvx.Difficulty;
        //            oshp.Duration = obsvx.Duration;
        //            oshp.Frequency = obsvx.Frequency;
        //            oshp.Importance = obsvx.Importance;
        //            //oshp.TaskNumber = obsvx.TaskNumber;

        //            //oshp.Set_Category_Container()
        //            //oshp.Set_Category_Layer();
        //        }
        //    }

        //}

    }
}
