﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

using Vis = Microsoft.Office.Interop.Visio;
using VL = Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Extensions
{
    public static class ShapeExtensions
    {
        public static IEnumerable<ShapeDataRow> ShapeDataRows(this Vis.Shape visShp)
        {
            if (visShp.SectionExists(Sec_Prop) == false) yield break;

            Vis.Section sec = visShp.Section[Sec_Prop];
            short iRowCt = sec.Count;
            for (short iRow = 0; iRow < iRowCt; iRow++)
            {
                ShapeDataRow sdr = new ShapeDataRow(sec[iRow]);
                yield return sdr;
            }
        }
    }
}
