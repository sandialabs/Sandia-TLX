﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;


namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Extensions
{
    /// <summary>
    /// Shape Data extensions could apply to cells in the Prop section, 
    /// Shape objects row objects, or other Visio entities.
    /// </summary>
    public static class ShapeDataExtensions
    {
        enum ListOptions { RowName, PropRowName, PropRowNameAndLabel, Label }
        // NameNameUFormulaFormulaU, etc.

        private const short Sec_Prop = (short)Vis.VisSectionIndices.visSectionProp;

        private const short Cell_Label = (short)Vis.VisCellIndices.visCustPropsLabel;
        private const short Cell_Prompt = (short)Vis.VisCellIndices.visCustPropsPrompt;
        private const short Cell_Type = (short)Vis.VisCellIndices.visCustPropsType;
        private const short Cell_Format = (short)Vis.VisCellIndices.visCustPropsFormat;
        private const short Cell_Value = (short)Vis.VisCellIndices.visCustPropsValue;

        private const short Exists_Anywhere = (short)Vis.VisExistsFlags.visExistsAnywhere;

        public static string ShapeDataList_Labels(this Vis.Shape visShp, string prefix, bool sort)
        {
            return visShp._shapeDataList(ListOptions.Label, prefix, sort);
        }
        public static string ShapeDataList_PropRowNameAndLabels(this Vis.Shape visShp, string prefix, bool sort)
        {
            return visShp._shapeDataList(ListOptions.PropRowNameAndLabel, prefix, sort);
        }
        private static string _shapeDataList(this Vis.Shape visShp,
            ListOptions opt, string prefix, bool sort)
        {
            var vals = new List<string>();
            var sdrs = visShp.ShapeDataRows();
            foreach (var sdr in sdrs)
            {
                string val = String.Empty;
                switch (opt)
                {
                    case ListOptions.RowName:
                        val = sdr.Name;
                        break;
                    case ListOptions.PropRowName:
                        val = sdr.ValueCell.Name;
                        break;
                    case ListOptions.PropRowNameAndLabel:
                        var val1 = sdr.ValueCell.Name;
                        var val2 = sdr.Label;
                        if (String.IsNullOrEmpty(val2))
                            val2 = $"[{sdr.ValueCell.Name}]";
                        val = $"{val1} [{val2}]";
                        break;
                    case ListOptions.Label:
                        val = sdr.Label;
                        if (String.IsNullOrEmpty(val))
                            val = $"[{sdr.ValueCell.Name}]";
                        break;
                    default:
                        val = sdr.ValueCell.Name + "=" + sdr.ValueCell.Formula;
                        break;
                }

                if (String.IsNullOrEmpty(val))
                {
                    val = sdr.ValueCell.Name + "=" + sdr.ValueCell.Formula;
                }
                vals.Add(val);
            }

            // Sort, if specified:
            if (sort)
            {
                vals.Sort();
            }

            var sb = new StringBuilder();
            foreach (var val in vals)
            {
                sb.AppendLine(prefix + val);
            }
            return sb.ToString();

        }

    }
}

