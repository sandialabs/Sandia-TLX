﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using Visguy.VisAddinLib.Extensions;
using Visguy.VisAddinLib.ExcelData;
using Visguy.VisAddinLib.UI;
using SNL_Cognitive_Task_Analysis_Visio_Add_in.View;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in
{
    /// <summary>
    /// Solution contains static objects and data that are essential
    /// for the solution to run, and that correspond one-to-one with
    /// the Visio instance/editing session.
    /// </summary>
    public static class Solution
    {
        private static Docs _docs = null;
        private static bool _newSolutionDocJustOpened = false;

        public static string Folderpath_Addin = String.Empty;
        public static string Folderpath_AddinContent = String.Empty;
        public static string Filepath_VisioTemplate = String.Empty;
        public static string Filepath_ExcelTemplate = String.Empty;
        public static string Filepath_ExcelSample = String.Empty;
        public static string Filepath_Help = String.Empty;

        public static UI.DockedWindowManager CtaPanelManager = null;
        public static UI.SelectedShape SelectedShape = null;
        public static View.VisSolutionEvents SolutionEvents = null;
        public static Vis.Application VisApp = null;
        //public static ViewModel.DataManager DataManager = null;

        public static Action UpdateRibbonUI = null;


        #region "Properties.Settings-related Fields"
        public static bool IsDeveloperMode { get { return Properties.Settings.Default.IsDeveloperMode; } }

        public static string CustomDataGraphicName01 { get { return Properties.Settings.Default.DataGraphicName01; } }
        public static string CustomDataGraphicName02 { get { return Properties.Settings.Default.DataGraphicName02; } }  
        public static string CustomDataGraphicName03 { get { return Properties.Settings.Default.DataGraphicName03; } }
        public static string CustomDataGraphicName04 { get { return Properties.Settings.Default.DataGraphicName04; } }

        #endregion

        public static void Start(Vis.Application visApp)
        {
            // Save Visio:
            VisApp = visApp;

            // Initialize the Docs collection:
            _docs = new Docs(visApp);

            //DataManager = new ViewModel.DataManager();
            
            // Set the default message captions:

            // In the add-in library:
            Visguy.VisAddinLib.UI.Msg.DefaultCaption =
                SolutionStrings.DefaultFormCaption;

            // In the app's UI forms:
            UI.ReportForm.DefaultCaption = SolutionStrings.DefaultFormCaption;

            // Register events:
            _initEvents();

            CtaPanelManager = new UI.DockedWindowManager(VisApp);

            // Initialize file paths:
            Folderpath_Addin = VisioSolutionHelpers.GetExecutingAssemblyFolderPath();

            Folderpath_AddinContent = Path.Combine(Folderpath_Addin, SolutionStrings.ContentSubdirectoryName);
            Filepath_VisioTemplate = Path.Combine(Folderpath_AddinContent, SolutionStrings.VisioTemplateFilename);
            Filepath_ExcelTemplate = Path.Combine(Folderpath_AddinContent, SolutionStrings.ExcelTemplateFilename);
            Filepath_ExcelSample = Path.Combine(Folderpath_AddinContent, SolutionStrings.ExcelSampleFilename);
            Filepath_Help = Path.Combine(Folderpath_AddinContent, SolutionStrings.HelpFilename);
        }
        public static void Stop()
        {
            
            // Do "dispose" stuff here...
            _disposeEvents();
        }

        public static void RefreshAfterOptionsChanged() //...set this when the add-in is started
        {
            Debug.WriteLine("TODO: Solution.RefreshAfterOptionsChanged");
            if(UpdateRibbonUI != null)
            {
                UpdateRibbonUI.Invoke();
            }
        }

        //public static DocData GetDocData(Vis.Document visDoc)
        //{
        //    View.Doc vdoc = _docs.GetOrAddSolutionDoc(visDoc);
        //    if (vdoc == null) return null;
        //    return DataManager.GetDocData(vdoc);
        //}


        public static View.Page_Diagram GetActiveSolutionDiagramPageOrNull()
        {
            // TODO: finish this, what exaclty are we trying to do...
            //_docs.GetActiveDocOrNull
            var d = GetActiveSolutionDocOrNull();
            if (d == null) return null;
            return d.DiagramPage_OrNull;
        }
        public static View.Page_Config GetActiveSolutionConfigPageOrNull()
        {
            // TODO: finish this, what exaclty are we trying to do...
            //_docs.GetActiveDocOrNull
            var d = GetActiveSolutionDocOrNull();
            if (d == null) return null;
            return d.ConfigPage_OrNull;
        }
        public static View.Doc GetActiveSolutionDocOrNull()
        {
            if (_docs == null) return null;
            return _docs.GetActiveDocOrNull();
        }


        private static void SolutionEvents_OnDocumentOpened(object sender, VisSolutionEvents.DocEvent_EventArgs e)
        {
            if (e.Document == null) return;
            if (e.IsShownInActiveWindow == false) return;

            // This happens before SelectedShape is updated,
            // so we can't really call:
            // Commands.ShowTliPanel();
            // right now, so set a flag:
            _newSolutionDocJustOpened = true;
            // SolutionEvents_SolutionSelectionChanged will now look for this
            // and call Commands.ShowTliPanel()

            // Wait, so if a new doc is opened, then the new window will likely be a drawing window with nothing selected...

            // TODO: add a new doc object? _docs.Add
            //View.Doc vdoc = new Doc(e.Document);
            //if(vdoc.IsSolutionDocument)
            //{
            //    _docs.Add(vdoc);
            //    _datamanager.add(vdoc); // or only do this when we need some data?
            //}
                       
        }

        private static void SolutionEvents_SolutionSelectionChanged(object sender, VisSolutionEvents.SolutionSelectionChanged_EventArgs e)
        {
            Debug.WriteLine("SolutionEvents_SolutionSelectionChanged! " + 
                DateTime.Now.ToString("yyyy.MM.dd HH.mm.ss"));

            if(e.IsSelected_SingleSolutionShape)
            {
                if(e.ObservableShapeOrNull != null)
                {
                    Debug.WriteLine("\tSelection is a single Observable shape.");

                    if (SelectedShape == null)
                    {
                        SelectedShape = new UI.SelectedShape(e.ShapeOrNull);
                    }
                    else
                    {
                        SelectedShape.UpdateShape(e.ShapeOrNull);
                    }
                }
                else if (e.CognitiveShapeOrNull != null)
                {
                    Debug.WriteLine("\tSelection is a single Cognitive shape.");

                    if (SelectedShape == null)
                    {
                        SelectedShape = new UI.SelectedShape(e.ShapeOrNull);
                    }
                    else
                    {
                        SelectedShape.UpdateShape(e.ShapeOrNull);
                    }
                }
                else
                {
                    Debug.WriteLine("\tSelection is interesting, but I don't know why.");

                    if (SelectedShape == null)
                    {
                        SelectedShape = new UI.SelectedShape(null);
                    }
                    else
                    {
                        SelectedShape.UpdateShape(null);
                    }
                }
            }
            else
            {
                Debug.WriteLine("\tSelection is not interesting.");

                if (SelectedShape == null)
                {
                    SelectedShape = new UI.SelectedShape(null);
                }
                else
                {
                    SelectedShape.UpdateShape(null);
                }
            }

            // See if this selection change was likely triggered by
            // a new document being opened, and show the panel...
            if(_newSolutionDocJustOpened == true)
            {
                // ...but only if the app setting says to do so:
                if (Properties.Settings.Default.AutoShowTliPanelOnDocOpen)
                {
                    Commands.ShowTliPanel();
                }

                // Restore the flag to its dormant state:
                _newSolutionDocJustOpened = false;
            }
        }

        private static void SolutionEvents_SolutionMarkerEvent(
            object sender, VisSolutionEvents.MarkerEvent_EventArgs e)
        {
            Debug.WriteLine(e.MarkerCommand.FullCommandName);
            //throw new NotImplementedException();

            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_Browse))
            {
                if (e.Shape != null)
                {
                    Commands.BrowseForDataFile(e.Shape);         
                }
            }

            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_CheckDataSource))
            {
                //Commands.CheckDataSource(); ?????
                if (e.Shape != null)
                {                    
                    Commands.CheckDataSource();
                }
            }

            //MarkerEvent_RefresProgressBars
            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_RefreshProgressBars))
            {
                if (e.Page != null)
                {
                    Commands.RefreshProgressBars(e.Page);
                }
            }

            // Choose a new name and/or category:
            //
            // MarkerEvent_ShapeDescAndCategory
            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_ShapeDescAndCategory))
            {
                if (e.Shape != null)
                {
                    Commands.DescriptionAndCategoryDialog(e.Shape);
                }
            }

            //MarkerEvent_CopySampleExcel
            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_CopySampleExcel))
            {
                Commands.CopySampleExcel();
            }
            //MarkerEvent_CopyEmptyExcel
            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_CopyEmptyExcel))
            {
                Commands.CopyExcelTemplate();
            }
            if (e.MarkerCommand.FullCommandNameEquals_CaseInsensitive(
                    SolutionStrings.MarkerEvent_ViewDataSourceFile))
            {
                Commands.ViewDataSource();
            }

        }



        private static void _disposeEvents()
        {
            if (SolutionEvents != null) SolutionEvents.UnsubscribeEvents();
            _docs = null; // TODO: see if _docs needs more destruction than this.
        }
        private static void _initEvents()
        {
            SolutionEvents = new View.VisSolutionEvents(
                VisApp, SolutionStrings.MarkerEvent_Prefix);

            SolutionEvents.OnBeforeDocumentClosed += SolutionEvents_OnBeforeDocumentClosed;
            SolutionEvents.OnDocumentOpened += SolutionEvents_OnDocumentOpened;
            SolutionEvents.OnSolutionSelectionChanged +=
                SolutionEvents_SolutionSelectionChanged;
            //SolutionEvents.NonSingleSolutionShapeSelected +=
            //    SolutionEvents_NonSingleSolutionShapeSelected;
            //SolutionEvents.SingleSolutionShapeSelected +=
            //    SolutionEvents_SingleSolutionShapeSelected;
            SolutionEvents.OnSolutionMarkerEvent += SolutionEvents_SolutionMarkerEvent;

        }

        private static void SolutionEvents_OnBeforeDocumentClosed(object sender, VisSolutionEvents.DocEvent_EventArgs e)
        {
            if (_docs == null) return;
            _docs.Remove_ByVisioDocument(e.Document);
        }

        //
        //public static string AddinFolder = String.Empty;
        //public static string AddinContentFolder = String.Empty;
        //public static void Initialize(Vis.Application visApp)
        //{
        //    SolutionEvents = new View.VisSolutionEvents(visApp);

        //    SolutionEvents.NonSingleSolutionShapeSelected +=
        //        SolutionEvents_NonSingleSolutionShapeSelected;
        //    SolutionEvents.SingleSolutionShapeSelected +=
        //        SolutionEvents_SingleSolutionShapeSelected;
        //}
        //public static void Cleanup()
        //{
        //    if (SolutionEvents != null) SolutionEvents.UnsubscribeEvents();
        //}

        //private static void SolutionEvents_SingleSolutionShapeSelected(
        //    object sender,
        //    View.VisSolutionEvents.SingleSolutionShapeSelected_EventArgs e)
        //{
        //    Debug.WriteLine("Solution shape selected!");
        //    //throw new NotImplementedException();
        //}

        //private static void SolutionEvents_NonSingleSolutionShapeSelected(
        //    object sender,
        //    View.VisSolutionEvents.SingleSolutionShapeSelected_EventArgs e)
        //{
        //    Debug.WriteLine("Non-solution shape or nothing selected!");
        //    //throw new NotImplementedException();
        //}


    }
}
