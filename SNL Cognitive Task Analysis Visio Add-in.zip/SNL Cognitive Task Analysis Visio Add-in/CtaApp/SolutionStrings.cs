﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in
{
    public static class SolutionStrings
    {
        // This module contains string constant definitions
        // that are used to identify shapes, pages, documents,
        // marker events and other entities that the code must
        // operate on and interact with.

        public static string PanelCaption = "Task Load Index";

        public static string DefaultFormCaption = "SNL Cognitive Task Analysis";
        public static string OptionsFormCaption = "SNL CTA Options";

        // File names and paths:
        public static string ContentSubdirectoryName = "Content";
        public static string VisioTemplateFilename = "Cognitive Task Analysis Template.vstx"; //"Cognitive Task Analysis Template.vsdx";
        public static string ExcelTemplateFilename = "Cognitive and Observable Tasks Template.xlsx";
        public static string ExcelSampleFilename = "Sample CTA Data.xlsx";
        public static string HelpFilename = "Help.pdf";

        // User.Class values:
        public static string DocClass_Solution = "SNL.CAT.Document";
        public static string PageClass_MainDiagram = "SNL.CAT.Page.MainDiagram";
        public static string PageClass_Config = "SNL.CAT.Page.Config";
        public static string ShapeClass_Cognitive = "SNL.CAT.Shape.Task.Cognitive";
        public static string ShapeClass_Observable = "SNL.CAT.Shape.Task.Observable";
        public static string ShapeClass_CtaConnector = "SNL.CAT.Shape.Connector";
        public static string ShapeClass_ProgressBars = "SNL.CAT.Shape.Task.ProgressBars";

        // Marker event constants:
        public static string MarkerEvent_Prefix = "SNL.CAT.Marker.";
        public static string MarkerEvent_Browse = "SNL.CAT.Marker.Browse";
        public static string MarkerEvent_CheckDataSource = "SNL.CAT.Marker.CheckDataSource";
        //QUEUEMARKEREVENT("SNL.CAT.Marker.CheckDataSource|"&FILENAME()&"|"&PAGENAME()&"|"&ID())

        public static string MarkerEvent_RefreshProgressBars = "SNL.CAT.Marker.RefreshProgressBars";

        public static string MarkerEvent_ShapeDescAndCategory = "SNL.CAT.Marker.Shape.DescAndCategory";
        // =QUEUEMARKEREVENT("SNL.CAT.Marker.Shape.DescAndCategory|"&TheDoc!ID()&"|"&ThePage!ID()&"|"&ID())

        public static string MarkerEvent_CopySampleExcel = "SNL.CAT.Marker.CopySampleExcel";
        public static string MarkerEvent_CopyEmptyExcel = "SNL.CAT.Marker.CopyEmptyExcel";
        public static string MarkerEvent_ViewDataSourceFile = "SNL.CAT.Marker.ViewDataSource";
        //QUEUEMARKEREVENT("SNL.CAT.Marker.CopySampleExcel|"&FILENAME()&"|"&PAGENAME()&"|"&ID())
        //QUEUEMARKEREVENT("SNL.CAT.Marker.ViewDataSource|"&FILENAME()&"|"&PAGENAME()&"|"&ID())

        //public static string MarkerEvent_AAA = "SNL.CAT.Marker.";
        //public static string MarkerEvent_BBB = "SNL.CAT.Marker.";

        // Call marker events from shapes like this:|
        // =QUEUEMARKEREVENT("SNL.CAT.Marker.Browse|"&TheDoc!ID()&"|"&ThePage!ID()&"|"&ID())
        // The use _____ to parse the doc, page and shape ids separated
        // by the pipes at the end of the string.


        // Shape names:
        public static string ShapeName_Diagram_TitleShape = "CtaTitle";
        public static string ShapeName_Config_DataSourcePath = "DataSourcePath";
        public static string ShapeName_Config_DataSourceBrowseButton = "DataSourceBrowse";     
        
        // Master names:
        public const string MasterName_CognitiveTask = "Cognitive Task";   
        public const string MasterName_ObservableTask = "Observable Task";
        public const string MasterName_CtaConnector = "Dynamic connector"; // "CTA Connector";
        public const string MasterName_ProgressBars = "Progress Bars";

        // Data Graphic Names:
        public const string DgName_AllItemsRated_Task = "DG - Task All Items Rated";
        public const string DgName_AverageRating_Cog = "DG - Average Rating Cognitive";
        public const string DgName_AverageRating_Obs = "DG - Average Rating Observable";

        // Highlight shapes
        public const string HighlightTag_Disconnected = "CTA Disconnected Highlight";
        public const string HighlightTag_Duplicate = "CTA Duplicate Highlight";

        // Shape cell names. It's debatable that these should be in the various Shape_ classes:
        public const string PropCell_TaskNumber = "Prop.TaskNumber";
        public const string PropCell_Description = "Prop.Description";
        public const string PropCell_OldDescription = "Prop.OldDescription";
        public const string PropCell_Category = "Prop.Category";
        public const string PropCell_CategoryLayer = "Prop.Cat_Layer";
        public const string PropCell_CategoryContainer = "Prop.Cat_Container";
        public const string PropCell_Enjoyment = "Prop.Enjoyment";

        // These were removed:
        // Prop.IsCurrent,Prop.CurrentDate,Prop.IsAccurate,Prop.AccurateDate,

        // Cognitive:
        // "Prop.MentalDemand,Prop.PhysicalDemand,Prop.TemporalDemand,Prop.Performance,Prop.Effort,Prop.Frustration";
        public const string PropCell_CategoryNearestObservableTask = "Prop.Cat_NearestObservableTask";
        public const string PropCell_MentalDemand = "Prop.MentalDemand";
        public const string PropCell_PhysicalDemand = "Prop.PhysicalDemand";
        public const string PropCell_TemporalDemand = "Prop.TemporalDemand";
        public const string PropCell_Performance = "Prop.Performance";
        public const string PropCell_Effort = "Prop.Effort";
        public const string PropCell_Frustration = "Prop.Frustration";

        // Observable:
        //"Prop.Importance,Prop.Difficulty,Prop.Duration,Prop.Frequency,Prop.Complexity";
        public const string PropCell_Importance = "Prop.Importance";
        public const string PropCell_Difficulty = "Prop.Difficulty";
        public const string PropCell_Duration = "Prop.Duration";
        public const string PropCell_Frequency = "Prop.Frequency";
        public const string PropCell_Complexity = "Prop.Complexity";

        //public static string PropCell_ = "Prop.";
        //public static string PropCell_ = "Prop.";


        // DataGraphic names from Settings:
        // TODO: add a way to refresh these when settings change?
        
        //public static string DataGraphicName01 = Properties.Settings.Default.DataGraphicName01;
        //public static string DataGraphicName02 = Properties.Settings.Default.DataGraphicName02;
        //public static string DataGraphicName03 = Properties.Settings.Default.DataGraphicName03;
        //public static string DataGraphicName04 = Properties.Settings.Default.DataGraphicName04;

        // Settings have events, so we could re-fry the DataGraphicNames dynamically
        // Or provide some sort of local method of getting at the Ribbon...
        //public static void X()
        //{
        //    Properties.Settings.Default.PropertyChanged += Default_PropertyChanged;
        //}
        //private static void Default_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        //{
        //    throw new NotImplementedException();
        //}
        // Just create some sort of Action/delegate that Solution can hold on to,
        // and the add-in can set.
        //public static Action<string> UpdateRibbonButton_ApplyDataGraphic01 = null;
        //UpdateRibbonButton_ApplyDataGraphic01.Invoke("Bob");



        // ----- Excel-related Strings ----------------------------------------
        public static string ExcelTableName_Cognitive = "Cognitive Tasks$";
        public static string ExcelTableName_Observable = "Observable Tasks$";

        public static string ColumnNames_Cognitive =
            "Task Number,Description,Category,Category_Layer,Category_Container,Category_NearestObservableTask,Mental Demand,Physical Demand,Temporal Demand,Performance,Effort,Frustration,Enjoyment";

        public static string ColumnNames_Observable =
            "Task Number,Category,Category_Container,Category_Layer,Complexity,Difficulty,Duration,Frequency,Importance,Enjoyment";

    }
}
