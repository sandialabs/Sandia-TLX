﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in
{
    public static class Commands
    {
        // TODO: gray out the ribbon group if the active page
        // isn't a diagram page...?


        // MentalDemand, PhysicalDemand, TemporalDemand, Performance, Effort, Frustration
        // Importance, Difficulty, Duration, Frequency, Complexity

        public static void CreateReportShape_WithUndo(string reportText)
        {
            Vis.Page visPg = Solution.VisApp.ActivePageOrNull();
            if (visPg == null) return;

            string sUndoScopeName = "Create Report Shape";

            var rs = new View.Reports.ReportShape(visPg, reportText);
           
            Action proc = rs.Create;

            string sErrorMessage = String.Empty;

            // Do the command:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(CreateReportShape_WithUndo));
        }

        public static void ViewCurrentData()
        {
            var doc = Solution.GetActiveSolutionDocOrNull();
            if (doc == null) return;

            // TODO: move the doc data to the View.Doc class.
            //var docdata = doc.GetData();
            var docdata = doc.Data; // Solution.GetDocData(doc.VisDoc);
            if (docdata == null) return;

            docdata.Refresh();

            var frm = new UI.ViewDiagramDataForm(docdata.Tasks);
            frm.ShowDialog();
           
            //Vis.Page pg = _getActiveDiagramVisPageOrNull(); // _getActiveDiagramPageOrNull();
            //if (pg == null) return;

            //Vis.Document doc = pg.Document;
            //var dd = Solution.GetDocData(doc);
            //dd.Refresh();

            //Debug.WriteLine("Cog descriptions " + String.Join(";", dd?.Tasks.Descriptions_Cog_Unique_Sorted(true)));
            //Debug.WriteLine("Cog categories " + String.Join(";", dd?.Tasks.Categories_Cog_Unique_Sorted()));
            //Debug.WriteLine("Obs descriptions " + String.Join(";", dd?.Tasks.Descriptions_Obs_Unique_Sorted(true)));
            //Debug.WriteLine("Obs categories " + String.Join(";", dd?.Tasks.Categories_Obs_Unique_Sorted()));
        }

        public static void TodoPlaceholder(string todoMessage)
        {
            VL.UI.Msg.Show(todoMessage);
        }

        public static void ShowTliPanel()
        {
            Vis.Page visPg = Solution.VisApp.ActivePageOrNull();
            if (visPg == null) return;

            Solution.CtaPanelManager.CreateOrShowPanel();
        }


        public static void ApplyDataGraphics_FromDgName(string dataGraphicNameFromName)
        {
            if (String.IsNullOrEmpty(dataGraphicNameFromName)) return;
            _applyDataGraphicsWithUndo(
                dataGraphicNameFromName, 
                String.Empty, 
                String.Empty);
        }
        public static void ApplyDataGraphics_AllItemsRated()
        {
            _applyDataGraphicsWithUndo(
                SolutionStrings.DgName_AllItemsRated_Task, 
                String.Empty, 
                String.Empty);
        }
        public static void ApplyDataGraphics_AverageRating()
        {
            _applyDataGraphicsWithUndo(
                SolutionStrings.DgName_AverageRating_Cog,
                SolutionStrings.DgName_AverageRating_Obs, 
                String.Empty);
        }
        public static void ApplyDataGraphics_None()
        {
            _applyDataGraphicsWithUndo(
                String.Empty,
                String.Empty, 
                String.Empty);
        }

        private static void _applyDataGraphicsWithUndo(
            string dgName1, string dgName2, string dgName3)
        {
            //if (String.IsNullOrEmpty(dataGraphicNameFromName)) return;

            bool bClearDgs = String.IsNullOrEmpty(dgName1) &&
                             String.IsNullOrEmpty(dgName2) &&
                             String.IsNullOrEmpty(dgName3);

            var sdpg = Solution.GetActiveSolutionDiagramPageOrNull();
            if (sdpg == null) return;

            string sUndoScopeName = "Apply DataGraphics";
            if (bClearDgs)
                sUndoScopeName = "Clear Datagraphics";

            // Just use an Action for a no-argument, no-return call:
            var dpa = new View.DataGraphicApplier(sdpg);
            dpa.DataGraphicName_1 = dgName1;
            dpa.DataGraphicName_2 = dgName2;
            dpa.DataGraphicName_3 = dgName3;

            Action proc = dpa.TryApplyDataGraphics;
            if (bClearDgs)
                proc = dpa.ClearDataGraphics;
            
            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(_applyDataGraphicsWithUndo));
        }


        public static void BrowseForDataFile(Vis.Shape visShpCallerOrNull)
        {
            Vis.Page visPg = null;

            // TODO: The code is in this View.Shape_Excel object, but it 
            // should probably be part of View.Page_Config or View.Doc.

            // Just get a valid or suspected config page:
            if(visShpCallerOrNull == null)
            {
                visPg = Solution.GetActiveSolutionDocOrNull()?
                    .ConfigPage_OrNull?
                    .VisioPage;
            }
            else
            {
                visPg = visShpCallerOrNull.ContainingPage;                             
            }

            if (visPg == null) return;

            // Build this Shape_ExcelPath thing:
            var vshpExcelPath = View.Shape_ExcelPath.GetExcelPathShapeOrNull(visPg);

            if (vshpExcelPath == null) return;

            // Do the browse thing:
            vshpExcelPath.BrowseForNewDataSourcePath();
        }

        public static void HighlightAllIssues()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string sUndoScopeName = "Highlight All Issues";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.IssueHighlighter.HighlightAllIssues;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                    VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(HighlightAllIssues));
        }

        public static void HighlightDisconnections()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string sUndoScopeName = "Highlight Disconnections";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.IssueHighlighter.HighlightDisconnections;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(HighlightDisconnections));
        }

        public static void HighlightTasksWithDuplicateDescriptions()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string sUndoScopeName = "Highlight Duplicate TaskNames";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.IssueHighlighter.HighlightTasksWithDuplicateDescriptions;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(HighlightTasksWithDuplicateDescriptions));
        }

        public static void ClearAllRatingValues()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string msg = string.Empty;

            // Double-check with the user:
            msg = "This will erase all of the rating values for task shapes in this document.\n" +
                  "This essentially prepares the document to be filled-out by subject matter experts.\n\n" +
                  "Would you like to continue?";
            if (VL.UI.Msg.ShowYesNo(msg) == false) return;

            string sUndoScopeName = "Clear All Rating Values in Task Shapes";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.ClearAllRatingValues;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(ClearIssueHighlights));

        }

        public static void ClearIssueHighlights()
        {
            // TODO: not sure if we should break down the delete ops
            // by highlight category.

            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string sUndoScopeName = "Delete Issue Highlights";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.IssueHighlighter.ClearHighlights;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(ClearIssueHighlights));
        }
        //private static bool _deleteDisconnectionsHighlights(Vis.Page visPg)
        //{
        //    var pd = new View.Page_Diagram(visPg);
        //    pd.ClearHighlights();
        //    return true;
        //}

        public static void DescriptionAndCategoryDialog(Vis.Shape visShp)
        {
            // Get the Shape_Cognitive or Shape_Observable object:
            var tshp = View.VisioSolutionHelpers.GetTaskShape_OrNull(visShp);
            if (tshp == null) return;

            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            // Get the active data doc:
            var dd = vdoc.Data; // Solution.GetDocData(visShp.Document);
            if (dd == null) return;

            // Update the data:
            dd.Refresh();

            // Define variables for the form:
            List<string> descs = null;
            List<string> cats = null;
            string initDesc = tshp.Description;
            string initCat = tshp.Category;

            // Get the lists based on which type of task visShp is:
            var taskShapeType = tshp.GetType();
            bool isCog = false;
            bool isObs = false;
            if(taskShapeType == typeof(View.Shape_Cognitive))
            {
                descs = dd.Tasks.Descriptions_Cog_Unique_Sorted(false);
                cats = dd.Tasks.Categories_Cog_Unique_Sorted(initCat);
                isCog = true;
            }
            else if (taskShapeType == typeof(View.Shape_Observable))
            {
                descs = dd.Tasks.Descriptions_Obs_Unique_Sorted(false);
                cats = dd.Tasks.Categories_Obs_Unique_Sorted(initCat);
                isObs = true;
            }
            else
            {
                return;
            }
           
            // Send the variables to the form and get some user input:
            var frm = new UI.DescriptionAndCategoryForm("Choose Description and Category",
                descs, cats, initDesc, initCat);

            // Show the form and get the dialog result:
            if (frm.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            // Pick any new values from the form object:
            string newDesc = frm.SelectedDescriptionValue;
            string newCat = frm.SelectedCategoryValue;

            if (newDesc != initDesc)
            {
                //tshp.Description = newDesc;

                if (frm.SelectedDescriptionIsChanged)
                {
                    // The user "renamed" the description.
                    tshp.UpdateDescription_IfDifferent(newDesc);
                    vdoc.Data.RenameDescription(taskShapeType, initDesc, newDesc);
                }
                else if (frm.SelectedDescriptionIsAdded)
                {
                    // The user created a new description.
                    tshp.Description = newDesc;

                    // This is a new description, therefore a new task 
                    // "definition". Erase everything in the shape, but 
                    // the description:
                    if (isCog)
                    {
                        var cshp = tshp as View.Shape_Cognitive;
                        cshp.EraseValues(false, true);
                    }
                    else if (isObs)
                    {
                        var oshp = tshp as View.Shape_Observable;
                        oshp.EraseValues(false, true);
                    }
                }
                else
                {
                    // The user picked a descripton from the Excel data.
                    tshp.Description = newDesc;

                    // Try to update the shape's property fromm the existing
                    // data record:
                    if (isCog)
                    {
                        var dataCog = dd.Tasks.FirstCognitiveTask_ByDescOrNull(newDesc);
                        if(dataCog != null)
                            ViewModel.VisioWriter.UpdateTaskShapeFromData(tshp, dataCog, false);
                    }
                    else if (isObs)
                    {
                        var dataObs = dd.Tasks.FirstObservableTask_ByDescOrNull(newDesc);
                        if(dataObs != null)
                            ViewModel.VisioWriter.UpdateTaskShapeFromData(tshp, dataObs, false);
                    }

                }

            }

            // Write the new category, if necessary:

            // Update the category:
            if (frm.SelectedCategoryIsChanged)
            {
                // Change all like-named categories in the page:
                vdoc.Data.RenameCategory(initCat, newCat);
            }
            else if (newCat != initCat)
            {
                // Write the new category to this shape:
                tshp.Category = newCat;
            }
        }

        public static void RefreshShapesFromData()
        {
            // TODO

            // 1. Compare data to shapes on page
            // 2. Report some sort of count of "number of shapes that will be changed"
            // 3. Confirm with user that this is ok (or that nothing will change)
            // 4. Blast away!

            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            string msg = string.Empty;

            string path = vdoc.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (string.IsNullOrEmpty(path))
            {
                VL.UI.Msg.Show("Can't find data source, no refresh will take place.");
                return;
            }

            // Double-check with the user:
            msg = "This will reset the rating values for all task shapes in this document to the values stored in the current data source.\n" +
                  "Of course, if a task shape has no corresponding data record, then the ratings for that shape will remain unchanged.\n\n" +
                  "Would you like to continue?";
            if (VL.UI.Msg.ShowYesNo(msg) == false) return;

            string sUndoScopeName = "Refresh Rating Values from Data";

            // Just use an Action for a no-argument, no-return call:
            Action proc = vdoc.RestoreRatingValuesFromData;

            string sErrorMessage = String.Empty;

            // Do the command, pass in the "global" Visio object:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, Solution.VisApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(ClearIssueHighlights));
        }

        public static void AddShape_CognitiveTask()
        {
            _addShape(View.ShapeTypes.CognitiveTask);
        }
        public static void AddShape_Connector()
        {
            _addShape(View.ShapeTypes.Connector);
        }
        public static void AddShape_ObservableTask()
        {
            _addShape(View.ShapeTypes.ObservableTask);
        }
        private static void _addShape(
            View.ShapeTypes shapeType)
        {
            var pd = Solution.GetActiveSolutionDiagramPageOrNull();
            if (pd == null) return;
            Vis.Page visPg = pd.VisioPage;

            string sUndoScopeName = string.Empty;
            switch (shapeType)
            {
                case View.ShapeTypes.Other:
                    break;
                case View.ShapeTypes.CognitiveTask:
                    sUndoScopeName = "Add Cognitive Task";
                    break;
                case View.ShapeTypes.Connector:
                    sUndoScopeName = "Add CTA Connector";
                    break;
                case View.ShapeTypes.ObservableTask:
                    sUndoScopeName = "Add Observable Task";
                    break;
                default:
                    break;
            }

            // Define a shape-dropping object and the procedure to 
            // pass to the undo manager:
            var sd = new View.ShapeDropper(shapeType, visPg);

            View.VisioUndoManager.VisPageDelegate_Bool proc = sd.DropShape;
            string sErrorMessage = String.Empty;

            // Do the command:
            bool bResult = View.VisioUndoManager.ExecuteCommand(
                proc, visPg, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(_addShape));
        }

        public static void AddShape_Many()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            // Validate data source:
            if (_hasNoExcelDataWithUiWarning(vdoc)) return;

            var docdata = vdoc.Data;
            docdata.Refresh();

            // Get the in-data-source-only objects:
            var cogs = docdata.CognitiveTasksList_InDataOnly;
            var obs = docdata.ObservableTasksList_InDataOnly;

            // Check for ZERO total tasks:
            int iTot = cogs.Count + obs.Count;
            if (iTot == 0)
            {
                VL.UI.Msg.Show("There are no remaining tasks to be added to the diagram!");
                return;
            }

            // Convert them to object lists:
            var ocogs = new List<object>();
            foreach (var c in cogs) ocogs.Add((object)c);
            var oobs = new List<object>();
            foreach (var o in obs) oobs.Add((object)o);

            // Define the returned arrays of selected objects:
            List<object> selCogs, selObs;

            // Call the select tasks form:
            var dlgres =
                UI.SelectTasksForm.SelectTasks(
                    "Drop Tasks",
                    ocogs, oobs,
                    "Description", "Description",
                    out selCogs, out selObs);

            // Cancelled?
            if (dlgres == System.Windows.Forms.DialogResult.Cancel)
                return;

            // Nothing selected?
            int selectedTotal = selCogs.Count + selObs.Count;
            if (selectedTotal == 0)
                return;

            const int WarnCt = 30;
            if (selectedTotal > WarnCt)
            {
                string msg = "You have chosen to add " + selectedTotal +
                             " tasks at once. This may take a while.\n\nAre you sure you want to continue?";
                if (VL.UI.Msg.ShowYesNo(msg) == false)
                    return;
            }

            // Convert the selected objects to proper objects:
            var dcts = new List<Data.CognitiveTask>();
            foreach (var o in selCogs)
            {
                var c = o as Data.CognitiveTask;
                if (c != null) dcts.Add(c);
            }
            var octs = new List<Data.ObservableTask>();
            foreach (var o in selObs)
            {
                var ot = o as Data.ObservableTask;
                if (ot != null) octs.Add(ot);
            }

            // Drop some shapes!
            _vdocForDropMany = vdoc;
            _cogTaskDataListForDropMany = dcts;
            _obsTaskDataListForDropMany = octs;

            Action proc = _addShapes_Many;
            string sErrorMessage = String.Empty;

            // Do the command:
            string sUndoScopeName = "Drop Multiple Task Shapes";
            var visApp = Solution.VisApp;
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, visApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(AddShape_Many));
            
        }

        private static View.Doc _vdocForDropMany = null;
        private static List<Data.CognitiveTask> _cogTaskDataListForDropMany = null;
        private static List<Data.ObservableTask> _obsTaskDataListForDropMany = null;
        private static void _addShapes_Many()
        {
            _vdocForDropMany.AddShapes_Many(_cogTaskDataListForDropMany, _obsTaskDataListForDropMany, true, true);
        }

        //public static void UpdateTaskCategories()
        //{
        //    var pd = Solution.GetActiveSolutionDiagramPageOrNull();
        //    if (pd == null) return;
        //    Vis.Page visPg = pd.VisioPage;

        //    string sUndoScopeName = "Update Task Categories";

        //    View.VisioUndoManager.VisPageDelegate_Void proc = _updateTaskCategories;

        //    string sErrorMessage = String.Empty;

        //    // Do the command:
        //    bool bResult = View.VisioUndoManager.ExecuteCommand(
        //        proc, visPg, sUndoScopeName, out sErrorMessage);

        //    // Report any errors:
        //    if (bResult == false ||
        //        String.IsNullOrEmpty(sErrorMessage) == false)
        //        VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(UpdateTaskCategories));
        //}
        //private static void _updateTaskCategories(Vis.Page visPg)
        //{
        //    var pd = new View.Page_Diagram(visPg);
        //    pd.UpdateCategories();
        //}

        public static void ChangeTaskItem()
        {
            var cog = View.VisioSolutionHelpers.GetSelectedCognitiveTaskOrNull(Solution.VisApp);
            if(cog != null)
            {
                cog.TestSetIdAndDescription();
                return;
            }

            var obs = View.VisioSolutionHelpers.GetSelectedObservableTaskOrNull(Solution.VisApp);
            if (obs != null)
            {
                obs.TestSetIdAndDescription();
                return;
            }
        }

        public static void CheckDataSource()
        {
            var d = Solution.GetActiveSolutionDocOrNull();
            if(d == null)
            {
                VL.UI.Msg.Show("No appropriate document nor data source were found!");
            }
            else
            {
                string msg = d.GetDataSourceCheckReport();
                UI.ReportForm.Show(msg, String.Empty, .5, .5, 
                    Commands.CreateReportShape_WithUndo, 
                    true);
            }
        }

        public static void CopyExcelTemplate()
        {
            var d = Solution.GetActiveSolutionDocOrNull();
            if (d == null) return;

            string newFilepath, msg;
            if (d.CopyExcelTemplate(out newFilepath) == false)
            {
                Debug.WriteLine("Error in Commands.CopyExcelTemplate. The file was not copied or some reason.");
                msg = "There was an error copying the Excel template. No files were copied!";
                VL.UI.Msg.Show(msg);
            }
            else
            {
                msg = "The Excel template was successfully copied to:\n\n" + newFilepath +
                    "\n\nWould you like to view the directory in Explorer?";
                if(VL.UI.Msg.ShowYesNo(msg))
                {
                    _tryShowFolderForFileInExplorer(newFilepath);
                }
            }
        }
        public static void CopySampleExcel()
        {
            var d = Solution.GetActiveSolutionDocOrNull();
            if (d == null) return;

            string newFilepath, msg;
            if (d.CopySampleExcel(out newFilepath) == false)
            {
                Debug.WriteLine("Error in Commands.CopySampleExcel. The file was not copied or some reason.");
                msg = "There was an error copying the Excel sample file. No files were copied!";
                VL.UI.Msg.Show(msg);
            }
            else
            {
                msg = "The Excel sample file was successfully copied to:\n\n" + newFilepath +
                    "\n\nWould you like to view the directory in Explorer?";
                if (VL.UI.Msg.ShowYesNo(msg))
                {
                    _tryShowFolderForFileInExplorer(newFilepath);
                }
            }

        }
        private static void _tryShowFolderForFileInExplorer(string filepath)
        {
            try
            {
                FileInfo fi = new FileInfo(filepath);
                string directoryPath = fi.Directory.FullName;
                System.Diagnostics.Process.Start(directoryPath);
            }
            catch (Exception ex)
            {
                VL.UI.Msg.ShowError(ex.Message, nameof(Commands), nameof(_tryShowFolderForFileInExplorer));
            }
        }

        private static bool _hasNoExcelDataWithUiWarning(View.Doc vdoc)
        {
            if (vdoc.DataSourceExists) return false;
            VL.UI.Msg.Show("The data source is not set for this document!");
            return true;
        }



        public static void GotoConfigPage()
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            vdoc.TrySwitchActiveWindowToConfigPage();
        }


        public static void ViewDataSource()
        {
            var d = Solution.GetActiveSolutionDocOrNull();
            if (d == null) return;
            d.ViewDataSource();
        }

        public static void NewCtaDiagram()
        {
            // Open an unsaved copy of the Visio template:
            string path = Solution.Filepath_VisioTemplate;
            if (File.Exists(path))
            {
                Solution.VisApp.Documents.OpenEx(path, (short)Vis.VisOpenSaveArgs.visOpenCopy);
            }
            else
            {
                string msg = "The template file is missing. It should be at:\n\n" + path;
                VL.UI.Msg.Show(msg);
            }
        }

        public static void ShowAddinFolder()
        {
            // Offer to show the folder where the add-in is installed:
            string addinfolderPath = Solution.Folderpath_Addin;

            // Open that location in Explorer:
            if (System.IO.Directory.Exists(addinfolderPath))
            {
                System.Diagnostics.Process.Start(addinfolderPath);
            }
        }
        public static void ShowOptionsForm()
        {
            var frm = new UI.OptionsForm();
            frm.ShowDialog();
        }
        //public static void UpdateConnectorColorReferences()
        //{
        //    var pd = Solution.GetActiveSolutionDiagramPageOrNull();
        //    if (pd == null) return;
        //    Vis.Page visPg = pd.VisioPage;
        //    Vis.Application visApp = visPg.Application;

        //    string sUndoScopeName = "Update Connector Colors";

        //    Action proc = pd.UpdateConnectorColorReferences;
        //    //View.VisioUndoManager.VisPageDelegate_Void proc = _updateConnectorColorReferences;

        //    string sErrorMessage = String.Empty;

        //    // Do the command:
        //    bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
        //        proc, visApp, sUndoScopeName, out sErrorMessage);

        //    // Report any errors:
        //    if (bResult == false ||
        //        String.IsNullOrEmpty(sErrorMessage) == false)
        //        VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(UpdateConnectorColorReferences));
        //}

        /// Updates categories (by layer, container, and preceding
        /// observable tasks) and connector colors in one fell swoop. 
        /// This can be called from various other actions, so that the
        /// shapes get updated without the user having to explicitly 
        /// call the procedure.
        public static void UpdateCategoriesAndConnectorColors()
        {
            var pd = Solution.GetActiveSolutionDiagramPageOrNull();
            if (pd == null) return;
            Vis.Page visPg = pd.VisioPage;
            Vis.Application visApp = visPg.Application;

            string sUndoScopeName = "Update Task Categories Connector Colors";

            Action proc = _updateCategoriesAndConnectors;

            string sErrorMessage = String.Empty;

            // Do the command:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, visApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(UpdateCategoriesAndConnectorColors));
        }

        private static void _updateCategoriesAndConnectors()
        {
            var pd = Solution.GetActiveSolutionDiagramPageOrNull();
            if (pd == null) return;
            pd.UpdateConnectorColorReferences();
            pd.UpdateCategories();
        }

        public static void RefreshProgressBars(Vis.Page visPageOrNull)
        {
            View.Page_Diagram pd = Solution.GetActiveSolutionDiagramPageOrNull();
            if (pd == null) return;

            Vis.Page visPg = pd.VisioPage;
            Vis.Application visApp = visPg.Application;
            Action proc = pd.RefreshProgressBars;
            //View.VisioUndoManager.VisPageDelegate_Void

            string sUndoScopeName = "Refresh Progress Bars";

            string sErrorMessage = String.Empty;

            // Do the command:
            bool bResult = View.VisioUndoManager.ExecuteCommand_NoParameters(
                proc, visApp, sUndoScopeName, out sErrorMessage);

            // Report any errors:
            if (bResult == false ||
                String.IsNullOrEmpty(sErrorMessage) == false)
                    VL.UI.Msg.ShowError(sErrorMessage, nameof(Commands), nameof(RefreshProgressBars));
        }

        public static void ReportUnusedTasks(
            bool includeCognitiveTasks,
            bool includeObservableTasks)
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            View.Reports.Reports.ShowReportUnusedTasks(
                vdoc, includeCognitiveTasks, includeObservableTasks);
        }

        public static void ReportFlowOrder(
            bool includeCognitiveTasks,
            bool includeObservableTasks)
        {
            var vdoc = Solution.GetActiveSolutionDocOrNull();
            if (vdoc == null) return;

            View.Reports.Reports.ShowReportConnectionOrder(
                vdoc, includeCognitiveTasks, includeObservableTasks);                
        }

        public static void SaveToExcel()
        {
            var ptes = new View.PageToExcelSaver();
            if(ptes.TrySaveToExcel() == false)
            {
                // Show the message dump:
                string msg = ptes.Errors;

                UI.ReportForm.Show(msg, "Save Data to Excel", 0.3, 0.3,
                    Commands.CreateReportShape_WithUndo, true);
            }
            else
            {
                VL.UI.Msg.Show("Excel data successfully saved!\n" +
                                "(" + ptes.LastSavedPathToExcel + ")");
                return;
            }
   
        }

        public static void ShowHelp()
        {
            string path = Solution.Filepath_Help;
            if (System.IO.File.Exists(path))
            {
                System.Diagnostics.Process.Start(path);
            }
        }

    }
}
