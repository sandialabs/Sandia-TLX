﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.Windows;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    internal class SelectedShapeMatrixItem
    {
        public SelectedShapeMatrixItem(
            string propertyName,
            string shapeDataCellname,
            Vis.Cell visCellShapeData,
            bool isCognitive,
            bool isObservable)
        {
            this.PropertyName = propertyName;
            this.ShapeDataCellname = shapeDataCellname;
            this.ShapeDataCell = visCellShapeData;
            this.IsCognitive = isCognitive;
            this.IsObservable = isObservable;
        }

        internal string ShapeDataCellname { get; private set; }
        internal string PropertyName { get; private set; }
        internal Vis.Cell ShapeDataCell { get; set; }
        internal bool IsCognitive { get; private set; }
        internal bool IsObservable { get; private set; }
    }
    internal class SelectedShapeMatrixItems : Dictionary<String,SelectedShapeMatrixItem>
    {
        internal void AddItem(
            string propertyName_Key,
            string shapeDataCellname,
            Vis.Cell visCellShapeData,
            bool isCognitive,
            bool isObservable)
        {
            SelectedShapeMatrixItem item;
            if(this.ContainsKey(propertyName_Key))
            {
                // Remove any existing object by key:
                this.Remove(propertyName_Key);
                item = this[propertyName_Key];
            }

            // Create a new object:
            item = new SelectedShapeMatrixItem(
                propertyName_Key, shapeDataCellname, visCellShapeData, isCognitive, isObservable);

            // Add the item by key:
            this.Add(propertyName_Key, item);          
        }

        internal SelectedShapeMatrixItem ItemByShapeDataCellName(string shapeDataCellName)
        {
            foreach(string key in this.Keys)
            {
                var i = this[key];
                if (i.ShapeDataCellname.Equals(shapeDataCellName, 
                    StringComparison.InvariantCultureIgnoreCase))
                    return i;
            }
            return null;
        }
    }

    public class SelectedShape : ViewModel.ViewModelBase
    {
        private const string PropName_IsCognitiveTaskSelected = "IsCognitiveTaskSelected";
        private const string PropName_IsObservableTaskSelected = "IsObservableTaskSelected";
        private const string PropName_IsNoTaskSelected = "IsNoTaskSelected";

        private const string PropName_TaskNumber = "TaskNumber";
        private const string PropName_TaskDescription = "Description";
        private const string PropName_Task_Enjoyment = "Enjoyment";

        private const string PropName_Cog_MentalDemand = "MentalDemand";
        private const string PropName_Cog_PhysicalDemand = "PhysicalDemand";
        private const string PropName_Cog_TemporalDemand = "TemporalDemand";
        private const string PropName_Cog_Performance = "Performance";
        private const string PropName_Cog_Effort = "Effort";
        private const string PropName_Cog_Frustration = "Frustration";
        //private const string PropName_Cog_Enjoyment = "Enjoyment";

        private const string PropName_Obs_Importance = "Importance";
        private const string PropName_Obs_Difficulty = "Difficulty";
        private const string PropName_Obs_Duration = "Duration";
        private const string PropName_Obs_Frequency = "Frequency";
        private const string PropName_Obs_Complexity = "Complexity";
        //private const string PropName_Obs_Enjoyment = "Enjoyment";


        //PropName_Cog_MentalDemand
        //PropName_Cog_PhysicalDemand
        //PropName_Cog_TemporalDemand
        //PropName_Cog_Performance 
        //PropName_Cog_Effort 
        //PropName_Cog_Frustration 

        //PropName_Obs_Importance
        //PropName_Obs_Difficulty
        //PropName_Obs_Duration 
        //PropName_Obs_Frequency 
        //PropName_Obs_Complexity

        //private string PropCellList_Cognitive = 
        //    "Prop.MentalDemand,Prop.PhysicalDemand,Prop.TemporalDemand,Prop.Performance,Prop.Effort,Prop.Frustration";

        //private string PropCellList_Observable = 
        //    "Prop.Importance,Prop.Difficulty,Prop.Duration,Prop.Frequency,Prop.Complexity";

        private Vis.Shape _visShp = null;

        #region "INotifychanged Properties"

        private bool _isCognitiveTaskSelected = false;
        public bool IsCognitiveTaskSelected
        {
            get { return _isCognitiveTaskSelected; }
            set
            {
                _setSelectedTaskType(value, !value);
            }
        }
        private bool _isObservableTaskSelected = false;
        public bool IsObservableTaskSelected
        {
            get { return _isObservableTaskSelected; }
            set
            {
                _setSelectedTaskType(!value, value);
            }
        }
        private bool _isNoTaskSelected = true;
        public bool IsNoTaskSelected
        {
            get { return _isNoTaskSelected; }
            set
            {
                _setSelectedTaskType(!value, !value);
            }
        }
        private void _setSelectedTaskType(bool isCog, bool isObs)
        {
            if(_isCognitiveTaskSelected != isCog)
            {
                _isCognitiveTaskSelected = isCog;
                OnPropertyChanged(PropName_IsCognitiveTaskSelected);
            }
            if(_isObservableTaskSelected != isObs)
            {
                _isObservableTaskSelected = isObs;
                OnPropertyChanged(PropName_IsObservableTaskSelected);
            }

            bool isNoTask = (isCog == false && isObs == false);
            if(_isNoTaskSelected != isNoTask)
            {                
                _isNoTaskSelected = isNoTask;
                OnPropertyChanged(PropName_IsNoTaskSelected);
            }

            _updateCaptionOnSelectionChanged();
        }

        private void _updateCaptionOnSelectionChanged()
        {
            if (_isNoTaskSelected)
            {
                _caption = "Some Panel";
                OnPropertyChanged(nameof(Caption));
            }
            else
            {
                if (_isCognitiveTaskSelected)
                {
                    _caption = "TLX Ratings";
                }
                else
                {
                    _caption = "Factor Ratings";
                }
            }
            OnPropertyChanged(nameof(Caption));
        }


        #region "Common Shape Properties"

        private string _caption = String.Empty;
        public string Caption
        {
            get
            {
                return _caption;
            }
            set
            {
                _caption = value;
                OnPropertyChanged(nameof(Caption));
            }
        }

        public string TaskNumber
        {
            get
            {
                return _getVisioCellResultStr(nameof(TaskNumber));
            }
            set
            {
                string propname = nameof(TaskNumber);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Description
        {
            get
            {
                return _getVisioCellResultStr(nameof(Description));
            }
            set
            {
                string propname = nameof(Description);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Enjoyment
        {
            get
            {
                return _getVisioCellResultStr(nameof(Enjoyment));
            }
            set
            {
                string propname = nameof(Enjoyment);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        #endregion  "Common Shape Properties"

        #region "Cognitive Task Notifiable Properties"
        public string MentalDemand
        {
            get
            {
                return _getVisioCellResultStr(nameof(MentalDemand));
            }
            set
            {
                string propname = nameof(MentalDemand);
                if(_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string PhysicalDemand
        {
            get
            {
                return _getVisioCellResultStr(nameof(PhysicalDemand));
            }
            set
            {
                string propname = nameof(PhysicalDemand);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string TemporalDemand
        {
            get
            {
                return _getVisioCellResultStr(nameof(TemporalDemand));
            }
            set
            {
                string propname = nameof(TemporalDemand);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Performance
        {
            get
            {
                return _getVisioCellResultStr(nameof(Performance));
            }
            set
            {
                string propname = nameof(Performance);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Effort
        {
            get
            {
                return _getVisioCellResultStr(nameof(Effort));
            }
            set
            {
                string propname = nameof(Effort);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Frustration
        {
            get
            {
                return _getVisioCellResultStr(nameof(Frustration));
            }
            set
            {
                string propname = nameof(Frustration);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }

        //PropName_Cog_MentalDemand
        //PropName_Cog_PhysicalDemand
        //PropName_Cog_TemporalDemand
        //PropName_Cog_Performance 
        //PropName_Cog_Effort 
        //PropName_Cog_Frustration 
        #endregion  "Cognitive Task Notifiable Properties"

        #region "Observable Task Notifiable Properties"
        public string Importance
        {
            get
            {
                return _getVisioCellResultStr(nameof(Importance));
            }
            set
            {
                string propname = nameof(Importance);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Difficulty
        {
            get
            {
                return _getVisioCellResultStr(nameof(Difficulty));
            }
            set
            {
                string propname = nameof(Difficulty);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Duration
        {
            get
            {
                return _getVisioCellResultStr(nameof(Duration));
            }
            set
            {
                string propname = nameof(Duration);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Frequency
        {
            get
            {
                return _getVisioCellResultStr(nameof(Frequency));
            }
            set
            {
                string propname = nameof(Frequency);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        public string Complexity
        {
            get
            {
                return _getVisioCellResultStr(nameof(Complexity));
            }
            set
            {
                string propname = nameof(Complexity);
                if (_setVisioCellResultStr(propname, value))
                    OnPropertyChanged(propname);
            }
        }
        //PropName_Obs_Importance
        //PropName_Obs_Difficulty
        //PropName_Obs_Duration 
        //PropName_Obs_Frequency 
        //PropName_Obs_Complexity
        #endregion "Observable Task Notifiable Properties"

        private string _getVisioCellResultStr(string propertyName)
        {            
            if (!_itemsMatrix.ContainsKey(propertyName)) return String.Empty;
            if (_visShp == null) return String.Empty;
            if (_visShp.Stat == (short)Vis.VisStatCodes.visStatDeleted) return String.Empty;

            var i = _itemsMatrix[propertyName];
            Vis.Cell c = i.ShapeDataCell;
            if (c == null) return String.Empty;

            return c.ResultStrNoCast();

            //string cellname = i.ShapeDataCellname;            
            //string val = _visShp.TryGetCellResultStr(cellname);
            //return val;
        }

        private bool _setVisioCellResultStr(string propertyName, string value)
        {
            if (!_itemsMatrix.ContainsKey(propertyName)) return false;
            if (_visShp == null) return false;

            var i = _itemsMatrix[propertyName]; 

            Vis.Cell visCellValue = i.ShapeDataCell;
            if (visCellValue == null) return false;

            string f = _getShapeDataIndexFormula(visCellValue, value);
            return visCellValue.TryFormulaForceU(f);          
        }

        /// <summary>
        /// Attempts to build an INDEX(0,Prop.SomeProp.Format) style ShapeSheet
        /// formula, based on a Shape Data value cell name and a string value.
        /// </summary>
        /// <param name="cellname"></param>
        /// <param name="value"></param>
        /// <returns>Returns and INDEX formula if the value is found in the
        /// Format cell's string, otherwise returns a quote-encapsulated
        /// version of the passed-in string value.</returns>
        private string _getShapeDataIndexFormula(string propertyName, string value)
        {
            if (!_itemsMatrix.ContainsKey(propertyName)) return "\"" + value + "\"";

            var i = _itemsMatrix[propertyName];
            string cellname = i.ShapeDataCellname;

            Vis.Cell cValue = _visShp.CellOrNull(cellname);
            if (cValue == null) return "\"" + value + "\"";

            Vis.Cell cFormat = _visShp.CellsSRC[cValue.Section, cValue.Row,
                (short)Vis.VisCellIndices.visCustPropsFormat];

            string format = cFormat.ResultStrNoCastU();
            string[] formatItems = format.Split(';');

            int index = Array.FindIndex(formatItems, t => t.Equals(value, StringComparison.InvariantCultureIgnoreCase));
            if(index == -1) return "\"" + value + "\"";

            return "INDEX(" + index.ToString() + "," + cFormat.Name + ")";
        }
        private string _getShapeDataIndexFormula(Vis.Cell visCellValue, string value)
        {
            string quotedValue = "\"" + value + "\"";
            if (visCellValue == null) return quotedValue;

            Vis.Cell cFormat = _visShp.CellsSRC[visCellValue.Section, visCellValue.Row,
                (short)Vis.VisCellIndices.visCustPropsFormat];

            string format = cFormat.ResultStrNoCastU();
            string[] formatItems = format.Split(';');

            int index = Array.FindIndex(formatItems, t => t.Equals(value, StringComparison.InvariantCultureIgnoreCase));
            if (index == -1) return quotedValue;

            return "INDEX(" + index.ToString() + "," + cFormat.Name + ")";
        }

        #endregion


        public SelectedShape(Vis.Shape visShp)
        {
            _initMatrix();
            if (visShp != null)
                _init(visShp);
        }

        public void UpdateShape(Vis.Shape visShp)
        {
            _init(visShp);
            _refreshPropertyValues(visShp);
        }

        private SelectedShapeMatrixItems _itemsMatrix = null;
        private void _initMatrix()
        {
            // Create a matrix of objects to make it easier to find
            // Visio cells, property names, shape data cell names, etc,
            // without having to hard code everything.

            _itemsMatrix = new SelectedShapeMatrixItems();

            _itemsMatrix.AddItem(PropName_TaskNumber, "Prop." + PropName_TaskNumber, null, true, true);
            _itemsMatrix.AddItem(PropName_TaskDescription, "Prop." + PropName_TaskDescription, null, true, true);
            _itemsMatrix.AddItem(PropName_Task_Enjoyment, "Prop." + PropName_Task_Enjoyment, null, true, true);

            _itemsMatrix.AddItem(PropName_Cog_MentalDemand, "Prop." + PropName_Cog_MentalDemand, null, true, false);
            _itemsMatrix.AddItem(PropName_Cog_PhysicalDemand, "Prop." + PropName_Cog_PhysicalDemand, null, true, false);
            _itemsMatrix.AddItem(PropName_Cog_TemporalDemand, "Prop." + PropName_Cog_TemporalDemand, null, true, false);
            _itemsMatrix.AddItem(PropName_Cog_Performance, "Prop." + PropName_Cog_Performance, null, true, false);
            _itemsMatrix.AddItem(PropName_Cog_Effort, "Prop." + PropName_Cog_Effort, null, true, false);
            _itemsMatrix.AddItem(PropName_Cog_Frustration, "Prop." + PropName_Cog_Frustration, null, true, false);
            //_itemsMatrix.AddItem(PropName_Cog_Enjoyment, "Prop." + PropName_Cog_Enjoyment, null, true, false);

            _itemsMatrix.AddItem(PropName_Obs_Importance, "Prop." + PropName_Obs_Importance, null, false, true);
            _itemsMatrix.AddItem(PropName_Obs_Difficulty, "Prop." + PropName_Obs_Difficulty, null, false, true);
            _itemsMatrix.AddItem(PropName_Obs_Duration, "Prop." + PropName_Obs_Duration, null, false, true);
            _itemsMatrix.AddItem(PropName_Obs_Frequency, "Prop." + PropName_Obs_Frequency, null, false, true);
            _itemsMatrix.AddItem(PropName_Obs_Complexity, "Prop." + PropName_Obs_Complexity, null, false, true);
            //_itemsMatrix.AddItem(PropName_Obs_Enjoyment, "Prop." + PropName_Obs_Enjoyment, null, true, false);
        }

        private void _init(Vis.Shape visShp)
        {
            // Deregister all events...
            //_deregisterCellChangedEvents();

            if (visShp == null)
            {
                _updateCellEvents(null, false, false);
                this.IsNoTaskSelected = true;
                return;
            }

            // Keep the new shape:
            _visShp = visShp;            
            if (View.VisioSolutionHelpers.IsCognitiveShape(visShp))
            {
                _updateCellEvents(_visShp, true, false);
                this.IsCognitiveTaskSelected = true;
            }
            else if (View.VisioSolutionHelpers.IsObservableShape(visShp))
            {
                _updateCellEvents(_visShp, false, true);
                this.IsObservableTaskSelected = true;
            }
        }

        private void _deregisterCellChangedEvents() //ref Vis.Cell visCell)
        {
            foreach(var item in _itemsMatrix.Values)
            {
                Vis.Cell c = item.ShapeDataCell;
                if(c != null)
                {
                    c.CellChanged -= CellChanged;
                    c = null;
                }
            }
        }

        private void _deregisterCellChangedEvent(ref Vis.Cell visCell)
        {
            if (visCell == null) return;
            visCell.CellChanged -= CellChanged;
            visCell = null;
        }
        private void _refreshPropertyValues(Vis.Shape visShp)
        {
            // Ok, since the properties have get/set, this is
            // all we have to do!
            OnPropertyChanged(PropName_TaskNumber);
            OnPropertyChanged(PropName_TaskDescription);
            OnPropertyChanged(PropName_Task_Enjoyment);

            OnPropertyChanged(PropName_Cog_MentalDemand);
            OnPropertyChanged(PropName_Cog_PhysicalDemand);
            OnPropertyChanged(PropName_Cog_TemporalDemand);
            OnPropertyChanged(PropName_Cog_Performance);
            OnPropertyChanged(PropName_Cog_Effort);
            OnPropertyChanged(PropName_Cog_Frustration);
            //OnPropertyChanged(PropName_Cog_Enjoyment);

            OnPropertyChanged(PropName_Obs_Importance);
            OnPropertyChanged(PropName_Obs_Difficulty);
            OnPropertyChanged(PropName_Obs_Duration);
            OnPropertyChanged(PropName_Obs_Frequency);
            OnPropertyChanged(PropName_Obs_Complexity);
            //OnPropertyChanged(PropName_Obs_Enjoyment);

            // TODO: have this._itemsMatrix somehow be able to refresh
            // property values automagically as well, so we don't have to
            // have all this text duplication.
            //this.MentalDemand = _getValueFromShape(PropName_Cog_MentalDemand, visShp);
            //this.PhysicalDemand = _getValueFromShape(PropName_Cog_PhysicalDemand, visShp);
            //this.TemporalDemand = _getValueFromShape(PropName_Cog_TemporalDemand, visShp);
            //this.Performance = _getValueFromShape(PropName_Cog_Performance, visShp);
            //this.Effort = _getValueFromShape(PropName_Cog_Effort, visShp);
            //this.Frustration = _getValueFromShape(PropName_Cog_Frustration, visShp);
            //this.Importance = _getValueFromShape(PropName_Obs_Importance, visShp);
            //this.Difficulty = _getValueFromShape(PropName_Obs_Difficulty, visShp);
            //this.Duration = _getValueFromShape(PropName_Obs_Duration, visShp);
            //this.Frequency = _getValueFromShape(PropName_Obs_Frequency, visShp);
            //this.Complexity = _getValueFromShape(PropName_Obs_Complexity, visShp);
        }

        private void _registerCellChangedEvent(ref Vis.Cell visCell)
        {
            if (visCell == null) return;
            visCell.CellChanged += CellChanged;
        }

        private void _updateCellEvents(
            Vis.Shape visShpOrNull, bool isCognitive, bool isObservable)
        {
            _deregisterCellChangedEvents();

            if (visShpOrNull == null) return;

            foreach (var item in _itemsMatrix.Values)
            {
                if( (item.IsCognitive && isCognitive) ||
                    (item.IsObservable && isObservable) )
                {
                    Vis.Cell visCell = visShpOrNull.CellOrNull(item.ShapeDataCellname);

                    if (visCell != null)
                    {
                        if (visCell == null) return;
                        visCell.CellChanged += CellChanged;
                        item.ShapeDataCell = visCell;

                        // TODO: I think we need to update the value here...
                    }
                }
            }
        }

        private void CellChanged(Vis.Cell Cell)
        {
            // Get a matrix item by Cell's name:
            var i = _itemsMatrix.ItemByShapeDataCellName(Cell.Name);
            if (i == null) return;

            // Simplify notify the world that the corresponding 
            // property changed:
            OnPropertyChanged(i.PropertyName);
        }
    }
}
