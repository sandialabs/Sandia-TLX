﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    partial class ViewDiagramDataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView_Cognitive = new System.Windows.Forms.DataGridView();
            this.dataGridView_Observable = new System.Windows.Forms.DataGridView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cognitiveTaskBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.observableTaskBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taskNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isInExcelDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isInVisioDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.mentalDemandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.physicalDemandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.temporalDemandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.performanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.effortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frustrationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Enjoyment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryLayerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryContainerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isChangedDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isNewDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isRenamedDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.taskNumberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isInExcelDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isInVisioDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.importanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.difficultyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frequencyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.complexityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryLayerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryContainerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isChangedDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isNewDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.isRenamedDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Cognitive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Observable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cognitiveTaskBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.observableTaskBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_Cognitive
            // 
            this.dataGridView_Cognitive.AllowUserToAddRows = false;
            this.dataGridView_Cognitive.AllowUserToDeleteRows = false;
            this.dataGridView_Cognitive.AutoGenerateColumns = false;
            this.dataGridView_Cognitive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Cognitive.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.taskNumberDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.isInExcelDataGridViewCheckBoxColumn,
            this.isInVisioDataGridViewCheckBoxColumn,
            this.mentalDemandDataGridViewTextBoxColumn,
            this.physicalDemandDataGridViewTextBoxColumn,
            this.temporalDemandDataGridViewTextBoxColumn,
            this.performanceDataGridViewTextBoxColumn,
            this.effortDataGridViewTextBoxColumn,
            this.frustrationDataGridViewTextBoxColumn,
            this.Enjoyment,
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn,
            this.categoryLayerDataGridViewTextBoxColumn,
            this.categoryContainerDataGridViewTextBoxColumn,
            this.isChangedDataGridViewCheckBoxColumn,
            this.isNewDataGridViewCheckBoxColumn,
            this.isRenamedDataGridViewCheckBoxColumn});
            this.dataGridView_Cognitive.DataSource = this.cognitiveTaskBindingSource;
            this.dataGridView_Cognitive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_Cognitive.Location = new System.Drawing.Point(0, 17);
            this.dataGridView_Cognitive.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView_Cognitive.Name = "dataGridView_Cognitive";
            this.dataGridView_Cognitive.ReadOnly = true;
            this.dataGridView_Cognitive.Size = new System.Drawing.Size(1704, 395);
            this.dataGridView_Cognitive.TabIndex = 0;
            // 
            // dataGridView_Observable
            // 
            this.dataGridView_Observable.AllowUserToAddRows = false;
            this.dataGridView_Observable.AllowUserToDeleteRows = false;
            this.dataGridView_Observable.AutoGenerateColumns = false;
            this.dataGridView_Observable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Observable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.taskNumberDataGridViewTextBoxColumn1,
            this.descriptionDataGridViewTextBoxColumn1,
            this.isInExcelDataGridViewCheckBoxColumn1,
            this.isInVisioDataGridViewCheckBoxColumn1,
            this.importanceDataGridViewTextBoxColumn,
            this.difficultyDataGridViewTextBoxColumn,
            this.durationDataGridViewTextBoxColumn,
            this.frequencyDataGridViewTextBoxColumn,
            this.complexityDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.categoryDataGridViewTextBoxColumn1,
            this.categoryLayerDataGridViewTextBoxColumn1,
            this.categoryContainerDataGridViewTextBoxColumn1,
            this.isChangedDataGridViewCheckBoxColumn1,
            this.isNewDataGridViewCheckBoxColumn1,
            this.isRenamedDataGridViewCheckBoxColumn1});
            this.dataGridView_Observable.DataSource = this.observableTaskBindingSource;
            this.dataGridView_Observable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_Observable.Location = new System.Drawing.Point(0, 17);
            this.dataGridView_Observable.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView_Observable.Name = "dataGridView_Observable";
            this.dataGridView_Observable.ReadOnly = true;
            this.dataGridView_Observable.Size = new System.Drawing.Size(1704, 392);
            this.dataGridView_Observable.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(4, 4);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView_Cognitive);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView_Observable);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Size = new System.Drawing.Size(1704, 826);
            this.splitContainer1.SplitterDistance = 412;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cognitive Tasks";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Observable Tasks";
            // 
            // cognitiveTaskBindingSource
            // 
            this.cognitiveTaskBindingSource.DataSource = typeof(SNL_Cognitive_Task_Analysis_Visio_Add_in.Data.CognitiveTask);
            // 
            // observableTaskBindingSource
            // 
            this.observableTaskBindingSource.DataSource = typeof(SNL_Cognitive_Task_Analysis_Visio_Add_in.Data.ObservableTask);
            // 
            // taskNumberDataGridViewTextBoxColumn
            // 
            this.taskNumberDataGridViewTextBoxColumn.DataPropertyName = "TaskNumber";
            this.taskNumberDataGridViewTextBoxColumn.HeaderText = "TaskNumber";
            this.taskNumberDataGridViewTextBoxColumn.Name = "taskNumberDataGridViewTextBoxColumn";
            this.taskNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // isInExcelDataGridViewCheckBoxColumn
            // 
            this.isInExcelDataGridViewCheckBoxColumn.DataPropertyName = "IsInExcel";
            this.isInExcelDataGridViewCheckBoxColumn.HeaderText = "IsInExcel";
            this.isInExcelDataGridViewCheckBoxColumn.Name = "isInExcelDataGridViewCheckBoxColumn";
            this.isInExcelDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // isInVisioDataGridViewCheckBoxColumn
            // 
            this.isInVisioDataGridViewCheckBoxColumn.DataPropertyName = "IsInVisio";
            this.isInVisioDataGridViewCheckBoxColumn.HeaderText = "IsInVisio";
            this.isInVisioDataGridViewCheckBoxColumn.Name = "isInVisioDataGridViewCheckBoxColumn";
            this.isInVisioDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // mentalDemandDataGridViewTextBoxColumn
            // 
            this.mentalDemandDataGridViewTextBoxColumn.DataPropertyName = "MentalDemand";
            this.mentalDemandDataGridViewTextBoxColumn.HeaderText = "MentalDemand";
            this.mentalDemandDataGridViewTextBoxColumn.Name = "mentalDemandDataGridViewTextBoxColumn";
            this.mentalDemandDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // physicalDemandDataGridViewTextBoxColumn
            // 
            this.physicalDemandDataGridViewTextBoxColumn.DataPropertyName = "PhysicalDemand";
            this.physicalDemandDataGridViewTextBoxColumn.HeaderText = "PhysicalDemand";
            this.physicalDemandDataGridViewTextBoxColumn.Name = "physicalDemandDataGridViewTextBoxColumn";
            this.physicalDemandDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // temporalDemandDataGridViewTextBoxColumn
            // 
            this.temporalDemandDataGridViewTextBoxColumn.DataPropertyName = "TemporalDemand";
            this.temporalDemandDataGridViewTextBoxColumn.HeaderText = "TemporalDemand";
            this.temporalDemandDataGridViewTextBoxColumn.Name = "temporalDemandDataGridViewTextBoxColumn";
            this.temporalDemandDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // performanceDataGridViewTextBoxColumn
            // 
            this.performanceDataGridViewTextBoxColumn.DataPropertyName = "Performance";
            this.performanceDataGridViewTextBoxColumn.HeaderText = "Performance";
            this.performanceDataGridViewTextBoxColumn.Name = "performanceDataGridViewTextBoxColumn";
            this.performanceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // effortDataGridViewTextBoxColumn
            // 
            this.effortDataGridViewTextBoxColumn.DataPropertyName = "Effort";
            this.effortDataGridViewTextBoxColumn.HeaderText = "Effort";
            this.effortDataGridViewTextBoxColumn.Name = "effortDataGridViewTextBoxColumn";
            this.effortDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // frustrationDataGridViewTextBoxColumn
            // 
            this.frustrationDataGridViewTextBoxColumn.DataPropertyName = "Frustration";
            this.frustrationDataGridViewTextBoxColumn.HeaderText = "Frustration";
            this.frustrationDataGridViewTextBoxColumn.Name = "frustrationDataGridViewTextBoxColumn";
            this.frustrationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Enjoyment
            // 
            this.Enjoyment.DataPropertyName = "Enjoyment";
            this.Enjoyment.HeaderText = "Enjoyment";
            this.Enjoyment.Name = "Enjoyment";
            this.Enjoyment.ReadOnly = true;
            // 
            // categoryNearestObservableTaskDataGridViewTextBoxColumn
            // 
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn.DataPropertyName = "Category_NearestObservableTask";
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn.HeaderText = "Category_NearestObservableTask";
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn.Name = "categoryNearestObservableTaskDataGridViewTextBoxColumn";
            this.categoryNearestObservableTaskDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryLayerDataGridViewTextBoxColumn
            // 
            this.categoryLayerDataGridViewTextBoxColumn.DataPropertyName = "Category_Layer";
            this.categoryLayerDataGridViewTextBoxColumn.HeaderText = "Category_Layer";
            this.categoryLayerDataGridViewTextBoxColumn.Name = "categoryLayerDataGridViewTextBoxColumn";
            this.categoryLayerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryContainerDataGridViewTextBoxColumn
            // 
            this.categoryContainerDataGridViewTextBoxColumn.DataPropertyName = "Category_Container";
            this.categoryContainerDataGridViewTextBoxColumn.HeaderText = "Category_Container";
            this.categoryContainerDataGridViewTextBoxColumn.Name = "categoryContainerDataGridViewTextBoxColumn";
            this.categoryContainerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // isChangedDataGridViewCheckBoxColumn
            // 
            this.isChangedDataGridViewCheckBoxColumn.DataPropertyName = "IsChanged";
            this.isChangedDataGridViewCheckBoxColumn.HeaderText = "IsChanged";
            this.isChangedDataGridViewCheckBoxColumn.Name = "isChangedDataGridViewCheckBoxColumn";
            this.isChangedDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // isNewDataGridViewCheckBoxColumn
            // 
            this.isNewDataGridViewCheckBoxColumn.DataPropertyName = "IsNew";
            this.isNewDataGridViewCheckBoxColumn.HeaderText = "IsNew";
            this.isNewDataGridViewCheckBoxColumn.Name = "isNewDataGridViewCheckBoxColumn";
            this.isNewDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // isRenamedDataGridViewCheckBoxColumn
            // 
            this.isRenamedDataGridViewCheckBoxColumn.DataPropertyName = "IsRenamed";
            this.isRenamedDataGridViewCheckBoxColumn.HeaderText = "IsRenamed";
            this.isRenamedDataGridViewCheckBoxColumn.Name = "isRenamedDataGridViewCheckBoxColumn";
            this.isRenamedDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // taskNumberDataGridViewTextBoxColumn1
            // 
            this.taskNumberDataGridViewTextBoxColumn1.DataPropertyName = "TaskNumber";
            this.taskNumberDataGridViewTextBoxColumn1.HeaderText = "TaskNumber";
            this.taskNumberDataGridViewTextBoxColumn1.Name = "taskNumberDataGridViewTextBoxColumn1";
            this.taskNumberDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn1
            // 
            this.descriptionDataGridViewTextBoxColumn1.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn1.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn1.Name = "descriptionDataGridViewTextBoxColumn1";
            this.descriptionDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // isInExcelDataGridViewCheckBoxColumn1
            // 
            this.isInExcelDataGridViewCheckBoxColumn1.DataPropertyName = "IsInExcel";
            this.isInExcelDataGridViewCheckBoxColumn1.HeaderText = "IsInExcel";
            this.isInExcelDataGridViewCheckBoxColumn1.Name = "isInExcelDataGridViewCheckBoxColumn1";
            this.isInExcelDataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // isInVisioDataGridViewCheckBoxColumn1
            // 
            this.isInVisioDataGridViewCheckBoxColumn1.DataPropertyName = "IsInVisio";
            this.isInVisioDataGridViewCheckBoxColumn1.HeaderText = "IsInVisio";
            this.isInVisioDataGridViewCheckBoxColumn1.Name = "isInVisioDataGridViewCheckBoxColumn1";
            this.isInVisioDataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // importanceDataGridViewTextBoxColumn
            // 
            this.importanceDataGridViewTextBoxColumn.DataPropertyName = "Importance";
            this.importanceDataGridViewTextBoxColumn.HeaderText = "Importance";
            this.importanceDataGridViewTextBoxColumn.Name = "importanceDataGridViewTextBoxColumn";
            this.importanceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // difficultyDataGridViewTextBoxColumn
            // 
            this.difficultyDataGridViewTextBoxColumn.DataPropertyName = "Difficulty";
            this.difficultyDataGridViewTextBoxColumn.HeaderText = "Difficulty";
            this.difficultyDataGridViewTextBoxColumn.Name = "difficultyDataGridViewTextBoxColumn";
            this.difficultyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // durationDataGridViewTextBoxColumn
            // 
            this.durationDataGridViewTextBoxColumn.DataPropertyName = "Duration";
            this.durationDataGridViewTextBoxColumn.HeaderText = "Duration";
            this.durationDataGridViewTextBoxColumn.Name = "durationDataGridViewTextBoxColumn";
            this.durationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // frequencyDataGridViewTextBoxColumn
            // 
            this.frequencyDataGridViewTextBoxColumn.DataPropertyName = "Frequency";
            this.frequencyDataGridViewTextBoxColumn.HeaderText = "Frequency";
            this.frequencyDataGridViewTextBoxColumn.Name = "frequencyDataGridViewTextBoxColumn";
            this.frequencyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // complexityDataGridViewTextBoxColumn
            // 
            this.complexityDataGridViewTextBoxColumn.DataPropertyName = "Complexity";
            this.complexityDataGridViewTextBoxColumn.HeaderText = "Complexity";
            this.complexityDataGridViewTextBoxColumn.Name = "complexityDataGridViewTextBoxColumn";
            this.complexityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Enjoyment";
            this.dataGridViewTextBoxColumn1.HeaderText = "Enjoyment";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // categoryDataGridViewTextBoxColumn1
            // 
            this.categoryDataGridViewTextBoxColumn1.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn1.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn1.Name = "categoryDataGridViewTextBoxColumn1";
            this.categoryDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // categoryLayerDataGridViewTextBoxColumn1
            // 
            this.categoryLayerDataGridViewTextBoxColumn1.DataPropertyName = "Category_Layer";
            this.categoryLayerDataGridViewTextBoxColumn1.HeaderText = "Category_Layer";
            this.categoryLayerDataGridViewTextBoxColumn1.Name = "categoryLayerDataGridViewTextBoxColumn1";
            this.categoryLayerDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // categoryContainerDataGridViewTextBoxColumn1
            // 
            this.categoryContainerDataGridViewTextBoxColumn1.DataPropertyName = "Category_Container";
            this.categoryContainerDataGridViewTextBoxColumn1.HeaderText = "Category_Container";
            this.categoryContainerDataGridViewTextBoxColumn1.Name = "categoryContainerDataGridViewTextBoxColumn1";
            this.categoryContainerDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // isChangedDataGridViewCheckBoxColumn1
            // 
            this.isChangedDataGridViewCheckBoxColumn1.DataPropertyName = "IsChanged";
            this.isChangedDataGridViewCheckBoxColumn1.HeaderText = "IsChanged";
            this.isChangedDataGridViewCheckBoxColumn1.Name = "isChangedDataGridViewCheckBoxColumn1";
            this.isChangedDataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // isNewDataGridViewCheckBoxColumn1
            // 
            this.isNewDataGridViewCheckBoxColumn1.DataPropertyName = "IsNew";
            this.isNewDataGridViewCheckBoxColumn1.HeaderText = "IsNew";
            this.isNewDataGridViewCheckBoxColumn1.Name = "isNewDataGridViewCheckBoxColumn1";
            this.isNewDataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // isRenamedDataGridViewCheckBoxColumn1
            // 
            this.isRenamedDataGridViewCheckBoxColumn1.DataPropertyName = "IsRenamed";
            this.isRenamedDataGridViewCheckBoxColumn1.HeaderText = "IsRenamed";
            this.isRenamedDataGridViewCheckBoxColumn1.Name = "isRenamedDataGridViewCheckBoxColumn1";
            this.isRenamedDataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // ViewDiagramDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1712, 881);
            this.Controls.Add(this.splitContainer1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewDiagramDataForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ViewDiagramDataForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Cognitive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Observable)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cognitiveTaskBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.observableTaskBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_Cognitive;
        private System.Windows.Forms.DataGridView dataGridView_Observable;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource cognitiveTaskBindingSource;
        private System.Windows.Forms.BindingSource observableTaskBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn Enjoyment;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isRenamedDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isNewDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isChangedDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryContainerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryLayerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn complexityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn frequencyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn durationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn difficultyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn importanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isInVisioDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isInExcelDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn taskNumberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isRenamedDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isNewDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isChangedDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryContainerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryLayerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryNearestObservableTaskDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn frustrationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn effortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn performanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn temporalDemandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn physicalDemandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mentalDemandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isInVisioDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isInExcelDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn taskNumberDataGridViewTextBoxColumn;
    }
}