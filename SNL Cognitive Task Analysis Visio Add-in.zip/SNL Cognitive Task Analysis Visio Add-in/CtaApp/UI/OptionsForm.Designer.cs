﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    partial class OptionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_OK = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label_DataGraphicName_01 = new System.Windows.Forms.Label();
            this.label_DataGraphicName_02 = new System.Windows.Forms.Label();
            this.label_DataGraphicName_03 = new System.Windows.Forms.Label();
            this.label_DataGraphicName_04 = new System.Windows.Forms.Label();
            this.textBox_DataGraphicName_04 = new System.Windows.Forms.TextBox();
            this.textBox_DataGraphicName_03 = new System.Windows.Forms.TextBox();
            this.textBox_DataGraphicName_02 = new System.Windows.Forms.TextBox();
            this.textBox_DataGraphicName_01 = new System.Windows.Forms.TextBox();
            this.checkBox_autoOpenTliPanel = new System.Windows.Forms.CheckBox();
            this.button_Defaults = new System.Windows.Forms.Button();
            this.checkBox_DevMode = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // button_OK
            // 
            this.button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_OK.AutoSize = true;
            this.button_OK.Location = new System.Drawing.Point(255, 298);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(75, 23);
            this.button_OK.TabIndex = 1;
            this.button_OK.Text = "OK";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cancel.AutoSize = true;
            this.button_Cancel.Location = new System.Drawing.Point(255, 327);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(75, 23);
            this.button_Cancel.TabIndex = 2;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(9, 229);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Show Add-in Folder...";
            this.toolTip1.SetToolTip(this.button1, "Open this add-in\'s installation folder in Windows Explorer");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_DataGraphicName_01
            // 
            this.label_DataGraphicName_01.AutoSize = true;
            this.label_DataGraphicName_01.Location = new System.Drawing.Point(9, 106);
            this.label_DataGraphicName_01.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DataGraphicName_01.Name = "label_DataGraphicName_01";
            this.label_DataGraphicName_01.Size = new System.Drawing.Size(120, 13);
            this.label_DataGraphicName_01.TabIndex = 4;
            this.label_DataGraphicName_01.Text = "Data Graphic Name #1:";
            // 
            // label_DataGraphicName_02
            // 
            this.label_DataGraphicName_02.AutoSize = true;
            this.label_DataGraphicName_02.Location = new System.Drawing.Point(9, 128);
            this.label_DataGraphicName_02.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DataGraphicName_02.Name = "label_DataGraphicName_02";
            this.label_DataGraphicName_02.Size = new System.Drawing.Size(120, 13);
            this.label_DataGraphicName_02.TabIndex = 4;
            this.label_DataGraphicName_02.Text = "Data Graphic Name #2:";
            // 
            // label_DataGraphicName_03
            // 
            this.label_DataGraphicName_03.AutoSize = true;
            this.label_DataGraphicName_03.Location = new System.Drawing.Point(9, 152);
            this.label_DataGraphicName_03.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DataGraphicName_03.Name = "label_DataGraphicName_03";
            this.label_DataGraphicName_03.Size = new System.Drawing.Size(120, 13);
            this.label_DataGraphicName_03.TabIndex = 4;
            this.label_DataGraphicName_03.Text = "Data Graphic Name #3:";
            // 
            // label_DataGraphicName_04
            // 
            this.label_DataGraphicName_04.AutoSize = true;
            this.label_DataGraphicName_04.Location = new System.Drawing.Point(9, 174);
            this.label_DataGraphicName_04.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DataGraphicName_04.Name = "label_DataGraphicName_04";
            this.label_DataGraphicName_04.Size = new System.Drawing.Size(120, 13);
            this.label_DataGraphicName_04.TabIndex = 4;
            this.label_DataGraphicName_04.Text = "Data Graphic Name #4:";
            // 
            // textBox_DataGraphicName_04
            // 
            this.textBox_DataGraphicName_04.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DataGraphicName_04.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "DataGraphicName04", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textBox_DataGraphicName_04.Location = new System.Drawing.Point(128, 171);
            this.textBox_DataGraphicName_04.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_DataGraphicName_04.Name = "textBox_DataGraphicName_04";
            this.textBox_DataGraphicName_04.Size = new System.Drawing.Size(206, 20);
            this.textBox_DataGraphicName_04.TabIndex = 5;
            this.textBox_DataGraphicName_04.Text = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.DataGraphicName04;
            // 
            // textBox_DataGraphicName_03
            // 
            this.textBox_DataGraphicName_03.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DataGraphicName_03.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "DataGraphicName03", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textBox_DataGraphicName_03.Location = new System.Drawing.Point(128, 149);
            this.textBox_DataGraphicName_03.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_DataGraphicName_03.Name = "textBox_DataGraphicName_03";
            this.textBox_DataGraphicName_03.Size = new System.Drawing.Size(206, 20);
            this.textBox_DataGraphicName_03.TabIndex = 5;
            this.textBox_DataGraphicName_03.Text = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.DataGraphicName03;
            // 
            // textBox_DataGraphicName_02
            // 
            this.textBox_DataGraphicName_02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DataGraphicName_02.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "DataGraphicName02", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textBox_DataGraphicName_02.Location = new System.Drawing.Point(128, 126);
            this.textBox_DataGraphicName_02.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_DataGraphicName_02.Name = "textBox_DataGraphicName_02";
            this.textBox_DataGraphicName_02.Size = new System.Drawing.Size(206, 20);
            this.textBox_DataGraphicName_02.TabIndex = 5;
            this.textBox_DataGraphicName_02.Text = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.DataGraphicName02;
            // 
            // textBox_DataGraphicName_01
            // 
            this.textBox_DataGraphicName_01.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DataGraphicName_01.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "DataGraphicName01", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textBox_DataGraphicName_01.Location = new System.Drawing.Point(128, 103);
            this.textBox_DataGraphicName_01.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_DataGraphicName_01.Name = "textBox_DataGraphicName_01";
            this.textBox_DataGraphicName_01.Size = new System.Drawing.Size(206, 20);
            this.textBox_DataGraphicName_01.TabIndex = 5;
            this.textBox_DataGraphicName_01.Text = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.DataGraphicName01;
            // 
            // checkBox_autoOpenTliPanel
            // 
            this.checkBox_autoOpenTliPanel.AutoSize = true;
            this.checkBox_autoOpenTliPanel.Checked = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.AutoShowTliPanelOnDocOpen;
            this.checkBox_autoOpenTliPanel.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "AutoShowTliPanelOnDocOpen", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox_autoOpenTliPanel.Location = new System.Drawing.Point(11, 63);
            this.checkBox_autoOpenTliPanel.Name = "checkBox_autoOpenTliPanel";
            this.checkBox_autoOpenTliPanel.Size = new System.Drawing.Size(277, 17);
            this.checkBox_autoOpenTliPanel.TabIndex = 0;
            this.checkBox_autoOpenTliPanel.Text = "Automatically show TLX pane when documents open";
            this.checkBox_autoOpenTliPanel.UseVisualStyleBackColor = true;
            // 
            // button_Defaults
            // 
            this.button_Defaults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Defaults.AutoSize = true;
            this.button_Defaults.Location = new System.Drawing.Point(9, 327);
            this.button_Defaults.Name = "button_Defaults";
            this.button_Defaults.Size = new System.Drawing.Size(145, 23);
            this.button_Defaults.TabIndex = 6;
            this.button_Defaults.Text = "Restore Default Settings";
            this.toolTip1.SetToolTip(this.button_Defaults, "Restore default settings");
            this.button_Defaults.UseVisualStyleBackColor = true;
            this.button_Defaults.Click += new System.EventHandler(this.button_Defaults_Click);
            // 
            // checkBox_DevMode
            // 
            this.checkBox_DevMode.AutoSize = true;
            this.checkBox_DevMode.Checked = global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default.IsDeveloperMode;
            this.checkBox_DevMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_DevMode.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::SNL_Cognitive_Task_Analysis_Visio_Add_in.Properties.Settings.Default, "IsDeveloperMode", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox_DevMode.Location = new System.Drawing.Point(11, 40);
            this.checkBox_DevMode.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox_DevMode.Name = "checkBox_DevMode";
            this.checkBox_DevMode.Size = new System.Drawing.Size(143, 17);
            this.checkBox_DevMode.TabIndex = 7;
            this.checkBox_DevMode.Text = "Developer/Design Mode";
            this.checkBox_DevMode.UseVisualStyleBackColor = true;
            // 
            // OptionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(342, 362);
            this.Controls.Add(this.checkBox_DevMode);
            this.Controls.Add(this.button_Defaults);
            this.Controls.Add(this.textBox_DataGraphicName_04);
            this.Controls.Add(this.label_DataGraphicName_04);
            this.Controls.Add(this.textBox_DataGraphicName_03);
            this.Controls.Add(this.label_DataGraphicName_03);
            this.Controls.Add(this.textBox_DataGraphicName_02);
            this.Controls.Add(this.label_DataGraphicName_02);
            this.Controls.Add(this.textBox_DataGraphicName_01);
            this.Controls.Add(this.label_DataGraphicName_01);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.checkBox_autoOpenTliPanel);
            this.Name = "OptionsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CtaAddinOptionsForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CtaAddinOptionsForm_FormClosing);
            this.Load += new System.EventHandler(this.CtaAddinOptionsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_autoOpenTliPanel;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label_DataGraphicName_01;
        private System.Windows.Forms.TextBox textBox_DataGraphicName_01;
        private System.Windows.Forms.Label label_DataGraphicName_02;
        private System.Windows.Forms.TextBox textBox_DataGraphicName_02;
        private System.Windows.Forms.Label label_DataGraphicName_03;
        private System.Windows.Forms.TextBox textBox_DataGraphicName_03;
        private System.Windows.Forms.Label label_DataGraphicName_04;
        private System.Windows.Forms.TextBox textBox_DataGraphicName_04;
        private System.Windows.Forms.Button button_Defaults;
        private System.Windows.Forms.CheckBox checkBox_DevMode;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}