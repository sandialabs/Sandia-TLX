﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    //const string idMerge_ShapeDataAndDwgExplorer = "{473E9EDA-2BFF-46D4-A463-B7484790EB1B}";
    //string idMerge = idMerge_ShapeDataAndDwgExplorer;
    //string idMerge = "SNL_Cognitive_Task_Analysis_Visio_Add_in";

    class PanelFrameWindow
    {
        public Vis.Window VisWindow { get; set; }
        public PanelFrame PanelFrame { get; set; }

        public PanelFrameWindow(PanelFrame pnlfrm, Vis.Window visWin)
        {
            this.PanelFrame = pnlfrm;
            this.VisWindow = visWin;
        }
    }
    class PanelFrameWindows : List<PanelFrameWindow>
    {
        public PanelFrameWindow GetItemByVisioWindow(Vis.Window visWin)
        {
            foreach(var item in this)
            {
                if (item.VisWindow == visWin) return item;
            }
            return null;
        }
        public void RemoveItemByVisWindow(Vis.Window visWin)
        {
            for (int i = this.Count-1; i <= 0; i--)
            {
                var item = this[i];
                if(item.VisWindow == visWin)
                {
                    this.RemoveAt(i);
                    return;
                }
            }
        }
    }

    public class DockedWindowManager
    {
        //private Vis.Window _visWinAddin = null;

        private Vis.Application _visApp = null;
        private PanelFrameWindows _pfwins = null;
        
        public DockedWindowManager(Vis.Application visApp)
        {
            _visApp = visApp;
            _pfwins = new PanelFrameWindows();
        }

        public void CreateOrShowPanel()
        {
            // Get the Visio window:
            Vis.Window visWin = _visApp.ActiveWindow;
            if (visWin == null) return;
            if (visWin.Type != (short)Vis.VisWinTypes.visDrawing) return;

            var pfw = _pfwins.GetItemByVisioWindow(visWin);
            if(pfw != null)
            {
                Debug.WriteLine("An existing PanelFrame-VisioWindow item was found, and shouldn't have been found!");
                // Show the window, activate the form, whatever
                //pfw.PanelFrame.Show();
                return;
            }

            // Windows Form with ElementHost wrapper for WPF control:
            var frm = new UI.PanelForm();
            frm.Text = SolutionStrings.PanelCaption;
            //frm.TlxControl.ObservableTask_Click += TliControl_ObservableTask_Click;
            //frm.TlxControl.CognitiveTask_Click += TliControl_CognitiveTask_Click;
            //frm.TlxControl.Connector_Click += TliControl_Connector_Click;
            //frm.TliControl.ChangeTaskItem_Click += TliControl_ChangeTaskItem_Click;
            //frm.ShowDialog();

            var pfrm = new PanelFrame(frm);
            pfrm.CreateWindow(visWin);

            frm.TlxControl.DataContext = Solution.SelectedShape; 

            // Listen for when the panelframe destroys itself:
            pfrm.PanelFrameClosed += Pfrm_PanelFrameClosed;

            _pfwins.Add(new PanelFrameWindow(pfrm, visWin));
           
            // See Nikoly's stuff here:
            // https://github.com/nbelyh/VisioPanelAddinVSTO/blob/master/TemplateCS/Addin/PanelFrame.cs
        }

        private void Pfrm_PanelFrameClosed(Vis.Window window)
        {
            _pfwins.RemoveItemByVisWindow(window);
            //throw new NotImplementedException();
        }

        //private void TliControl_CognitiveTask_Click(object sender, EventArgs e)
        //{
        //    Commands.AddShape_CognitiveTask();
        //}
        //private void TliControl_ObservableTask_Click(object sender, EventArgs e)
        //{
        //    Commands.AddShape_ObservableTask();
        //}
        //private void TliControl_Connector_Click(object sender, EventArgs e)
        //{
        //    Commands.AddShape_Connector();
        //}
        //private void TliControl_ChangeTaskItem_Click(object sender, EventArgs e)
        //{
        //    Commands.ChangeTaskItem();
        //    //throw new NotImplementedException();
        //}
    }

    /// <summary>
    /// Integrates a winform in Visio.
    /// Creates an anchor window for the given diagram window, and installs the specified form as a child in that panel.
    /// </summary>
    /// 
    public sealed class PanelFrame : Vis.IVisEventProc
    {
        private const string AddonWindowMergeId = "$mergeguid$";

        #region WIN API Declares

        [DllImport("user32.dll", EntryPoint = "SetWindowLong", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        private static extern int SetWindowLong(IntPtr hWnd, int index, int newLong);

        [DllImport("user32.dll", EntryPoint = "SetParent", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        private static extern int SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [DllImport("user32.dll", EntryPoint = "GetWindowRect", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        private static extern int GetWindowRect(IntPtr hWnd, ref RECT lpRect);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        private static extern int SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
                    int x, int y, int cx, int cy, int wFlags);

        private const int GWL_STYLE = (-16);
        private const int WS_CHILD = 0x40000000;
        private const int WS_OVERLAPPED = 0x00000000;
        private const int SWP_NOCOPYBITS = 0x100;
        private const int SWP_NOMOVE = 0x2;
        private const int SWP_NOZORDER = 0x4;
        private const int GW_CHILD = 5;
        private const int GW_HWNDNEXT = 2;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        #endregion

        #region fields

        private Vis.Window _visioWindow;
        private Form _form;

        #endregion

        /// <summary>
        /// The event is triggered when user closes the panel using "x" button
        /// </summary>
        /// <param name="window">The parent diagram window for which the panel was closed.</param>
        /// 
        public delegate void PanelFrameClosedEventHandler(Vis.Window window);
        public event PanelFrameClosedEventHandler PanelFrameClosed;        

        /// <summary>
        /// Constructs a new panel frame.
        /// </summary>
        /// <param name="form">The form to install</param>
        public PanelFrame(Form form)
        {
            _form = form;

            // Special-case for the SNL solution:
            UI.PanelForm pfrm = _form as UI.PanelForm;
            if(pfrm != null)
            {
                pfrm.CaptionChanged += Pfrm_CaptionChanged;
            }
        }

        private void Pfrm_CaptionChanged(object sender, string caption)
        {
            _visioWindow.Caption = caption;
        }

        #region methods

        /// <summary>
        /// Destroys the panel frame along with the form.
        /// </summary>
        public void DestroyWindow()
        {
            try
            {
                if (_visioWindow != null && _form != null)
                {
                    var childWindowHandle = _form.Handle;

                    _form.Hide();

                    SetWindowLong(childWindowHandle, GWL_STYLE, WS_OVERLAPPED);
                    SetParent(childWindowHandle, (IntPtr)0);

                    _visioWindow.Close();
                    _visioWindow = null;
                }

                if (_form != null)
                {
                    _form.Close();
                    _form.Dispose();
                    _form = null;
                }
            }
            // ReSharper disable once EmptyGeneralCatchClause : ignore all errors on exit
            catch
            {
            }
        }

        /// <summary>
        /// Install the panel into given window (actually creates the form and shows it)
        /// </summary>
        /// <param name="visioParentWindow">The parent Visio window where the panel should be installed to.</param>
        /// <returns></returns>
        public Vis.Window CreateWindow(Vis.Window visioParentWindow)
        {
            Vis.Window retVal = null;
          
            try
            {
                if (visioParentWindow == null)
                    return null;

                if (_form != null)
                {
                    // Get the screen size to make a better choice for the width 
                    // of the form. Alternatively, we could look at the size of the
                    // Visio window...
                    var bounds = Screen.FromControl(_form).Bounds;
                    var w = bounds.Width / 4;

                    IntPtr childWindowHandle = _form.Handle;

                    _visioWindow = visioParentWindow.Windows.Add(
                        _form.Text,
                        (int)Vis.VisWindowStates.visWSDockedRight | (int)Vis.VisWindowStates.visWSAnchorMerged,
                        Vis.VisWinTypes.visAnchorBarAddon,
                        0,
                        0,
                        w,
                        300,
                        AddonWindowMergeId,
                        string.Empty,
                        0);

                    _visioWindow.BeforeWindowClosed += OnBeforeWindowClosed;

                    _visioWindow.Visible = false;

                    var parentWindowHandle = (IntPtr)_visioWindow.WindowHandle32;

                    SetWindowLong(childWindowHandle, GWL_STYLE, WS_CHILD);
                    SetParent(childWindowHandle, parentWindowHandle);

                    _form.Show();

                    JiggleWindow(parentWindowHandle);

                    _visioWindow.Visible = true;
                    _visioWindow.Activate();

                    retVal = _visioWindow;
                }
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
            }

            return retVal;
        }

        private static void JiggleWindow(
            IntPtr handle)
        {
            var lpRect = new RECT();
            GetWindowRect(handle, ref lpRect);

            var l = lpRect.left;
            var T = lpRect.top;
            var w = lpRect.right - lpRect.left;
            var h = lpRect.bottom - lpRect.top;

            const int flags = SWP_NOCOPYBITS | SWP_NOMOVE | SWP_NOZORDER;
            SetWindowPos(handle, new IntPtr(0), l, T, w, h + 1, flags);
            SetWindowPos(handle, new IntPtr(0), l, T, w, h, flags);
        }

        #endregion

        object Vis.IVisEventProc.VisEventProc(short nEventCode, object pSourceObj, int nEventId, int nEventSeqNum, object pSubjectObj, object vMoreInfo)
        {
            object returnValue = false;

            try
            {
                var subjectWindow = pSubjectObj as Vis.Window;
                switch (nEventCode)
                {
                    case ((short)Vis.VisEventCodes.visEvtDel + (short)Vis.VisEventCodes.visEvtWindow):
                        {
                            OnBeforeWindowClosed(subjectWindow);
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
            }

            return returnValue;
        }

        private void OnBeforeWindowClosed(Vis.Window visioWindow)
        {
            if (PanelFrameClosed != null)
                PanelFrameClosed(_visioWindow.ParentWindow);

            DestroyWindow();
        }

        //public void Show()
        //{
        //    Unnecessary because the panel destroys the Visio window and the form
        //    when the window is closed
        //    _visioWindow.Visible = true;
        //    _visioWindow.Activate();
        //}
    }

    public sealed class PanelFrameWpf : Vis.IVisEventProc
    {
        private const string AddonWindowMergeId = "$mergeguid$";

        #region WIN API Declares

        [DllImport("user32.dll", EntryPoint = "SetWindowLong", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        //private static extern int SetWindowLong(IntPtr hWnd, int index, int newLong);
        private static extern IntPtr SetWindowLong(IntPtr hWnd, int index, int newLong);

        [DllImport("user32.dll", EntryPoint = "SetParent", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        //private static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
        private static extern int SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [DllImport("user32.dll", EntryPoint = "GetWindowRect", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        //private static extern IntPtr GetWindowRect(IntPtr hWnd, ref RECT lpRect);
        private static extern int GetWindowRect(IntPtr hWnd, ref RECT lpRect);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos", CharSet = CharSet.Auto,
                    CallingConvention = CallingConvention.Winapi)]
        private static extern int SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
                    int x, int y, int cx, int cy, int wFlags);

        private const int GWL_STYLE = (-16);
        private const int WS_CHILD = 0x40000000;
        private const int WS_OVERLAPPED = 0x00000000;
        private const int SWP_NOCOPYBITS = 0x100;
        private const int SWP_NOMOVE = 0x2;
        private const int SWP_NOZORDER = 0x4;
        private const int GW_CHILD = 5;
        private const int GW_HWNDNEXT = 2;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        #endregion

        #region fields

        private Vis.Window _visioWindow;
        private System.Windows.Window _form; // Form _form;

        #endregion

        /// <summary>
        /// The event is triggered when user closes the panel using "x" button
        /// </summary>
        /// <param name="window">The parent diagram window for which the panel was closed.</param>
        /// 
        public delegate void PanelFrameClosedEventHandler(Vis.Window window);
        public event PanelFrameClosedEventHandler PanelFrameClosed;

        /// <summary>
        /// Constructs a new panel frame.
        /// </summary>
        /// <param name="wpfForm">The form to install</param>
        public PanelFrameWpf(System.Windows.Window wpfForm)
        {
            _form = wpfForm;
        }

        #region methods

        /// <summary>
        /// Destroys the panel frame along with the form.
        /// </summary>
        public void DestroyWindow()
        {
            try
            {
                if (_visioWindow != null && _form != null)
                {
                    //var childWindowHandle = _form.Handle;
                    var childWindowHandle = new WindowInteropHelper(_form).Handle;

                    _form.Hide();

                    SetWindowLong(childWindowHandle, GWL_STYLE, WS_OVERLAPPED);
                    SetParent(childWindowHandle, (IntPtr)0);

                    _visioWindow.Close();
                    _visioWindow = null;
                }

                if (_form != null)
                {
                    _form.Close();
                    // Not necessary with WPF forms?
                    //_form.Dispose();
                    _form = null;
                }
            }
            // ReSharper disable once EmptyGeneralCatchClause : ignore all errors on exit
            catch
            {
            }
        }

        /// <summary>
        /// Install the panel into given window (actually creates the form and shows it)
        /// </summary>
        /// <param name="visioParentWindow">The parent Visio window where the panel should be installed to.</param>
        /// <returns></returns>
        public Vis.Window CreateWindow(Vis.Window visioParentWindow)
        {
            Vis.Window retVal = null;

            try
            {
                if (visioParentWindow == null)
                    return null;

                if (_form != null)
                {
                    //IntPtr childWindowHandle = _form.Handle;
                    var childWindowHandle = new WindowInteropHelper(_form).Handle;

                    // Note: see this thread regarding WPF window handles:
                    // http://stackoverflow.com/questions/1556182/finding-the-handle-to-a-wpf-window

                    _visioWindow = visioParentWindow.Windows.Add(
                        "TODO: Window Caption", //_form.Text,
                        (int)Vis.VisWindowStates.visWSDockedRight | (int)Vis.VisWindowStates.visWSAnchorMerged,
                        Vis.VisWinTypes.visAnchorBarAddon,
                        0,
                        0,
                        300,
                        300,
                        AddonWindowMergeId,
                        string.Empty,
                        0);

                    _visioWindow.BeforeWindowClosed += OnBeforeWindowClosed;

                    _visioWindow.Visible = false;

                    var parentWindowHandle = (IntPtr)_visioWindow.WindowHandle32;

                    SetWindowLong(childWindowHandle, GWL_STYLE, WS_CHILD);
                    SetParent(childWindowHandle, parentWindowHandle);

                    _form.Show();
                    Debug.WriteLine("Form S&P: " + _form.Left + ", " + _form.Top + ", " + _form.Width + ", " + _form.Height );

                    JiggleWindow(parentWindowHandle);

                    _visioWindow.Visible = true;
                    _visioWindow.Activate();

                    retVal = _visioWindow;
                }
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
            }

            return retVal;
        }

        private static void JiggleWindow(
            IntPtr handle)
        {
            var lpRect = new RECT();
            GetWindowRect(handle, ref lpRect);

            var l = lpRect.left;
            var T = lpRect.top;
            var w = lpRect.right - lpRect.left;
            var h = lpRect.bottom - lpRect.top;

            const int flags = SWP_NOCOPYBITS | SWP_NOMOVE | SWP_NOZORDER;
            SetWindowPos(handle, new IntPtr(0), l, T, w, h + 1, flags);
            SetWindowPos(handle, new IntPtr(0), l, T, w, h, flags);
        }

        #endregion

        object Vis.IVisEventProc.VisEventProc(short nEventCode, object pSourceObj, int nEventId, int nEventSeqNum, object pSubjectObj, object vMoreInfo)
        {
            object returnValue = false;

            try
            {
                var subjectWindow = pSubjectObj as Vis.Window;
                switch (nEventCode)
                {
                    case ((short)Vis.VisEventCodes.visEvtDel + (short)Vis.VisEventCodes.visEvtWindow):
                        {
                            OnBeforeWindowClosed(subjectWindow);
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
            }

            return returnValue;
        }

        private void OnBeforeWindowClosed(Vis.Window visioWindow)
        {
            if (PanelFrameClosed != null)
                PanelFrameClosed(_visioWindow.ParentWindow);

            DestroyWindow();
        }
    }
}

//_visioWindow = visioParentWindow.Windows.Add(
//    _form.Text,
//    (int)VisWindowStates.visWSDockedRight | (int)VisWindowStates.visWSAnchorMerged,
//    VisWinTypes.visAnchorBarAddon,
//    0,
//    0,
//    300,
//    300,
//    AddonWindowMergeId,
//    string.Empty,
//    0);

//VisWinTypes
//visInvalWinID = -1,
//visWinOther = 0,
//visDrawing = 1,
//visStencil = 2,
//visSheet = 3,
//visIcon = 4,
//visApplication = 5,
//visAnchorBarBuiltIn = 6,
//visDockedStencilBuiltIn = 7,
//visDrawingAddon = 8,
//visStencilAddon = 9,
//visAnchorBarAddon = 10,
//visDockedStencilAddon = 11,
//visMasterWin = 64,
//visMasterGroupWin = 96,
//visPageWin = 128,
//visPageGroupWin = 160,
//visWinIDPanZoom = 1653,
//visWinIDCustProp = 1658,
//visWinIDShapeSearch = 1669,
//visWinIDSizePos = 1670,
//visWinIDDrawingExplorer = 1721,
//visWinIDFormulaTracing = 1781,
//visWinIDStencilExplorer = 1796,
//visWinIDMasterExplorer = 1916,
//visWinIDExternalData = 2044,
//visWinIDValidationIssues = 2263