﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class SelectTasksForm : Form
    {
        private string _displayMemberCog = String.Empty;
        private string _displayMemberObs = String.Empty;

        private List<object> _tasksCog = null;
        private List<object> _tasksObs = null;

        private List<object> _selectedTasksCog = null;
        private List<object> _selectedTasksObs = null;

        public static DialogResult SelectTasks(string formtitle,
            List<object> tasksCog, List<object> tasksObs,
            string displayMemberCog, string displayMemberObs,
            out List<object> selectedTasksCog, out List<object> selectedTasksObs)
        {
            // TODO: return dialog result, pass in
            // arrays to fill

            var frm = new SelectTasksForm();

            frm.Text = formtitle;

            frm._displayMemberCog = displayMemberCog;
            frm._displayMemberObs = displayMemberObs;

            frm._tasksCog = tasksCog;
            frm._tasksObs = tasksObs;

            var dlgres = frm.ShowDialog();

            selectedTasksCog = frm._selectedTasksCog;
            selectedTasksObs = frm._selectedTasksObs;

            return dlgres;
        }

        private SelectTasksForm()
        {
            InitializeComponent();

            _selectedTasksCog = new List<object>();
            _selectedTasksObs = new List<object>();
        }

        private void SelectTasksForm_Load(object sender, EventArgs e)
        {
            // Set up binding to internal lists:
            listBox_Cogs.DataSource = _tasksCog;
            listBox_Cogs.DisplayMember = _displayMemberCog;

            listBox_Obs.DataSource = _tasksObs;
            listBox_Obs.DisplayMember = _displayMemberObs;

            // Nothing selected by default:
            listBox_Cogs.SelectedIndex = -1;
            listBox_Obs.SelectedIndex = -1;
        }

        private void _changeSelection(
            ListBox lstbox, bool selectAll, bool selectNone, bool selectInvert)
        {
            if (lstbox == null) return;

            // The arguments are a bit funny, and have a precedence:

            if (selectAll)
            {
                for (int i = 0; i < lstbox.Items.Count; i++)
                {
                    lstbox.SetSelected(i, true);
                }
                return;
            }
            if (selectNone)
            {
                for (int i = 0; i < lstbox.Items.Count; i++)
                {
                    lstbox.SetSelected(i, false);
                }
                return;
            }
            if (selectInvert)
            {
                for (int i = 0; i < lstbox.Items.Count; i++)
                {
                    lstbox.SetSelected(i, !lstbox.GetSelected(i));
                }
                return;
            }
        }

        private void button_AllCog_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Cogs, true, false, false);
        }

        private void button_NoneCog_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Cogs, false, true, false);
        }
        private void button_InvertCog_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Cogs, false, false, true);
        }

        private void button_AllObs_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Obs, true, false, false);
        }

        private void button_NoneObs_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Obs, false, true, false);
        }    
        private void button_InvertObs_Click(object sender, EventArgs e)
        {
            _changeSelection(listBox_Obs, false, false, true);
        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;

            // Fill out the selected arrays...
            _setSelectedArrays();

            this.Close();
        }
        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        private void _setSelectedArrays()
        {
            _selectedTasksCog = _getSelectedItems(listBox_Cogs);
            _selectedTasksObs = _getSelectedItems(listBox_Obs);
        }

        private List<object> _getSelectedItems(ListBox lstbox)
        {
            var sel = new List<object>();
            for (int i = 0; i < lstbox.Items.Count; i++)
            {
                if(lstbox.GetSelected(i))
                {
                    sel.Add(lstbox.Items[i]);
                }
            }
            return sel;
        }
    }
}
