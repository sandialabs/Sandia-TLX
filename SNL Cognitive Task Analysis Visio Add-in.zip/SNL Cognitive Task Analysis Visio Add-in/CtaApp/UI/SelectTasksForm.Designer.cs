﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    partial class SelectTasksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox_Cogs = new System.Windows.Forms.ListBox();
            this.button_AllCog = new System.Windows.Forms.Button();
            this.button_NoneCog = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.button_OK = new System.Windows.Forms.Button();
            this.button_InvertCog = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox_Obs = new System.Windows.Forms.GroupBox();
            this.button_InvertObs = new System.Windows.Forms.Button();
            this.button_NoneObs = new System.Windows.Forms.Button();
            this.button_AllObs = new System.Windows.Forms.Button();
            this.listBox_Obs = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox_Obs.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_InvertCog);
            this.groupBox1.Controls.Add(this.button_NoneCog);
            this.groupBox1.Controls.Add(this.button_AllCog);
            this.groupBox1.Controls.Add(this.listBox_Cogs);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(489, 273);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cognitive Tasks";
            // 
            // listBox_Cogs
            // 
            this.listBox_Cogs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox_Cogs.FormattingEnabled = true;
            this.listBox_Cogs.ItemHeight = 16;
            this.listBox_Cogs.Location = new System.Drawing.Point(3, 34);
            this.listBox_Cogs.Name = "listBox_Cogs";
            this.listBox_Cogs.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox_Cogs.Size = new System.Drawing.Size(399, 228);
            this.listBox_Cogs.TabIndex = 0;
            // 
            // button_AllCog
            // 
            this.button_AllCog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AllCog.AutoSize = true;
            this.button_AllCog.Location = new System.Drawing.Point(408, 34);
            this.button_AllCog.Name = "button_AllCog";
            this.button_AllCog.Size = new System.Drawing.Size(75, 27);
            this.button_AllCog.TabIndex = 1;
            this.button_AllCog.Text = "All";
            this.button_AllCog.UseVisualStyleBackColor = true;
            this.button_AllCog.Click += new System.EventHandler(this.button_AllCog_Click);
            // 
            // button_NoneCog
            // 
            this.button_NoneCog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_NoneCog.AutoSize = true;
            this.button_NoneCog.Location = new System.Drawing.Point(408, 67);
            this.button_NoneCog.Name = "button_NoneCog";
            this.button_NoneCog.Size = new System.Drawing.Size(75, 27);
            this.button_NoneCog.TabIndex = 2;
            this.button_NoneCog.Text = "None";
            this.button_NoneCog.UseVisualStyleBackColor = true;
            this.button_NoneCog.Click += new System.EventHandler(this.button_NoneCog_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cancel.AutoSize = true;
            this.button_Cancel.Location = new System.Drawing.Point(426, 589);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(75, 27);
            this.button_Cancel.TabIndex = 2;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // button_OK
            // 
            this.button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_OK.AutoSize = true;
            this.button_OK.Location = new System.Drawing.Point(345, 589);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(75, 27);
            this.button_OK.TabIndex = 2;
            this.button_OK.Text = "OK";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // button_InvertCog
            // 
            this.button_InvertCog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_InvertCog.AutoSize = true;
            this.button_InvertCog.Location = new System.Drawing.Point(408, 100);
            this.button_InvertCog.Name = "button_InvertCog";
            this.button_InvertCog.Size = new System.Drawing.Size(75, 27);
            this.button_InvertCog.TabIndex = 2;
            this.button_InvertCog.Text = "Invert";
            this.button_InvertCog.UseVisualStyleBackColor = true;
            this.button_InvertCog.Click += new System.EventHandler(this.button_InvertCog_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(12, 12);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox_Obs);
            this.splitContainer1.Size = new System.Drawing.Size(489, 550);
            this.splitContainer1.SplitterDistance = 273;
            this.splitContainer1.TabIndex = 3;
            // 
            // groupBox_Obs
            // 
            this.groupBox_Obs.Controls.Add(this.button_InvertObs);
            this.groupBox_Obs.Controls.Add(this.button_NoneObs);
            this.groupBox_Obs.Controls.Add(this.button_AllObs);
            this.groupBox_Obs.Controls.Add(this.listBox_Obs);
            this.groupBox_Obs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Obs.Location = new System.Drawing.Point(0, 0);
            this.groupBox_Obs.Name = "groupBox_Obs";
            this.groupBox_Obs.Size = new System.Drawing.Size(489, 273);
            this.groupBox_Obs.TabIndex = 0;
            this.groupBox_Obs.TabStop = false;
            this.groupBox_Obs.Text = "Observable Tasks";
            // 
            // button_InvertObs
            // 
            this.button_InvertObs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_InvertObs.AutoSize = true;
            this.button_InvertObs.Location = new System.Drawing.Point(408, 100);
            this.button_InvertObs.Name = "button_InvertObs";
            this.button_InvertObs.Size = new System.Drawing.Size(75, 27);
            this.button_InvertObs.TabIndex = 2;
            this.button_InvertObs.Text = "Invert";
            this.button_InvertObs.UseVisualStyleBackColor = true;
            this.button_InvertObs.Click += new System.EventHandler(this.button_InvertObs_Click);
            // 
            // button_NoneObs
            // 
            this.button_NoneObs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_NoneObs.AutoSize = true;
            this.button_NoneObs.Location = new System.Drawing.Point(408, 67);
            this.button_NoneObs.Name = "button_NoneObs";
            this.button_NoneObs.Size = new System.Drawing.Size(75, 27);
            this.button_NoneObs.TabIndex = 2;
            this.button_NoneObs.Text = "None";
            this.button_NoneObs.UseVisualStyleBackColor = true;
            this.button_NoneObs.Click += new System.EventHandler(this.button_NoneObs_Click);
            // 
            // button_AllObs
            // 
            this.button_AllObs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AllObs.AutoSize = true;
            this.button_AllObs.Location = new System.Drawing.Point(408, 34);
            this.button_AllObs.Name = "button_AllObs";
            this.button_AllObs.Size = new System.Drawing.Size(75, 27);
            this.button_AllObs.TabIndex = 1;
            this.button_AllObs.Text = "All";
            this.button_AllObs.UseVisualStyleBackColor = true;
            this.button_AllObs.Click += new System.EventHandler(this.button_AllObs_Click);
            // 
            // listBox_Obs
            // 
            this.listBox_Obs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox_Obs.FormattingEnabled = true;
            this.listBox_Obs.ItemHeight = 16;
            this.listBox_Obs.Location = new System.Drawing.Point(3, 34);
            this.listBox_Obs.Name = "listBox_Obs";
            this.listBox_Obs.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox_Obs.Size = new System.Drawing.Size(399, 212);
            this.listBox_Obs.TabIndex = 0;
            // 
            // SelectTasksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 628);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.button_Cancel);
            this.Name = "SelectTasksForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "SelectTasksForm";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.SelectTasksForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox_Obs.ResumeLayout(false);
            this.groupBox_Obs.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_InvertCog;
        private System.Windows.Forms.Button button_NoneCog;
        private System.Windows.Forms.Button button_AllCog;
        private System.Windows.Forms.ListBox listBox_Cogs;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox_Obs;
        private System.Windows.Forms.Button button_InvertObs;
        private System.Windows.Forms.Button button_NoneObs;
        private System.Windows.Forms.Button button_AllObs;
        private System.Windows.Forms.ListBox listBox_Obs;
    }
}