﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class ReportForm : Form
    {
        //public static void ShowDialog_Static(
        //    string reportText,
        //    bool showPastToShapeButton) // TODO: horrible nameing 'ShowDialog_Static'? 
        //{
        //    var f = new ReportForm();
            
        //    f.button_pasteToShape.Visible = showPastToShapeButton;
        //    f.textBox_Report.Text = reportText;

        //    f.ShowDialog();
        //}
        //public static void ShowDialog_Static(
        //    string formTitleOrEmptyForDefault,
        //    string reportText, 
        //    bool showPastToShapeButton) // TODO: horrible nameing 'ShowDialog_Static'? 
        //{
        //    var f = new ReportForm();

        //    if (!String.IsNullOrEmpty(formTitleOrEmptyForDefault))
        //        f.Text = formTitleOrEmptyForDefault;

        //    f.button_pasteToShape.Visible = showPastToShapeButton;
        //    f.textBox_Report.Text = reportText;

        //    f.ShowDialog();            
        //}

        public static string DefaultCaption = "Report";

        private Action<string> _pasteToShapeProcedure = null;

        public ReportForm()
        {
            InitializeComponent();
            this.Text = DefaultCaption;
        }

        public static void Show(string msg)
        {
            var f = new ReportForm();
            f.textBox_Report.Text = msg;
            f.ShowDialog();

            f.button_pasteToShape.Visible = false;
        }

        public static void Show(string msg, 
            double formWidthAsScreenWidthPct, double formHeightAsScreenHeightPct)
        {
            var f = new ReportForm();
            f.textBox_Report.Text = msg;

            f._setFormSize(formWidthAsScreenWidthPct, formHeightAsScreenHeightPct);

            f.button_pasteToShape.Visible = false;

            f.ShowDialog();
        }

        public static void Show(string msg,
            string formTitleOrEmptyForDefault,
            double formWidthAsScreenWidthPct, double formHeightAsScreenHeightPct,
            Action<string> pasteToShapeProcedureOrNull,
            bool showModal)
        {
            // The form:
            var f = new ReportForm();
            f._setFormSize(formWidthAsScreenWidthPct, formHeightAsScreenHeightPct);

            // The form title/caption:
            if (!String.IsNullOrEmpty(formTitleOrEmptyForDefault))
                f.Text = formTitleOrEmptyForDefault;

            // The report text:
            f.textBox_Report.Text = msg;

            // The "Paste to Shape" button, its visibility, 
            // and associated procedure:            
            f._pasteToShapeProcedure = pasteToShapeProcedureOrNull;
            f.button_pasteToShape.Visible = (pasteToShapeProcedureOrNull != null);

            // Show it modal or modeless:
            if(showModal)
            {
                f.ShowDialog();
            }
            else
            {
                f.Show();
            }            
        }

        private void _setFormSize(double pctW, double pctH)
        {
            Screen myScreen = Screen.FromControl(this);
            Rectangle area = myScreen.WorkingArea;

            double dw, dh;
            dw = Math.Max(0, Math.Min(1, pctW)) * (double)area.Width;
            dh = Math.Max(0, Math.Min(1, pctH)) * (double)area.Height;

            int iw, ih;
            iw = Math.Max(100, (int)dw);
            ih = Math.Max(100, (int)dh);

            this.Width = iw;
            this.Height = ih;
        }

        private void button_Copy_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Clipboard.SetText(this.textBox_Report.Text);
        }
        private void button_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_pasteToShape_Click(object sender, EventArgs e)
        {
            if (_pasteToShapeProcedure != null)
                _pasteToShapeProcedure.Invoke(textBox_Report.Text);
        }
    }
}
