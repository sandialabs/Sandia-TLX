﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Report = new System.Windows.Forms.TextBox();
            this.button_Close = new System.Windows.Forms.Button();
            this.button_Copy = new System.Windows.Forms.Button();
            this.button_pasteToShape = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_Report
            // 
            this.textBox_Report.AcceptsReturn = true;
            this.textBox_Report.AcceptsTab = true;
            this.textBox_Report.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Report.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_Report.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Report.Location = new System.Drawing.Point(6, 6);
            this.textBox_Report.Multiline = true;
            this.textBox_Report.Name = "textBox_Report";
            this.textBox_Report.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_Report.Size = new System.Drawing.Size(346, 310);
            this.textBox_Report.TabIndex = 8;
            // 
            // button_Close
            // 
            this.button_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Close.AutoSize = true;
            this.button_Close.Location = new System.Drawing.Point(295, 356);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(75, 23);
            this.button_Close.TabIndex = 7;
            this.button_Close.Text = "Close";
            this.button_Close.UseVisualStyleBackColor = true;
            this.button_Close.Click += new System.EventHandler(this.button_Close_Click);
            // 
            // button_Copy
            // 
            this.button_Copy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Copy.AutoSize = true;
            this.button_Copy.Location = new System.Drawing.Point(105, 356);
            this.button_Copy.Name = "button_Copy";
            this.button_Copy.Size = new System.Drawing.Size(75, 23);
            this.button_Copy.TabIndex = 6;
            this.button_Copy.Text = "Copy";
            this.button_Copy.UseVisualStyleBackColor = true;
            this.button_Copy.Click += new System.EventHandler(this.button_Copy_Click);
            // 
            // button_pasteToShape
            // 
            this.button_pasteToShape.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_pasteToShape.AutoSize = true;
            this.button_pasteToShape.Location = new System.Drawing.Point(9, 356);
            this.button_pasteToShape.Name = "button_pasteToShape";
            this.button_pasteToShape.Size = new System.Drawing.Size(90, 23);
            this.button_pasteToShape.TabIndex = 9;
            this.button_pasteToShape.Text = "Paste to Shape";
            this.button_pasteToShape.UseVisualStyleBackColor = true;
            this.button_pasteToShape.Click += new System.EventHandler(this.button_pasteToShape_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.textBox_Report);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(6);
            this.panel1.Size = new System.Drawing.Size(358, 322);
            this.panel1.TabIndex = 10;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(382, 391);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_pasteToShape);
            this.Controls.Add(this.button_Close);
            this.Controls.Add(this.button_Copy);
            this.Name = "ReportForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ReportForm";
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Report;
        private System.Windows.Forms.Button button_Close;
        private System.Windows.Forms.Button button_Copy;
        private System.Windows.Forms.Button button_pasteToShape;
        private System.Windows.Forms.Panel panel1;
    }
}