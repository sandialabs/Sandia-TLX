﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class OptionsForm : Form
    {
        private bool _isSettingsChanged = false;

        public OptionsForm()
        {
            InitializeComponent();
            this.Text = SolutionStrings.OptionsFormCaption;

            Properties.Settings.Default.PropertyChanged += Default_PropertyChanged;

            // Bind controls to settings:
            //AutoShowTliPanelOnDocOpen
            //checkBox_autoOpenTliPanel.DataBindings.Add(
            //    new Binding("Checked", Properties.Settings.)
            //Properties.Settings.Default.AutoShowTliPanelOnDocOpen
        }
        private void CtaAddinOptionsForm_Load(object sender, EventArgs e)
        {

        }
        private void CtaAddinOptionsForm_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            // Save settings:
            if (_isSettingsChanged)
            {
                Properties.Settings.Default.Save();
                Solution.RefreshAfterOptionsChanged();
                // TODO: it is possible tha a users could "unchange" a setting, at which
                // case we don't really need to save settings, nor updating any UI.
            }
            this.Close();
        }

        private void Default_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            _isSettingsChanged = true;

            // TODO: it is possible tha a users could "unchange" a setting, at which
            // case we don't really need to save settings, nor updating any UI.
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            // Don't save settings...
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Commands.ShowAddinFolder();
        }

        private void button_Defaults_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reset();
        }
    }
}
