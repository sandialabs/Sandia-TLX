﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class ViewDiagramDataForm : Form
    {
        private Data.TaskSet _taskset = null;
        public ViewDiagramDataForm(Data.TaskSet taskset)
        {
            InitializeComponent();

            _taskset = taskset;


            // Weird hack to get derived-class properties to show their
            // values in the data grid:
            this.dataGridView_Cognitive.DataSource = 
                taskset.CognitiveTasks.ConvertAll(c => c as Data.CognitiveTask);

            this.dataGridView_Observable.DataSource =
                _taskset.ObservableTasks.ConvertAll(o => o as Data.ObservableTask);

            // More info:
            // Make DataGridView Show Properties of Derived Class Objects when Using List of Base Class Objects
            // http://stackoverflow.com/questions/17584214/make-datagridview-show-properties-of-derived-class-objects-when-using-list-of-ba
            // col.DataPropertyName = "MyPropertyDerived";
            // dataGridView.Columns.Add(col);
            // dataGridView.DataSource = list.ConvertAll(c => c as MyDerivedClass);

        }
    }
}
