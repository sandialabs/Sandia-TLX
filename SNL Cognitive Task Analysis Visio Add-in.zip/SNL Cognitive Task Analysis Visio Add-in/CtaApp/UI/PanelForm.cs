﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WP = SnlWpf;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class PanelForm : Form
    {
        private WP.TliControl _tliControl = null;
        public WP.TliControl TlxControl { get { return _tliControl; } }

        public PanelForm()
        {
            InitializeComponent();

            //var wpfFrm = new TW.TliControl(); // .TliControl(); //.MainWindow();

            //var w = new TW.MainWindow();
            _tliControl = new WP.TliControl();
            //_tliControl.SelectedSearchItem.

            _tliControl.CaptionChanged += _tliControl_CaptionChanged;

            elementHostWpfChild.Child = _tliControl;

            // TODO: we need an event that says: selected context changed
            // so that we can change the caption of the form to:

            // Cog -> TLX
            // Obs -> Factor Ratings
            // Nothing -> I don't know, maybe just blank.

            //_tliControl.CognitiveTask_Click += _tliControl_CognitiveTask_Click;
            //_tliControl.ObservableTask_Click += _tliControl_ObservableTask_Click;
            
        }

        private void _tliControl_CaptionChanged(object sender, string caption)
        {
            // Throw the caption event up even higher, so that Visio can 
            // make use of it in the DockedWindowManager/PanelFrame:
            CaptionChanged(this, caption);            
        }

        public event CaptionChangedEventHandler CaptionChanged = null;
        public delegate void CaptionChangedEventHandler(object sender, string caption);

        //private void _tliControl_ObservableTask_Click(object sender, EventArgs e)
        //{
        //    Debug.WriteLine("_tliControl_ObservableTask_Click");
        //    //throw new NotImplementedException();
        //}

        //private void _tliControl_CognitiveTask_Click(object sender, EventArgs e)
        //{
        //    Debug.WriteLine("_tliControl_CognitiveTask_Click");
        //    //throw new NotImplementedException();
        //}
    }
}
