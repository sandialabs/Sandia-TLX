﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VL = Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class DescriptionAndCategoryForm : Form
    {
        // These are collections of controls, objects, strings,
        // etc., that are associated with either descriptions or 
        // categories. Passing these objects makes the parameter
        // list for the change, add, reset, delete operations MUCH
        // simpler.
        private ObjectGroup _descObjects = null;
        private ObjectGroup _catObjects = null;

        private string _addedCatKey = String.Empty;
        private string _changedCatKey = String.Empty;

        public string SelectedDescriptionKey { get; private set; }
        public string SelectedDescriptionValue { get; private set; }
        public bool SelectedDescriptionIsChanged { get; private set; }
        public bool SelectedDescriptionIsAdded { get; private set; }

        public string SelectedCategoryKey { get; private set; }
        public string SelectedCategoryValue { get; private set; }
        public bool SelectedCategoryIsChanged { get; private set; }
        public bool SelectedCategoryIsAdded { get; private set; }


        // ----- Constructors -------------------------------------------------
        public DescriptionAndCategoryForm(string formtitle,
            List<string> uniqueDescriptions, List<string> uniqueCategories,
            string initialDescription, string initialCategory)
        {
            this.Text = formtitle;

            InitializeComponent();

            // TODO: add the initial values to the lists, if they're not in them...

            // Initialize the object groups:
            _initObjectGroups();

            List<string> descs = uniqueDescriptions;
            List<string> cats = uniqueCategories;

            if(descs.Contains(initialDescription) == false)
            {
                if (String.IsNullOrEmpty(initialDescription) == false)
                {
                    descs.Add(initialDescription);
                    descs.Sort();
                }
            }
            if (descs.Count == 0)
                descs.Add(String.Empty);

            _descObjects.OriginalList = descs;
            _descObjects.InitialValue = initialDescription;


            if (cats.Contains(initialDescription) == false)
            {
                if (String.IsNullOrEmpty(initialDescription) == false)
                {
                    cats.Add(initialCategory);
                    cats.Sort();
                }
            }
            if (cats.Count == 0)
                cats.Add(String.Empty);

            _catObjects.OriginalList = cats;
            _catObjects.InitialValue = initialCategory;

            _init();
        }
        public DescriptionAndCategoryForm()
        {
            InitializeComponent();

            // Initialize the object groups.
            _initObjectGroups();

            // Initialize other stuff:
            _init();
        }


        private void _init()
        {
            // Build test data for the OriginalList objects if they are null:
            _createTestOriginalListsIfNull();

            // Build dictionaries:
            _descObjects.Dict = new SortedDictionary<string, string>();
            foreach (var d in _descObjects.OriginalList)
            {
                if (!_descObjects.Dict.ContainsKey(d))
                    _descObjects.Dict.Add(d, d);
            }
            _catObjects.Dict = new SortedDictionary<string, string>();
            foreach (var c in _catObjects.OriginalList)
            {
                if (!_catObjects.Dict.ContainsKey(c))
                    _catObjects.Dict.Add(c, c);
            }

            // Bind to combo boxes:
            //_bindingSourceDescs = new BindingSource(_descriptions, null);
            comboBox_Descriptions.DataSource = new BindingSource(_descObjects.Dict, null);
            //_bindingSourceDescs;
            comboBox_Descriptions.DisplayMember = "Value";
            comboBox_Categories.DataSource = new BindingSource(_catObjects.Dict, null);
            comboBox_Categories.DisplayMember = "Value";


            // Select initial items:
            if (_descObjects.Dict.ContainsKey(_descObjects.InitialValue))
            {
                comboBox_Descriptions.Text = _descObjects.InitialValue;
            }
            else
            {
                if(_descObjects.Dict.Count > 0)
                { 
                    comboBox_Descriptions.Text = _descObjects.Dict.First().Key;
                }
                else
                {
                    comboBox_Descriptions.Text = String.Empty;
                }
            }
            if (_catObjects.Dict.ContainsKey(_catObjects.InitialValue))
            {
                comboBox_Categories.Text = _catObjects.InitialValue;
            }
            else
            {
                if (_catObjects.Dict.Count > 0)
                {
                    comboBox_Categories.Text = _catObjects.Dict.First().Key;
                }
                else
                {
                    comboBox_Categories.Text = String.Empty;
                }
            }

        }
        private void _initObjectGroups()
        {
            // Build the functional object groups to ease parameter passing:
            _descObjects = new ObjectGroup();
            _descObjects.ButtonAdd             = button_AddDesc;
            _descObjects.ButtonChange          = button_ChangeDesc;
            _descObjects.ButtonDelete          = button_DelDesc;
            _descObjects.ButtonReset           = button_ResetDesc;
            _descObjects.ComboBox              = comboBox_Descriptions;
            //_descObjects.Dict                  = _dictDescs;
            _descObjects.LabelSelectedItemInfo = label_SelectedItemInfo_Descriptions;
            //_descObjects.LastSelectedKey       = _lastSelectedDescKey;
            //_descObjects.OriginalList          = _listDescsOriginal;

            _catObjects = new ObjectGroup();
            _catObjects.ButtonAdd             = button_AddCat;
            _catObjects.ButtonChange          = button_ChangeCat;
            _catObjects.ButtonDelete          = button_DelCat;
            _catObjects.ButtonReset           = button_ResetCat;
            _catObjects.ComboBox              = comboBox_Categories;
            //_catObjects.Dict                  = _dictCats;
            _catObjects.LabelSelectedItemInfo = label_SelectedItemInfo_Categories;
            //_catObjects.LastSelectedKey       = _lastSelectedCatKey;
            //_catObjects.OriginalList          = _listCatsOriginal;
        }


        private void _addItem(ObjectGroup g)
        {
            // Get the new value from the combo box text:
            string v = g.ComboBox.Text.Trim();
            if (String.IsNullOrEmpty(v)) return;

            // Clear any original items:
            _clearAddedItemIfExists(g.Dict, g.OriginalList);

            // Reset any changed items:
            _resetChangedItems(g.Dict);

            // Create a new added item. The key and value are identical:
            g.Dict.Add(v, v);

            g.LastSelectedKey = v;

            // Update the combo box:
            _updateComboBoxAndLabel(g);
        }
        private void _changeItem(ObjectGroup g)
        {
            // For a changed item, we update the value, which is,
            // displayed but keep the original key.
            //
            // We shouldn't be allowed to change if the new value
            // is whitespace or empty.

            // The new value for the changed item:
            string v = g.ComboBox.Text.Trim();
            if (String.IsNullOrEmpty(v)) return;

            // We will only allow one ADDED item or one CHANGED item!

            // First remove the ADDED item, if it exists:
            _clearAddedItemIfExists(g.Dict, g.OriginalList);

            // Reset any changed items:
            _resetChangedItems(g.Dict);

            g.Dict[g.LastSelectedKey] = v;

            _updateComboBoxAndLabel(g);
        }
        private void _clearAddedItemIfExists(
            SortedDictionary<string, string> dict,
            List<string> originalList)
        {
            string kAdded = _getAddedKeyOrEmpty(dict, originalList);
            if (!String.IsNullOrEmpty(kAdded))
            {
                dict.Remove(kAdded);
            }
        }
        private void _createTestOriginalListsIfNull()
        {
            if (_descObjects.OriginalList == null)
            {
                _descObjects.OriginalList = new List<string>();
                for (int i = 0; i < 10; i++)
                {
                    _descObjects.OriginalList.Add("Description " + i.ToString("000"));
                }
            }
            if (_catObjects.OriginalList == null)
            {
                _catObjects.OriginalList = new List<string>();
                for (int i = 0; i < 10; i++)
                {
                    _catObjects.OriginalList.Add("Category " + i.ToString("000"));
                }
            }
        }
        private void _deleteItem(ObjectGroup g)
        {
            _clearAddedItemIfExists(g.Dict, g.OriginalList);
            _updateComboBoxAndLabel(g);
        }
        private string _getAddedKeyOrEmpty(
            SortedDictionary<string, string> dict,
            List<string> originalList)
        {
            foreach (string k in dict.Keys)
            {
                if (!originalList.Contains(k)) return k;
            }
            return String.Empty;
        }
        private void _resetChangedItems(
            SortedDictionary<string, string> dict)
        {
            foreach(string k in dict.Keys.ToList())
            {
                string v = dict[k];
                if (k != v) dict[k] = k;
            }
        }
        private void _resetItem(ObjectGroup g)
        {
            _resetChangedItems(g.Dict);
            _updateComboBoxAndLabel(g);
        }
        private void _textChanged(ObjectGroup g)
        {
            var v = g.ComboBox.Text.Trim();

            // Enable or disable the Add or Change buttons:
            bool bEnableAdd = false;
            bool bEnableChange = false;
            bool bEnableDelete = false;
            bool bEnableReset = false;
            bool bEnableOk = false;

            string key = String.Empty;
            string sItemToChangeText = string.Empty;
            if (g.Dict.ContainsValue(v))
            {
                // Current text is in the dictionary:
                var itm = g.Dict.First(i => i.Value == v);
                g.LastSelectedKey = itm.Key;
                sItemToChangeText = itm.Key + " = " + itm.Value;

                bEnableReset = (itm.Key != itm.Value);

                // Determine if this is an ADDED item:
                string keyAdded = _getAddedKeyOrEmpty(g.Dict, g.OriginalList);
                bEnableDelete = (keyAdded == itm.Key);

                bEnableOk = true;
            }
            else if (!String.IsNullOrEmpty(v) &&
                     !g.Dict.ContainsKey(v))
            {
                // Current text is not in dictionary, and isn't empty,
                // so allow change or add:
                bEnableAdd = true;
                bEnableChange = true;

                sItemToChangeText = g.LastSelectedKey;            
            }
                
            g.ButtonAdd.Enabled = bEnableAdd;
            g.ButtonChange.Enabled = bEnableChange;
            g.ButtonDelete.Enabled = bEnableDelete;
            g.ButtonReset.Enabled = bEnableReset;

            button_OK.Enabled = bEnableOk;

            _updateSelectedItemInfoLabel(g.LabelSelectedItemInfo, g.LastSelectedKey, v);
        }
        private void _updateComboBoxAndLabel(ObjectGroup g)
        {
            string sCbOld = g.ComboBox.Text;
            string sLastSelKey = g.LastSelectedKey; //...save, it gets blown away when resetting the data source for some reason
                   
            g.ComboBox.DataSource = new BindingSource(g.Dict, null);
            g.ComboBox.DisplayMember = "Value";

            if (g.Dict.ContainsKey(sLastSelKey))
            {
                g.ComboBox.Text = g.Dict[sLastSelKey]; 
                //...ie: the text is the value of the selected item.
            }
            else
            {
                var itm = g.Dict.First();// (i => i.Value == v);
                g.LastSelectedKey = itm.Key;
            }

            // Trigger a label change if the text of the combo box
            // has NOT changed. Otherwise, _textChanged will handle this.
            if(sCbOld == g.ComboBox.Text)
            {
                string key = g.LastSelectedKey;
                string val = g.Dict[g.LastSelectedKey];
                _updateSelectedItemInfoLabel(g.LabelSelectedItemInfo, key, val);
            }
        }

        private void _updateSelectedItemInfoLabel(
            Label lbl, string key, string value)
        {
            string t = key;
            if (key != value)
                t = t + " --> " + value;
            lbl.Text = t;
        }



        #region Form Events

        private void DescriptionAndCategoryForm_Load(object sender, EventArgs e)
        {
            // Focus:
            comboBox_Descriptions.Focus();
        }


        // Description control events:
        private void comboBox_Descriptions_TextChanged(object sender, EventArgs e)
        {
            _textChanged(_descObjects);
        }
        private void button_AddDesc_Click(object sender, EventArgs e)
        {
            _addItem(_descObjects);
        }
        private void button_ChangeDesc_Click(object sender, EventArgs e)
        {
            _changeItem(_descObjects);
        }
        private void button_DelDesc_Click(object sender, EventArgs e)
        {
            _deleteItem(_descObjects);
        }
        private void button_ResetDesc_Click(object sender, EventArgs e)
        {
            _resetItem(_descObjects);
        }

        // Category control events:
        private void button_AddCat_Click(object sender, EventArgs e)
        {
            _addItem(_catObjects);
        }
        private void button_ChangeCat_Click(object sender, EventArgs e)
        {
            _changeItem(_catObjects);
        }
        private void button_DelCat_Click(object sender, EventArgs e)
        {
            _deleteItem(_catObjects);
        }
        private void button_ResetCat_Click(object sender, EventArgs e)
        {
            _resetItem(_catObjects);
        }
        private void comboBox_Categories_TextChanged(object sender, EventArgs e)
        {
            _textChanged(_catObjects);
        }


        // OK and Cancel:
        private void button_OK_Click(object sender, EventArgs e)
        {
            // Set private-set properties:

            // Description:
            string v_desc = _descObjects.ComboBox.Text;
            var itm_Desc = _descObjects.Dict.First(i => i.Value == v_desc);
            string keyAdded_Desc = _getAddedKeyOrEmpty(_descObjects.Dict, _descObjects.OriginalList);

            SelectedDescriptionKey = itm_Desc.Key;
            SelectedDescriptionValue = itm_Desc.Value;
            SelectedDescriptionIsChanged = (itm_Desc.Key != itm_Desc.Value);
            SelectedDescriptionIsAdded = (!String.IsNullOrEmpty(keyAdded_Desc));

            // Category:
            string v_cat = _catObjects.ComboBox.Text;
            var itm_Cat = _catObjects.Dict.First(i => i.Value == v_cat);
            string keyAdded_Cat = _getAddedKeyOrEmpty(_catObjects.Dict, _catObjects.OriginalList);

            SelectedCategoryKey = itm_Cat.Key;
            SelectedCategoryValue = itm_Cat.Value;
            SelectedCategoryIsChanged = (itm_Cat.Key != itm_Cat.Value);
            SelectedCategoryIsAdded = (!String.IsNullOrEmpty(keyAdded_Cat));

            this.DialogResult = DialogResult.OK;

            this.Close();
        }
        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;

            this.Close();
        }

        #endregion

    }

    class ObjectGroup
    {
        internal ComboBox ComboBox { get; set; }
        internal Button ButtonAdd { get; set; }
        internal Button ButtonChange { get; set; }
        internal Button ButtonDelete { get; set; }
        internal Button ButtonReset { get; set; }

        internal string InitialValue { get; set; }
        internal Label LabelSelectedItemInfo { get; set; }
        internal SortedDictionary<string, string> Dict {
            get; set; }
        internal List<string> OriginalList { get; set; }

        internal string LastSelectedKey { get; set; }

        public ObjectGroup()
        {
            //Dict = new SortedDictionary<string, string>();
            //OriginalList = new List<string>();
        }
    }
}
