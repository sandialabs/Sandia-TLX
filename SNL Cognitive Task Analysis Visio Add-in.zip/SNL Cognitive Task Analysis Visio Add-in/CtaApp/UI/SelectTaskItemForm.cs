﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SWPF = SnlWpf;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    public partial class SelectTaskItemForm : Form
    {
        private SWPF.ChooseTaskItemControl _chooseTaskControl = null;
        public SWPF.ChooseTaskItemControl ChooseTaskControl { get { return _chooseTaskControl; } }

        private bool _cancelled = false;
        public bool Cancelled
        {
            get { return _cancelled; }           
        }

        public object DataContext
        {
            set
            {
                if (_chooseTaskControl == null) return;
                _chooseTaskControl.DataContext = value;
            }
        }
        private string _description = String.Empty;
        public string Description { get { return _description; } }
        private string _number = String.Empty;
        public string Number { get { return _number; } }


        public SelectTaskItemForm()
        {
            InitializeComponent();

            _chooseTaskControl = new SWPF.ChooseTaskItemControl();
            _chooseTaskControl.OnButtonCancel_Click += _chooseTaskControl_OnButtonCancel_Click;
            _chooseTaskControl.OnButtonOk_Click += _chooseTaskControl_OnButtonOk_Click;
            elementHostWpfChild.Child = _chooseTaskControl;
        }

        private void _chooseTaskControl_OnButtonOk_Click(object sender, EventArgs e)
        {
            _number = _chooseTaskControl.Number;
            _description = _chooseTaskControl.Description;

            _cancelled = false;
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        private void _chooseTaskControl_OnButtonCancel_Click(object sender, EventArgs e)
        {
            _number = String.Empty;
            _description = String.Empty;

            _cancelled = true;
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

    }
}
