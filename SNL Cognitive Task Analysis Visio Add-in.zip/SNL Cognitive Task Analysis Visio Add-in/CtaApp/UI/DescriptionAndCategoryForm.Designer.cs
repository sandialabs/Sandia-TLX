﻿namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.UI
{
    partial class DescriptionAndCategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_Descriptions = new System.Windows.Forms.ComboBox();
            this.button_ChangeDesc = new System.Windows.Forms.Button();
            this.button_AddDesc = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_Categories = new System.Windows.Forms.ComboBox();
            this.button_ChangeCat = new System.Windows.Forms.Button();
            this.button_AddCat = new System.Windows.Forms.Button();
            this.button_OK = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.label_SelectedItemInfo_Descriptions = new System.Windows.Forms.Label();
            this.label_SelectedItemInfo_Categories = new System.Windows.Forms.Label();
            this.button_DelDesc = new System.Windows.Forms.Button();
            this.button_ResetDesc = new System.Windows.Forms.Button();
            this.button_DelCat = new System.Windows.Forms.Button();
            this.button_ResetCat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Description:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // comboBox_Descriptions
            // 
            this.comboBox_Descriptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_Descriptions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_Descriptions.FormattingEnabled = true;
            this.comboBox_Descriptions.Location = new System.Drawing.Point(76, 10);
            this.comboBox_Descriptions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox_Descriptions.Name = "comboBox_Descriptions";
            this.comboBox_Descriptions.Size = new System.Drawing.Size(326, 21);
            this.comboBox_Descriptions.Sorted = true;
            this.comboBox_Descriptions.TabIndex = 0;
            this.comboBox_Descriptions.TextChanged += new System.EventHandler(this.comboBox_Descriptions_TextChanged);
            // 
            // button_ChangeDesc
            // 
            this.button_ChangeDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangeDesc.AutoSize = true;
            this.button_ChangeDesc.Enabled = false;
            this.button_ChangeDesc.Location = new System.Drawing.Point(405, 8);
            this.button_ChangeDesc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_ChangeDesc.Name = "button_ChangeDesc";
            this.button_ChangeDesc.Size = new System.Drawing.Size(56, 23);
            this.button_ChangeDesc.TabIndex = 2;
            this.button_ChangeDesc.Text = "Change";
            this.button_ChangeDesc.UseVisualStyleBackColor = true;
            this.button_ChangeDesc.Click += new System.EventHandler(this.button_ChangeDesc_Click);
            // 
            // button_AddDesc
            // 
            this.button_AddDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AddDesc.AutoSize = true;
            this.button_AddDesc.Enabled = false;
            this.button_AddDesc.Location = new System.Drawing.Point(466, 8);
            this.button_AddDesc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_AddDesc.Name = "button_AddDesc";
            this.button_AddDesc.Size = new System.Drawing.Size(56, 23);
            this.button_AddDesc.TabIndex = 2;
            this.button_AddDesc.Text = "Add";
            this.button_AddDesc.UseVisualStyleBackColor = true;
            this.button_AddDesc.Click += new System.EventHandler(this.button_AddDesc_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Category:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // comboBox_Categories
            // 
            this.comboBox_Categories.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_Categories.FormattingEnabled = true;
            this.comboBox_Categories.Location = new System.Drawing.Point(75, 73);
            this.comboBox_Categories.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox_Categories.Name = "comboBox_Categories";
            this.comboBox_Categories.Size = new System.Drawing.Size(326, 21);
            this.comboBox_Categories.Sorted = true;
            this.comboBox_Categories.TabIndex = 1;
            this.comboBox_Categories.TextChanged += new System.EventHandler(this.comboBox_Categories_TextChanged);
            // 
            // button_ChangeCat
            // 
            this.button_ChangeCat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangeCat.AutoSize = true;
            this.button_ChangeCat.Enabled = false;
            this.button_ChangeCat.Location = new System.Drawing.Point(405, 71);
            this.button_ChangeCat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_ChangeCat.Name = "button_ChangeCat";
            this.button_ChangeCat.Size = new System.Drawing.Size(56, 23);
            this.button_ChangeCat.TabIndex = 2;
            this.button_ChangeCat.Text = "Change";
            this.button_ChangeCat.UseVisualStyleBackColor = true;
            this.button_ChangeCat.Click += new System.EventHandler(this.button_ChangeCat_Click);
            // 
            // button_AddCat
            // 
            this.button_AddCat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_AddCat.AutoSize = true;
            this.button_AddCat.Enabled = false;
            this.button_AddCat.Location = new System.Drawing.Point(466, 72);
            this.button_AddCat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_AddCat.Name = "button_AddCat";
            this.button_AddCat.Size = new System.Drawing.Size(56, 23);
            this.button_AddCat.TabIndex = 2;
            this.button_AddCat.Text = "Add";
            this.button_AddCat.UseVisualStyleBackColor = true;
            this.button_AddCat.Click += new System.EventHandler(this.button_AddCat_Click);
            // 
            // button_OK
            // 
            this.button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_OK.AutoSize = true;
            this.button_OK.Location = new System.Drawing.Point(526, 140);
            this.button_OK.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(56, 23);
            this.button_OK.TabIndex = 2;
            this.button_OK.Text = "OK";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cancel.AutoSize = true;
            this.button_Cancel.Location = new System.Drawing.Point(587, 140);
            this.button_Cancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(56, 23);
            this.button_Cancel.TabIndex = 2;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // label_SelectedItemInfo_Descriptions
            // 
            this.label_SelectedItemInfo_Descriptions.AutoSize = true;
            this.label_SelectedItemInfo_Descriptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SelectedItemInfo_Descriptions.Location = new System.Drawing.Point(73, 34);
            this.label_SelectedItemInfo_Descriptions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.label_SelectedItemInfo_Descriptions.Name = "label_SelectedItemInfo_Descriptions";
            this.label_SelectedItemInfo_Descriptions.Size = new System.Drawing.Size(35, 13);
            this.label_SelectedItemInfo_Descriptions.TabIndex = 3;
            this.label_SelectedItemInfo_Descriptions.Text = "label3";
            // 
            // label_SelectedItemInfo_Categories
            // 
            this.label_SelectedItemInfo_Categories.AutoSize = true;
            this.label_SelectedItemInfo_Categories.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SelectedItemInfo_Categories.Location = new System.Drawing.Point(73, 98);
            this.label_SelectedItemInfo_Categories.Margin = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.label_SelectedItemInfo_Categories.Name = "label_SelectedItemInfo_Categories";
            this.label_SelectedItemInfo_Categories.Size = new System.Drawing.Size(35, 13);
            this.label_SelectedItemInfo_Categories.TabIndex = 4;
            this.label_SelectedItemInfo_Categories.Text = "label4";
            // 
            // button_DelDesc
            // 
            this.button_DelDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_DelDesc.AutoSize = true;
            this.button_DelDesc.Enabled = false;
            this.button_DelDesc.Location = new System.Drawing.Point(526, 8);
            this.button_DelDesc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_DelDesc.Name = "button_DelDesc";
            this.button_DelDesc.Size = new System.Drawing.Size(56, 23);
            this.button_DelDesc.TabIndex = 5;
            this.button_DelDesc.Text = "Delete";
            this.button_DelDesc.UseVisualStyleBackColor = true;
            this.button_DelDesc.Click += new System.EventHandler(this.button_DelDesc_Click);
            // 
            // button_ResetDesc
            // 
            this.button_ResetDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ResetDesc.AutoSize = true;
            this.button_ResetDesc.Enabled = false;
            this.button_ResetDesc.Location = new System.Drawing.Point(587, 8);
            this.button_ResetDesc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_ResetDesc.Name = "button_ResetDesc";
            this.button_ResetDesc.Size = new System.Drawing.Size(56, 23);
            this.button_ResetDesc.TabIndex = 6;
            this.button_ResetDesc.Text = "Reset";
            this.button_ResetDesc.UseVisualStyleBackColor = true;
            this.button_ResetDesc.Click += new System.EventHandler(this.button_ResetDesc_Click);
            // 
            // button_DelCat
            // 
            this.button_DelCat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_DelCat.AutoSize = true;
            this.button_DelCat.Enabled = false;
            this.button_DelCat.Location = new System.Drawing.Point(526, 71);
            this.button_DelCat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_DelCat.Name = "button_DelCat";
            this.button_DelCat.Size = new System.Drawing.Size(56, 23);
            this.button_DelCat.TabIndex = 2;
            this.button_DelCat.Text = "Delete";
            this.button_DelCat.UseVisualStyleBackColor = true;
            this.button_DelCat.Click += new System.EventHandler(this.button_DelCat_Click);
            // 
            // button_ResetCat
            // 
            this.button_ResetCat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ResetCat.AutoSize = true;
            this.button_ResetCat.Enabled = false;
            this.button_ResetCat.Location = new System.Drawing.Point(587, 71);
            this.button_ResetCat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_ResetCat.Name = "button_ResetCat";
            this.button_ResetCat.Size = new System.Drawing.Size(56, 23);
            this.button_ResetCat.TabIndex = 2;
            this.button_ResetCat.Text = "Reset";
            this.button_ResetCat.UseVisualStyleBackColor = true;
            this.button_ResetCat.Click += new System.EventHandler(this.button_ResetCat_Click);
            // 
            // DescriptionAndCategoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(652, 173);
            this.Controls.Add(this.button_ResetDesc);
            this.Controls.Add(this.button_DelDesc);
            this.Controls.Add(this.label_SelectedItemInfo_Categories);
            this.Controls.Add(this.label_SelectedItemInfo_Descriptions);
            this.Controls.Add(this.button_ResetCat);
            this.Controls.Add(this.button_DelCat);
            this.Controls.Add(this.button_AddCat);
            this.Controls.Add(this.button_AddDesc);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.button_ChangeCat);
            this.Controls.Add(this.button_ChangeDesc);
            this.Controls.Add(this.comboBox_Categories);
            this.Controls.Add(this.comboBox_Descriptions);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DescriptionAndCategoryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "NameAndCategoryForm";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.DescriptionAndCategoryForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_Descriptions;
        private System.Windows.Forms.Button button_ChangeDesc;
        private System.Windows.Forms.Button button_AddDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_Categories;
        private System.Windows.Forms.Button button_ChangeCat;
        private System.Windows.Forms.Button button_AddCat;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Label label_SelectedItemInfo_Descriptions;
        private System.Windows.Forms.Label label_SelectedItemInfo_Categories;
        private System.Windows.Forms.Button button_DelDesc;
        private System.Windows.Forms.Button button_ResetDesc;
        private System.Windows.Forms.Button button_DelCat;
        private System.Windows.Forms.Button button_ResetCat;
    }
}