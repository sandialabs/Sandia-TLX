﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using ODB = System.Data.OleDb;

// TODO: what does System.Data get us instead?
// Reference: Microsoft ActiveX Data Objects 6.1 Library 
//using ADODB; 

// Microsoft Access Database Engine 2010 Redistributable
// http://www.microsoft.com/en-us/download/details.aspx?id=13255
//
// RE: this error:
// "Additional information: The 'Microsoft.ACE.OLEDB.12.0' provider is not registered on the local machine."
// http://social.msdn.microsoft.com/Forums/en-US/1d5c04c7-157f-4955-a14b-41d912d50a64/how-to-fix-error-the-microsoftaceoledb120-provider-is-not-registered-on-the-local-machine

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.DataAccess
{
    /// <summary>
    /// Currently built to work with string values ONLY, however we could
    /// probably genericize this to work with a variety of data types.
    /// </summary>
    public class OdbExcel
    {
        private string _excelFileName = String.Empty;

        // The INSERT and UPDATE statements are organized per row, ie:
        // "For Some table with a row-key equal to row-value, insert or update a bunch of cells".
        // This means we need to maintainn collections of cells that are organized by 
        // table-keyname-keyvalue. This is what _getRowIdentifier creates for us.
        // 
        // So these collections organize the data-tlo-change according to these
        // table-keyname-keyvalue identifiers, so that it is easy to produce the
        // SQL to send to the database.
        private Dictionary<string, DataFields> _updateItems = null;
        private Dictionary<string, DataFields> _insertItems = null;
        //private Dictionary<string, DataFields> _deleteItems = null;

        // Record the stuff that works and doesn't work:
        private List<string> _lastReadErrors = null;
        private List<string> _lastWriteErrors = null;
        private List<string> _lastWriteSuccesses = null;

        public int WriteAttemptsCount { get { return _lastWriteErrors.Count + _lastWriteSuccesses.Count; } }
        public int WriteErrorsCount { get { return _lastWriteErrors.Count; } }
        public int WriteSuccessesCount { get { return _lastWriteSuccesses.Count; } }

        public List<string> LastWriteErrors { get { return _lastWriteErrors; } }
        public List<string> LastWriteSuccesses { get { return _lastWriteSuccesses; } }

        // An item would be: field-name, field-value, and key-name, key-value


        #region "'Old' Connection String Stuff"
        //private const string ConnStringToken_DataFile = "[DATAFILENAME]";

        //private const string connectionstringOleDb_Read =
        //    "Provider=Microsoft.ACE.OLEDB.12.0;" +
        //    "User ID=Admin;" +
        //    "Data Source=[DATAFILENAME];" +
        //    "Mode=Read;" +
        //    "Extended Properties=\"HDR=YES;IMEX=1;MaxScanRows=0;Excel 12.0;\";" +
        //    "Jet OLEDB:Engine Type=34;";
        ////ReadOnly=True/False...?

        ////Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Book1.xls;Extended Properties="Excel 8.0;HDR=YES;"

        //// Solution for avoiding the "Operation must use an updateable query." error:
        //// http://stackoverflow.com/questions/7622492/operation-must-use-an-updateable-query-when-updating-excel-sheet
        //// Removed the IMEX and MaxScanRows stuff, plus added ReadOnly=False.
        ////;MaxScanRows=0
        //private const string connectionstringOleDb_Write =
        //    "Provider=Microsoft.ACE.OLEDB.12.0;" +
        //    "Data Source=[DATAFILENAME];" +
        //    "Extended Properties=\"HDR=YES;ReadOnly=False;Excel 12.0;\";" +
        //    "Jet OLEDB:Engine Type=34;";
        //// Removed ;IMEX=1


        //// Error: "Operation must use an updateable query"
        //// http://stackoverflow.com/questions/7622492/operation-must-use-an-updateable-query-when-updating-excel-sheet
        //private const string connectionstringOldDb_NoImex =
        //    "Provider=Microsoft.ACE.OLEDB.12.0;" +
        //    "User ID=Admin;" +
        //    "Data Source=[DATAFILENAME];" +
        //    "Mode=Read;" +
        //    "Extended Properties=\"HDR=YES;MaxScanRows=0;Excel 12.0;\";" +
        //    "Jet OLEDB:Engine Type=34;";

        ////private const string connectionstringAdoNet =
        ////      "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=[DATAFILENAME];Extended Properties='Excel 12.0 Xml;HDR=[HDR]';";
        ////Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Book1.xls;Extended Properties="Excel 8.0;HDR=YES;"
        #endregion


        public OdbExcel(string excelFileName)
        {
            _excelFileName = excelFileName;

            _resetLogArrays();

            _updateItems = new Dictionary<string, DataFields>();
            _insertItems = new Dictionary<string, DataFields>();
            //_deleteItems = new Dictionary<string, DataFields>();
        }

        public DataField AddDataField_ForUpdate(
            string tableName, string keyName, string keyValue, 
            string fieldName, string fieldValue)
        {
            var dfs = _getOrMakeDataFields(ref _updateItems,
                tableName, keyName, keyValue);
            return dfs.Add(fieldName, fieldValue);
        }
        //public void AddDataFields_ForUpdate(
        //    string tableName, string keyName, string keyValue, 
        //    string[] fieldName, string[] fieldValue)
        //{
        //    var dfs = _getOrMakeDataFields(ref _updateItems,
        //        tableName, keyName, keyValue);
        //    return dfs.Add(fieldName, fieldValue);
        //}
        public void AddDataFields_ForUpdate(
            string tableName, string keyName, string keyValue,
            Dictionary<string, string> fieldNamesValues)
        {
            // TODO: return dfs?
            var dfs = _getOrMakeDataFields(ref _updateItems,
                tableName, keyName, keyValue);

            foreach (var k in fieldNamesValues.Keys)
            {
                dfs.Add(k, fieldNamesValues[k]);
            }
        }

        // Thinking our loud:
        // A rename of the key column would go like this:
        // AddDataField_ForUpdate(table, keyField, keyValue, keyField, keyValueNew)
        //public DataField AddDataField_ForUpdateRename(string tableName, string fieldName, string fieldValue)
        //{

        //}
        public DataField AddDataField_ForInsert(
            string tableName, string keyName, string keyValue, string fieldName, string fieldValue)
        {
            var dfs = _getOrMakeDataFields(ref _insertItems,
                tableName, keyName, keyValue);
            return dfs.Add(fieldName, fieldValue);
        }
        public void AddDataFields_ForInsert(
            string tableName, string keyName, string keyValue,
            Dictionary<string, string> fieldNamesValues)
        {
            // TODO: return dfs?
            var dfs = _getOrMakeDataFields(ref _insertItems,
                tableName, keyName, keyValue);

            foreach (var k in fieldNamesValues.Keys)
            {
                dfs.Add(k, fieldNamesValues[k]);
            }
        }
        //public DataField AddDataField_ForDelete(
        //    string tableName, string keyName, string keyValue, string fieldName, string fieldValue)
        //{

        //}
        // TODO: Some sort of CREATE for new tables. Right now, we're focusing on updating data.

        public void Write()
        {
            _write();


            // TODO: refactor, with blocks of commands, and a nice using{} block

            // make a command,
            // Send all of the inserts
            // Send all of the updates, etc.
        }

        public string GetPendingWriteSql()
        {
            var sb = new StringBuilder();

            var ups = _getUpdateStatements();
            sb.AppendLine("UPDATE:");
            foreach (var s in ups)
                sb.AppendLine(s);

            var ins = _getInsertStatements();
            sb.AppendLine("INSERT:");
            foreach (var s in ins)
                sb.AppendLine(s);

            return sb.ToString();
        }


        // TODO: constructor with filename

        private ODB.OleDbConnection _getConnectionToExcelFile()
        {
            var conn = new ODB.OleDbConnection();
            
            //conn.Provider = "SQLOLEDB";

            //  conn.Properties("Data Source").value = sDataSourceName
            //  conn.Properties("Initial Catalog").value = sDatabaseName
            //  conn.Properties("Integrated Security").value = "SSPI"

            return null;
        }

        /// <summary>
        /// Grabs all of the data in all of the Excel sheets and returns 
        /// DataSet object. Suitable for not-too-large Excel files.
        /// </summary>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public DataSet GetDataSet_AllSheets()
        {
            // Make *something* to return:
            DataSet ds = new DataSet();

            // Check that the file exists:
            if (!File.Exists(_excelFileName)) return ds; //...ie: an empty bagp-o-data!

            string connectionString = _getConnectionString(_excelFileName);

            using (var conn = new ODB.OleDbConnection(connectionString))
            {
                conn.Open();
                ODB.OleDbCommand cmd = new ODB.OleDbCommand();
                cmd.Connection = conn;

                // Get all Sheets in Excel File
                DataTable dtSheet = conn.GetOleDbSchemaTable(ODB.OleDbSchemaGuid.Tables, null);

                // Loop through all Sheets to get data
                foreach (DataRow dr in dtSheet.Rows)
                {
                    string sheetName = dr["TABLE_NAME"].ToString();
                    Debug.WriteLine(sheetName);

                    // I think this is to skip "Tables" that don't end with $.
                    // What I'm seeing is that the sheets are wrapped in single
                    // quotes.
                    if ( ! ( sheetName.EndsWith("$") || 
                             sheetName.EndsWith("$'") ) )
                        continue;
                    //if (!sheetName.EndsWith("$"))
                    //    continue;

                    // Get all rows from the Sheet
                    cmd.CommandText = "SELECT * FROM [" + sheetName + "]";

                    DataTable dt = new DataTable();
                    dt.TableName = sheetName;

                    ODB.OleDbDataAdapter da = new ODB.OleDbDataAdapter(cmd);
                    da.Fill(dt);

                    ds.Tables.Add(dt);
                }

                cmd = null;
                // Not needed with "using" conn.Close();
            }

            return ds;
        }

        public void TestWriteExcelFile(string filepath)
        {
            string connectionString = _getConnectionString(filepath);

            using (var conn = new ODB.OleDbConnection(connectionString))
            {
                conn.Open();
                var cmd = new ODB.OleDbCommand();
                cmd.Connection = conn;

                cmd.CommandText = "CREATE TABLE [table1] (id INT, name VARCHAR, datecol DATE );";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(1,'AAAA','2014-01-01');";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(2, 'BBBB','2014-01-03');";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(3, 'CCCC','2014-01-03');";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "UPDATE [table1] SET name = 'DDDD' WHERE id = 3;";
                cmd.ExecuteNonQuery();

                // Multiple update
                //  UPDATE Customers
                //  SET ContactName = 'Alfred Schmidt', City = 'Hamburg'
                //  WHERE CustomerName = 'Alfreds Futterkiste';

                // Not needed with "using" conn.Close();
            }
        }

        private string _getRowIdentifier(string tableName, string keyName, string keyValue)
        {
            return tableName + "!" + keyName + "=" + keyValue;
        }

        private string _getConnectionString(string filepath)
        {
            // This is a nice way to build a connection string with
            // individual properties, instead of the mess of quotes
            // and escapes that a normal connection string has.

            // See: codeproject
            // http://www.codeproject.com/Tips/705470/Read-and-Write-Excel-Documents-Using-OLEDB

            Dictionary<string, string> props = new Dictionary<string, string>();

            // XLSX - Excel 2007, 2010, 2012, 2013
            props["Provider"] = "Microsoft.ACE.OLEDB.12.0;";
            props["Extended Properties"] = "Excel 12.0 XML";
            props["Data Source"] = filepath; // "C:\\MyExcel.xlsx";

            // XLS - Excel 2003 and Older
            //props["Provider"] = "Microsoft.Jet.OLEDB.4.0";
            //props["Extended Properties"] = "Excel 8.0";
            //props["Data Source"] = "C:\\MyExcel.xls";

            StringBuilder sb = new StringBuilder();

            foreach (KeyValuePair<string, string> prop in props)
            {
                sb.Append(prop.Key);
                sb.Append('=');
                sb.Append(prop.Value);
                sb.Append(';');
            }

            return sb.ToString();
        }

        private List<string> _getUpdateStatements()
        {
            // TODO: return empty if _udpateItems is empty?
            // TODO: note items where the key is being renamed, and send them to the end, somehow

            var statements = new List<string>();

            foreach(var key in _updateItems.Keys)
            {
                var dfs = _updateItems[key];

                // The preamble:
                var s = "UPDATE [" + dfs.TableName + "] SET ";
                
                // The name = value pairs:
                int i = 0;
                foreach(var df in dfs)
                {
                    if (i != 0) s += ", ";
                    string sVal = df.Value;
                    //if (string.IsNullOrEmpty(sVal))
                    //    sVal = "-1";
                    s += "[" + df.Name + "] = '" + sVal + "'";
                    i++;
                }

                // ...in closing:
                s += " WHERE [" + dfs.KeyName + "] = '" + dfs.KeyValue + "';";

                // Keep it:
                statements.Add(s);

                //cmd.CommandText = "UPDATE [table1] SET name = 'DDDD' WHERE id = 3;";
                //cmd.ExecuteNonQuery();

                // Multiple update
                //  UPDATE Customers
                //  SET ContactName = 'Alfred Schmidt', City = 'Hamburg'
                //  WHERE CustomerName = 'Alfreds Futterkiste';

            }
            return statements;
        }

        private List<string> _getInsertStatements()
        {
            // TODO: use a StringBuilder?
            // TODO: return empty if _insertItems is empty?
            // TODO: note items where the key is being renamed, and send them to the end, somehow

            var statements = new List<string>();

            foreach (var key in _insertItems.Keys)
            {
                var dfs = _insertItems[key];

                // The preamble:
                var s = "INSERT INTO [" + dfs.TableName + "](";
                var sVals = " VALUES(";

                // The name = value pairs:
                int i = 0;
                foreach (var df in dfs)
                {
                    if (i != 0)
                    {
                        s += ",";
                        sVals += ",";
                    }
                    s += "[" + df.Name + "]";
                    sVals += "'" + df.Value + "'";
                    i++;
                }

                // ...in closing:
                s += ")";
                sVals += ")";

                s += sVals + ";";
                //s += " WHERE [" + dfs.KeyName + "] = '" + dfs.KeyValue + "';";

                // Keep it:
                statements.Add(s);

                //cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(2, 'BBBB','2014-01-03');"

            }
            return statements;
        }

        /// <summary>
        /// Finds a Dictionary<string, DataFields> object if it exists in collection,
        /// otherwise it creates a new object and adds it to collection.
        /// </summary>
        /// <param name="collection"></param>
        /// <param name="tableName"></param>
        /// <param name="keyName"></param>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        private DataFields _getOrMakeDataFields(
            ref Dictionary<string, DataFields> collection, string tableName, string keyName, string keyValue)
        {
            string id = _getRowIdentifier(tableName, keyName, keyValue);
            if (collection.ContainsKey(id))
            {
                return collection[id];
            }
            else
            {
                var df = new DataFields(id, tableName, keyName, keyValue);
                collection.Add(id, df);
                return df;
            }        
        }

        private void _resetLogArrays()
        {
            if (_lastReadErrors == null )
            {
                _lastReadErrors = new List<string>();
            }
            else
            {
                _lastReadErrors.Clear();
            }

            if (_lastWriteErrors == null)
            {
                _lastWriteErrors = new List<string>();
            }
            else
            {
                _lastWriteErrors.Clear();
            }

            if (_lastWriteSuccesses == null)
            {
                _lastWriteSuccesses = new List<string>();
            }
            else
            {
                _lastWriteSuccesses.Clear();
            }
        }

        //Public Function GetNewAdodbConnection( _
        //    ByVal sDataSourceName As String, _
        //    ByVal sDatabaseName As String) As ADODB.Connection

        //  On Error GoTo Cleanup:

        //  Set GetNewAdodbConnection = Nothing

        //  '// Make a new ADODB.Connection object:
        //  Dim conn As ADODB.Connection
        //  Set conn = New ADODB.Connection

        //  conn.Provider = "SQLOLEDB"
        //  conn.Properties("Data Source").value = sDataSourceName
        //  conn.Properties("Initial Catalog").value = sDatabaseName
        //  conn.Properties("Integrated Security").value = "SSPI"

        //  Set GetNewAdodbConnection = conn

        //Cleanup:
        //  Set conn = Nothing
        //End Function

        private void _write()
        {
            // Clear the successes and errors log:
            _resetLogArrays();

            // Get the SQL to execute:
            var updates = _getUpdateStatements();
            var inserts = _getInsertStatements();

            // Bail, if there's nothing to do:
            if ((updates.Count + inserts.Count) == 0)
            {
                _lastWriteErrors.Add("No UPDATE or INSERT commands to execute!");
                return;
            }

            // Bail if file doesn't exist:
            if (!File.Exists(_excelFileName))
            {
                _lastWriteErrors.Add("File: '" + _excelFileName + "' does not exist!");
                return;
            }

            string connectionString = _getConnectionString(_excelFileName);

            using (var conn = new ODB.OleDbConnection(connectionString))
            {
                conn.Open();

                foreach(var i in inserts)
                {
                    _tryExecuteNonQueryCommand(conn, i);
                }
                foreach (var u in updates)
                {
                    _tryExecuteNonQueryCommand(conn, u);
                }

                //var cmd = new ODB.OleDbCommand();
                //cmd.Connection = conn;

                //cmd.CommandText = "CREATE TABLE [table1] (id INT, name VARCHAR, datecol DATE );";
                //cmd.ExecuteNonQuery();

                //cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(1,'AAAA','2014-01-01');";
                //cmd.ExecuteNonQuery();

                //cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(2, 'BBBB','2014-01-03');";
                //cmd.ExecuteNonQuery();

                //cmd.CommandText = "INSERT INTO [table1](id,name,datecol) VALUES(3, 'CCCC','2014-01-03');";
                //cmd.ExecuteNonQuery();

                //cmd.CommandText = "UPDATE [table1] SET name = 'DDDD' WHERE id = 3;";
                //cmd.ExecuteNonQuery();

                //// Multiple update
                ////  UPDATE Customers
                ////  SET ContactName = 'Alfred Schmidt', City = 'Hamburg'
                ////  WHERE CustomerName = 'Alfreds Futterkiste';

                // Not needed with "using" conn.Close();
            }

        }

        private void _tryExecuteNonQueryCommand(
            ODB.OleDbConnection openConnection, string sqlUpdateOrInsert)
        {
            try
            {
                var cmd = new ODB.OleDbCommand();
                cmd.CommandText = sqlUpdateOrInsert;
                cmd.Connection = openConnection;

                cmd.ExecuteNonQuery();

                _lastWriteSuccesses.Add(sqlUpdateOrInsert);
            }
            catch (Exception ex)
            {
                string sErr = sqlUpdateOrInsert + " (" + ex.Message + ")";
                _lastWriteErrors.Add(sErr);
                //throw;
            }
        }



    }


    public class DataFields : List<DataField>
    {
        public string ID { get; private set; }
        public string TableName { get; private set; }
        public string KeyName { get; private set; }
        public string KeyValue { get; private set; }

        public DataFields(string id, string tableName, string keyName, string keyValue)
        {
            ID = id;
            TableName = tableName;
            KeyName = keyName;
            KeyValue = keyValue;
        }

        public DataField Add(string fieldName, string fieldValue)
        {
            // Check if fieldName already exists. If so, then simply
            // overwrite it:

            var df = _getOrMakeDataField(fieldName, fieldValue);
            this.Add(df);
            return df;
        }

        private DataField _getOrMakeDataField(string fieldName, string fieldValue)
        {
            foreach (var df in this)
            {
                if (String.Compare(df.Name, fieldName, true) == 0) return df;
            }

            var dfNew = new DataField(fieldName, fieldValue);
            return dfNew;
        }
    }

    public class DataField
    {
        public string Name { get; set; }
        public string Value { get; set; }

        public DataField(string fieldName, string fieldValue)
        {
            Name = fieldName;
            Value = fieldValue;
        }
    }
}
