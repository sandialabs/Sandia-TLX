﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Page_Base
    {
        protected Vis.Page _visPg = null;
        public Vis.Page VisioPage { get { return _visPg; } }

        protected string _userClassValue = String.Empty;

        public bool IsSolutionPage
        {
            get
            {
                return _visPg.IsClass(_userClassValue);
            }
        }
        public Page_Base(Vis.Page visPg)
        {
            _visPg = visPg;
        }
    }
}
