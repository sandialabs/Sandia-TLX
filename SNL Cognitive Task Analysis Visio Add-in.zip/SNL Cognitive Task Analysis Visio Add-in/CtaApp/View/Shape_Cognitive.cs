﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;
using SSC = SNL_Cognitive_Task_Analysis_Visio_Add_in.SolutionStrings;
using System.Diagnostics;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Shape_Cognitive : Shape_Task //: Shape_Base
    {
        // TODO: make it an array - the commas are a bit hokey...
        public static string RequiredCellsConst =
            "User.Class," +
            SSC.PropCell_TaskNumber + "," +
            SSC.PropCell_Description + "," +
            SSC.PropCell_Category + "," +
            SSC.PropCell_CategoryContainer + "," +
            SSC.PropCell_CategoryLayer + "," +
            SSC.PropCell_CategoryNearestObservableTask + "," +
            SSC.PropCell_MentalDemand + "," +
            SSC.PropCell_PhysicalDemand + "," +
            SSC.PropCell_TemporalDemand + "," +
            SSC.PropCell_Performance + "," +
            SSC.PropCell_Effort + "," +
            SSC.PropCell_Frustration;
            // TODO: SSC.PropCell_Enjoyment?
        
        public static string UserClassConst = SSC.ShapeClass_Cognitive; // "SNL.CAT.Shape.Cognitive";

        public static void GetCompletedStats(
            Vis.Page visPg, out int count, out int completed)
        {
            var ts = GetCognitiveShapesOnPage(visPg);
            count = ts.Count;
            completed = 0;
            foreach (var t in ts)
            {
                if (t.IsAllRated) completed++;
            }
        }
        public static List<Shape_Cognitive> GetCognitiveShapesOnPage(Vis.Page visPg)
        {
            string classValue = SolutionStrings.ShapeClass_Cognitive;

            var ts = new List<Shape_Cognitive>();

            Vis.Selection sel = visPg.ShapesOfClass(classValue);

            foreach (Vis.Shape shp in sel)
            {
                var t = new Shape_Cognitive(shp);
                if (t.IsSolutionShape) ts.Add(t);
            }
            return ts;
        }

        //public override string MasterName {  get { return MasterNameConst; } }
        public override string RequiredCellsCSV { get { return RequiredCellsConst; } }
        public override string UserClassValue {  get { return UserClassConst; } }

        public Shape_Cognitive(Vis.Shape visShp) : base(visShp)
        {
            //_isSolutionShape(visShp);
        }

        public string Cat_NearestObservableTask
        { get { return _visShp.TryGetCellResultStr(SSC.PropCell_CategoryNearestObservableTask); } }
        public void Set_Cat_NearestObservableTask()
        {
            string descriptionsList = String.Empty;

            Debug.WriteLine(_visShp.Characters.TextAsString);

            // Get the nearest observables:
            var obs = _getNearestObservableShapes();
            foreach(var ob in obs)
            {
                if (descriptionsList.Length > 0)
                    descriptionsList += ";";
                descriptionsList += ob.Description;
            }

            _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryNearestObservableTask, descriptionsList, true);
        }


        private List<Shape_Observable> _getNearestObservableShapes()
        {
            string[] classValsConn = new string[] { SSC.ShapeClass_CtaConnector };
            string[] classValsAll = new string[] { SSC.ShapeClass_Cognitive,
                                                    SSC.ShapeClass_Observable };
            string[] classValsObs = new string[] { SSC.ShapeClass_Observable };

            // Get a selection of Visio shapes that qualify as
            // "nearest observable tasks".
            List<Vis.Shape> visShpsToSearch = new List<Vis.Shape> { _visShp };
            List<int> idsSearched = new List<int>(); 
            List<Vis.Shape> visShpsObs = _nearestObsRecursive(classValsConn, classValsObs, classValsAll, 
                visShpsToSearch, idsSearched);

            // Make Shape_Observables out of them:
            var obs = new List<Shape_Observable>();
            foreach(Vis.Shape shp in visShpsObs)
            {
                var ob = new Shape_Observable(shp);
                if (ob.IsSolutionShape)
                    obs.Add(ob);
            }

            return obs;
        }

        private List<Vis.Shape> _nearestObsRecursive(
            string[] classValsConn, string [] classValsObs, string[] classValsAll,
            List<Vis.Shape> visShpsToSearch, List<int> idsSearched)
        {
            // Get directly-connected observables, connected to
            // the shapes in visShpsToSearch:
            var shpsConnectedObs = new List<Vis.Shape>();

            if (visShpsToSearch == null) return shpsConnectedObs;
            if (visShpsToSearch.Count == 0) return shpsConnectedObs;

            Vis.Selection visSelIncoming, visSelOutgoing;

            foreach(Vis.Shape shp in visShpsToSearch)
            {
                shp.ConnectedShapes(classValsConn, classValsObs, classValsObs,
                    out visSelIncoming, out visSelOutgoing);

                foreach (Vis.Shape s in _visSelToList(visSelIncoming))
                {
                    if(!shpsConnectedObs.Contains(s))
                        shpsConnectedObs.Add(s);
                }
                foreach (Vis.Shape s in _visSelToList(visSelOutgoing))
                {
                    if (!shpsConnectedObs.Contains(s))
                        shpsConnectedObs.Add(s);
                }

                if (!idsSearched.Contains(shp.ID))
                    idsSearched.Add(shp.ID);
            }

            // If we found some connected shapes, then our work is done:
            if (shpsConnectedObs.Count > 0) return shpsConnectedObs;

            // If no observables were found, then search ALL of the connected 
            // shapes, excluding those that have already been searched:

            var visShpsToSearchNext = new List<Vis.Shape>();
            foreach (Vis.Shape shp in visShpsToSearch)
            {
                shp.ConnectedShapes(classValsConn, classValsAll, classValsAll,
                    out visSelIncoming, out visSelOutgoing);
                
                foreach (Vis.Shape s in _visSelToList(visSelIncoming))
                {
                    if (!idsSearched.Contains(s.ID))
                        visShpsToSearchNext.Add(s);
                }
                foreach (Vis.Shape s in _visSelToList(visSelOutgoing))
                {
                    if (!idsSearched.Contains(s.ID))
                        visShpsToSearchNext.Add(s);
                }
            }


            // Do the scary recursive call:
            return _nearestObsRecursive(classValsConn, classValsObs, classValsAll,
                visShpsToSearchNext, idsSearched);
        }
        private List<Vis.Shape> _visSelToList(Vis.Selection visSel)
        {
            var shps = new List<Vis.Shape>();
            if (visSel.IsNullOrGone()) return shps;

            foreach (Vis.Shape shp in visSel)
                shps.Add(shp);

            return shps;
        }

        //public short? MentalDemand
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_MentalDemand); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_MentalDemand, value); } }

        //public short? PhysicalDemand
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_PhysicalDemand); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_PhysicalDemand, value); } }

        //public short? TemporalDemand
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_TemporalDemand); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_TemporalDemand, value); } }

        //public short? Performance
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Performance); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Performance, value); } }

        //public short? Effort
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Effort); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Effort, value); } }

        //public short? Frustration
        //{
        //    get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Frustration); }
        //    set { _visShp.TrySetCellResultShort(SSC.PropCell_Frustration, value); }
        //}

        public Data.RatingCog MentalDemand
        {
            get { return this.GetRating(SSC.PropCell_MentalDemand); }
            set { this.SetRating(value, SSC.PropCell_MentalDemand); }
        }
        public Data.RatingCog PhysicalDemand
        {
            get { return this.GetRating(SSC.PropCell_PhysicalDemand); }
            set { this.SetRating(value, SSC.PropCell_PhysicalDemand); }
        }
        public Data.RatingCog Performance
        {
            get { return this.GetRating(SSC.PropCell_Performance); }
            set { this.SetRating(value, SSC.PropCell_Performance); }
        }
        public Data.RatingCog TemporalDemand
        {
            get { return this.GetRating(SSC.PropCell_TemporalDemand); }
            set { this.SetRating(value, SSC.PropCell_TemporalDemand); }
        }
        public Data.RatingCog Effort
        {
            get { return this.GetRating(SSC.PropCell_Effort); }
            set { this.SetRating(value, SSC.PropCell_Effort); }
        }

        public Data.RatingCog Frustration
        {
            get { return this.GetRating(SSC.PropCell_Frustration); }
            set { this.SetRating(value, SSC.PropCell_Frustration); }
        }
        public Data.RatingCog Enjoyment
        {
            get { return this.GetRating(SSC.PropCell_Enjoyment); }
            set { this.SetRating(value, SSC.PropCell_Enjoyment); }
        }

        public void ClearAllRatingValues()
        {
            // Note: this is different than EraseValues, because it is
            // only setting the *Rating Values* to null/blank/nothin'

            // TODO: for performance, we could use some sort of ManySetter
            // to blast all of these at once - or even better, do it for
            // an entire page!

            // Don't use this.Rating.ToNull(), as that doesn't set the ShapeSheet cell!
            this.Effort = null;
            this.Frustration = null;
            this.MentalDemand = null;
            this.Performance = null;
            this.PhysicalDemand = null;
            this.TemporalDemand = null;
            this.Enjoyment = null;
        }

        public void EraseValues(bool eraseDescription, bool eraseCategories)
        {
            this.TaskNumber = null;

            if (eraseDescription)
                this.Description = String.Empty;

            if (eraseCategories)
            {
                this.Category = String.Empty;
                _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryContainer, String.Empty, true);
                _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryLayer, String.Empty, true);
                _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryNearestObservableTask, String.Empty, true);
            }

            ClearAllRatingValues();
 
        }


        public new Data.RatingCog GetRating(string cellname)
        {
            string val = _visShp.TryGetCellResultStr(cellname);

            var r = new Data.RatingCog();
            r.Value = val;

            return r;
        }

    }
}
