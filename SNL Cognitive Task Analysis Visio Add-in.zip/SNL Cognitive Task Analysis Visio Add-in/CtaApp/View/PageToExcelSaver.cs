﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    // TODO: this is probably a class whose bits belong elsewhere,
    // but the code was really gumming up Commands.cs. It brings together
    // a bunch of stuff, View.Doc, View.DocData, and View.Page_Diagram, 
    // along with the save-to-excel code.
    //
    // Also, this module contains a lot of string building code, and
    // language, although it doesn't present any UI.

    public class PageToExcelSaver
    {
        private View.Doc _vdoc = null;
        private View.Page_Diagram _vpg = null;
        //private string _lastWritePathToExcel = String.Empty; // TODO: remove this?
        private string _verifiedExcelPath = String.Empty;
        private View.Reports.ReportStringBuilder _errors = null;

        private DataAccess.OdbExcel _xlodb = null;

        public string Errors
        {
            get
            {
                if (_errors == null) return String.Empty;
                return _errors.ToString();
            }
        }
        public string LastSavedPathToExcel
        {
            get
            {
                return _verifiedExcelPath;
            }
        }


        public PageToExcelSaver()
        {
            _errors = new Reports.ReportStringBuilder();
        }

        public bool TrySaveToExcel()
        {
            if (_hasNoPreSaveErrors() == false)
            {
                // Finish packaging up the mass of errors:
                _errors.AppendHeaderLine("Errors were encountered in trying to save data to Excel.");
                _errors.AppendHeaderLine();
                _errors.AppendHeaderLine("The save action did not complete.");

                return false;
            }
            //return _trySave();
            // TODO: save the path from the _hasNoPreSaveErrors analysis
            bool bSuccess = _trySave2(_vdoc.GetAbsoluteAndValidExcelFilePath_OrEmpty());

            if(_xlodb.WriteErrorsCount > 0)
            {
                bSuccess = false;
                foreach(var e in _xlodb.LastWriteErrors)
                {
                    _errors.AppendBodyLine(e);
                }
            }

            return bSuccess;                                   
        }

        private bool _hasNoPreSaveErrors()
        {
            _errors = new View.Reports.ReportStringBuilder();

            // Check the solution document:
            _vdoc = Solution.GetActiveSolutionDocOrNull();
            if (_vdoc == null)
            {
                _errors.AppendBodyLine(" - Active document is not a solution document.");
                return false;
            }

            // Check the path to the Excel file:
            _verifiedExcelPath = _vdoc.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (String.IsNullOrEmpty(_verifiedExcelPath))
            {
                _errors.AppendBodyLine(" - The data source for this document is either invalid or could not be found.");
                return false;
            }

            // Get the diagram page:
            _vpg = _vdoc.DiagramPage_OrNull;
            if (_vpg == null)
            {
                _errors.AppendBodyLine(" - There is diagram page for this document.");
                return false;
            }

            // Get the doc-data:
            var dd = _vdoc.Data;
            if (dd == null)
            {
                _errors.AppendBodyLine(" - There is no data to save for this document.");
                return false;
            }

            return _hasNoDuplicateDescs(dd);
                       
        }

        private bool _hasNoDuplicateDescs(View.DocData dd)
        {
            // Remember that the Description field is the "unique id"
            // for task shapes.

            // Check for duplicate descriptions in the Excel file and in Visio:

            // Check for duplicates:
            List<string> cogDupsVis = null;
            List<string> obsDupsVis = null;
            List<string> cogDupsXl = null;
            List<string> obsDupsXl = null;

            if (dd.GetDuplicatesDescpriptions(
                out cogDupsXl, out obsDupsXl,
                out cogDupsVis, out obsDupsVis) == false) return true;

            
            if ((cogDupsVis.Count + obsDupsVis.Count) > 0)
            {
                _errors.AppendBodyLine(" - There are Visio shapes with duplicate Descriptions:");
                if (cogDupsVis.Count > 0)
                {
                    _errors.AppendBodyLine("   Cognitive Task Shape Duplicates:");
                    foreach (string d in cogDupsVis)
                        _errors.AppendBodyLine("    - " + d);
                }
                if (obsDupsVis.Count > 0)
                {
                    _errors.AppendBodyLine("   Observable Task Shape Duplicates:");
                    foreach (string d in obsDupsVis)
                        _errors.AppendBodyLine("    - " + d);
                }

                return false;
            }


            if ((cogDupsXl.Count + obsDupsXl.Count) > 0)
            {
                // TODO: the get data functionality for Excel is not returning
                // duplicates, so this is currently NOT going to find anything.

                _errors.AppendBodyLine(" - There are Excel records with duplicate Descriptions:");
                if (cogDupsXl.Count > 0)
                {
                    _errors.AppendBodyLine("   Cognitive Task Duplicates in Excel:");
                    foreach (string d in cogDupsVis)
                        _errors.AppendBodyLine("    - " + d);
                }
                if (obsDupsXl.Count > 0)
                {
                    _errors.AppendBodyLine("   Observable Task Duplicates in Excel:");
                    foreach (string d in obsDupsVis)
                        _errors.AppendBodyLine("    - " + d);
                }

                return false;
            }

            return true;
          
        }

        private bool _trySave()
        {
            try
            {
                // TODO: try-catch...?
                // TODO: use return value...
                if (_vdoc.SaveToExcel()) //...get a boolean, maybe an error?
                {
                    _verifiedExcelPath = _vdoc.GetAbsoluteAndValidExcelFilePath_OrEmpty();
                    _vpg.ClearOldDescriptionFields();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _errors.AppendBodyLine(" - An unexpected error occurred while saving data to Excel:\n" + ex.Message);
                //throw;
                return false;
            }
        }
        private bool _trySave2(string verifiedExcelPath)
        {
            try
            {
                _getSql(_vdoc, verifiedExcelPath);
                _xlodb.Write();
                _vpg.ClearOldDescriptionFields();
                return true;
            }
            catch (Exception ex)
            {
                _errors.AppendBodyLine(" - An unexpected error occurred while saving data to Excel:\n" + ex.Message);
                //throw;
                return false;
            }
        }

        
        private void _getSql(
            View.Doc vdoc,
            string verifiedExcelPath)
        {
            // verifiedExcelPath should be verified to exist before
            // we ever get to this procedure, since we would have to
            // keep checking it here and in other lower-level procs
            // as well.

            // Get the two task sets:
            var tasksVisio = new Data.TaskSet();
            var tasksExcel = new Data.TaskSet();

            GetVisioAndExcelTaskSets(vdoc, verifiedExcelPath, out tasksVisio, out tasksExcel);

            // Compare Visio tasks to Excel tasks, creating 
            // Updates or Inserts, as needed:

            // Reset the local data writer:
            _xlodb = new DataAccess.OdbExcel(verifiedExcelPath);

            foreach(var tv in tasksVisio.CognitiveTasks)
            {
                // If the Visio shape's description was renamed,
                // we need to find and Excel record with the OLD
                // description, then compare those two:
                bool isRename = (!String.IsNullOrEmpty(tv.OldDescription));
                string targetDesc = String.Empty;
                if(isRename)
                {
                    targetDesc = tv.OldDescription;
                }
                else
                {
                    targetDesc = tv.Description;
                }

                // Find a matching Excel task:
                var te = tasksExcel.CognitiveTasks.FirstOrDefault
                    (t => string.Compare(t.Description, targetDesc, true) == 0);

                if(te == null)
                {
                    //Debug.WriteLine("A cognitive task to insert.");
                    _addTaskForInsert(tv, te);
                }
                else
                {
                    //Debug.WriteLine("A cognitive task to update.");
                    _addTaskForUpdate(tv, te);
                }                   
            }


            foreach (var tv in tasksVisio.ObservableTasks)
            {
                // If the Visio shape's description was renamed,
                // we need to find and Excel record with the OLD
                // description, then compare those two:
                bool isRename = (!String.IsNullOrEmpty(tv.OldDescription));
                string targetDesc = String.Empty;
                if (isRename)
                {
                    targetDesc = tv.OldDescription;
                }
                else
                {
                    targetDesc = tv.Description;
                }

                // Find a matching Excel task:
                var te = tasksExcel.ObservableTasks.FirstOrDefault
                    (t => string.Compare(t.Description, targetDesc, true) == 0);

                if (te == null)
                {
                    //Debug.WriteLine("A cognitive task to insert.");
                    _addTaskForInsert(tv, te);
                }
                else
                {
                    //Debug.WriteLine("A cognitive task to update.");
                    _addTaskForUpdate(tv, te);
                }
            }

            Debug.WriteLine(_xlodb.GetPendingWriteSql());

        }

        private void _addTaskForInsert(
            Data.Task tskVis,
            Data.Task tskXl)
        {
            // For an insert, we simply add ALL of the fields:
            string tbl = String.Empty;
            string key = "Description"; // TODO: where to get these names?
            string keyVal = String.Empty;

            if (typeof(Data.CognitiveTask) == tskVis.GetType())
            {
                var c = tskVis as Data.CognitiveTask;
                keyVal = c.Description;

                tbl = "'" + SolutionStrings.ExcelTableName_Cognitive + "'"; // TODO: wrapping in single quotes here is tacky/hacky
           
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Description", c.Description);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category", c.Category);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category_Container", c.Category_Container);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category_Layer", c.Category_Layer);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category_NearestObservableTask", c.Category_NearestObservableTask);
                                                    
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Effort", c.Effort.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Frustration", c.Frustration.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Mental Demand", c.MentalDemand.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Performance", c.Performance.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Physical Demand", c.PhysicalDemand.Value);
                                                       
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Temporal Demand", c.TemporalDemand.Value);
            }
            else if (typeof(Data.ObservableTask) == tskVis.GetType())
            {
                var o = tskVis as Data.ObservableTask;
                keyVal = o.Description;

                tbl = "'" + SolutionStrings.ExcelTableName_Observable + "'"; // TODO: wrapping in single quotes here is tacky/hacky

                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Description", o.Description);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category", o.Category);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category_Container", o.Category_Container);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Category_Layer", o.Category_Layer);               
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Complexity", o.Complexity.Value);
                
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Difficulty", o.Difficulty.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Duration", o.Duration.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Frequency", o.Frequency.Value);
                _xlodb.AddDataField_ForInsert(tbl, key, keyVal, "Importance", o.Importance .Value); 
            }
        }
        private void _addTaskForUpdate(
            Data.Task tskVis,
            Data.Task tskXl)
        {
            // For an update, we add fields that are not the sae:
            string tbl = String.Empty;
            string key = "Description"; // TODO: where to get these names?
            string keyVal = String.Empty;

            int iCt = 0;

            if (typeof(Data.CognitiveTask) == tskVis.GetType())
            {
                var cv = tskVis as Data.CognitiveTask;
                keyVal = cv.Description;

                var ce = tskXl as Data.CognitiveTask;

                tbl = "'" + SolutionStrings.ExcelTableName_Cognitive + "'"; // TODO: wrapping in single quotes here is tacky/hacky

                bool isRename = (!String.IsNullOrEmpty(cv.OldDescription));

                // If this is a rename, then we are updating all of the data by
                // the old description:
                if (isRename)
                {
                    keyVal = cv.OldDescription;
                }
                else
                {
                    keyVal = cv.Description;
                }


                if (cv.Category != ce.Category)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category", cv.Category);
                    iCt++;
                }
                if (cv.Category_Container != ce.Category_Container)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category_Container", cv.Category_Container);
                    iCt++;
                }
                if (cv.Category_Layer != ce.Category_Layer)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category_Layer", cv.Category_Layer);
                    iCt++;
                }
                if (cv.Category_NearestObservableTask != ce.Category_NearestObservableTask)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category_NearestObservableTask", cv.Category_NearestObservableTask);
                    iCt++;
                }
                if (cv.Effort.Value != ce.Effort.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Effort", cv.Effort.Value);
                    iCt++;
                }


                if (cv.Frustration.Value != ce.Frustration.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Frustration", cv.Frustration.Value);
                    iCt++;
                }
                if (cv.MentalDemand.Value != ce.MentalDemand.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Mental Demand", cv.MentalDemand.Value);
                    iCt++;
                }
                if (cv.Performance.Value != ce.Performance.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Performance", cv.Performance.Value);
                    iCt++;
                }
                if (cv.PhysicalDemand.Value != ce.PhysicalDemand.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Physical Demand", cv.PhysicalDemand.Value);
                    iCt++;
                }
                if (cv.TemporalDemand.Value != ce.TemporalDemand.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Temporal Demand", cv.TemporalDemand.Value);
                    iCt++;
                }
                if (cv.Enjoyment.Value != ce.Enjoyment.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Enjoyment", cv.Enjoyment.Value);
                    iCt++;
                }

                // Now update the old description to the new description:
                if (isRename)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Description", cv.Description);
                }

            }
            else if (typeof(Data.ObservableTask) == tskVis.GetType())
            {
                var ov = tskVis as Data.ObservableTask;
                keyVal = ov.Description;

                var oe = tskXl as Data.ObservableTask;

                tbl = "'" + SolutionStrings.ExcelTableName_Observable + "'"; // TODO: wrapping in single quotes here is tacky/hacky

                bool isRename = (!String.IsNullOrEmpty(ov.OldDescription));

                // If this is a rename, then we are updating all of the data by
                // the old description:
                if (isRename)
                {
                    keyVal = ov.OldDescription;
                }
                else
                {
                    keyVal = ov.Description;
                }


                if (ov.Category != oe.Category)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category", ov.Category);
                    iCt++;
                }
                if (ov.Category_Container != oe.Category_Container)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category_Container", ov.Category_Container);
                    iCt++;
                }
                if (ov.Category_Layer != oe.Category_Layer)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Category_Layer", ov.Category_Layer);
                    iCt++;
                }
                if (ov.Complexity.Value != oe.Complexity.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Complexity", ov.Complexity.Value);
                    iCt++;
                }


                if (ov.Difficulty.Value != oe.Difficulty.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Difficulty", ov.Difficulty.Value);
                    iCt++;
                }
                if (ov.Duration.Value != oe.Duration.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Duration", ov.Duration.Value);
                    iCt++;
                }
                if (ov.Frequency.Value != oe.Frequency.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Frequency", ov.Frequency.Value);
                    iCt++;
                }
                if (ov.Importance.Value != oe.Importance.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Importance", ov.Importance.Value);
                    iCt++;
                }
                if (ov.Enjoyment.Value != oe.Enjoyment.Value)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Enjoyment", ov.Enjoyment.Value);
                    iCt++;
                }

                // Now update the old description to the new description:
                if (isRename)
                {
                    _xlodb.AddDataField_ForUpdate(tbl, key, keyVal, "Description", ov.Description);
                }

            }
        }

        // This is also useful for updating the data for shapes...
        public void GetVisioAndExcelTaskSets(
            View.Doc vdoc,
            string verifiedExcelPath, 
            out Data.TaskSet tasksVisio,
            out Data.TaskSet tasksExcel)
        {
            // Initialize the collections, even empty
            // collections are better than null!
            tasksVisio = new Data.TaskSet();
            tasksExcel = new Data.TaskSet();

            // Get the tasks from Visio:
            var vpg = _vdoc.DiagramPage_OrNull;
            if (vpg != null)
            {
                var visrdr = new ViewModel.VisioReader();
                visrdr.UpdateTasks(vpg.VisioPage, ref tasksVisio);
            }

            // Get the tasks from Excel:
            var xlrdr = new ViewModel.ExcelReader();
            xlrdr.UpdateTasks(verifiedExcelPath, ref tasksExcel);
          
        }

    }
}
