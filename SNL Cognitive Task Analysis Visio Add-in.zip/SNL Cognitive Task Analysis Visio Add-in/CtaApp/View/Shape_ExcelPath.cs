﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Shape_ExcelPath
    {
        // private const string ShapeName = "DataSourcePath" = SolutionStrings.ShapeName_Config_DataSourcePath

        private Vis.Document _visDoc = null;
        private Vis.Shape _visShp = null;
        private Vis.Shape _visShpPath = null;

        private string _sThisDocPath = String.Empty;
        //private string _sExcelFilePath = String.Empty;
        private string _sInitialShapeText = String.Empty;

        public static Shape_ExcelPath GetExcelPathShapeOrNull(Vis.Page visPg)
        {
            Vis.Shape shp = visPg.ShapeFromNameOrNull(
                SolutionStrings.ShapeName_Config_DataSourcePath);
            if (shp == null) return null;
            var sep = new Shape_ExcelPath(shp);
            return sep;
        }

        public string AbsoluteAndValidFilePathOrEmpty
        {
            get
            {
                if (_visShpPath == null) return String.Empty;

                // Return the shape text if it is an absolute path
                // to an existing file:
                string shapeText = _visShpPath.Text;
                if (File.Exists(shapeText)) return shapeText; //...it's a valid path!


                // See if the shape text was a relative path, combine
                // it with the document's path:
                string docPath = _visDoc.Path;
                if (docPath.Length == 0) return String.Empty; //...unsaved document, no path

                string docPathAndShapeText = Path.Combine(docPath, shapeText);
                if (File.Exists(docPathAndShapeText)) return docPathAndShapeText;

                // We can't find the file. We don't know if the shape
                // text is a valid path, or if the doc-path-plus-shapetext
                // would make a valid path. In either case, no file exists
                // so return empty:
                return String.Empty;
            }
        }

        public Shape_ExcelPath(Vis.Shape visShp)
        {
            _visShp = visShp;
            _visDoc = _visShp.Document;
            _sThisDocPath = _visDoc.Path;

            Vis.Page visPg = _visShp.ContainingPage;

            _visShpPath = visPg.ShapeFromNameOrNull(SolutionStrings.ShapeName_Config_DataSourcePath);

            if(_visShpPath != null)
                _sInitialShapeText = _visShpPath.Text;

            //_updatePathVariables();
        }

        /// <summary>
        /// Updates the text in the text box shape (SolutionStrings.ShapeName_Config_DataSourcePath)
        /// that holds the relative or absolute path to the data source. If the path can be
        /// made relative, this procedure does that automatically.
        /// </summary>
        /// <param name="newExcelFilePath">An absolute or relative path to a data source/Excel file.</param>
        public void SetPath(string newExcelFilepath)
        {
            if (_visShpPath.IsNullOrGone()) return;

            // Get a relative path, if possible, otherwise whatever
            // is in newExcelFilepath will be written to the path shape:
            string p = _tryGetRelativePath(newExcelFilepath);
            _visShpPath.Text = p;            
        }

        public void BrowseForNewDataSourcePath()
        {

            string currentFilePath = this.AbsoluteAndValidFilePathOrEmpty;

            string initialDirectory = String.Empty;

            if(File.Exists(currentFilePath))
            {
                FileInfo fi = new FileInfo(currentFilePath);
                initialDirectory = fi.Directory.FullName;
            }
            else
            {
                if (Directory.Exists(_sThisDocPath))
                    initialDirectory = _sThisDocPath;
            }

            // Reconcile if relative...
            //string sPathFromDocAndShapeText = Path.Combine(_sDocPath, sPathFromShapeText);

            // Open file dialog...
            // = _sDocPath;
            string newExcelFilePath = VL.ExcelData.DataChooser.GetExcelFileFromOpenFileDialog(initialDirectory);

            if (!File.Exists(newExcelFilePath)) return;

            if (_visShpPath != null)
            {
                string sShapeTextPath = _tryGetRelativePath(newExcelFilePath);
                _visShpPath.Text = sShapeTextPath;
            }            
        }

        private string _tryGetRelativePath(string absolutePath)
        {            
            // See if we can simplify the path, by returning a relative path:
            if (absolutePath.StartsWith(
                _sThisDocPath, StringComparison.InvariantCultureIgnoreCase) == false)
                return absolutePath;

            string sRelPath = absolutePath.Substring(_sThisDocPath.Length);
            
            // This actually causes a lot of problems, although it looks nice...
            //if (sRelPath.StartsWith(@"\") == false)
            //    sRelPath = @"\" + sRelPath;
           
            return sRelPath;
        }

    }
}
