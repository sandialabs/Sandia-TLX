﻿using System;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class VisioUndoManager
    {

        //public delegate bool VisVoidDelegate(string sResultInfo);
        public delegate void EmptyVoidDelegate();
        public delegate bool VisDocDelegate(Vis.Document visDoc);
        public delegate bool VisDocWithMessageDelegate(Vis.Document visDoc, string sResultInfo);
        public delegate bool VisPageDelegate_Bool(Vis.Page visPage);
        public delegate void VisPageDelegate_Void(Vis.Page visPage);
        public delegate bool VisSelDelegate(Vis.Selection visSel);
        public delegate void VisSelDelegateVoid(Vis.Selection visSel);
        public delegate bool VisSelWithCountsDelegate(Vis.Selection visSel, int iSelCt, int iChangeCt);
        public delegate bool VisShapeDelegate(Vis.Shape visShp);


        //out string sErrorMessage
        //sErrorMessage = String.Empty;
        //sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

        //Private Shared _undoScopeId As Integer = -1

        //Public Shared Sub ExecuteCommand(
        //            ByRef proc As Action,
        //            ByRef visApp As Vis.Application,
        //            ByVal sUndoScopeName As String)

        //    Dim undoScopeId As Integer = -1
        //    Try
        //        undoScopeId = visApp.BeginUndoScope(sUndoScopeName)
        //        proc.Invoke()
        //        visApp.EndUndoScope(undoScopeId, True)
        //    Catch ex As Exception
        //        If (visApp IsNot Nothing) Then
        //            If (undoScopeId <> -1) Then
        //                visApp.EndUndoScope(undoScopeId, False)
        //            End If
        //        End If
        //    End Try

        //End Sub

        // Command for no object, no argument:
        //public static void ExecuteCommand_NoParameters(
        //    Action proc,
        //    Vis.Application visApp,
        //    string sUndoScopeName,
        //    out string sErrorMessage)
        //{
        //    sErrorMessage = String.Empty;

        //    if ((visApp == null))
        //        return false;

        //    int undoScopeId = -1;
        //    try
        //    {
        //        undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
        //        proc.Invoke();
        //        visApp.EndUndoScope(undoScopeId, true);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

        //        if ((visApp != null))
        //        {
        //            if ((undoScopeId != -1))
        //            {
        //                visApp.EndUndoScope(undoScopeId, false);
        //            }
        //        }
        //        return false;
        //    }
        //}

        // Command for no object:
        public static bool ExecuteCommand_NoParameters(
            Action proc,
            Vis.Application visApp,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visApp == null))
                return false;

            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke();
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        //// Command for Visio application:

        //out string sErrorMessage
        //sErrorMessage = String.Empty;
        //sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
        public static bool ExecuteCommand(
            Action<Vis.Application> proc,
            Vis.Application visApp,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visApp == null))
                return false;

            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visApp);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }

        }

        //// Command for Visio page:

        public static bool ExecuteCommand(
            VisPageDelegate_Bool proc,
            Vis.Page visPg,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visPg == null))
                return false;

            Vis.Application visApp = visPg.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visPg);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        public static bool ExecuteCommand(
            VisPageDelegate_Void proc,
            Vis.Page visPg,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visPg == null))
                return false;

            Vis.Application visApp = visPg.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visPg);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        //// Command for Visio document:

        public static bool ExecuteCommand(
            VisDocDelegate proc,
            Vis.Document visDoc,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visDoc == null))
                return false;

            Vis.Application visApp = visDoc.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visDoc);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        public static bool ExecuteCommand(
            VisDocWithMessageDelegate proc,
            Vis.Document visDoc,
            string sUndoScopeName,
            string sResultInfo,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visDoc == null))
                return false;

            Vis.Application visApp = visDoc.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visDoc, sResultInfo);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }


        //TODO: Command for Visio shape:
        //// Command for Visio selection:

        public static bool ExecuteCommand(
            VisSelDelegate proc,
            Vis.Selection visSel,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            //var info = (MethodCallExpression)proc.Body;
            //Debug.WriteLine(proc.Method.Name);
            sErrorMessage = String.Empty;

            if ((visSel == null))
                return false;

            Vis.Application visApp = visSel.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visSel);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        public static bool ExecuteCommand(
            VisSelDelegateVoid proc,
            Vis.Selection visSel,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            //var info = (MethodCallExpression)proc.Body;
            //Debug.WriteLine(proc.Method.Name);
            sErrorMessage = String.Empty;

            if ((visSel == null))
                return false;

            Vis.Application visApp = visSel.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visSel);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;
                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        public static bool ExecuteCommand
            (VisShapeDelegate proc,
            Vis.Shape visShp,
            string sUndoScopeName,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visShp == null))
                return false;

            Vis.Application visApp = visShp.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visShp);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }
        }

        public static bool ExecuteCommand(
            VisSelWithCountsDelegate proc,
            Vis.Selection visSel, string sUndoScopeName,
            int iSelCt,
            int iChangeCt,
            out string sErrorMessage)
        {
            sErrorMessage = String.Empty;

            if ((visSel == null))
                return false;

            Vis.Application visApp = visSel.Application;
            int undoScopeId = -1;
            try
            {
                undoScopeId = visApp.BeginUndoScope(sUndoScopeName);
                proc.Invoke(visSel, iSelCt, iChangeCt);
                visApp.EndUndoScope(undoScopeId, true);
                return true;
            }
            catch (Exception ex)
            {
                sErrorMessage = "An error occurred in " + proc.Method.Name + ":\n" + ex.Message;

                if ((visApp != null))
                {
                    if ((undoScopeId != -1))
                    {
                        visApp.EndUndoScope(undoScopeId, false);
                    }
                }
                return false;
            }


        }

    }

}



