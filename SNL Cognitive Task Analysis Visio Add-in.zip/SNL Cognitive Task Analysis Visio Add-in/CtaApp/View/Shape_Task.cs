﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using SSC = SNL_Cognitive_Task_Analysis_Visio_Add_in.SolutionStrings; 

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public abstract class Shape_Task : Shape_Base  ///abstract
    {
        public const string BlankDescription = "---";

        private const string UserCell_IsAllRated = "User.IsAllRated";

        public bool IsNoDescription
        {
            get
            {
                string s = this.Description;
                if (String.IsNullOrEmpty(s)) return true;
                if (String.Compare(s, BlankDescription, true) == 0) return true;
                return false;
            }
        }

        public bool IsAllRated
        {
            get
            {
                bool? val = _visShp.TryGetCellResultBool_Nullable(UserCell_IsAllRated);
                if (val == null) return false;
                if (val == false) return false;
                return true;
            }  
        }
        public string TaskNumber
        { get { return _visShp.TryGetCellResultStr(SSC.PropCell_TaskNumber); }
          set { _visShp.TrySetCellResultStrU(SSC.PropCell_TaskNumber, value, true); } }

        public string Description
        { get { return _visShp.TryGetCellResultStr(SSC.PropCell_Description); }
          set { _visShp.TrySetCellResultStrU(SSC.PropCell_Description, value, true); } }

        public string OldDescription
        {
            get { return _visShp.TryGetCellResultStr(SSC.PropCell_OldDescription); }
            set { _visShp.TrySetCellResultStrU(SSC.PropCell_OldDescription, value, true); }
        }

        public string Category
        { get { return _visShp.TryGetCellResultStr(SSC.PropCell_Category); }
          set { _visShp.TrySetCellResultStrU(SSC.PropCell_Category, value, true); } }

        public void Set_Category()
        {
            // Make an alphabetized list of the layer names:
            var layerNames = new List<string>();

            for (short i = 1; i <= _visShp.LayerCount; i++)
            {
                Vis.Layer lyr = _visShp.Layer[i];
                layerNames.Add(lyr.Name);
            }

            layerNames.Sort();

            string layerList = String.Join(";", layerNames.ToArray());

            _visShp.TrySetCellResultStrU(SSC.PropCell_Category, layerList, true);
        }

        public string Category_Layer
            { get { return _visShp.TryGetCellResultStr(SSC.PropCell_CategoryLayer); } }
        public void Set_Category_Layer()
        {
            // Make an alphabetized list of the layer names:
            var layerNames = new List<string>();

            for (short i = 1; i <= _visShp.LayerCount; i++)
            {
                Vis.Layer lyr = _visShp.Layer[i];
                layerNames.Add(lyr.Name);
            }

            layerNames.Sort();

            string layerList = String.Join(";", layerNames.ToArray());

            _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryLayer, layerList, true);
        }
        public string Category_Container
            { get { return _visShp.TryGetCellResultStr(SSC.PropCell_CategoryContainer); } }

        public void Set_Category_Container()
        {
            string containerText = String.Empty;
            var ids = _visShp.MemberOfContainers;
            if (ids != null)
            {
                if (ids.Length > 0)
                {
                    Vis.Shape shpPar = _visShp.ContainingShape;
                    int containerId = (int)ids.GetValue(0);
                    Vis.Shape shpFirstCont = shpPar.GetShapeByIdSafe(containerId);
                    if (shpFirstCont != null)
                    {
                        //Debug.WriteLine(shpFirstCont.Text);
                        //Debug.WriteLine(shpFirstCont.Characters);
                        //string s1 = shpFirstCont.Characters.Text;
                        //Debug.WriteLine(s1);
                        //string s2 = shpFirstCont.Characters.Text.ToString();
                        //Debug.WriteLine(s2);

                        // Note: if the container has an inserted field, this
                        // will write a funny [obj] character instead of 
                        // the actual text:
                        // "￼"
                        containerText = shpFirstCont.Text; //.Characters.Text.ToString();
                    }
                }
            }
            // TrySetCellResultStrU handles double-quotes, and doubles
            // them up automatically.
            _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryContainer, containerText, true);
        }

        public Shape_Task(Vis.Shape visShp) : base(visShp) { }


        public Data.Rating GetRating(string cellname)
        {
            string val = _visShp.TryGetCellResultStr(cellname);

            var r = new Data.Rating();
            r.Value = val;

            return r;
        }

        public void SetRating(Data.Rating rating, string cellname)
        {
            if(rating == null)
            {
                _visShp.TrySetCellResultStrU(cellname, String.Empty, true);
            }
            else if(rating.IsNull || rating.IsNA)
            {
                _visShp.TrySetCellResultStrU(cellname, rating.Value, true);
            }
            else if (rating.IsNumeric)
            {
                _visShp.TrySetCellResultShort(cellname, rating.ValueShort);
            }
        }

        public void UpdateDescription_IfDifferent(string newDescription)
        {
            string oldDesc = this.Description;
            if (String.Compare(oldDesc, newDescription, false) == 0) return;

            // Set the new description:
            this.Description = newDescription;

            // Set the old description--this will act as a kind of flag
            // when the data is written out to Exce--if it isn't already
            // set. We don't want to "rename a rename", so to speak:
            if (String.IsNullOrEmpty(this.OldDescription))
                this.OldDescription = oldDesc;
        }


        #region "Connected Task Shape Code"

        // Set other flags related to connections:
        //this.IsStartShape = (visSelIncoming.Count == 0);
        //this.IsNotConnected = ((visSelIncoming.Count + visSelOutgoing.Count) == 0);

        private static string[] _classValsConn = 
            new string[] { SSC.ShapeClass_CtaConnector };
        private static string[] _classValsAll = 
            new string[] { SSC.ShapeClass_Cognitive, SSC.ShapeClass_Observable };

        public List<Shape_Task> ConnectedTaskShapes()
        {
            var taskshapes = _directlyConnectedTaskShapes(true, true);
            return taskshapes;
        }
        public List<Shape_Task> PreviousTaskShapes()
        {
            var taskshapes = _directlyConnectedTaskShapes(true, false);
            return taskshapes;
        }
        public List<Shape_Task> NextTaskShapes()
        {
            var taskshapes = _directlyConnectedTaskShapes(false, true);
            return taskshapes;
        }

        private List<Shape_Task> _directlyConnectedTaskShapes(bool getIncoming, bool getOutgoing)
        {
            var taskshapes = new List<Shape_Task>();

            var shps = _directlyConnectedShapes(getIncoming, getOutgoing);
            foreach(var shp in shps)
            {
                if(VisioSolutionHelpers.IsCognitiveShape(shp))
                {
                    var t = new Shape_Cognitive(shp);
                    if (t.IsSolutionShape) taskshapes.Add(t);
                }
                else if (VisioSolutionHelpers.IsObservableShape(shp))
                {
                    var t = new Shape_Observable(shp);
                    if (t.IsSolutionShape) taskshapes.Add(t);
                }
            }
            return taskshapes;
        }
        /// <summary>
        /// Gets the pure Visio shapes that are connected to _visShp, filtered
        /// by connector and shape User.Class values. The ids of connected shapes
        /// are tracked so that duplicates are not added to the collection.
        /// </summary>
        /// <param name="getIncoming"></param>
        /// <param name="getOutgoing"></param>
        /// <returns></returns>
        private List<Vis.Shape> _directlyConnectedShapes(bool getIncoming, bool getOutgoing)
        {
            // The collection to return:
            var shpsConnected = new List<Vis.Shape>();

            // Stupid case:
            if (getIncoming == false && getOutgoing == false) return shpsConnected;

            // Track the ids of connected shapes, so we don't double-add items:
            var ids = new List<int>();
            ids.Add(ShapeID);

            // Get the incoming and outgoing shapes:
            Vis.Selection visSelIncoming = null;
            Vis.Selection visSelOutgoing = null;

            _visShp.ConnectedShapes(_classValsConn, _classValsAll, _classValsAll,
                out visSelIncoming, out visSelOutgoing);

            // Add to the collection:

            if (getIncoming)
            {
                foreach (Vis.Shape shp in visSelIncoming)
                    if (ids.Contains(shp.ID) == false)
                        shpsConnected.Add(shp);
            }
            if (getOutgoing)
            {
                foreach (Vis.Shape shp in visSelOutgoing)
                    if (ids.Contains(shp.ID) == false)
                        shpsConnected.Add(shp);
            }

            return shpsConnected;
        }

        #endregion "Connected Task Shape Code"

        //{ _isSolutionShape(visShp); }

        //public override string RequiredCellsCSV
        //{
        //    get
        //    {
        //        throw new NotImplementedException();
        //    }
        //}

        //public override string UserClassValue
        //{
        //    get
        //    {
        //        throw new NotImplementedException();
        //    }
        //}
    }
}
