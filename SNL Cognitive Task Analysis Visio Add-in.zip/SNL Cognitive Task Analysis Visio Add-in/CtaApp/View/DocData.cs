﻿using System;
using System.Collections.Generic;
using System.IO;
//using SNL_Cognitive_Task_Analysis_Visio_Add_in.ViewModel;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    // Some sort of thing that ties together Excel Data, Visio, and life.
    public class DocData
    {
        // On open doc or refresh, read Excel, note the various categories
        // Read Visio add to the categories, add valid shapes as records, note any conflicts


        // Really applies to a page...

        // Excel file path

        private View.Doc _vdoc = null;

        private DateTime _ExcelLastReadAttempt = DateTime.MinValue;
        private bool _ExcelDataEmpty = true;
        private DateTime _VisioLastReadAttempt = DateTime.MinValue;

        private Data.TaskSet _tasks = null;
        public Data.TaskSet Tasks { get { return _tasks; } }

        public List<Data.CognitiveTask> CognitiveTasksList_InDataOnly
        {
            get
            {
                var lst = new List<Data.CognitiveTask>();
                foreach (var itm in _tasks.CognitiveTasks)
                {
                    if (itm.IsInExcel && (itm.IsInVisio == false))
                        lst.Add((Data.CognitiveTask)itm);
                }
                return lst;
            }
        }
        public List<Data.ObservableTask> ObservableTasksList_InDataOnly
        {
            get
            {
                var lst = new List<Data.ObservableTask>();
                foreach (var itm in _tasks.ObservableTasks)
                {
                    if (itm.IsInExcel && (itm.IsInVisio == false))
                        lst.Add((Data.ObservableTask)itm);
                }
                return lst;
            }
        }

        // Get Id/Descriptions for cog and obs

        // Constructor
        public DocData(View.Doc vdoc) // Vis.Document visDoc)
        {
            _vdoc = vdoc; // new View.Doc(visDoc);
            //_init(); //...do we want to specify when to do this?
        }

        public void Refresh() //...ie: FORCE refresh
        {
            _refreshData();
        }

        public int GetNewId() { return -1; } // TODO generate new id

        public void RenameCategory(string oldname, string newname)
        {
            // TODO: does RenameCategory belong in DocData or Doc or Page_Diagram?
            _renameCategory(oldname, newname);
        }
        public void RenameDescription(Type taskShapeType, string oldDescription, string newDescription)
        {
            // TODO: does RenameDescription belong in DocData or Doc or Page_Diagram?
            _renameDescription(taskShapeType, oldDescription, newDescription);
        }

        // Get Names cog/obs
        // Get categories cog/obs


        private void _refreshData()
        {
            // Decide if we need to re-initialize everything:
            bool bRestart = false;

            // If for any reason we are "re-starting", then Excel will
            // get read. Visio will always be re-read (I think)

            if (_tasks == null)
            {
                bRestart = true;
            }
            else
            {
                if (_ExcelLastReadAttempt == DateTime.MinValue)
                {
                    // Excel read was never attempted:
                    bRestart = true;
                }
                else
                {
                    // Reread if Excel data is "old"
                    // 2016.02.09: 10 seconds                  
                    var tsElapsedTime = DateTime.Now - _ExcelLastReadAttempt;
                    if (tsElapsedTime.Seconds > 10) bRestart = true;
                }
            }
            // We might also want to re-read Excel if the last read
            // produced NO data:
            //if (_ExcelDataEmpty)


            if (bRestart)
            {
                // Re-initialize the collections:
                _tasks = new Data.TaskSet();

                // Get Excel data
                _getData_Excel(ref _tasks);

                _ExcelLastReadAttempt = DateTime.Now;
                _ExcelDataEmpty = (_tasks.TotalCount == 0);
            }



            // Get Visio data. If there are conflicts, then ask the user if
            // 1. The shapes should be updated from Excel
            // 2. The Visio data is the "real data", and the Excel can update
            //    Excel at a later point in time (on save or whatever...)


            // We could also not re-scan Visio every single time if the
            // Visio "last read" is relatively recent. This would suppose that
            // not much has changed in a minute or two...

            var tsVisElapsedTime = DateTime.Now - _VisioLastReadAttempt;
            if (tsVisElapsedTime.Seconds > 1) // TODO: Visio time to refresh
            {
                // Get Visio data:
                _getData_Visio();
                _VisioLastReadAttempt = DateTime.Now;
            }

            // Dump:
            _tasks.DebugDump();


            // So we need two sets of data, and then a melding, based on the Conflicts flag,
            // i.e.:
            // cogs.Meld(cogsExcel, cogsVisio, KeepVisioValuesAsActual)
            // cogs.Meld(cogsExcel, cogsVisio, OverwriteVisioValuesWithExcel)
            //
            // pass in a UI delegate that lets the user choose...
            //
            // When we first meld the two sets, keep a record of which shape-records clash with which excel-records.
            //
            // We could also have the case that some Visio records conflict with each other...

        }

        public Data.TaskSet GetExcelData()
        {
            var xldataset = new Data.TaskSet(); ;
            _getData_Excel(ref xldataset);
            return xldataset;
        }

        private void _getData_Excel(ref Data.TaskSet taskset)
        {
            // If the Excel path is bogus, this should just return
            // a whole bunch of nothing. That way we can continue to
            // work.
            string xlpath = _vdoc.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (File.Exists(xlpath))
            {
                var er = new ViewModel.ExcelReader();

                List<Data.CognitiveTask> cogs;
                List<Data.ObservableTask> obs;
                er.GetTasks(xlpath, out cogs, out obs);
                foreach (var c in cogs) taskset.Add(c, true, false);
                foreach (var o in obs) taskset.Add(o, true, false);               
            }
        }

        private void _getData_Visio()
        {
            // Use the VisioReader...

            // Get the Visio page we're dealing with:
            var vpg = _vdoc.DiagramPage_OrNull;
            if (vpg == null) return;

            // Let the VisioReader update _tasks:
            var visreader = new ViewModel.VisioReader();
            visreader.UpdateTasks(vpg.VisioPage, ref _tasks);

            return;


            // TODO: implement "overwrite modes", but initially
            // a Visio shape should override an Excel record, THEN,
            // duplicate Visio shapes should be noted...somewhere...maybe
            // as a list of ids in teh TaskVx object or in the collection handler...

            //View.Doc d;
            //d.GetDiagramPageOrNull()?.GetCogntiveShapes...
            //d.GetDiagramPageOrNull()?.GetCogntiveShapes... List<ObsTaskWorking>



            var dcogs = new List<Data.CognitiveTask>();
            var vcogshps = vpg.GetCognitiveShapes();
            foreach (var vshp in vcogshps)
            {
                var dcog = new Data.CognitiveTask();

                dcog.TaskNumber = vshp.TaskNumber;
                dcog.Description = vshp.Description;

                // Only add "non-null" tasks:
                //dcog.TaskNumber == null ||                               
                //if (!( String.IsNullOrEmpty(dcog.Description) ||
                //       dcog.Description == "---") ) //...need a better "IsDefault placeholder" test
                if (!vshp.IsNoDescription)
                {

                    dcog.Category = vshp.Category;
                    dcog.Category_Container = vshp.Category_Container;
                    dcog.Category_Layer = vshp.Category_Container;
                    dcog.Category_NearestObservableTask = vshp.Cat_NearestObservableTask;


                    
                    dcog.Effort = vshp.Effort;
                    dcog.Frustration = vshp.Frustration;
                    dcog.MentalDemand = vshp.MentalDemand;
                    dcog.Performance = vshp.Performance;
                    dcog.PhysicalDemand = vshp.PhysicalDemand;
                    dcog.TemporalDemand = vshp.TemporalDemand;
                    dcog.Enjoyment = vshp.Enjoyment;

                    dcogs.Add(dcog);
                }
            }

            var dobs = new List<Data.ObservableTask>();
            var vobshps = vpg.GetObservableShapes();
            foreach (var vshp in vobshps)
            {
                var dob = new Data.ObservableTask();

                dob.TaskNumber = vshp.TaskNumber;
                dob.Description = vshp.Description;

                // Only add "non-null" tasks:
                //if (!(dob.TaskNumber == null ||
                //   String.IsNullOrEmpty(dob.Description) ||
                //   dob.Description == "---")) //...need a better "IsDefault placeholder" test
                if (!vshp.IsNoDescription)
                {

                    dob.Category = vshp.Category;
                    dob.Category_Container = vshp.Category_Container;
                    dob.Category_Layer = vshp.Category_Layer;

                    dob.Complexity = vshp.Complexity;
                    dob.Difficulty = vshp.Difficulty;
                    dob.Duration = vshp.Duration;
                    dob.Frequency = vshp.Frequency;
                    dob.Importance = vshp.Importance;
                    dob.Enjoyment = vshp.Enjoyment;

                    dobs.Add(dob);
                }
            }

            // For now, just add everything to the private collections. Eventually
            // we need to merge with the Excel data.
            foreach (var c in dcogs) _tasks.Add(c, false, true);
            foreach (var o in dobs) _tasks.Add(o, false, true);
        }

        public bool GetDuplicatesDescpriptions(
            out List<string> cogDupsExcel,
            out List<string> obsDupsExcel, 
            out List<string> cogDupsVisio,
            out List<string> obsDupsVisio)
        {
            _refreshData();

            cogDupsExcel = _getDuplicateDescriptions_Excel(true, false);
            obsDupsExcel = _getDuplicateDescriptions_Excel(false, true);

            _getDuplicateDescriptions_Visio(out cogDupsVisio, out obsDupsVisio);

            return (cogDupsExcel.Count + obsDupsExcel.Count +
                    cogDupsVisio.Count + obsDupsVisio.Count) > 0;
        }

        public bool GetDuplicatesInExcel(
            out List<string> cognitiveDuplicateDescriptions,
            out List<string> observableDuplicateDescriptions)
        {
            _refreshData();

            cognitiveDuplicateDescriptions = _getDuplicateDescriptions_Excel(true, false);
            observableDuplicateDescriptions = _getDuplicateDescriptions_Excel(false, true);

            return (cognitiveDuplicateDescriptions.Count > 0) ||
                   (observableDuplicateDescriptions.Count > 0);
        }

        private bool _getDuplicateDescriptions_Visio(
            out List<string> cogDups, out List<string> obsDups)
        {
            // Note: assumes _refreshData() has already been called.
            cogDups = new List<string>();

            var vpg = _vdoc.DiagramPage_OrNull;
            if (vpg != null)
            {
                vpg.GetDuplicateDescriptions(out cogDups, out obsDups);            
            }
            else
            {
                cogDups = new List<string>();
                obsDups = new List<string>();
            }
            return ((cogDups.Count + obsDups.Count) > 0);
            
        }
        private List<string> _getDuplicateDescriptions_Excel(bool getCogs, bool getObs)
        {
            // Note: assumes _refreshData() has already been called.

            // TODO: the get data functionality for Excel is not returning
            // duplicates, so this is currently NOT going to find anything.

            var dict = new Dictionary<string, int>();

            if (getCogs)
            {
                foreach (var t in this.Tasks.CognitiveTasks)
                {
                    // Add or increment the dictionary entry:
                    if (t.IsInVisio == false &&
                        t.IsInExcel)
                    {
                        string d = t.Description;
                        if (dict.ContainsKey(d))
                        {
                            dict[d]++;
                        }
                        else
                        {
                            dict.Add(d, 1);
                        }
                    }
                }
            }
            if (getObs)
            {
                foreach (var t in this.Tasks.ObservableTasks)
                {
                    // Add or increment the dictionary entry:
                    if (t.IsInVisio == false &&
                        t.IsInExcel)
                    {
                        string d = t.Description;
                        if (dict.ContainsKey(d))
                        {
                            dict[d]++;
                        }
                        else
                        {
                            dict.Add(d, 1);
                        }
                    }
                }
            }

            var dups = new List<string>();
            foreach(var k in dict.Keys)
            {
                if (dict[k] > 1)
                    dups.Add(k);
            }

            dups.Sort();
            return dups;
        }

        private void _renameCategory(string oldname, string newname)
        {
            // TODO: get ALL task shapes from DiagramPage  - no need to have this separate for certain things.

            var vpg = _vdoc.DiagramPage_OrNull;
            if (vpg == null) return;

            // Update all task shapes:
            foreach(var t in vpg.GetTaskShapes())// .GetCognitiveShapes())
            {
                if (String.Compare(oldname, t.Category, true) == 0)
                    t.Category = newname;
            }
            //foreach (var t in vpg.GetObservableShapes())
            //{
            //    if (String.Compare(oldname, t.Category, true) == 0)
            //        t.Category = newname;
            //}

            // Update items in Excel too? We are trying to avoid writing to Excel
            // until absolutely necessary...
        }
        private void _renameDescription(Type taskShapeType, string oldDescription, string newDescription)
        {
            var vpg = _vdoc.DiagramPage_OrNull;
            if (vpg == null) return;

            // Check that the calling shape is being updated too.

            if(taskShapeType == typeof(View.Shape_Cognitive))
            {
                foreach(var t in vpg.GetCognitiveShapes())
                    t.UpdateDescription_IfDifferent(newDescription);
            }
            else
            {
                foreach (var t in vpg.GetObservableShapes())
                    t.UpdateDescription_IfDifferent(newDescription);
            }
           
        }

    }
}
