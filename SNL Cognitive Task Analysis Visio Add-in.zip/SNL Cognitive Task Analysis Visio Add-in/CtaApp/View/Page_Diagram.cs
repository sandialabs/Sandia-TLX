﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Page_Diagram : Page_Base
    {
        public static Page_Diagram GetFirstConfigPageOrNull(Vis.Document visDoc)
        {
            Vis.Page visPg = visDoc.FirstPageOfClass(
                SolutionStrings.PageClass_Config, true, false);
            if (visPg == null) return null;
            return new Page_Diagram(visPg);
        }

        public Page_Diagram(Vis.Page visPg) : base(visPg)
        {
            _userClassValue = SolutionStrings.PageClass_MainDiagram;
        }

        // Use methods in DataGraphicApplier now...
        //public void ClearDataGraphics()
        //{
        //    foreach (var s in _getAllTasks_Cognitive())
        //            s.ClearDataGraphic();
        //    foreach (var s in _getAllTasks_Observable())
        //            s.ClearDataGraphic();

        //    // Update the "current data graphic" status:
        //    UpdateCurrentDataGraphicLabels(true, true, null);
        //}

        // Use methods in DataGraphicApplier now...
        //public void TryApplyDataGraphic(string dataGraphicName)
        //{
        //    // Try to get a datagraphic/master by name, then apply
        //    // it to Cognitive and/or Observable shapes.

        //    Vis.Document doc = _visPg.Document;
        //    Vis.Master mstDg = doc.MasterByName(dataGraphicName);
        //    if (mstDg == null) return;

        //    bool bApplyToCog = false;
        //    bool bApplyToObs = false;

        //    // We can implement some funny, name-based logic to
        //    // filter which shapes we apply the data graphics to.
        //    // If the name contains "Task" apply to both. If the
        //    // name contains "Cog" of "Cognitive", or "Obs" or 
        //    // "Observable", then...
        //    // If the name contains none of these things, then apply
        //    // to both - "inappropriate" datagraphics will fail 
        //    // gracefully anyway...


        //    string nameLC = dataGraphicName.ToLower();
        //    if( nameLC.Contains("cog") || 
        //        nameLC.Contains("cognitive"))
        //    {
        //        bApplyToCog = true;
        //    }
        //    if (nameLC.Contains("obs") || 
        //        nameLC.Contains("observable"))
        //    {
        //        bApplyToObs = true;
        //    }
        //    if (nameLC.Contains("task") )
        //    {
        //        bApplyToCog = true;
        //        bApplyToObs = true;
        //    }

        //    // This is maybe the weirdest one: if neither
        //    // flag is set, set both of them, ie: "what the heck,
        //    // go for it!":
        //    if (bApplyToCog == false && 
        //        bApplyToObs == false)
        //    {
        //        bApplyToCog = true;
        //        bApplyToObs = true;
        //    }

        //    // Now do it!
        //    if(bApplyToCog)
        //    {
        //        foreach (var s in _getAllTasks_Cognitive())
        //            s.TryApplyDataGraphic(mstDg);
        //    }
        //    if (bApplyToObs)
        //    {
        //        foreach (var s in _getAllTasks_Observable())
        //            s.TryApplyDataGraphic(mstDg);
        //    }

        //    // Update the "current data graphic" status:
        //    UpdateCurrentDataGraphicLabels(bApplyToCog, bApplyToObs, mstDg);
        //}

        public bool AddShapes_Many(
            List<Data.CognitiveTask> taskDataCogs,
            List<Data.ObservableTask> taskDataObs,
            bool addConnectors)
        {
            // TODO: some refactoring...

            int iTotal = taskDataCogs.Count + taskDataObs.Count;
            if ((iTotal) == 0) return false;
            if (_visPg.StatNotNormal()) return false;

            // Get the page center:
            double xCenter, yCenter;
            var win = _visPg.GetViewCenter(out xCenter, out yCenter);
            if (win == null)
            {
                xCenter = _visPg.PageWidthIU() * 0.5;
                yCenter = _visPg.PageHeightIU() * 0.5;
            }

            // Shape size and drop coordinates:
            double wCog, wObs, h, px, py;
            wCog = 0;
            wObs = 0;
            h = 0;
            px = 0;
            py = 0;


            // Drop cognitive shapes, arrange in vertical column, 
            // and populate data:
            var newCogShps = new List<Vis.Shape>();
            if (taskDataCogs.Count > 0)
            {
                var sdc = new View.ShapeDropper(ShapeTypes.CognitiveTask, _visPg);
                newCogShps = sdc.DropShapeArray(_visPg, taskDataCogs.Count);

                int iCog = 0;
                foreach (var tskdata in taskDataCogs)
                {
                    // Get the shape and move it:
                    var shp = newCogShps[iCog];
                    if (iCog == 0)
                    {
                        wCog = shp.WidthIU();
                        h = shp.HeightIU();
                        px = xCenter - wCog;
                        py = yCenter;
                    }
                    shp.SetCenter(px, py);

                    // Set the data:
                    var vshp = new Shape_Cognitive(shp);
                    ViewModel.VisioWriter.UpdateTaskShapeFromData(vshp, tskdata, true);

                    // Increment, decrement stuff:
                    iCog++;
                    py = py - h - 0.125;
                }
            }

            // Drop observable shapes, arrange in vertical column,
            // and populate data:
            var newObsShps = new List<Vis.Shape>();
            if (taskDataObs.Count > 0)
            {
                var sdo = new View.ShapeDropper(ShapeTypes.ObservableTask, _visPg);
                newObsShps = sdo.DropShapeArray(_visPg, taskDataObs.Count);

                int iObs = 0;
                foreach(var tskdata in taskDataObs)
                {
                    // Get the shape and move it:
                    var shp = newObsShps[iObs];
                    if (iObs == 0)
                    {
                        wObs = shp.WidthIU();
                        h = shp.HeightIU();
                        px = xCenter + wObs;
                        py = yCenter;
                    }
                    shp.SetCenter(px, py);

                    // Set the data:
                    var vshp = new Shape_Observable(shp);                    
                    ViewModel.VisioWriter.UpdateTaskShapeFromData(vshp, tskdata, true);

                    // Increment, decrement stuff:
                    iObs++;
                    py = py - h - 0.125;
                }
            }

            // Drop the connectors:
            var newConnShps = new List<Vis.Shape>();
            var sdconn = new View.ShapeDropper(ShapeTypes.Connector, _visPg);
            newConnShps = sdconn.DropShapeArray(_visPg, iTotal);

            // Connect connectors:
            Vis.Shape shpConn = null;
            int iConn = 0;
            double offset = 0.5;
            foreach(var shp in newCogShps)
            {
                shpConn = newConnShps[iConn];
                _attachConnectorBeginToShape(shpConn, shp, offset);
                iConn++;
            }
            foreach (var shp in newObsShps)
            {
                shpConn = newConnShps[iConn];
                _attachConnectorBeginToShape(shpConn, shp, offset);
                iConn++;
            }



            // Switch to diagram page
            // Drop in two columns, centered on the current view
            // add connector with fixed 0.75" offset to each shape to
            // save time.


            // TODO: 
            // Drop a shape:
            // Set the shape's data:
            //if (isCog)
            //{
            //    var dataCog = dd.Tasks.FirstCognitiveTask_ByDescOrNull(newDesc);
            //    if (dataCog != null)
            //        ViewModel.VisioWriter.UpdateTaskShapeFromData(tshp, dataCog, false);
            //}
            //else if (isObs)
            //{
            //    var dataObs = dd.Tasks.FirstObservableTask_ByDescOrNull(newDesc);
            //    if (dataObs != null)
            //        ViewModel.VisioWriter.UpdateTaskShapeFromData(tshp, dataObs, false);
            //}

            return true;
        }


        public void ClearOldDescriptionFields()
        {            
            foreach (var t in this.GetTaskShapes())
                t.OldDescription = String.Empty;
        }

        /// <summary>
        /// Glues the 1-D Begin of a connector to a target shape, 
        /// and sets up the 1-D End so that it dynamically protrudes
        /// to the right (or left) of the begin--the connector moves
        /// with the shape until the user glues the 1-D End.
        /// </summary>
        /// <param name="shpConn"></param>
        /// <param name="shpTarget"></param>
        /// <param name="offset"></param>
        private void _attachConnectorBeginToShape(
            Vis.Shape shpConn, Vis.Shape shpTarget, double offset)
        {
            // Note: shpConn should be an SNL CTA Dynamic Connector,
            // and shpTarget should be a Cognitive Task or Observable
            // Task, with cell Connection.Right.

            // Note: dynamic glue was being weird about offseting
            // the end, so we'll just glue to the right connection
            // point for now...

            //PAR(PNT(Observable Task!Connections.Right.X, Observable Task!Connections.Right.Y))

            double x, y;
            shpTarget.RightMiddleIU(out x, out y);

            // Glue the Begin to Connections.Right:
            string f = "PAR(PNT(" + shpTarget.NameID + "!Connections.Right.X," + shpTarget.NameID + "!Connections.Right.Y))";
            shpConn.CellsU["BeginX"].FormulaForceU = f;
            shpConn.CellsU["BeginY"].FormulaForceU = f;

            // Prime the location of the shape:
            //shpConn.CellsU["BeginX"].ResultIUForce = x;
            //shpConn.CellsU["BeginY"].ResultIUForce = y;
            //shpConn.CellsU["EndY"].ResultIUForce = y;

            // Constrain the end to the begin, plus an offset:
            shpConn.CellsU["EndX"].FormulaForceU = "BeginX+" + offset.ToString();
            shpConn.CellsU["EndY"].FormulaForceU = "BeginY";

            // Glue the begin to the target:
            //shpConn.CellsU["BeginX"].GlueTo(shpTarget.CellsU["PinX"]);                        
        }

        public void UpdateCurrentDataGraphicLabels(
            bool forCognitive, bool forObservable,
            Vis.Master visMstDg_OrNull)
        {
            Vis.Shape shpTitle = _visPg.ShapeFromNameOrNull(SolutionStrings.ShapeName_Diagram_TitleShape);
            if (shpTitle == null) return;

            // TODO: create a View.Shape_Title class?
            const string DgNameForNull = "None";

            // Cognitive data graphic name:
            if(forCognitive)
            {
                string dgNameCog;
                if (visMstDg_OrNull == null)
                {
                    dgNameCog = DgNameForNull;
                }
                else
                {
                    dgNameCog = visMstDg_OrNull.Name;
                }

                shpTitle.TrySetCellResultStrU("Prop.CurrentDataGraphic_Cognitive", dgNameCog, true);
            }

            // Cognitive data graphic name:
            if (forObservable)
            {
                string dgNameObs;
                if (visMstDg_OrNull == null)
                {
                    dgNameObs = DgNameForNull;
                }
                else
                {
                    dgNameObs = visMstDg_OrNull.Name;
                }

                shpTitle.TrySetCellResultStrU("Prop.CurrentDataGraphic_Observable", dgNameObs, true);
            }
        }

        public void DisconnectedShapes(
            out List<Vis.Shape> disconnected2dShapes,
            out List<Vis.Shape> disconnected1dShapes)
        {
            disconnected2dShapes = new List<Microsoft.Office.Interop.Visio.Shape>();
            disconnected1dShapes = new List<Microsoft.Office.Interop.Visio.Shape>();

            Vis.Selection sel = VisioSolutionHelpers.GetSolutionShapesOnPage_CogObsConn(_visPg);

            foreach(Vis.Shape shp in sel)
            {
                if (shp.Is1D())
                {
                    if (VisioSolutionHelpers.IsDisconnected_1D(shp))
                        disconnected1dShapes.Add(shp);
                }
                else
                {
                    if (VisioSolutionHelpers.IsDisconnected_2D(shp))
                        disconnected2dShapes.Add(shp);
                }
            }
        }


        public List<Shape_Cognitive> GetCognitiveShapes()
        {
            var vshps = new List<Shape_Cognitive>();
            Vis.Selection sel = VisioSolutionHelpers.GetSolutionShapesOnPage_Cog(_visPg);
            foreach (Vis.Shape shp in sel)
            {
                var vshp = new Shape_Cognitive(shp);
                vshps.Add(vshp);
            }
            return vshps;
        }
        public List<Shape_Observable> GetObservableShapes()
        {
            var vshps = new List<Shape_Observable>();
            Vis.Selection sel = VisioSolutionHelpers.GetSolutionShapesOnPage_Obs(_visPg);
            foreach (Vis.Shape shp in sel)
            {
                var vshp = new Shape_Observable(shp);
                vshps.Add(vshp);
            }
            return vshps;
        }

        public void GetTasksWithDuplicateDescriptions(
            out List<Shape_Cognitive> duplicateCogs,
            out List<Shape_Observable> duplicateObs)
        {
            // Get a dictionary of <descriptions, cog object collection>:
            var descCogs = new Dictionary<string, List<View.Shape_Cognitive>>();
            var cogs = this.GetCognitiveShapes();
            foreach (var cog in cogs)
            {
                var d = cog.Description;
                if (descCogs.ContainsKey(d) == false)
                    descCogs.Add(d, new List<Shape_Cognitive>());
                descCogs[d].Add(cog);
            }
            // Save only the cogs that have more than one item:
            duplicateCogs = new List<Shape_Cognitive>();
            foreach (var k in descCogs.Keys)
            {
                var lst = descCogs[k];
                if (lst.Count > 1)
                {
                    duplicateCogs.AddRange(lst);
                }
            }

            // Repeat for observable tasks:

            // Get a dictionary of <descriptions, cog object collection>:
            var descObs = new Dictionary<string, List<View.Shape_Observable>>();
            var obs = this.GetObservableShapes();
            foreach (var ob in obs)
            {
                var d = ob.Description;
                if (descObs.ContainsKey(d) == false)
                    descObs.Add(d, new List<Shape_Observable>());
                descObs[d].Add(ob);
            }
            // Save only the cogs that have more than one item:
            duplicateObs = new List<Shape_Observable>();
            foreach (var k in descObs.Keys)
            {
                var lst = descObs[k];
                if (lst.Count > 1)
                {
                    duplicateObs.AddRange(lst);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="duplicateCogDescs"></param>
        /// <param name="duplicateObsDescs"></param>
        /// <returns>Returns true if there are duplicates.</returns>
        public bool GetDuplicateDescriptions(
            out List<string> duplicateCogDescs,
            out List<string> duplicateObsDescs)
        {
            List<Shape_Cognitive> dupCogShps = null;
            List<Shape_Observable> dupObShps = null;
            this.GetTasksWithDuplicateDescriptions(out dupCogShps, out dupObShps);

            const string blankPlaceholder = "<no description>";

            duplicateCogDescs = new List<string>();
            foreach (var s in dupCogShps)
            {
                var d = s.Description;
                if (Data.Task.IsEmptyDescription(d)) d = blankPlaceholder;
                if (!duplicateCogDescs.ContainsAllCsvItems_CaseInsensitive(d))
                    duplicateCogDescs.Add(d);
                duplicateCogDescs.Sort();
            }

            duplicateObsDescs = new List<string>();
            foreach (var s in dupObShps)
            {
                var d = s.Description;
                if (Data.Task.IsEmptyDescription(d)) d = blankPlaceholder;
                if (!duplicateObsDescs.ContainsAllCsvItems_CaseInsensitive(d))
                    duplicateObsDescs.Add(d);
                duplicateObsDescs.Sort();
            }

            return ((duplicateCogDescs.Count + duplicateObsDescs.Count) > 0);
        }

        public List<Shape_Task> GetTaskShapes()
        {
            var vshps = new List<Shape_Task>();
            Vis.Selection sel = VisioSolutionHelpers.GetSolutionShapesOnPage_CogObs(_visPg);
            foreach (Vis.Shape shp in sel)
            {
                if(VisioSolutionHelpers.IsCognitiveShape(shp))
                {
                    var t = new Shape_Cognitive(shp);
                    if (t.IsSolutionShape)
                        vshps.Add(t);
                }
                else if (VisioSolutionHelpers.IsObservableShape(shp))
                {
                    var t = new Shape_Observable(shp);
                    if (t.IsSolutionShape)
                        vshps.Add(t);
                }
            }
            return vshps;
        }

        //public int Highlight_DuplicateTaskNames_Cognitive()
        //{
        //    // Build Vis.Selection object of those shapes
        //    Vis.Selection visSel = _getDuplicateVisSelection_CogTaskNames();

        //    // Highlight the shapes
        //    var hl =
        //        HighlightShape.HighlightTargets(
        //        visSel,
        //        HighlightShape.HighlightShapeStyle.Oval,
        //        HighlightShape.HighlightShapeColors.Green,
        //        SolutionStrings.HighlightTag_Duplicate);

        //    return hl.Count;
        //}
        public int Highlight_Disconnections()
        {
            // Delete existing highlights:
            //ClearHighlights();

            List<Vis.Shape> disconnected2dShapes;
            List<Vis.Shape> disconnected1dShapes;

            DisconnectedShapes(out disconnected2dShapes, out disconnected1dShapes);

            // 2D shapes:
            var HL2D = 
                HighlightShape.HighlightTargets(
                disconnected2dShapes,                    
                HighlightShape.HighlightShapeStyle.Oval, 
                HighlightShape.HighlightShapeColors.Red, 
                SolutionStrings.HighlightTag_Disconnected);

            // 1D shapes:
            var targetCellsX = new List<Vis.Cell>();
            var targetCellsY = new List<Vis.Cell>();
            foreach (Vis.Shape shp in disconnected1dShapes)
            {
                if(VisioSolutionHelpers.IsDisconnectedAt1dBegin(shp))
                {
                    Vis.Cell cx = shp.CellsU["BeginX"];
                    Vis.Cell cy = shp.CellsU["BeginY"];
                    targetCellsX.Add(cx);
                    targetCellsY.Add(cy);
                }
                if (VisioSolutionHelpers.IsDisconnectedAt1dEnd(shp))
                {
                    Vis.Cell cx = shp.CellsU["EndX"];
                    Vis.Cell cy = shp.CellsU["EndY"];
                    targetCellsX.Add(cx);
                    targetCellsY.Add(cy);
                }
            }

            var HL1D =
            HighlightShape.HighlightPoints(
                targetCellsX, targetCellsY,
                0.1,
                HighlightShape.HighlightShapeStyle.Oval,
                HighlightShape.HighlightShapeColors.Red,
                SolutionStrings.HighlightTag_Disconnected);

            // Set line color transparency for all the highlights:
            //foreach (var hl in HL2D)
            //    hl.LineTransparency = 0.5;
            //foreach (var hl in HL1D)
            //    hl.LineTransparency = 0.5;

            return (HL2D.Count + HL1D.Count);
        }

        public void RefreshProgressBars()
        {
            int count = Shape_ProgressBars.UpdateProgressReportsShapesOnPage(_visPg);
            Debug.WriteLine("Updated {0} Progress Bars shapes", count);
            // TODO: implement actual refresh code!           
            //Vis.Selection selPbs = _visPg.ShapesOfClass(SolutionStringConstants.ShapeClass_ProgressBars);
            //VL.UI.Msg.Show("TODO: Refresh " + selPbs.Count + " ProgressBars!");
        }

        public void UpdateConnectorColorReferences()
        {
            if (_visPg == null) return;
            var cs = VisioSolutionHelpers.GetSolutionObjectsOnPage_CogObsConn(_visPg);
            foreach(var c in cs)
            {
                c.UpdateConnectorColors();
            }
        }

        public void UpdateCategories()
        {
            var cogs = Shape_Cognitive.GetCognitiveShapesOnPage(_visPg);            
            foreach (var cog in cogs)
            {
                cog.Set_Category_Layer();
                cog.Set_Category_Container();
                cog.Set_Cat_NearestObservableTask();
            }
            var obs = Shape_Observable.GetObservableShapesOnPage(_visPg);
            foreach (var ob in obs)
            {
                ob.Set_Category_Layer();
                ob.Set_Category_Container();
            }
        }

        private List<Shape_Cognitive> _getAllTasks_Cognitive()
        {           
            var cogs = new List<Shape_Cognitive>();
            foreach(Vis.Shape shp in _visPg.Shapes)
            {
                var cog = new Shape_Cognitive(shp);
                if (cog.IsSolutionShape) cogs.Add(cog);
            }
            return cogs;
        }
        private List<Shape_Observable> _getAllTasks_Observable()
        {
            var obs = new List<Shape_Observable>();
            foreach (Vis.Shape shp in _visPg.Shapes)
            {
                var ob = new Shape_Observable(shp);
                if (ob.IsSolutionShape) obs.Add(ob);
            }
            return obs;
        }
        private Vis.Selection _getDuplicateVisSelection_CogTaskNames()
        {
            // TODO: refactor to handle both obs and cog?

            // Get all tasks:
            var cogs = _getAllTasks_Cognitive();

            // Create a Visio Selection:
            Vis.Selection visSel = _visPg.CreateEmptySelection();

            // Determine objects with same names and build
            // a Vis.Selection object of those shapes
            for (int i = 0; i < cogs.Count; i++)
            {
                var cog1 = cogs[i];
                var id1 = cog1.TaskNumber;

                for (int j = i + 1; j < cogs.Count; j++)
                {
                    var cog2 = cogs[j];
                    var id2 = cog2.TaskNumber;

                    //if(id2.Equals(id1, 
                    //    StringComparison.InvariantCultureIgnoreCase))
                    if(id2 == id1)
                    {
                        visSel.Select(cog1.Shape); // Possibly redundant, but .Select won't hurt anything
                        visSel.Select(cog2.Shape);
                    }
                }
            }

            return visSel;            
        }

    }
}
