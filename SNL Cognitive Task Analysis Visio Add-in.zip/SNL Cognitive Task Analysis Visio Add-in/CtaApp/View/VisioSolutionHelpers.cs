﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public static class VisioSolutionHelpers
    {
        public static string GetExecutingAssemblyFolderPath()
        {
            // Get the assembly information
            System.Reflection.Assembly assemblyInfo =
                System.Reflection.Assembly.GetExecutingAssembly();

            // Location is where the assembly is run from 
            string assemblyLocation = assemblyInfo.Location;

            // CodeBase is the location of the ClickOnce deployment files
            Uri uriCodeBase = new Uri(assemblyInfo.CodeBase);
            //string ClickOnceLocation = ...

            string path = System.IO.Path.GetDirectoryName(uriCodeBase.LocalPath.ToString());

            return path;
        }

        public static bool IsDisconnectedAt1dBegin(Vis.Shape visShpConn)
        {
            Vis.Shape shpGluedTo = visShpConn.ShapeGluedTo_1dBegin();
            if (shpGluedTo == null) return true;
            if (!IsCognitiveOrObservable(shpGluedTo)) return true;
            return false;
        }
        public static bool IsDisconnectedAt1dEnd(Vis.Shape visShpConn)
        {
            Vis.Shape shpGluedTo = visShpConn.ShapeGluedTo_1dEnd();
            if (shpGluedTo == null) return true;
            if (!IsCognitiveOrObservable(shpGluedTo)) return true;
            return false;
        }
        public static bool IsDisconnected_1D(Vis.Shape visShpConn)
        {
            if (IsCtaConnector(visShpConn) == false) return false; // shape is not interesting to us
            if (visShpConn.Connects.Count != 2) return true;

            // Both ends of connector are glued to something, make sure
            // they are solution shapes:

            Vis.Shape shpAtBeg;
            shpAtBeg = visShpConn.ShapeGluedTo_1dBegin();
            if (shpAtBeg == null) return true;
            if (IsCognitiveOrObservable(shpAtBeg) == false) return true;

            Vis.Shape shpAtEnd;
            shpAtEnd = visShpConn.ShapeGluedTo_1dEnd();
            if (shpAtEnd == null) return true;
            if (IsCognitiveOrObservable(shpAtEnd) == false) return true;

            return false;
        }

        public static bool IsDisconnected_2D(Vis.Shape visShp)
        {
            if (IsCognitiveOrObservable(visShp) == false) return false; // shape is not interesting to us
            if (visShp.FromConnects.Count == 0 ) return true;

            string[] connClasses = new string[] { SolutionStrings.ShapeClass_CtaConnector };
            string[] shpClasses = new string[] { SolutionStrings.ShapeClass_Cognitive,
                                                 SolutionStrings.ShapeClass_Observable};

            Vis.Selection visSelIncomingShapes, visSelOutgoingShapes;

            visShp.ConnectedShapes(connClasses, shpClasses, shpClasses,
                                   out visSelIncomingShapes, out visSelOutgoingShapes);
            
            int iSnlIn, iSnlOut;
            iSnlIn = visSelIncomingShapes != null ? visSelIncomingShapes.Count : 0;
            iSnlOut = visSelOutgoingShapes != null ? visSelOutgoingShapes.Count : 0;

            if (iSnlIn + iSnlOut == 0) return true;

            return false;
        }

        public static bool IsCognitiveOrObservable(Vis.Shape visShp)
        {

            return visShp.IsClass(SolutionStrings.ShapeClass_Cognitive) ||
                   visShp.IsClass(SolutionStrings.ShapeClass_Observable);

            //var cog = new Shape_Cognitive(visShp);
            //if (cog.IsSolutionShape) return true;

            //var obs = new Shape_Observable(visShp);
            //if (obs.IsSolutionShape) return true;

            //// TODO: Maybe connector too?

            //return false;            
        }
        public static bool IsCognitiveShape(Vis.Shape visShp)
        {
            return visShp.IsClass(SolutionStrings.ShapeClass_Cognitive);
            //var cog = new Shape_Cognitive(visShp);
            //if (cog.IsSolutionShape) return true;
        }
        public static bool IsObservableShape(Vis.Shape visShp)
        {
            return visShp.IsClass(SolutionStrings.ShapeClass_Observable);
        }
        public static bool IsCtaConnector(Vis.Shape visShp)
        {
            return visShp.IsClass(SolutionStrings.ShapeClass_CtaConnector);
        }

        public static View.Shape_Task GetTaskShape_OrNull(Vis.Shape visShp)
        {
            if(IsCognitiveShape(visShp))
            {
                var c = new Shape_Cognitive(visShp);
                if (c.IsSolutionShape) return c;
            }
            else if(IsObservableShape(visShp))
            {
                var o = new Shape_Observable(visShp);
                if (o.IsSolutionShape) return o;
            }
            
            // visShp must have been weird, return nothing:
            return null;
        }


        public static View.Shape_Cognitive GetSelectedCognitiveTaskOrNull(Vis.Application visApp)
        {
            if (visApp == null) return null;
            Vis.Shape visShp = visApp.SingleSelectedShapeOrNull();
            if (visShp == null) return null;
            var s = new View.Shape_Cognitive(visShp);
            if (!s.IsSolutionShape) return null;

            return s;
        }
        public static View.Shape_Observable GetSelectedObservableTaskOrNull(Vis.Application visApp)
        {
            if (visApp == null) return null;
            Vis.Shape visShp = visApp.SingleSelectedShapeOrNull();
            if (visShp == null) return null;
            var s = new View.Shape_Observable(visShp);
            if (!s.IsSolutionShape) return null;

            return s;
        }

        public static Vis.Selection GetSelectedShapes_Cognitive_OrNull(Vis.Application visApp)
        {
            string[] shapeClasses = 
                new string[] { SolutionStrings.ShapeClass_Cognitive };
            return _getSelectedShapes(visApp, shapeClasses);
        }
        public static Vis.Selection GetSelectedShapes_Observable_OrNull(Vis.Application visApp)
        {
            string[] shapeClasses = 
                new string[] { SolutionStrings.ShapeClass_Observable };
            return _getSelectedShapes(visApp, shapeClasses);
        }
        public static Vis.Selection GetSelectedShapes_CognitiveAndObservable_OrNull(Vis.Application visApp)
        {
            string[] shapeClasses = 
                new string[] { SolutionStrings.ShapeClass_Cognitive,
                               SolutionStrings.ShapeClass_Observable};
            return _getSelectedShapes(visApp, shapeClasses);
        }

        public static Vis.Selection GetSolutionShapesOnPage_CogObsConn(Vis.Page visPg)
        {
            if (visPg == null) return null;

            Vis.Selection sel = visPg.CreateEmptySelection();
            string[] shapeClasses =
                new string[] { SolutionStrings.ShapeClass_Cognitive,
                               SolutionStrings.ShapeClass_Observable,
                               SolutionStrings.ShapeClass_CtaConnector};

            foreach (Vis.Shape shp in visPg.Shapes)
            {
                if (shp.IsClass(shapeClasses)) sel.Select(shp);
            }
            return sel;
        }
        public static Vis.Selection GetSolutionShapesOnPage_Cog(Vis.Page visPg)
        {
            if (visPg == null) return null;

            Vis.Selection sel = visPg.CreateEmptySelection();
            string[] shapeClasses =
                new string[] { SolutionStrings.ShapeClass_Cognitive };

            foreach (Vis.Shape shp in visPg.Shapes)
            {
                if (shp.IsClass(shapeClasses)) sel.Select(shp);
            }
            return sel;
        }
        public static Vis.Selection GetSolutionShapesOnPage_Obs(Vis.Page visPg)
        {
            if (visPg == null) return null;

            Vis.Selection sel = visPg.CreateEmptySelection();
            string[] shapeClasses =
                new string[] { SolutionStrings.ShapeClass_Observable };

            foreach (Vis.Shape shp in visPg.Shapes)
            {
                if (shp.IsClass(shapeClasses)) sel.Select(shp);
            }
            return sel;
        }
        public static List<Shape_CtaConnector> GetSolutionObjectsOnPage_CogObsConn(Vis.Page visPg)
        {
            var cs = new List<Shape_CtaConnector>();

            if (visPg == null) return cs;

            Vis.Selection sel = GetSolutionShapesOnPage_CogObsConn(visPg);
            if (sel == null) return cs;

            foreach (Vis.Shape shp in sel)
            {
                var c = new Shape_CtaConnector(shp);
                if (c.IsSolutionShape) cs.Add(c);
            }
            return cs;
        }
        public static Vis.Selection GetSolutionShapesOnPage_CogObs(Vis.Page visPg)
        {
            if (visPg == null) return null;

            Vis.Selection sel = visPg.CreateEmptySelection();
            string[] shapeClasses =
                new string[] { SolutionStrings.ShapeClass_Cognitive,
                               SolutionStrings.ShapeClass_Observable};

            foreach(Vis.Shape shp in visPg.Shapes)
            {
                if (shp.IsClass(shapeClasses)) sel.Select(shp);
            }
            return sel;
        }

        public static bool IsSolutionDoc(Vis.Document visDoc)
        {
            Vis.Shape shp = visDoc.DocumentSheet;
            return shp.IsClass(SolutionStrings.DocClass_Solution);               
        }
        public static bool IsSolutionDiagramPage(Vis.Page visPage)
        {
            return visPage.IsClass(SolutionStrings.PageClass_MainDiagram);
        }
        public static bool IsSolutionConfigPage(Vis.Page visPage)
        {
            return visPage.IsClass(SolutionStrings.PageClass_Config);
        }
        public static bool IsSolutionDiagramPageInWindow(Vis.Window visWin)
        {
            if (!visWin.IsDrawingPageWindow()) return false;
            Vis.Page pg = visWin.PageAsObj;
            return pg.IsClass(SolutionStrings.PageClass_MainDiagram);
        }

        private static Vis.Selection _getSelectedShapes(
            Vis.Application visApp, string[] shapeClasses)
        {
            Vis.Selection sel = visApp.GetSelectionOrNull();
            if (sel == null) return null;
            if (sel.Count == 0) return null;
            for(int i = sel.Count; i > 0; i--)
            {
                Vis.Shape shp = sel[i];
                if (!shp.IsClass(shapeClasses)) sel.Deselect(shp);
            }

            if (sel.Count == 0) return null;
            return sel;
        }
    }
}
