﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using SSC = SNL_Cognitive_Task_Analysis_Visio_Add_in.SolutionStrings;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    // We need to organize by chunks of connected shapes,
    // sortable top-to-bottom, left-to-right, as well as
    // in connected order to the best of our abilities

    public class ConnectedTaskShapeGroups : List<ConnectedTaskShapeGroup>
    {
        private List<ConnectedTaskShape> _allConnectedaskShapes = null;
        private List<int> _allVisShapeIds = null;

        public ConnectedTaskShapeGroups(View.Doc vdoc)
        {
            // Get all the solution-specific shape objects on the diagram page:
            _allConnectedaskShapes = _getAllConnectedTaskShapesOnPage(vdoc);

            // Get two arrays of all the shape ids:
            _allVisShapeIds = new List<int>();
            List<int> allIds = new List<int>();
            foreach (var ctshp in _allConnectedaskShapes)
            {
                int id = ctshp.ShapeID;
                _allVisShapeIds.Add(id);
                allIds.Add(id); //...we will be messing with this array
            }

            // Build the connected group-blobs:

            while(allIds.Count > 0)
            {
                int id = allIds[0];
                var ctshp = _allConnectedaskShapes.FirstOrDefault(c => c.ShapeID == id);

                // Build a new group from ctshp. The connection network is analyzed
                // automatically in the ConnectedTaskShapeGroup constructor:
                var grp = new ConnectedTaskShapeGroup(ctshp);

                // Add this group to the list-of-groups:
                this.Add(grp);

                // Remove grp's ids from allIds:
                //allIds = allIds.Except(grp.ShapeIds).ToList(); // not working because of that "boundary" problem               
                var grpIds = grp.ShapeIds;
                for (int i = allIds.Count - 1; i >= 0; i--)
                {
                    int idi = allIds[i];
                    if (grpIds.Contains(idi))
                        allIds.RemoveAt(i);
                }
            }
        }
        private  List<ConnectedTaskShape> _getAllConnectedTaskShapesOnPage(View.Doc vdoc)
        {
            var ctshps = new List<ConnectedTaskShape>();

            var vpg = vdoc.DiagramPage_OrNull;
            if (vpg == null) return ctshps;

            var tshps = vpg.GetTaskShapes();
            foreach (var tshp in tshps)
            {
                var ctshp = new ConnectedTaskShape(tshp);
                ctshps.Add(ctshp);
            }
            return ctshps;
        }

        public void SortByTopLeftToBottomRight()
        {
            var sorted = this.SortByLeftTop();

            this.Clear();
            foreach(var ctsg in sorted)
            {
                this.Add(ctsg); // TODO: will blowing away the original array members mess up any other initialization?
            }

            //List < ConnectedTaskShapeGroup >
            //var l = this as List<ConnectedTaskShape>;
            //return l.SortByLeftTop();

            //double minX = this.Min(e => e.WeightedLeft);
            //double maxX = this.Max(e => e.WeightedLeft);
            //double minY = this.Min(e => e.WeightedTop);
            //double maxY = this.Max(e => e.WeightedTop);

            //double dx = (maxX - minX) / 10;
            //double dy = (maxY - minY) / 10;

            //// This isn't good enough. The shapes need to be placed
            //// in rows, and sorted left-to-right within the rows.
            //this.OrderBy(e => (int)((maxY - e.WeightedTop) / dy)).ThenBy(e => (int)((e.WeightedLeft - minX) / dx));
        }

        public string ToStringDump()
        {
            var sb = new StringBuilder();
            sb.AppendLine("Groups: " + this.Count.ToString());
            sb.AppendLine("------------------------------");

            int i = 1;
            foreach(var g in this)
            {
                sb.AppendLine("Group: " + i.ToString());
                sb.AppendLine("--------------------");
                sb.AppendLine("  Start shapes: " + g.StartShapes.Count);
                sb.AppendLine("  End shapes: " + g.EndShapes.Count);
                sb.AppendLine("  Shape ids (" + g.ShapeIds.Count + ") " + String.Join(",", g.ShapeIds));
                sb.AppendLine("  Descriptions:");
                foreach(var ctshp in g)
                {
                    sb.AppendLine("  - " + ctshp.TaskShape.Description);
                }
                i++;
            }

            return sb.ToString();
        }

    } //...class ConnectedTaskShapeGroups

    /// <summary>
    /// A ConnectedTaskShapeGroup is a group of shapes that are connected to
    /// each other, no matter the degree of separation. It is possible to get
    /// this "tree" or network of shapes from a single shape, by recursively
    /// tracing its connections.
    /// </summary>
    public class ConnectedTaskShapeGroup : List<ConnectedTaskShape>
    {
        //private List<ConnectedTaskShape> _startShapes = null;
        //private List<ConnectedTaskShape> _endShapes = null;

        // public List<ConnectedTaskShape> GetInOrder/Sorted..blahblah
        //private List<ConnectedTaskShape> _allConnectedaskShapes = null;

        public double WeightedTop { get; private set; }
        public double WeightedLeft { get; private set; }

        private List<ConnectedTaskShape> _startShapes = null;
        public List<ConnectedTaskShape> StartShapes { get { return _startShapes; } }
        private List<ConnectedTaskShape> _endShapes = null;
        public List<ConnectedTaskShape> EndShapes { get { return _endShapes; } }

        private List<int> _allVisShapeIds = null;
        public List<int> ShapeIds { get { return _allVisShapeIds; } }

        public ConnectedTaskShapeGroup(ConnectedTaskShape ctshp)
        {
            // Initialize collections:
            //_allConnectedaskShapes = new List<ConnectedTaskShape>();
            _allVisShapeIds = new List<int>();

            // Trace the network of shapes connected to ctshp:
            _traceConnections_Recursive(ctshp); // <-- recursive!    

            _startShapes = new List<ConnectedTaskShape>();
            _endShapes = new List<ConnectedTaskShape>();
            foreach (var cts in this)
            {
                if (cts.IsEndShape) _endShapes.Add(cts);
                if (cts.IsStartShape) _startShapes.Add(cts);
            }

            _calculateWeightedCenter();
        }

        // TODO:sort by connection
        // Get Starts. If there are multiple starts, then sort by left/top
        // Get nexts until there are none left. If there are multiple nexts,
        // then get the left/top-most first. 
        // So we need an easy way of getting all of these things "by left/top"
        //

        /// <summary>
        /// Gets the ConnectedTaskShape objects in order of connection
        /// as well as from top-left to bottom-right.
        /// </summary>
        /// <returns></returns>
        public List<ConnectedTaskShape> ShapesInConnectedOrder()
        {
            var ctshps = new List<ConnectedTaskShape>();
            var shapeids = new List<int>();
           
            var starts = this.StartShapes.SortByLeftTop();
            foreach(var start in starts)
            {
                var chain = start.GetChain();
                foreach(var ch in chain)
                {
                    int id = ch.ShapeID;
                    if (shapeids.Contains(id) == false)
                    {
                        ctshps.Add(ch);
                        shapeids.Add(id);
                    }
                }
            }

            //var shapeids = new List<int>();
            return ctshps;
        }

        private void _calculateWeightedCenter()
        {
            double x, y;
            x = 0;
            y = 0;
            foreach (var cts in this)
            {
                Vis.Shape shp = cts.TaskShape.Shape;
                double l, t;
                shp.LeftTopIU_Upright(out l, out t);
                //shp.VisualBoundingBox //...2016?

                x += l;
                y += t;                
            }
            this.WeightedLeft = x / this.Count;
            this.WeightedTop = y / this.Count;
        }

        // SortedTasks
        // Top
        // Left

        // Items = Shapes, Sorted by first to last

        // Sorting:
        // Firsts are those with no incoming, then sorted by top/left

        private void _traceConnections_Recursive(ConnectedTaskShape ctshp)
        {
            // Check if it's already here:
            int id = ctshp.ShapeID;
            if (_allVisShapeIds.Contains(id)) return;

            // Keep the id:
            _allVisShapeIds.Add(id);

            // Keep it in the object collection as well:            
            this.Add(ctshp);

            // Run through the shapes it's connected to (RECURSIVE!)
            foreach (var ctshpIn in ctshp.IncomingConnectedTaskShapes)
            {
                _traceConnections_Recursive(ctshpIn);             
            }
            foreach (var ctshpOut in ctshp.OutgoingConnectedTaskShapes)
            {
                _traceConnections_Recursive(ctshpOut);
            }
        }

    } //...class ConnectedTaskShapeGroup

    public class ConnectedTaskShape
    {       
        private Vis.Shape _visShp = null;
        public View.Shape_Task TaskShape { get; private set; }

        public bool IsCognitive
        {
            get
            {
                return ((this.TaskShape as View.Shape_Cognitive) != null);
            }
        }
        public bool IsObservable
        {
            get
            {
                return ((this.TaskShape as View.Shape_Observable) != null);
            }
        }

        public int ShapeID { get; private set; }

        // TODO: get the top and left of this shape...
        public double Top {
            get {
                var ts = this.TaskShape;
                var shp = ts.Shape;
                return shp.TopIU_Upright();
            }
        }
        public double Left {
            get
            {
                var ts = this.TaskShape;
                var shp = ts.Shape;
                return shp.LeftIU_Upright();
            }
        }        

        private bool _isEndShape = false;
        public bool IsEndShape
        {
            get
            {
                if (_incomingTaskShapes == null) _initConnectionInfo();
                return _isEndShape;
            }
        }
        private bool _isStartShape = false;
        public bool IsStartShape
        {
            get
            {
                if (_incomingTaskShapes == null) _initConnectionInfo();
                return _isStartShape;
            }
        }
        private bool _isNotConnected = false;
        public bool IsNotConnected
        {
            get
            {
                if (_incomingTaskShapes == null) _initConnectionInfo();
                return _isNotConnected;
            }
        }

        private List<ConnectedTaskShape> _incomingTaskShapes = null;
        public List<ConnectedTaskShape> IncomingConnectedTaskShapes
        {
            get
            {
                if (_incomingTaskShapes == null) _initConnectionInfo();
                return _incomingTaskShapes;
            }
        }
        private List<ConnectedTaskShape> _outgoingTaskShapes = null;
        public List<ConnectedTaskShape> OutgoingConnectedTaskShapes
        {
            get
            {
                if (_outgoingTaskShapes == null) _initConnectionInfo();
                return _outgoingTaskShapes;
            }
        }


        public ConnectedTaskShape(Shape_Task taskshape) 
        {
            this.TaskShape = taskshape;
            _visShp = TaskShape.Shape;
            this.ShapeID = taskshape.ShapeID;
            //_initConnectionInfo();
        }

        public List<ConnectedTaskShape> GetChain()
        {
            var tshapes = new List<ConnectedTaskShape>();
            var shapeids = new List<int>();

            _getChain(this, ref tshapes, ref shapeids);

            return tshapes;
        }

        private void _getChain(ConnectedTaskShape tshape,
            ref List<ConnectedTaskShape> tshapes, 
            ref List<int> shapeids )
        {
            var idRoot = tshape.ShapeID;
            if(shapeids.Contains(idRoot) == false)
            {
                tshapes.Add(tshape);
                shapeids.Add(idRoot);
            }

            // Get the "next" ConnectedTaskShapes:
            var nexts = tshape.OutgoingConnectedTaskShapes;
            var keepers = new List<ConnectedTaskShape>();
            foreach(var next in nexts)
            {
                int id = next.ShapeID;
                if(shapeids.Contains(id) == false)
                {
                    keepers.Add(next);
                }
            }

            // Sort the keepers by top/left:
            keepers = keepers.SortByLeftTop();

            // Add the keeper tasks to the ref tshapes collection,
            // and the ids to the shapeids collection:
            foreach(var keeper in keepers)
            {
                tshapes.Add(keeper);
                shapeids.Add(keeper.ShapeID);
            }

            // Recurse into the the shapes if they have nexts:
            foreach(var keeper in keepers)
            {
                var outs = keeper.OutgoingConnectedTaskShapes;
                if(outs != null)
                {
                    if(outs.Count > 0)
                    {
                        _getChain(keeper, ref tshapes, ref shapeids);
                    }
                }
            }
        }

        private void _initConnectionInfo()
        {
            var ins = TaskShape.PreviousTaskShapes();           
            _incomingTaskShapes = new List<ConnectedTaskShape>();
            foreach (var t in ins)
                _incomingTaskShapes.Add(new ConnectedTaskShape(t));

            var outs = TaskShape.NextTaskShapes();
            _outgoingTaskShapes = new List<ConnectedTaskShape>();
            foreach (var t in outs)
                _outgoingTaskShapes.Add(new ConnectedTaskShape(t));

            _isEndShape = (_outgoingTaskShapes.Count == 0);
            _isStartShape = (_incomingTaskShapes.Count == 0);
            _isNotConnected = ((_incomingTaskShapes.Count + _outgoingTaskShapes.Count) == 0);
        }
    } //...class ConnectedTaskShape

    // Extensions for List<Shape_Task> or List<ConnectedItem> ?

    public static class ConnectedTaskExtensions
    {
        public static List<ConnectedTaskShape> SortByLeftTop(
            this List<ConnectedTaskShape> ctasks)
        {
            if (ctasks == null) return new List<ConnectedTaskShape>();
            if (ctasks.Count == 0) return new List<ConnectedTaskShape>();

            const int bandCt = 10;

            // Break the page or distribution of tasks into ten
            // bands or so. Place each task into one of those bands,
            // then sort each band left to right.

            // Divide the page into ten bands:
            Vis.Shape shp0 = ctasks[0].TaskShape.Shape;
            Vis.Page pg = shp0.ContainingPage;
            double h = pg.PageHeightIU();
            double dh = h / bandCt;

            // Add each task shape to the appropriate band:
            var bands = new List<ConnectedTaskShape>[bandCt];
            foreach(var ct in ctasks)
            {
                int i = (int) ( ct.Top / dh );
                i = Math.Max(0, Math.Min((bandCt-1), i));

                // Reverse i, so that the top-most tasks go to the
                // top band:
                i = bandCt - i - 1;
                if (bands[i] == null) bands[i] = new List<ConnectedTaskShape>();
                bands[i].Add(ct);
            }

            // Sort each band and add it to the sorted list, starting
            // starting at the top-most band:
            var sortedCtasks = new List<ConnectedTaskShape>();
            foreach (var band in bands)
            {
                if (band != null)
                {
                    foreach (var ct in band.OrderBy(t => t.Left))
                    {
                        sortedCtasks.Add(ct);
                    }
                }
            }

            // Return!
            return sortedCtasks;
        }

        public static List<ConnectedTaskShapeGroup> SortByLeftTop(
            this List<ConnectedTaskShapeGroup> ctasksgroups)
        {
            if (ctasksgroups == null) return new List<ConnectedTaskShapeGroup>();
            if (ctasksgroups.Count == 0) return new List<ConnectedTaskShapeGroup>();

            const int bandCt = 10;

            // Break the page or distribution of tasks into ten
            // bands or so. Place each task into one of those bands,
            // then sort each band left to right.

            // Divide the page into ten bands:
            var ctg0 = ctasksgroups[0];
            Vis.Shape shp0 = ctg0[0].TaskShape.Shape;
            Vis.Page pg = shp0.ContainingPage;
            double h = pg.PageHeightIU();
            double dh = h / bandCt;

            // Add each task shape to the appropriate band:
            var bands = new List<ConnectedTaskShapeGroup>[bandCt];
            foreach (var ctg in ctasksgroups)
            {
                int i = (int)(ctg.WeightedTop / dh);
                i = Math.Max(0, Math.Min((bandCt - 1), i));

                // Reverse i, so that the top-most tasks go to the
                // top band:
                i = bandCt - i - 1;
                if (bands[i] == null) bands[i] = new List<ConnectedTaskShapeGroup>();
                bands[i].Add(ctg);
            }

            // Sort each band and add it to the sorted list, starting
            // starting at the top-most band:
            var sortedCtgs = new List<ConnectedTaskShapeGroup>();
            foreach (var band in bands)
            {
                if (band != null)
                {
                    foreach (var ctg in band.OrderBy(g => g.WeightedLeft))
                    {                       
                        sortedCtgs.Add(ctg);                            
                    }
                }
            }

            // Return!
            return sortedCtgs;
        }
    }
}
