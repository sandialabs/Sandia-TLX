﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class ShapeDropper
    {       
        private ShapeTypes _shapeTypeToDrop;
        private Vis.Application _visApp = null;
        private Vis.Page _visPg = null;

        public ShapeDropper(View.ShapeTypes shapeType, Vis.Page visPg)
        {
            _shapeTypeToDrop = shapeType;
            _visPg = visPg;
            _visApp = visPg.Application;
        }

        public bool DropShape(Vis.Page visPg)
        {
            // TODO: redundant from constructor...
            _visPg = visPg;
            _visApp = visPg.Application;

            // TODO: there is one more case where the selected
            // shape is a connector, and we drop a 2D shape. It
            // would be nice to glue the closest dangling end
            // to the new shape.

            // TODO: some refactoring here!

            const double DropOffsetX = 0.5;

            Vis.Shape shpSelected = _getSelectedSnlShape();
         
            Vis.Master mstShpToDrop = _getMaster(_shapeTypeToDrop);
            bool bMasterToDropIsConnector = (_shapeTypeToDrop == ShapeTypes.Connector);

            // Check the master to drop:
            if (mstShpToDrop == null) return false;

            // Drop the shape in the middle of the view, or to the
            // right of the selected shape:
            Vis.Shape shpDropped = null;
            if (shpSelected == null)
            {
                shpDropped = _visPg.Drop_ViewCenter_Master(mstShpToDrop);
            }
            else
            {
                shpDropped = _visPg.Drop_ViewCenter_Master_ToRightOfSelectedShape(
                    mstShpToDrop, shpSelected, DropOffsetX, true);
            }

            // Add a connector, if appropriate, or reassign the connector
            // object if we already dropped a connector:
            Vis.Shape shpConn = null;
            if (bMasterToDropIsConnector)
            {
                shpConn = shpDropped;
            }
            else
            {
                if (shpSelected != null)
                {
                    Vis.Master mstConn = _visPg.MasterByName(
                        SolutionStrings.MasterName_CtaConnector);
                    if (mstConn != null)
                        shpConn = _visPg.Drop(mstConn, 0, 0); // TODO: coordinates of drop!
                }
            }

            // Glue the connector to the "from" shape--
            // the shape that was selected:
            if (shpSelected != null &&
                shpConn != null)
            {
                Vis.Cell cellFrom = shpConn.CellsU["BeginX"];
                Vis.Cell cellTo = shpSelected.CellsU["PinX"];
                cellFrom.GlueTo(cellTo);
            }

            // Glue the other end of the connector to the dropped
            // shape, unless the dropped shape IS a connector!
            if (bMasterToDropIsConnector == false &&
               shpDropped != null &&
               shpConn != null)
            {
                Vis.Cell cellFrom = shpConn.CellsU["EndX"];
                Vis.Cell cellTo = shpDropped.CellsU["PinX"];
                cellFrom.GlueTo(cellTo);
            }

            // Make sure that the dropped shape is selected:
            if (shpDropped != null)
                visPg.SelectInWindow(shpDropped);

            return true;
        }

        public List<Vis.Shape> DropShapeArray(Vis.Page visPg, int iCt)
        {
            var shps = new List<Vis.Shape>();
            var mst = _getMaster(_shapeTypeToDrop);
            if (mst == null) return shps;

            for (int i = 0; i < iCt; i++)
            {
                var shp = _visPg.Drop_ViewCenter_Master(mst);
                shps.Add(shp);
            }
            return shps;
        }

        private Vis.Master _getMaster(ShapeTypes shapeType)
        {
            Vis.Master mst = null;

            if (_shapeTypeToDrop == ShapeTypes.CognitiveTask)
            {
                mst = _visPg.MasterByName(SolutionStrings.MasterName_CognitiveTask);
            }
            else if (_shapeTypeToDrop == ShapeTypes.ObservableTask)
            {
                mst = _visPg.MasterByName(SolutionStrings.MasterName_ObservableTask);
            }
            else if (_shapeTypeToDrop == ShapeTypes.Connector)
            {
                mst = _visPg.MasterByName(SolutionStrings.MasterName_CtaConnector);
            }
            else
            {
                // Should never occur...
            }
            return mst;
        }

        /// <summary>
        /// Only returns a shape object if the Visio ActiveWindow is a
        /// page with one and only one cognitive or observable task shape
        /// selected.
        /// </summary>
        /// <returns></returns>
        private Vis.Shape _getSelectedSnlShape()
        {
            var sel = VisioSolutionHelpers.GetSelectedShapes_CognitiveAndObservable_OrNull(_visApp);
            if (sel == null) return null;
            if (sel.Count == 1) return sel[1];
            return null;
        }
    }
}
