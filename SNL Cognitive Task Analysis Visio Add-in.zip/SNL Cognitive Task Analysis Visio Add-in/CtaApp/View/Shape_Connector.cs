﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Shape_CtaConnector : Shape_Base
    {
        // Note: User.Class = 
        // SolutionStringConstants.ShapeClass_CtaConnector

        // User.Class = "SNL.CAT.Shape.Connector"
        // Master Name = "CAT Connector"

        // TODO: there are a couple of "Is solution shape" methods. 
        // The Shape_ classes have the IsSolution, but also 
        // VisHelpers do a quick check of User.Class values.


        //public const string MasterNameConst = "Observable Task";

        // Task shapes: Prop.ID,Prop.Description,Prop.IsCurrent,Prop.CurrentDate,Prop.IsAccurate,Prop.AccurateDate
        // Observable shape: Prop.MentalDemand,Prop.PhysicalDemand,Prop.TemporalDemand,Prop.Performance,Prop.Effort,Prop.Frustration
        public const string RequiredCellsConst = "";
            //"User.Class," +
            //"Prop.TaskNumber,Prop.TaskText_Description,Prop.IsCurrent,Prop.CurrentDate,Prop.IsAccurate,Prop.AccurateDate," +
            //"Prop.Importance,Prop.Difficulty,Prop.Duration,Prop.Frequency,Prop.Complexity";

        public static string UserClassConst = SolutionStrings.ShapeClass_CtaConnector;

        //public override string MasterName { get { return MasterNameConst; } }
        public override string RequiredCellsCSV { get { return RequiredCellsConst; } }
        public override string UserClassValue { get { return UserClassConst; } }

        public Shape_CtaConnector(Vis.Shape visShp) : base(visShp)
        {
            _isSolutionShape(visShp);
        }

        public void UpdateConnectorColors()
        {
            if (_visShp.IsNullOrGone()) return;
            _updateEndColor("User.FromColor", true);
            _updateEndColor("User.ToColor", false);
        }

        /// <summary>
        /// Updates a cell in _visShp that holds a reference to a color
        /// in a shape to which _visShp is glued.
        /// </summary>
        /// <param name="cellNameUserColor">The name of the cell that will hold
        /// the color reference, e.g. User.FromColor=Sheet.31!FillForegnd</param>
        /// <param name="bFromBegin">If true, the shape that Begin is glued
        /// to is examined, otherwise the shape that End is glued to is used.</param>
        private void _updateEndColor(string cellNameUserColor, bool bFromBegin)
        {
            Vis.Shape shpOther = null;
            if(bFromBegin)
            {
                shpOther = _visShp.ShapeGluedTo_1dBegin();
            }
            else
            {
                shpOther = _visShp.ShapeGluedTo_1dEnd();
            }
            if (shpOther.IsNullOrGone()) return;

            // TODO: check that this works 
            string f = shpOther.NameID + "!FillForegnd";
            _visShp.TryFormulaForceU(cellNameUserColor, f);
        }
    }
}
