﻿using System;
using System.Collections.Generic;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;
using System.Diagnostics;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public abstract class Shape_Base 
    {
        public abstract string UserClassValue { get; }
        public abstract string RequiredCellsCSV { get; }

        protected Vis.Shape _visShp = null;
        protected VisShapeDataSection _sdsection = null;

        protected double _dropX = 2;
        protected double _dropY = 4;
        public double DropX { get { return _dropX; } set { _dropX = value; } }
        public double DropY { get { return _dropY; } set { _dropY = value; } }

        public double Top { get { return _visShp.TopIU_Upright(); } }
        public double Left { get { return _visShp.LeftIU_Upright(); } }

        public string MasterNameFromInstance
        {
            get
            {
                if (_visShp == null) return String.Empty;
                Vis.Master mst = _visShp.Master;
                if (mst == null) return String.Empty;
                return mst.Name;
            }
        }
        public Vis.Page Page { get { return _visShp.ContainingPage; } }
        public bool IsSolutionShape { get; protected set; }


        public Vis.Shape Shape { get { return _visShp; } }
        public int ShapeID { get; private set; }


        public Shape_Base(Vis.Shape visShp)
        {
            _visShp = visShp;
            this.ShapeID = visShp.ID;
            IsSolutionShape = _isSolutionShape(visShp);
        }
        //Sample constructor, to be implemented by the derived:
        //public Shape_Part(Vis.Shape visShp)
        //{
        //    this.IsSolutionShape = _isSolutionShape(visShp);
        //}

        public void ClearDataGraphic()
        {
            if (_visShp.IsNullOrGone()) return;
            _visShp.DataGraphic = null;
        }
        public void SetShapeData(string label, string value)
        {
            if (_visShp == null) return;
            if (_sdsection == null)
                _sdsection = new VisShapeDataSection(_visShp);

            _sdsection.TrySet_Value_ByLabel(label, value);
        }
        public void TestSetIdAndDescription()
        {
            // Initialize a form:
            var frm = new UI.SelectTaskItemForm();
            
            // Get some data:
            var data = Data.ExcelUtils.Test_GetTaskIdDescriptions(Data.TaskTypes.CognitiveTask);

            // Link the two:
            frm.DataContext = data;

            //var frm = new SnlWpf.ChooseNumberDescForm();
            //frm.DataContext = data;

            // Show the form!
            frm.ShowDialog();

            string n, d;
            n = frm.Number;
            d = frm.Description;
            Debug.WriteLine("Chose: " + n + ", " + d);

            string cellname = "Prop.TaskNumber";
            //Prop.TaskNumber,Prop.TaskText_Description
            var s = _visShp.TryGetCellResultStr(cellname);

            int i;
            if(int.TryParse(s, out i))
            {
                i++;                
            }
            else
            {
                i = 1;
            }
            _visShp.TrySetCellResultStrU(cellname, i.ToString(), true);

            string sNewDesc = String.Empty;
            string thisClass = _visShp.UserClassValue();
            if(thisClass == SolutionStrings.ShapeClass_Cognitive)
            {
                sNewDesc = "Cognitive Task" + i;
            }
            else if(thisClass == SolutionStrings.ShapeClass_Observable)
            {
                sNewDesc = "Observable Task" + i;
            }
            else
            {
                sNewDesc = "Unknown Type of Task" + i; // Shouldn't hit this!
            }

            _visShp.TrySetCellResultStrU("Prop.TaskText_Description", sNewDesc, true);

        }
        public bool TryApplyDataGraphic(Vis.Master visMstDataGraphic)
        {
            if (_visShp.IsNullOrGone()) return false;
            if (visMstDataGraphic == null) return false;
            _visShp.DataGraphic = visMstDataGraphic;
            return true;
        }
        

        protected void _drop(Vis.Page visPg, Vis.Master visMst)
        {
            if (visMst == null) return;
            _visShp = visPg.Drop(visMst, _dropX, _dropY);
        }
        protected void _drop(Vis.Page visPg, Vis.Master visMst, double x, double y)
        {
            if (visMst == null) return;
            _visShp = visPg.Drop(visMst, x, y);
        }
        protected IEnumerable<Vis.Shape> _getGluedShapes()
        {
            List<int> ids = new List<int>();
            if (_visShp == null) yield return null;

            short iCt = _visShp.RowCount[(short)Vis.VisSectionIndices.visSectionConnectionPts];
            for (short i = 1; i <= iCt; i++)
            {
                Vis.Cell c = _visShp.CellsSRC[
                    (short)Vis.VisSectionIndices.visSectionConnectionPts,
                    (short)(i - 1),
                    (short)Vis.VisCellIndices.visX];

                foreach (Vis.Shape shp in c.DependentShapes()) // shp. _getOtherDependentShapes(c))
                {
                    int id = shp.ID;
                    if (!ids.Contains(id))
                    {
                        yield return shp;
                        ids.Add(id);
                    }
                }
            }
        }
        protected bool _isSolutionShape(Vis.Shape visShp)
        {
            // We will check for the existence of required
            // cells, and the value of User.Class. That is
            // probably enough for 99.99% of the cases.

            // Check User.Class:
            if (!visShp.IsClass(this.UserClassValue))
            {
                return false;
            }

            // Check for required cells:
            string reqdCellnames = this.RequiredCellsCSV;
            if (reqdCellnames.Length > 0)
            {
                if (!visShp.CellsExistsAnywhere(reqdCellnames))
                {
                    return false;
                }
            }

            return true;
        }

        //public Vis.Selection GetNeighboringShapes_Filtered(
        //    double tolerance_maxWidthOrHeightFraction, VL.ShapeTest filter)
        //{
        //    // Get the raw selection of neighbors:
        //    Vis.Selection sel = this.GetNeighboringShapes(tolerance_maxWidthOrHeightFraction);
        //    if (sel == null) return null;
        //    if (sel.Count == 0) return null;

        //    // Filter the selection:
        //    sel.Filter(filter);

        //    // Bail if there are no neighbors that are cabinets:
        //    if (sel == null) return null;
        //    if (sel.Count == 0) return null;

        //    return sel;
        //}

        //public Vis.Shape GetNearestShapeOfType(
        //    double tolerance_maxWidthOrHeightFraction, VL.ShapeTest filter)
        //{
        //    Vis.Selection sel = this.GetNeighboringShapes_Filtered(
        //        tolerance_maxWidthOrHeightFraction, filter);

        //    if (sel == null) return null;
        //    if (sel.Count == 0) return null;

        //    Vis.Shape shpNearest = null;

        //    double px, py, minDistSqr;
        //    px = _visShp.PinXIU();
        //    py = _visShp.PinYIU();
        //    minDistSqr = double.MaxValue;

        //    foreach (Vis.Shape shp in sel)
        //    {
        //        double pxItem, pyItem, distItemSqr;
        //        pxItem = shp.PinXIU();
        //        pyItem = shp.PinYIU();
        //        distItemSqr = Math.Pow(px - pxItem, 2.0) + Math.Pow(py - pyItem, 2.0);

        //        bool bIsCloser = (shpNearest == null) ||
        //                         (distItemSqr < minDistSqr);
        //        if (bIsCloser)
        //        {
        //            shpNearest = shp;
        //            minDistSqr = distItemSqr;
        //        }
        //    }
        //    return shpNearest;
        //}
        //public void SetShapeData(string label, string value, ManySetter mnysetter, bool wrapInQuotes)
        //{
        //    if (_visShp == null) return;
        //    if (_sdsection == null)
        //        _sdsection = new VL.ShapeDataSection(_visShp);

        //    VL.ShapeDataRow sdr = _sdsection.GetSdRowByLabel(label);
        //    if (sdr == null) return;

        //    string val = value;
        //    if (wrapInQuotes) val = "\"" + val + "\"";

        //    mnysetter.AddFormulaU(_visShp, "Prop." + sdr.NameU, val);
        //    //_sdsection.TrySet_Value_ByLabel(label, value);
        //}

        //protected void _drop(Vis.Page visPg, string mastername)
        //{
        //    Vis.Master mst = visPg.MasterByName(mastername);
        //    if (mst == null) return;
        //    _visShp = visPg.Drop(mst, _dropX, _dropY);
        //}
        //protected void _drop(Vis.Page visPg, string mastername, double x, double y)
        //{
        //    Vis.Master mst = visPg.MasterByName(mastername);
        //    if (mst == null) return;
        //    _visShp = visPg.Drop(mst, x, y);
        //}

    }
}
