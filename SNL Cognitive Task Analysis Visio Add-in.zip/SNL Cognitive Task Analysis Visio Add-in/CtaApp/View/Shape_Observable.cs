﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;
using SSC = SNL_Cognitive_Task_Analysis_Visio_Add_in.SolutionStrings;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Shape_Observable : Shape_Task //Shape_Base
    {
        // TODO: there are a couple of "Is solution shape" methods. 
        // The Shape_ classes have the IsSolution, but also 
        // VisHelpers do a quick check of User.Class values.


        public static string RequiredCellsConst =
            "User.Class," +
            SolutionStrings.PropCell_TaskNumber + "," +
            SolutionStrings.PropCell_Description + "," +
            SolutionStrings.PropCell_Category + "," +
            SolutionStrings.PropCell_CategoryContainer + "," +
            SolutionStrings.PropCell_CategoryLayer + "," +
            SolutionStrings.PropCell_Importance + "," +
            SolutionStrings.PropCell_Difficulty + "," +
            SolutionStrings.PropCell_Duration + "," +
            SolutionStrings.PropCell_Frequency + "," +
            SolutionStrings.PropCell_Complexity;
        // TODO: PropCell_Enjoyment?

        public static string UserClassConst = SolutionStrings.ShapeClass_Observable; //"SNL.CAT.Shape.Observable";

        public static void GetCompletedStats(
            Vis.Page visPg, out int count, out int completed)
        {
            var ts = GetObservableShapesOnPage(visPg);
            count = ts.Count;
            completed = 0;
            foreach (var t in ts)
            {
                if (t.IsAllRated) completed++;
            }
        }
        public static List<Shape_Observable> GetObservableShapesOnPage(Vis.Page visPg)
        {
            string classValue = SolutionStrings.ShapeClass_Observable;

            var ts = new List<Shape_Observable>();

            Vis.Selection sel = visPg.ShapesOfClass(classValue);

            foreach (Vis.Shape shp in sel)
            {
                var t = new Shape_Observable(shp);
                if (t.IsSolutionShape) ts.Add(t);
            }
            return ts;
        }

        //public override string MasterName { get { return MasterNameConst; } }
        public override string RequiredCellsCSV { get { return RequiredCellsConst; } }
        public override string UserClassValue { get { return UserClassConst; } }


        //public short? Importance
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Importance); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Importance, value); } }

        //public short? Difficulty
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Difficulty); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Difficulty, value); } }

        //public short? Duration
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Duration); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Duration, value); } }

        //public short? Frequency
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Frequency); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Frequency, value); } }

        //public short? Complexity
        //{ get { return _visShp.TryGetCellResultShortOrNull(SSC.PropCell_Complexity); }
        //  set { _visShp.TrySetCellResultShort(SSC.PropCell_Complexity, value); } }

        public Data.RatingObs Importance
        {
            get { return this.GetRating(SSC.PropCell_Importance); }
            set { this.SetRating(value, SSC.PropCell_Importance); }
        }
        public Data.RatingObs Difficulty
        {
            get { return this.GetRating(SSC.PropCell_Difficulty); }
            set { this.SetRating(value, SSC.PropCell_Difficulty); }
        }
        public Data.RatingObs Duration
        {
            get { return this.GetRating(SSC.PropCell_Duration); }
            set { this.SetRating(value, SSC.PropCell_Duration); }
        }
        public Data.RatingObs Frequency
        {
            get { return this.GetRating(SSC.PropCell_Frequency); }
            set { this.SetRating(value, SSC.PropCell_Frequency); }
        }
        public Data.RatingObs Complexity
        {
            get { return this.GetRating(SSC.PropCell_Complexity); }
            set { this.SetRating(value, SSC.PropCell_Complexity); }
        }
        public Data.RatingObs Enjoyment
        {
            get { return this.GetRating(SSC.PropCell_Enjoyment); }
            set { this.SetRating(value, SSC.PropCell_Enjoyment); }
        }

        public Shape_Observable(Vis.Shape visShp) : base(visShp)
        {
            //_isSolutionShape(visShp);
        }

        public void ClearAllRatingValues()
        {
            // Note: this is different than EraseValues, because it is
            // only setting the *Rating Values* to null/blank/nothin'

            // TODO: for performance, we could use some sort of ManySetter
            // to blast all of these at once - or even better, do it for
            // an entire page!

            // Don't use this.Rating.ToNull(), as that doesn't set the ShapeSheet cell!
            this.Complexity = null;
            this.Difficulty = null;
            this.Duration = null;
            this.Frequency = null;
            this.Importance = null;
            this.Enjoyment = null;
        }
        public void EraseValues(bool eraseDescription, bool eraseCategories)
        {
            this.TaskNumber = null;

            if (eraseDescription)
                this.Description = String.Empty;

            if (eraseCategories)
            {
                this.Category = String.Empty;
                _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryContainer, String.Empty, true);
                _visShp.TrySetCellResultStrU(SSC.PropCell_CategoryLayer, String.Empty, true);
            }

            ClearAllRatingValues();
        }

        public new Data.RatingObs GetRating(string cellname)
        {
            string val = _visShp.TryGetCellResultStr(cellname);

            var r = new Data.RatingObs();
            r.Value = val;

            return r;
        }

    }
}