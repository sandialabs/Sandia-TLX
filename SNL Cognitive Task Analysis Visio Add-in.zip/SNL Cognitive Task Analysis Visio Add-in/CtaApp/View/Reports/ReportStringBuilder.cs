﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View.Reports
{
    public class ReportStringBuilder
    {
        private StringBuilder _sbHeader = null;
        private StringBuilder _sbBody = null;
        private StringBuilder _sbCloser = null;

        public void AppendHeaderLine()
        {
            AppendHeaderLine(String.Empty);
        }
        public void AppendHeaderLine(string text)
        {
            if (_sbHeader == null ) _sbHeader = new StringBuilder();
            _sbHeader.AppendLine(text);
        }
        public void AppendBodyLine()
        {
            AppendBodyLine(String.Empty);
        }
        public void AppendBodyLine(string text)
        {
            if (_sbBody == null) _sbBody = new StringBuilder();
            _sbBody.AppendLine(text);
        }
        public void AppendCloserLine()
        {
            AppendCloserLine(String.Empty);
        }
        public void AppendCloserLine(string text)
        {
            if (_sbCloser == null) _sbCloser = new StringBuilder();
            _sbCloser.AppendLine(text);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            if (_sbHeader != null)
                sb.AppendLine(_sbHeader.ToString());

            if (_sbBody != null)
            {
                if (sb.Length > 0)
                    sb.AppendLine(String.Empty);

                sb.AppendLine(_sbBody.ToString());
            }

            if (_sbCloser != null)
            {
                if (sb.Length > 0)
                    sb.AppendLine(String.Empty);

                sb.AppendLine(_sbCloser.ToString());
            }

            return sb.ToString();
        }



    }
}
