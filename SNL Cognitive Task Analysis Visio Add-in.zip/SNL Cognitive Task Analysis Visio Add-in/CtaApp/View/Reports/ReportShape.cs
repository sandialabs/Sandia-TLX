﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View.Reports
{
    public class ReportShape
    {
        private string _reportText = String.Empty;
        private Vis.Page _visPgTarget = null;
        private Vis.Shape _visShp = null;

        public ReportShape(Vis.Page visPg, string reportText)
        {
            _visPgTarget = visPg;
            _reportText = reportText;
        }

        public void Create()
        {
            if (_visPgTarget.StatNotNormal()) return;
            if (String.IsNullOrEmpty(_reportText)) return;

            Vis.Shape shpPg = _visPgTarget.PageSheet;
            double pw, ph;
            pw = shpPg.CellsU["PageWidth"].ResultIU;
            ph = shpPg.CellsU["PageHeight"].ResultIU;

            _visShp = _visPgTarget.DrawRectangle(pw*0.5, ph*0.5, pw*0.5, ph*0.5);

            string[] cellsAndFormulas = {
                    "Width", "TEXTWIDTH(TheText)",
                    "Height", "MAX(SETATREFEXPR(),TEXTHEIGHT(TheText,Width))",
                    "Char.Size", "12pt",
                    "Para.HorzAlign", "0",
                    "VerticalAlign", "0"
                };

            _setFormulasU(_visShp, cellsAndFormulas);

            _visShp.Text = _reportText;
        }

        private void _setFormulasU(Vis.Shape shp, string[] cellsAndFormulas)           
        {
            // TODO: could check CellExists for each c
            // TODO: catch some sort of error for bad formulas?
            // cellsAndFormulas is a one-dimensional array, which alternates
            // between cellname, formula, cellname, formula, etc.
            string c, f;
            for (int i = 0; i < cellsAndFormulas.Length; i += 2)
            {
                c = cellsAndFormulas[i];
                f = cellsAndFormulas[i + 1];
                //f = f.Replace(ParentToken, sParentSheetID);
                //f = f.Replace(TargetToken1, sTarget1_SheetID);
                //f = f.Replace(TargetToken2, sTarget2_SheetID);
                //f = f.Replace(TargetToken3, sTarget3_SheetID);

                if (shp.TryFormulaForceU(c, f) == false)
                {
                    Console.WriteLine("Failed to set cell '" + c + "' with formula '" + f + "' in shape '" + shp.ID + "'");
                }
            }

        }
    }
}
