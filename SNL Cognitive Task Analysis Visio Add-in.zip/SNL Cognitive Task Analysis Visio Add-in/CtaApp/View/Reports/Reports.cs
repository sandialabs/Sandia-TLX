﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View.Reports
{
    public static class Reports
    {
        // Disconnected connectors and obs/cog shapes
        // Duplicate ids
        // Unnamed obs/cog shapes
        // Incompletely rated obs/cog shapes
        // Noch was?


        public static void ShowReportUnusedTasks(View.Doc vdoc,
            bool includeCognitiveTasks, bool includeObservableTasks)
        {
            if (vdoc == null) return;
            try
            {
                _showReportUnusedTasks(vdoc, includeCognitiveTasks, includeObservableTasks);
            }
            catch (Exception ex)
            {
                VL.UI.Msg.ShowError(
                    ex.Message, nameof(Reports), nameof(ShowReportUnusedTasks));
            }
        }

        public static void ShowReportConnectionOrder(View.Doc vdoc,
            bool includeCognitiveTasks, bool includeObservableTasks)
        {
            if (vdoc == null) return;
            try
            {
                _showReportConnectionOrder(vdoc, includeCognitiveTasks, includeObservableTasks);
            }
            catch (Exception ex)
            {
                VL.UI.Msg.ShowError(
                    ex.Message, nameof(Reports), nameof(ShowReportConnectionOrder));
            }
        }


        private static void _showReportUnusedTasks(View.Doc vdoc,
            bool includeCognitiveTasks, bool includeObservableTasks)
        {
            if (vdoc == null) return;

            var docdata = vdoc.Data;
            docdata.Refresh();
           
            var sb = new StringBuilder();

            sb.AppendLine("Unused Tasks (in Excel, but not in diagram)");
            sb.AppendLine("(" + DateTime.Now.ToString("yyyy.MM.dd - HH:mm:ss") + ")");
            sb.AppendLine();

            // List the individual items:
            int iCtCog = 0;
            int iCtObs = 0;

            if(includeCognitiveTasks)
            {
                sb.AppendLine("Cognitive Tasks:");
                sb.AppendLine("--------------------");
                var tsks = docdata.Tasks.CognitiveTasks;
                foreach(var tsk in tsks)
                {
                    if (tsk.IsInExcel && !tsk.IsInVisio)
                    {
                        sb.AppendLine("- " + tsk.Description);
                        iCtCog++;
                    }
                }
                sb.AppendLine(iCtCog + " unused cognitive tasks.");
            }

            if (includeObservableTasks)
            {
                if (includeCognitiveTasks) sb.AppendLine();

                sb.AppendLine("Observable Tasks:");
                sb.AppendLine("--------------------");

                var tsks = docdata.Tasks.ObservableTasks;
                foreach (var tsk in tsks)
                {
                    if (tsk.IsInExcel && !tsk.IsInVisio)
                    {
                        sb.AppendLine("- " + tsk.Description);
                        iCtObs++;
                    }
                }
                sb.AppendLine(iCtObs + " unused observable tasks.");
            }

            string sReport = sb.ToString();

            // TODO: having a call back to a procedure in Commands -
            // don't really like that, but it IS a central place
            // for UI stuff. I suppose it should be a parameter for this procedure\?
            UI.ReportForm.Show(
                sReport,
                "Unused Tasks",
                0.3, 0.3,
                Commands.CreateReportShape_WithUndo,
                false);
        }

        private static void _showReportConnectionOrder(View.Doc vdoc,
            bool includeCognitiveTasks, bool includeObservableTasks)
        {
            if (vdoc == null) return;

            var grps = new View.ConnectedTaskShapeGroups(vdoc);
            grps.SortByTopLeftToBottomRight();

            // Build a report of groups in top/left order, with
            // sorted connected order, with top/left subsorting
            // order:
            var sbAll = new StringBuilder();
            sbAll.AppendLine("Flow Order");
            sbAll.AppendLine("(" + DateTime.Now.ToString("yyyy.MM.dd - HH:mm:ss") + ")");

            string subtitle = String.Empty;
            if (includeCognitiveTasks) subtitle += "Cognitive tasks";
            if (includeObservableTasks)
            {
                if (subtitle.Length > 0) subtitle += ", ";
                subtitle += "Observable tasks";
            }
            sbAll.AppendLine(subtitle);

            sbAll.AppendLine();

            var iCt = grps.Count;
            for (int i = 0; i < iCt; i++)
            {
                var sbGrp = new StringBuilder();
                var grp = grps[i];

                var ctasks = grp.ShapesInConnectedOrder();
                foreach (var ctask in ctasks)
                {
                    bool bAdd = false;
                    if (ctask.IsCognitive)
                    {
                        if (includeCognitiveTasks) bAdd = true;
                    }
                    else
                    {
                        if (includeObservableTasks) bAdd = true;
                    }

                    // Create a line of text for each task shape:
                    if (bAdd)
                    {
                        string s = String.Empty;
                        if (ctask.IsStartShape)
                        {
                            s = "+ ";
                        }
                        else
                        {
                            s = "> ";
                        }
                        s += ctask.TaskShape.Description;
                        sbGrp.AppendLine(s);
                    }
                }

                // Append the group text:
                sbAll.AppendLine(sbGrp.ToString());

            }

            string sReport = sbAll.ToString();

            // TODO: having a call back to a procedure in Commands -
            // don't really like that, but it IS a central place
            // for UI stuff. I suppose it should be a parameter for this procedure\?
            UI.ReportForm.Show(
                sReport,
                "All Tasks Flow Order",
                0.3, 0.3,
                Commands.CreateReportShape_WithUndo,
                false);
        }

    }
}
