﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    
    public class Page_Config : Page_Base
    {
        public bool DataFileExists
        {
            get
            {
                string path = GetAbsoluteAndValidExcelFilePath_OrEmpty();
                return File.Exists(path);
            }
        }
        public static Page_Config GetConfigPageOrNull(Vis.Document visDoc)
        {
            Vis.Page visPg = visDoc.FirstPageOfClass(
                SolutionStrings.PageClass_Config, false, true);
            if (visPg == null) return null;
            return new Page_Config(visPg);
        }

        private Page_Config(Vis.Page visPg) : base(visPg) { }

        public string GetAbsoluteAndValidExcelFilePath_OrEmpty()
        {
            var sep = Shape_ExcelPath.GetExcelPathShapeOrNull(_visPg);
            if (sep == null) return String.Empty;
            return sep.AbsoluteAndValidFilePathOrEmpty;
        }

        public void GetDataFileInfo(
            out bool fileExists, out string filepath, out string folderpath, out string filename)
        {
            filepath = this.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            fileExists = File.Exists(filepath);

            if(String.IsNullOrEmpty(filepath))
            {
                filename = String.Empty;
                folderpath = String.Empty;
            }
            else
            {
                var fi = new FileInfo(filepath);
                filename = fi.Name;
                folderpath = fi.Directory.FullName;
            }

        }

    }
}
