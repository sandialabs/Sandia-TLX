﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;
using VL = Visguy.VisAddinLib;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class VisSolutionEvents
    {
        // TODO: Finish _visAppEvtSink_OnBeforeWindowClosed, and
        // OnBeforeDocumentClosed

        public class SolutionSelectionChanged_EventArgs : EventArgs
        {
            // A simplified event that raises a "selection changed"
            // event when the selection changes and/or the window
            // changes. This lets the add-on concentrate on what
            // is important. It also processes whether the selection
            // is of one single solution-shape, on a solution-specific
            // page...
            public Vis.Shape ShapeOrNull { get; set; } // Possibly null
            public View.Shape_Cognitive CognitiveShapeOrNull { get; set; } // Possibly null
            public View.Shape_Observable ObservableShapeOrNull { get; set; } // Possibly null

            public Vis.Window Window { get; set; } // Can't be null
            public Vis.Page PageOrNull { get; set; } // Null if window not a drawing page?

            public bool IsDrawingPage_Solution { get; set; }
            public bool IsSelected_SingleSolutionShape { get; set; }

            //public Vis.Window Window { get; set;}
            //public Vis.Page Page { get; set; }
            //public Vis.Master Master { get; set; }
        }

        public class SingleSolutionShapeSelected_EventArgs : EventArgs
        {
            public Vis.Shape Shape { get; set; } // Possibly null
            public View.Shape_Cognitive CogntiveShape{get; set;} // Possibly null
            public View.Shape_Observable ObservableShape{get; set; } // Possibly null

            public Vis.Window Window { get; set; } // Can't be null
            public Vis.Page Page { get; set; } // Null if window not a drawing page?

            //public Vis.Window Window { get; set;}
            //public Vis.Page Page { get; set; }
            //public Vis.Master Master { get; set; }
        }

        //public class WindowActivated_EventArgs : EventArgs
        //{
        //    public bool IsSolutionWindow { get; set; }
        //    public Vis.Window Window { get; set; }
        //    public Vis.Page PageOrNull { get; set; } 
        //}

        public class DocEvent_EventArgs : EventArgs
        {
            public bool IsShownInActiveWindow { get; set; }
            public Vis.Document Document { get; set; }
            public Vis.Page ActivePage { get; set; }
            //public Vis.Shape Shape { get; set; }
        }

        public class MarkerEvent_EventArgs : EventArgs
        {
            public VL.MarkerCommand MarkerCommand { get; set; }
            public Vis.Document Document { get; set; }
            public Vis.Page Page { get; set; }
            public Vis.Shape Shape { get; set; }
        }

        // This is the class from VisAppEventSink...
        //public class VisMarkerEvent_EventArgs : EventArgs
        //{
        //    public string MarkerString { get; set; }
        //    public string MarkerArgs { get; set; }
        //}

        // TODO: use VisAppEventSink and wrap it's low-leve events into events
        //       that have meaning to the solution:
        // - Event: solution shape selected
        // - Event: no solution shapes selected
        // - Event: solution doc activated
        // - Event: no solution doc activated



        //public event EventHandler<SingleSolutionShapeSelected_EventArgs> SingleSolutionShapeSelected;
        //public event EventHandler<SingleSolutionShapeSelected_EventArgs> NonSingleSolutionShapeSelected;
        //public event EventHandler<WindowActivated_EventArgs> WindowActivated;
        //public event EventHandler NonSolutionWindowActivated; // Not a page window, or not a solution-but-page window
        public event EventHandler<DocEvent_EventArgs> OnBeforeDocumentClosed; // TODO: OnBeforeDocumentClosed never used!
        public event EventHandler<MarkerEvent_EventArgs> OnSolutionMarkerEvent;
        public event EventHandler<SolutionSelectionChanged_EventArgs> OnSolutionSelectionChanged;
        public event EventHandler<DocEvent_EventArgs> OnDocumentOpened;

        //public event EventHandler MySpecialEvent...;
        // Phase 2 will require connection events for the coloring...

        //public event EventHandler<PartPickedEventArgs> PartPicked

        private Vis.Application _visApp = null;
        private VisAppEventSink _visAppEvtSink = null;
        private string _markerEventPrefix = String.Empty;
        public VisSolutionEvents(
            Vis.Application visApp,
            string markerEventPrefix)
        {
            _visApp = visApp;
            _markerEventPrefix = markerEventPrefix;

            _visAppEvtSink = new VisAppEventSink(_visApp);

            _visAppEvtSink.OnBeforeDocClosed += _visAppEvtSink_OnBeforeDocClosed;
            _visAppEvtSink.OnDocumentOpened += _visAppEvtSink_OnDocumentOpened;
            _visAppEvtSink.OnSelectionChanged += _visAppEvtSink_SelectionChanged;
            _visAppEvtSink.OnWindowActivated += _visAppEvtSink_OnWindowActivated;
            _visAppEvtSink.OnWindowTurnedToPage += _visAppEvtSink_OnWindowTurnedToPage;
            _visAppEvtSink.OnBeforeWindowClosed += _visAppEvtSink_OnBeforeWindowClosed;
            _visAppEvtSink.OnMarkerEvent += _visAppEvtSink_OnMarkerEvent;
        }

        private void _visAppEvtSink_OnBeforeDocClosed(object sender, VisDocEvent_EventArgs e)
        {
            // Get the new document:
            Vis.Document doc = e.Document;

            var e2 = new DocEvent_EventArgs();
            e2.Document = doc;
            Vis.Page pgActive = null;
            e2.IsShownInActiveWindow = doc.IsShownInActiveWindow(out pgActive);
            e2.ActivePage = pgActive;
            
            OnDocumentOpened(_visApp, e2);
        }

        public void UnsubscribeEvents()
        {
            // Is there a way to do this procedurely?
            _visAppEvtSink.OnBeforeDocClosed -= _visAppEvtSink_OnBeforeDocClosed;
            _visAppEvtSink.OnDocumentOpened -= _visAppEvtSink_OnDocumentOpened;
            _visAppEvtSink.OnSelectionChanged -= _visAppEvtSink_SelectionChanged;
            _visAppEvtSink.OnWindowActivated -= _visAppEvtSink_OnWindowActivated;
            _visAppEvtSink.OnWindowTurnedToPage -= _visAppEvtSink_OnWindowTurnedToPage;
            _visAppEvtSink.OnBeforeWindowClosed -= _visAppEvtSink_OnBeforeWindowClosed;
            _visAppEvtSink.OnMarkerEvent -= _visAppEvtSink_OnMarkerEvent;
        }

        private void _visAppEvtSink_OnBeforeWindowClosed(Vis.Document visDoc)
        {

            //OnBeforeWindowClosed(_visApp, e2);
        }

        private void _visAppEvtSink_OnDocumentOpened(object sender, VisDocEvent_EventArgs e)
        {
            // Get the new document:
            Vis.Document doc = e.Document;

            var e2 = new DocEvent_EventArgs();
            e2.Document = doc;
            Vis.Page pgActive = null;
            e2.IsShownInActiveWindow = doc.IsShownInActiveWindow(out pgActive);
            e2.ActivePage = pgActive;
                                
            OnDocumentOpened(_visApp, e2);
        }
        private void _visAppEvtSink_OnWindowTurnedToPage(object sender, VisWindowEvent_EventArgs e)
        {
            _doSolutionSelectedChangedEvent(e.Window, null);
            //Debug.WriteLine("TODO: _visAppEvtSink_OnWindowTurnedToPage");
            //throw new NotImplementedException();
        }

        private void _visAppEvtSink_OnWindowActivated(object sender, VisWindowEvent_EventArgs e)
        {
            _doSolutionSelectedChangedEvent(e.Window, null);
            //Debug.WriteLine("TODO: _visAppEvtSink_OnWindowActivated");
            //throw new NotImplementedException();
        }

        private void _visAppEvtSink_SelectionChanged(object sender, VisSelectionEvent_EventArgs e)
        {
            _doSolutionSelectedChangedEvent(e.Window, e.Selection);

            // Note: selection doesn't change just because the window changes. 
            // However, we can change our selection changed events to wrap
            // this up, so that a selection change or a window change constitutes
            // a selection change.

            //Vis.Selection sel = e.Selection;
            //var e2 = new SingleSolutionShapeSelected_EventArgs();
            //e2.CogntiveShape = null;
            //e2.ObservableShape = null;

            //// TODO: fill other members of e2?
            //if (sel == null)
            //{
            //    e2.Shape = null;
            //}
            //else if(sel.Count != 1)
            //{
            //    e2.Shape = null;
            //}
            //else
            //{
            //    // There is ONE shape selected, check it for solution-ness:
            //    Vis.Shape shp = sel[1];
            //    e2.Shape = shp;

            //    // if shape is an Observable or Cognitive shape, then raise
            //    // the "we got one" event:
            //    var cog = new Shape_Cognitive(shp);
            //    if (cog.IsSolutionShape)
            //    {
            //        e2.CogntiveShape = cog;
            //        //SingleSolutionShapeSelected(_visApp, e2);
            //        return;
            //    }
            //    else
            //    {
            //        var obs = new Shape_Observable(shp);
            //        if (obs.IsSolutionShape)
            //        {
            //            e2.ObservableShape = obs;
            //            //SingleSolutionShapeSelected(_visApp, e2);
            //            return;
            //        }
            //    }              
            //}

            // Raise the nothing-interesting event:
            //NonSingleSolutionShapeSelected(_visApp, e2); 
        }

        private void _visAppEvtSink_OnBeforeWindowClosed(object sender, VisWindowEvent_EventArgs e)
        {
            Debug.WriteLine("_visAppEvtSink_OnBeforeWindowClosed");
        }
        private void _visAppEvtSink_OnMarkerEvent(object sender, VisMarkerEvent_EventArgs e)
        {
            string mrkr = e.MarkerString;
            //Debug.WriteLine(mrkr);

            if(mrkr.StartsWith_CaseInsensitiveInvariant(_markerEventPrefix))
            {
                // Throw some prepackaged event object from this class,
                // preferably containing doc, page, shape objects or at
                // least ids, where present.
                //Debug.WriteLine("Solution event! " + mrkr);

                var mc = Visguy.VisAddinLib.MarkerCommand.CommandFromString(
                    mrkr, SolutionStrings.MarkerEvent_Prefix);
                if (mc != null)
                    Debug.WriteLine(mc.ToStringDump("", "  "));

                var eMrkEvt = new MarkerEvent_EventArgs();
                Vis.Document doc = null;
                Vis.Page pg = null;
                Vis.Shape shp = null;

                eMrkEvt.MarkerCommand = mc;

                _visApp.GetDocPageShape(mc,
                    out doc, out pg, out shp);

                eMrkEvt.Document = doc;
                eMrkEvt.Page = pg;
                eMrkEvt.Shape = shp;

                // Raise the solution-specific event:
                OnSolutionMarkerEvent(_visApp, eMrkEvt);
            }
            else
            {
                // Do nothing, ignore this event.
            }
            //throw new NotImplementedException();
        }

        private void _doSolutionSelectedChangedEvent(Vis.Window visWin, Vis.Selection visSelOrNull)
        {
            // The window object really should be something:
            if (visWin == null) return;

            // The selection might be null, though, since we are trapping
            // window changes in this event.

            var e2 = new SolutionSelectionChanged_EventArgs();

            // Pessimistic defaults:
            e2.CognitiveShapeOrNull = null;
            e2.IsSelected_SingleSolutionShape = false;
            e2.ObservableShapeOrNull = null;
            e2.PageOrNull = null;
            e2.ShapeOrNull = null;

            // Save the window:
            e2.Window = visWin;

            // Try and get the drawing page:
            e2.IsDrawingPage_Solution = VisioSolutionHelpers.IsSolutionDiagramPageInWindow(visWin);
            if(e2.IsDrawingPage_Solution)
            {
                e2.PageOrNull = visWin.PageAsObj;
            }

            if (visSelOrNull != null)
            {
                if (visSelOrNull.Count == 1)
                {
                    e2.ShapeOrNull = visSelOrNull[1];

                    var cog = new Shape_Cognitive(e2.ShapeOrNull);
                    if (cog.IsSolutionShape)
                    {
                        e2.CognitiveShapeOrNull = cog;
                    }

                    var obs = new Shape_Observable(e2.ShapeOrNull);
                    if (obs.IsSolutionShape)
                    {
                        e2.ObservableShapeOrNull = obs;
                    }
                    
                    e2.IsSelected_SingleSolutionShape = (e2.CognitiveShapeOrNull != null) ||
                                                        (e2.ObservableShapeOrNull != null);
                }
            }

            OnSolutionSelectionChanged(_visApp, e2);
        }

        //public void test()
        //{
        //    // Raise an event....
        //    //SolutionShapeSelected(sender, e);
        //}

        // ======== Event sample code below ================
        //public class PartPickedEventArgs : EventArgs
        //{
        //    public string PartID { get; set; }
        //}
        //protected virtual void OnPartPicked(string partID)
        //{
        //    // Check if any subscribers to the event:
        //    if (PartPicked != null)
        //    {
        //        PartPicked(this, new PartPickedEventArgs() { PartID = partID });
        //        EventArgs args = new EventArgs();
        //    }
        //}


        // Event stuff:
        //
        // 1. Define a delegate:
        //public delegate void PartPickedEventHandler(object sender, EventArgs args);
        // Convent: end with "EventHandler"
        //
        // 2. Define an event based on the delegate:
        //public event PartPickedEventHandler PartPicked; // Ok, that makes sense, take "EventHandler" away from delegate
        // Or just use EventHandler
        //public event EventHandler PartPicked;
        //////////////////public event EventHandler<PartPickedEventArgs> PartPicked;
        //
        // 3. Publish event. Convention is "On" + name of event
        //
        //////////////////protected virtual void OnPartPicked(string partID)
        //////////////////{
        //////////////////    // Check if any subscribers to the event:
        //////////////////    if (PartPicked != null)
        //////////////////    {
        //////////////////        PartPicked(this, new PartPickedEventArgs() { PartID = partID });
        //////////////////        EventArgs args = new EventArgs();
        //////////////////    }
        //////////////////}
        //
        // 4. Raise the event:
        //public void DoSomething()
        //{
        //    //...code that does something...

        //    // Notify the outside world:
        //    OnPartPicked("some part id");
        //}

    }
}
