﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Docs : List<Doc>
    {
        // TODO: we could have the events for doc open/close
        // in this class, but I've centralized Visio events in
        // the class VisSolutionEvents (which gets info from
        // VisAppEventSink)

        private Vis.Application _visApp = null;

        // Active Doc > data > names, etc.

        public Docs(Vis.Application visApp)
        {
            _visApp = visApp;
        }

        /// <summary>
        /// If the active Visio doc is a solution doc, then
        /// a corresponding Doc object is created or retrieved 
        /// from the collection. Otherwise null is returned.
        /// </summary>
        /// <returns></returns>
        public Doc GetActiveDocOrNull()
        {
            if (_visApp == null) return null;

            // Get active document:
            Vis.Document visDoc = _visApp.ActiveDocument;
            if (visDoc == null) return null;

            // Check that it is a solution document:
            if (!VisioSolutionHelpers.IsSolutionDoc(visDoc)) return null;

            // Try and get an existing Doc:
            var d = _itemFromVisDocOrNull(visDoc);
            if(d == null)
            {
                d = new Doc(visDoc);
                this.Add(d);
            }
            return d;            
        }
        /// <summary>
        /// If visDoc is a solution doc, then a corresponding Doc
        /// object is created or retrieved from the collection.
        /// </summary>
        /// <param name="visDoc"></param>
        /// <returns></returns>
        public Doc GetOrAddSolutionDoc(Vis.Document visDoc)
        {
            if (!VisioSolutionHelpers.IsSolutionDoc(visDoc)) return null;

            var d = _itemFromVisDocOrNull(visDoc);
            if (d == null)
            {
                d = new Doc(visDoc);
            }
            return d;
        }
       /// <summary>
       /// Removes the corresponding Doc object from this
       /// collection if a match-by-Visio-document is found.
       /// </summary>
       /// <param name="visDoc"></param>
       /// <returns>Returns true if a Doc object is found with
       /// the corresponding Visio document.</returns>
        public bool Remove_ByVisioDocument(Vis.Document visDoc)
        {
            for (int i = this.Count - 1; i >= 0; i--)
            {
                var d = this[i];
                if(d.VisDoc == visDoc)
                {
                    this.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }


        private Doc _itemFromVisDocOrNull(Vis.Document visDoc)
        {
            foreach(var d in this)
            {
                if (d.VisDoc == visDoc) return d;
            }
            return null;
        }

    }
}
