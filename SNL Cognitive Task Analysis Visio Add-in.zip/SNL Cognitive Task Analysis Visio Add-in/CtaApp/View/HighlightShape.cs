﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class HighlightShape
    {
        // TODO: add method for SNL to highlight 1D Begin/End

        // TODO: IsRed, IsGreen or soemthing
        // TODO: static method to get target shape
        // TODO: static method to identify shape or get all on page, all in doc (why not!?) - using extension select methods!
        // TODO: constructor or properties that associated tags with colors, ie: DeleteShape, Red; AddShape, Green
        // TODO: might be nice to be able to easily style these things!

        // TODO: different forms? Bar left/right/top/bottom, oval, outline, frame, X

        // TODO: centralize exhaustive and quick color code:
        public enum HighlightShapeColors
        {
            Black, Blue, BlueMedium, Green, GreenLime, Magenta, Orange, Purple, Red, Yellow, White
        }
        public enum HighlightShapeStyle
        {
            Frame, Oval, Outline, X
        }

        // TODO: might want to change this class string. This was
        // the original developer's "secret namespace", haha.
        // 
        // The point is for the add-in to be able to identify
        // which highlight shapes it created, so that it can find 
        // them and get rid of them. The ClassValue isn't super
        // important, and could be "x.y.z.highlightshape". 
        private const string ClassValue = "Wanderkind.VisGuy.Lib.Visio.HighlightShape";

        private Vis.Shape _visShp = null;
        private List<Vis.Shape> _visShpTargets = null;

        // TODO: currently no way to read the color for an existing shape.
        private HighlightShapeColors _color = HighlightShapeColors.Red;
        public HighlightShapeColors Color
        {
            set
            {
                if (_visShp != null)
                {
                    string f = _shapeSheetColorFormula(value);
                    _visShp.TryFormulaForceU("FillForegnd", f);
                }
            }
        }

        //public double LineTransparency
        //{
        //    set { _visShp.CellsU["LineColorTrans"].ResultIUForce = value; }
        //}


        private string _tag = string.Empty;
        public string Tag
        {
            get { return _tag; }
            set { }
        }

        private bool _isHighlightShape = false; //...for use when initializing from existing shape.

        // TODO: Currently no way to read style from existing shape
        private HighlightShapeStyle _style = HighlightShapeStyle.Frame;

        //private int _targetShapeID = -1;

        public Vis.Shape TargetShape
        {
            get
            {
                if (_visShp == null) return null;
                // TODO: get the precedent shape for the PinX cell...

                return null;
            }
        }


        // ----- Constructors -------------------------------------------------
        public HighlightShape(HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            _color = color;
            _style = style;
            _tag = tag;
        }
        private HighlightShape(Vis.Shape visShp)
        {
            // Initialize the object from an existing shape, 
            // which might not really be a highlight shape:
            _visShp = visShp;
            _isHighlightShape = _getIsHighlightShape(_visShp);

            if (_isHighlightShape)
            {
                _tag = _visShp.ResultString("User.Tag");
            }
        }
        // Factory method for getting an existing shape as a HighlightShape object:
        public static HighlightShape GetHighlightShape(Vis.Shape visShp)
        {
            HighlightShape hs = new HighlightShape(visShp);
            if (hs._getIsHighlightShape(visShp) == false) return null;
            return hs;
        }
        public static List<HighlightShape> GetHighlightShapes(Vis.Page visPg)
        {
            List<HighlightShape> hss = new List<HighlightShape>();
            foreach (Vis.Shape shp in visPg.Shapes)
            {
                HighlightShape hs = HighlightShape.GetHighlightShape(shp);
                if (hs != null) hss.Add(hs);
            }
            return hss;
        }
        public static List<HighlightShape> GetHighlightShapes(Vis.Document visDoc)
        {
            // TODO: use Selector.ShapesOnPages() or something like that?         
            List<HighlightShape> hss = new List<HighlightShape>();
            foreach (Vis.Page pg in visDoc.Pages)
            {
                foreach (Vis.Shape shp in pg.Shapes)
                {
                    HighlightShape hs = HighlightShape.GetHighlightShape(shp);
                    if (hs != null) hss.Add(hs);
                }
            }
            return hss;
        }
        //public static void AddHighlights(
        //    List<Vis.Shape> targetShapes, 
        //    string tag, HighlightShapeColors color)
        //{
        //    // Create a highlight shape, then duplicate it...

        //}

        public void AddTargetShape(Vis.Shape visShp)
        {
            if (_visShpTargets == null) _visShpTargets = new List<Vis.Shape>();
            _visShpTargets.Add(visShp);
        }

        public bool DeleteHighlightShape()
        {
            if (_visShp != null &&
               _visShp.Stat != (short)Vis.VisStatCodes.visStatDeleted)
            {
                _visShp.Delete();
                _visShp = null;
                return true;
            }
            return false;
        }
        public bool DeleteHighlightAndTargetShape()
        {
            // Bail if there's a problem with _visShp:
            if (_visShp == null ||
               _visShp.Stat == (short)Vis.VisStatCodes.visStatDeleted) return false;

            // The highlight is 'glued' to the target shape, so its Pin
            // cells have the target shape as a precedent:
            Vis.Shape shpTarg = null;
            Array precCells = _visShp.CellsU["PinX"].Precedents;
            if (precCells.Length > 0)
            {
                Vis.Cell c = precCells.GetValue(1) as Vis.Cell;
                if (c != null)
                {
                    shpTarg = c.Shape;
                    if (shpTarg.Stat != (short)Vis.VisStatCodes.visStatDeleted)
                        shpTarg.Delete();
                }

            }

            // Delete the highlight too!
            _visShp.Delete();

            return true;
        }

        public static HighlightShape HighlightTarget(Vis.Shape visTargetShape,
            HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            List<Vis.Shape> shps = new List<Vis.Shape>();
            shps.Add(visTargetShape);
            List<HighlightShape> highlights = _highlightTargetShapes(shps, style, color, tag);
            if (highlights.Count == 0) return null;
            return highlights[0];
        }
        public static List<HighlightShape> HighlightPoints(
            List<Vis.Cell> visTargetCellsX,
            List<Vis.Cell> visTargetCellsY,
            double diameterIU,
            HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            List<HighlightShape> highlights = new List<HighlightShape>();

            // Look for reasons to quit:
            if (visTargetCellsX == null) return highlights;
            if (visTargetCellsY == null) return highlights;
            if (visTargetCellsX.Count == 0) return highlights;
            if (visTargetCellsY.Count == 0) return highlights;
            if (visTargetCellsX.Count != visTargetCellsY.Count) return highlights;

            // Check that all cell-pairs belong to the same shape:
            int iCt = visTargetCellsX.Count;
            for (int i = 0; i < iCt; i++)
            {
                Vis.Shape shpX = visTargetCellsX[i].Shape;
                Vis.Shape shpY = visTargetCellsY[i].Shape;
                if (shpX != shpY) return highlights;
            }


            // Get the first target and its page:
            Vis.Shape shpTarg0 = visTargetCellsX[0].Shape;
            Vis.Cell cellTargetX0 = visTargetCellsX[0];
            Vis.Cell cellTargetY0 = visTargetCellsY[0];
            Vis.Page pg0 = shpTarg0.ContainingPage;

            // Create a highlight and attach it to the first target:
            HighlightShape hs0 = new HighlightShape(style, color, tag);
            hs0._visShp = hs0._createHighlightShape(pg0);
            hs0._attachToTargetShape(hs0._visShp, cellTargetX0, cellTargetY0, diameterIU);
            highlights.Add(hs0);

            // Create additional HighlightShape items, if necessary            
            if (iCt == 1)
            {
                return highlights;
            }
            else
            {
                for (int i = 1; i < iCt; i++)
                {                    
                    Vis.Cell cellTargetXN = visTargetCellsX[i];
                    Vis.Cell cellTargetYN = visTargetCellsY[i];
                    Vis.Shape shpTargN = cellTargetYN.Shape;
                    Vis.Page pgN = shpTargN.ContainingPage;
                    Vis.Shape shpHsN = pgN.Drop(hs0._visShp, 0.5, 0.5);

                    HighlightShape hsN = HighlightShape.GetHighlightShape(shpHsN);
                    hsN._attachToTargetShape(hsN._visShp, cellTargetXN, cellTargetYN, diameterIU);

                    highlights.Add(hsN);
                }
            }

            return highlights;
            //List<Vis.Shape> shps = new List<Vis.Shape>();
            //shps.Add(visTargetShape);
            //List<HighlightShape> highlights = _highlightTargetShapes(shps, style, color, tag);
            //if (highlights.Count == 0) return null;
            //return highlights; // s[0];
        }


        public static List<HighlightShape> HighlightTargets(Vis.Selection visTargetSelection,
            HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            List<Vis.Shape> shps = new List<Vis.Shape>();
            foreach (Vis.Shape shp in visTargetSelection)
            {
                shps.Add(shp);
            }
            return _highlightTargetShapes(shps, style, color, tag);
        }
        public static List<HighlightShape> HighlightTargets(List<Vis.Shape> visTargetShapes,
            HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            return _highlightTargetShapes(visTargetShapes, style, color, tag);
        }

        public List<HighlightShape> HighlightTargets()
        {
            return HighlightShape.HighlightTargets(_visShpTargets, _style, _color, _tag);
        }


        public static void ClearHighlightShapes(Vis.Page visPg)
        {
            HighlightShape hs;
            Vis.Selection sel = visPg.CreateSelection(Vis.VisSelectionTypes.visSelTypeEmpty);
            foreach (Vis.Shape shp in visPg.Shapes)
            {
                hs = HighlightShape.GetHighlightShape(shp);
                if (hs != null)
                {
                    sel.Select(shp, (short)Vis.VisSelectArgs.visSelect);
                }
            }
            if (sel.Count > 0) sel.Delete();
        }
        public static void ClearHighlightShapes(Vis.Document visDoc)
        {
            foreach (Vis.Page pg in visDoc.Pages)
            {
                ClearHighlightShapes(pg);
            }
        }

        private bool _getIsHighlightShape(Vis.Shape visShp)
        {
            return (visShp.ResultString("User.Class") == ClassValue);
        }
        private static List<HighlightShape> _highlightTargetShapes(List<Vis.Shape> visTargetShapes,
            HighlightShapeStyle style, HighlightShapeColors color, string tag)
        {
            List<HighlightShape> highlights = new List<HighlightShape>();
            if (visTargetShapes == null) return highlights;
            if (visTargetShapes.Count == 0) return highlights;

            // Get the first target and its page:
            Vis.Shape shpTarg1 = visTargetShapes[0];
            Vis.Page pg1 = shpTarg1.ContainingPage;

            // Create a highlight and attach it to the first target:
            HighlightShape hs1 = new HighlightShape(style, color, tag);
            hs1._visShp = hs1._createHighlightShape(pg1);
            hs1._attachToTargetShape(hs1._visShp, shpTarg1);
            highlights.Add(hs1);

            // Create additional HighlightShape items, if necessary
            if (visTargetShapes.Count == 1)
            {
                return highlights;
            }
            else
            {
                for (int i = 1; i < visTargetShapes.Count; i++)
                {
                    Vis.Shape shpTargN = visTargetShapes[i];
                    Vis.Page pgN = shpTargN.ContainingPage;
                    Vis.Shape shpHsN = pgN.Drop(hs1._visShp, 0.5, 0.5);

                    HighlightShape hsN = HighlightShape.GetHighlightShape(shpHsN);
                    hsN._attachToTargetShape(hsN._visShp, shpTargN);

                    highlights.Add(hsN);
                }
            }

            return highlights;
        }

        private void _attachToTargetShape(
            Vis.Shape shpHighlight, 
            Vis.Cell cellTargetX, Vis.Cell cellTargetY,
            double diameterIU)
        {
            Vis.Shape shpTarg = cellTargetX.Shape;

            const string TargetToken = "{TARGET}";
            string sTargetSheetID = shpTarg.NameID;

            string sDiam = diameterIU.ToString();

            string[] cellsAndFormulas = {
                "Width", "GUARD(" +  sDiam + ")",
                "Height", "GUARD(" +  sDiam + ")",
                "PinX", "GUARD({TARGET}!" + cellTargetX.Name + ")",
                "PinY", "GUARD({TARGET}!" + cellTargetY.Name + ")",
                "LocPinX", "GUARD(Width*0.5)",
                "LocPinY", "GUARD(Height*0.5)",
                "Angle", "GUARD(0)",
                "FlipX", "GUARD(0)",
                "FlipY", "GUARD(0)"
                };

            // Replace the target tokens:
            for (int i = 1; i < cellsAndFormulas.Length; i += 2)
            {
                cellsAndFormulas[i] = cellsAndFormulas[i].Replace(TargetToken, sTargetSheetID);
            }

            _setFormulasU(shpHighlight, cellsAndFormulas, string.Empty, sTargetSheetID, string.Empty, string.Empty);
        }

        private void _attachToTargetShape(Vis.Shape shpHighlight, Vis.Shape shpTarg)
        {
            const string TargetToken = "{TARGET}";
            string sTargetSheetID = shpTarg.NameID;

            string[] cellsAndFormulas = {
                "Width", "GUARD({TARGET}!Width)",
                "Height", "GUARD({TARGET}!Height)",
                "PinX", "GUARD({TARGET}!PinX)",
                "PinY", "GUARD({TARGET}!PinY)",
                "LocPinX", "GUARD({TARGET}!LocPinX)",
                "LocPinY", "GUARD({TARGET}!LocPinY)",
                "Angle", "GUARD({TARGET}!Angle)",
                "FlipX", "GUARD({TARGET}!FlipX)",
                "FlipY", "GUARD({TARGET}!FlipY)"
                };

            // Replace the target tokens:
            for (int i = 1; i < cellsAndFormulas.Length; i += 2)
            {
                cellsAndFormulas[i] = cellsAndFormulas[i].Replace(TargetToken, sTargetSheetID);
            }

            _setFormulasU(shpHighlight, cellsAndFormulas, string.Empty, sTargetSheetID, string.Empty, string.Empty);

        }

        private Vis.Shape _createHighlightShape(Vis.Page visPg)
        {
            // Draw a rectangle, then draw another rectangle inside
            // to make a frame:
            Vis.Shape shp = visPg.DrawRectangle(0.25, 0.25, 0.5, 0.5);

            // Add needed user cells:
            shp.AddNamedRow((short)Vis.VisSectionIndices.visSectionUser,
                "Class", (short)Vis.VisRowTags.visTagDefault);
            shp.AddNamedRow((short)Vis.VisSectionIndices.visSectionUser,
                "AntiScale", (short)Vis.VisRowTags.visTagDefault);
            shp.AddNamedRow((short)Vis.VisSectionIndices.visSectionUser,
                "Tag", (short)Vis.VisRowTags.visTagDefault);
            shp.AddNamedRow((short)Vis.VisSectionIndices.visSectionUser,
                "frameThickness", (short)Vis.VisRowTags.visTagDefault);

            shp.AddNamedRow((short)Vis.VisSectionIndices.visSectionUser,
                "TargetShapeID", (short)Vis.VisRowTags.visTagDefault);

            string sColorFormula = "GUARD(" + _shapeSheetColorFormula(_color) + ")";

            string[] cellsAndFormulas1 = {
                    "User.Class", "\"" + ClassValue + "\"",
                    "User.Tag", "\"" + this.Tag + "\"",
                    "User.AntiScale", "ThePage!DrawingScale/ThePage!PageScale",
                    "LockThemeColors", "1",
                    "LockThemeEffects", "1",
                    "FillForegnd", sColorFormula,
                    "FillForegndTrans", "0.5",
                    "FillBkgnd", sColorFormula,
                    "LineColor", sColorFormula,
                    "LineColorTrans", "0.75",
                    "FillBkgndTrans", "0.5",
                    "ObjType", "4" // non-routable
                };

            int iSuccessCt = shp.TrySetFormulasU(cellsAndFormulas1);

            // Handle style-specific geometry:
            if (_style == HighlightShapeStyle.Frame)
            {
                // Add a second geometry section:
                shp.DrawRectangle(0, 0, 0, 0);

                string[] cellsAndFormulas2 = {
                    "User.frameThickness", "-0.125*User.AntiScale",
                    "Geometry1.NoLine", "1",
                    "Geometry2.NoLine", "1",
                    "Geometry2.X1", "User.frameThickness",
                    "Geometry2.Y1", "Height-User.frameThickness",
                    "Geometry2.X2", "User.frameThickness",
                    "Geometry2.Y2", "User.frameThickness",
                    "Geometry2.X3", "Width-User.frameThickness",
                    "Geometry2.Y3", "User.frameThickness",
                    "Geometry2.X4", "Width-User.frameThickness",
                    "Geometry2.Y4", "Height-User.frameThickness"
                };

                int iSuccessCt2 = shp.TrySetFormulasU(cellsAndFormulas2);
            }

            if (_style == HighlightShapeStyle.Outline)
            {
                string[] cellsAndFormulas2 = {
                    "User.frameThickness", "0",

                    "Geometry1.NoFill", "True",

                    "Geometry1.X1", "0",
                    "Geometry1.Y1", "0",
                    "Geometry1.X2", "0",
                    "Geometry1.Y2", "Height",

                    "Geometry1.X3", "Width",
                    "Geometry1.Y3", "Height",
                    "Geometry1.X4", "Width",
                    "Geometry1.Y4", "0",

                    "Geometry1.X5", "Geometry1.X1",
                    "Geometry1.Y5", "Geometry1.Y1",

                    "LineWeight", "3 pt"
                };

                int iSuccessCt2 = shp.TrySetFormulasU(cellsAndFormulas2);
            }

            if (_style == HighlightShapeStyle.X)
            {
                Vis.Cell c = shp.Cells["Geometry1.X3"];
                shp.set_RowType(c.Section, c.Row, (short)Vis.VisRowTags.visTagMoveTo);

                string[] cellsAndFormulas2 = {
                    "User.frameThickness", "-0.25*User.AntiScale",

                    "Geometry1.NoFill", "True",

                    "Geometry1.X1", "User.frameThickness",
                    "Geometry1.Y1", "User.frameThickness",
                    "Geometry1.X2", "Width-User.frameThickness",
                    "Geometry1.Y2", "Height-User.frameThickness",

                    "Geometry1.X3", "User.frameThickness",
                    "Geometry1.Y3", "Height-User.frameThickness",
                    "Geometry1.X4", "Width-User.frameThickness",
                    "Geometry1.Y4", "User.frameThickness",

                    "Geometry1.X5", "Geometry1.X4",
                    "Geometry1.Y5", "Geometry1.Y4",

                    "LineWeight", "3 pt"
                };

                int iSuccessCt2 = shp.TrySetFormulasU(cellsAndFormulas2);
            }

            if (_style == HighlightShapeStyle.Oval)
            {
                Vis.Cell c = shp.Cells["Geometry1.X1"];
                shp.set_RowType(c.Section, c.Row, (short)Vis.VisRowTags.visTagEllipse);

                c = shp.Cells["Geometry1.X5"];
                shp.DeleteRow(c.Section, c.Row);
                c = shp.Cells["Geometry1.X4"];
                shp.DeleteRow(c.Section, c.Row);
                c = shp.Cells["Geometry1.X3"];
                shp.DeleteRow(c.Section, c.Row);
                c = shp.Cells["Geometry1.X2"];
                shp.DeleteRow(c.Section, c.Row);

                string[] cellsAndFormulas2 = {
                    "User.frameThickness", "-0.25*User.AntiScale",

                    "Geometry1.NoFill", "True",

                    "Geometry1.X1", "Width*0.5",
                    "Geometry1.Y1", "Height*0.5",
                    "Geometry1.A1", "User.frameThickness",
                    "Geometry1.B1", "Height*).5",

                    "Geometry1.C1", "Width*0.5",
                    "Geometry1.D1", "User.frameThickness",

                    "LineWeight", "3 pt"
                };

                int iSuccessCt2 = shp.TrySetFormulasU(cellsAndFormulas2);
            }

            return shp;

            // TODO: Add highlight to layer.

            // TODO: specify an 'added' or 'deleted' highlight shape
        }

        // TODO: move the whole token-y thing to VisLib?
        private const string ParentToken = "{PARENT}"; 
        // VL.Extensions.CellExtensions.ParentToken; //...{PARENT}
        private const string TargetToken1 = "{TARGET1}"; 
        // VL.Extensions.CellExtensions.TargetToken1; //...{TARGET1}
        private const string TargetToken2 = "{TARGET2}"; 
        // VL.Extensions.CellExtensions.TargetToken2; //...{TARGET2}
        private const string TargetToken3 = "{TARGET3}"; 
        // VL.Extensions.CellExtensions.TargetToken3; //...{TARGET3}

        private void _setFormulasU(Vis.Shape shp,
            string[] cellsAndFormulas, string sParentSheetID, string sTarget1_SheetID, string sTarget2_SheetID, string sTarget3_SheetID)
        {
            // TODO: could check CellExists for each c
            // TODO: catch some sort of error for bad formulas?
            // cellsAndFormulas is a one-dimensional array, which alternates
            // between cellname, formula, cellname, formula, etc.
            string c, f;
            for (int i = 0; i < cellsAndFormulas.Length; i += 2)
            {
                c = cellsAndFormulas[i];
                f = cellsAndFormulas[i + 1];
                f = f.Replace(ParentToken, sParentSheetID);
                f = f.Replace(TargetToken1, sTarget1_SheetID);
                f = f.Replace(TargetToken2, sTarget2_SheetID);
                f = f.Replace(TargetToken3, sTarget3_SheetID);

                if (shp.TryFormulaForceU(c, f) == false)
                {
                    Console.WriteLine("Failed to set cell '" + c + "' with formula '" + f + "' in shape '" + shp.ID + "'");
                }
            }

        }


        private string _shapeSheetColorFormula(HighlightShapeColors hsCol)
        {
            switch (hsCol)
            {
                case HighlightShapeColors.Black:
                    return "RGB(0,0,0)";
                case HighlightShapeColors.Blue:
                    return "RGB(0,255,0)";
                case HighlightShapeColors.Green:
                    return "RGB(0,0,255)";
                case HighlightShapeColors.BlueMedium:
                    return "RGB(0,127,255)";
                case HighlightShapeColors.GreenLime:
                    return "RGB(127,255,0)";
                case HighlightShapeColors.Magenta:
                    return "RGB(255,0,255)";
                case HighlightShapeColors.Orange:
                    return "RGB(255,127,0)";
                case HighlightShapeColors.Purple:
                    return "RGB(127,0,255)";
                case HighlightShapeColors.Red:
                    return "RGB(255,0,0)";
                case HighlightShapeColors.Yellow:
                    return "RGB(255,255,0)";
                case HighlightShapeColors.White:
                    return "RGB(255,255,255)";
                default:
                    return "RGB(255,0,0)";
            }
        }

        ///// <summary>
        ///// Adds a highlight to the Begin or End of a 1D connector.
        ///// </summary>
        ///// <param name="targetShape"></param>
        ///// <param name="toBegin"></param>
        ///// <param name="message"></param>
        //public static void AddHighlight1dBegin(Vis.Shape targetShape,
        //                                       double radius,
        //                                       string message)
        //{
        //    _addHighlight1D(targetShape, radius, true, message);
        //}

        //public static void AddHighlight1dEnd(Vis.Shape targetShape,
        //                                       double radius,
        //                                       string message)
        //{
        //    _addHighlight1D(targetShape, radius, false, message);
        //}

        ///// <summary>
        ///// Adds a highlight to a normal, non-rotated 2D shape.
        ///// </summary>
        ///// <param name="targetShape"></param>
        ///// <param name="message"></param>
        //public static void AddHighlight2D(Vis.Shape targetShape,
        //                                  string message)
        //{
        //    // Drops a highlight shape and locates it over the
        //    // offending shape, and sets the text to a message.

        //    // Get the master:
        //    Vis.Master mst = targetShape.Document.Masters[MasterName];

        //    // Get the page:
        //    Vis.Page pg = targetShape.ContainingPage;

        //    // Get the width, height, and location of the target shape:
        //    double w, h, px, py;
        //    w = targetShape.get_CellsU("Width").ResultIU;
        //    h = targetShape.get_CellsU("Height").ResultIU;
        //    px = targetShape.get_CellsU("PinX").ResultIU;
        //    py = targetShape.get_CellsU("PinY").ResultIU;

        //    Vis.Shape shpHighlight = _dropShape(mst, pg, w, h, px, py);

        //    // 'Glue' the shape's location to that of the shape:
        //    shpHighlight.get_CellsU("PinX").FormulaForceU = "GUARD(Sheet." + targetShape.ID + "!PinX)";
        //    shpHighlight.get_CellsU("PinY").FormulaForceU = "GUARD(Sheet." + targetShape.ID + "!PinY)";

        //    // Set the message:
        //    shpHighlight.Text = message;
        //}

        //public static void AddHighlightPage(Vis.Page visPg,
        //                                    string message)
        //{
        //    // Drops a highlight shape 'for the page'. This
        //    // doesn't belong to any shape in particular. The
        //    // message applies to the page in general.

        //    // Get the master:
        //    Vis.Master mst = visPg.Document.Masters[MasterName];

        //    // Get the PageSheet:
        //    //Vis.Shape visShpPg = visPg.PageSheet;

        //    // TODO: it would be nice to find an empty location on the 
        //    //       page, in which to drop this shape.

        //    // Get the width, height, and location of the target shape:
        //    // For now, just hard-code the size, and put the shape in the
        //    // lower-left corner of the page:
        //    double w, h, px, py;
        //    w = 1.25;
        //    h = 1.25;
        //    px = w * 0.6;
        //    py = h * 0.6;

        //    Vis.Shape shpHighlight = _dropShape(mst, visPg, w, h, px, py );

        //    // Set the message:
        //    shpHighlight.Text = message;

        //    // Turn on the page icon:
        //    shpHighlight.get_Cells(User_ShowPageIcon).ResultIU = 1;
        //}

        //public static void ClearHighlightShapes(Vis.Page visPage)
        //{
        //    Vis.Master mst = visPage.Document.Masters[MasterName];

        //    Vis.Selection sel = visPage.CreateSelection(
        //        Vis.VisSelectionTypes.visSelTypeByMaster,
        //        Vis.VisSelectMode.visSelModeSkipSuper,
        //        mst);

        //    if (sel.Count > 0) sel.Delete();

        //}

        //private static Vis.Shape _dropShape(Vis.Master mst, Vis.Page pg,
        //    double w, double h, double px, double py)
        //{
        //    Vis.Shape shp = pg.Drop(mst, px, py);

        //    shp.get_CellsU("Width").ResultIU = w;
        //    shp.get_CellsU("Height").ResultIU = h;

        //    return shp;
        //}

        //private static void _addHighlight1D(Vis.Shape targetShape,
        //                                double radius,
        //                                bool toBegin,
        //                                string message)
        //{
        //    // Drops a highlight shape and locates it over the
        //    // target shape, and sets the text to a message.

        //    // Get the master:
        //    Vis.Master mst = targetShape.Document.Masters[MasterName];

        //    // Get the page:
        //    Vis.Page pg = targetShape.ContainingPage;

        //    // Set 'Begin' or 'End' prefix to use in formulas:
        //    string endName;

        //    if (toBegin)
        //    {
        //        endName = "Begin";
        //    }
        //    else
        //    {
        //        endName = "End";
        //    }

        //    // Positional formulas:
        //    string fx, fy;
        //    fx = "GUARD(Sheet." + targetShape.ID + "!" + endName + "X)";
        //    fy = "GUARD(Sheet." + targetShape.ID + "!" + endName + "Y)";

        //    // Positional values:
        //    // TODO: is this needed if we are setting formulas?
        //    double px, py;
        //    px = targetShape.get_CellsU(endName + "X").ResultIU;
        //    py = targetShape.get_CellsU(endName + "Y").ResultIU;

        //    // Drop the highlight shape:
        //    Vis.Shape shpHighlight = _dropShape(mst, pg, radius, radius, px, py);

        //    // 'Glue' the shape's location to that of the shape:
        //    shpHighlight.get_CellsU("PinX").FormulaForceU = fx;
        //    shpHighlight.get_CellsU("PinY").FormulaForceU = fy;

        //    // Set the message:
        //    shpHighlight.Text = message;
        //}

    }
}

