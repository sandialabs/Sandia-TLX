﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
using System.IO;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Doc
    {
        private Vis.Document _visDoc = null;
        private DocData _docData = null;

        public Vis.Document VisDoc { get { return _visDoc; } }

        public DocData Data {  get { return _docData;  } }
        public IssueHighlighter IssueHighlighter { get; private set; }

        //private Data ExcelData;
        private Page_Config _configPage = null;
        private Page_Diagram _diagramPage = null;

        public Page_Config ConfigPage_OrNull { get { return _configPage; } }
        public Page_Diagram DiagramPage_OrNull { get { return _diagramPage; } }

        public static View.Doc GetActiveSolutionDoc_OrNull(Vis.Application visApp)
        {
            if (visApp == null) return null;

            // Get active document:
            Vis.Document visDoc = visApp.ActiveDocument;

            // Check that it is a solution document:
            if (!View.VisioSolutionHelpers.IsSolutionDoc(visDoc)) return null;

            // Get the active page:
            Vis.Page visPg = visApp.ActivePage;
            if (visPg == null) return null;

            // Check that the page is the same as the document:
            if (visPg.Document != visDoc) return null;

            // Create a new View.Doc object:
            View.Doc d = new Doc(visDoc);

            return d;
        }

        public bool IsSolutionDocument { get; private set; }

        // Associated windows?
        // Associated panels

        // Excel file path from config...

        // Cognitive Task names/ids
        // Observable Task names/ids

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="visDoc"></param>
        public Doc(Vis.Document visDoc)
        {
            _visDoc = visDoc;
           
            IsSolutionDocument = visDoc.IsClass(SolutionStrings.DocClass_Solution);

            _configPage = _getConfigPageOrNull();
            _diagramPage = _getDiagramPageOrNull();

            _docData = new DocData(this);

            this.IssueHighlighter = new IssueHighlighter(this);
        }

        public bool AddShapes_Many(
            List<Data.CognitiveTask> tasksCog,
            List<Data.ObservableTask> tasksObs,
            bool addConnectors, 
            bool switchToDiagramPage)
        {
            if((tasksCog.Count + tasksObs.Count) == 0) return false;
            var vpg = _getDiagramPageOrNull();
            if (vpg == null) return false;

            // Switch to diagram page:
            if(switchToDiagramPage)
                this.TrySwitchActiveWindowToDiagramPage();

            return vpg.AddShapes_Many(tasksCog, tasksObs, addConnectors);
        }

        public bool CopyExcelTemplate(out string newFilepath)
        {
            return _copyExcelFileToVisioFileFolder(
                Solution.Filepath_ExcelTemplate,
                out newFilepath);
        }
        public bool  CopySampleExcel(out string newFilepath)
        {
            return _copyExcelFileToVisioFileFolder(
                Solution.Filepath_ExcelSample,
                out newFilepath);
        }

        public void ClearAllRatingValues()
        {
            var vpg = this.DiagramPage_OrNull;
            if (vpg == null) return;

            foreach (var t in vpg.GetCognitiveShapes())
                t.ClearAllRatingValues();
            foreach (var t in vpg.GetObservableShapes())
                t.ClearAllRatingValues();
        }

        public void RestoreRatingValuesFromData()
        {
            string path = this.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (string.IsNullOrEmpty(path)) return; // TODO: notify user that there's no data source?

            var vpg = this.DiagramPage_OrNull;
            if (vpg == null) return;

            Data.TaskSet tasksExcel = _docData.GetExcelData();
            if (tasksExcel.TotalCount == 0) return;
            
            string descCurr, descOld;
            string targetDesc = string.Empty;

            foreach(var tskshp in vpg.GetCognitiveShapes())
            {
                // Figure out which description to key on:
                descCurr = tskshp.Description;
                descOld = tskshp.OldDescription;
                if (string.IsNullOrEmpty(descOld))
                {
                    targetDesc = descCurr;
                }
                else
                {
                    targetDesc = descOld;
                }

                // Get a matching Excel task:
                var te = tasksExcel.CognitiveTasks.FirstOrDefault
                    (t => string.Compare(t.Description, targetDesc, true) == 0);
                if(te != null)
                {
                    ViewModel.VisioWriter.UpdateTaskShapeFromData(tskshp, te, false);                    
                }

                // Restore the description, if necessary:
                if (descCurr != targetDesc)
                    tskshp.Description = descOld;
            }

            foreach (var tskshp in vpg.GetObservableShapes())
            {
                // Figure out which description to key on:
                descCurr = tskshp.Description;
                descOld = tskshp.OldDescription;
                if (string.IsNullOrEmpty(descOld))
                {
                    targetDesc = descCurr;
                }
                else
                {
                    targetDesc = descOld;
                }

                // Get a matching Excel task:
                var te = tasksExcel.CognitiveTasks.FirstOrDefault
                    (t => string.Compare(t.Description, targetDesc, true) == 0);
                if (te != null)
                {
                    ViewModel.VisioWriter.UpdateTaskShapeFromData(tskshp, te, false);
                }

                // Restore the description, if necessary:
                if (descCurr != targetDesc)
                    tskshp.Description = descOld;
            }
        }

        public void ViewDataSource()
        {
            var cpg = this.ConfigPage_OrNull;
            if (cpg == null) return;

            string filepath = cpg.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (!File.Exists(filepath)) return;

            // Open the file!
            try
            {
                Process.Start(filepath);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error in View.Doc.ViewDataSource:\n" + ex.Message);
                //throw;
            }            
        }

        public bool DataSourceExists
        {
            get
            {
                string p = this.GetAbsoluteAndValidExcelFilePath_OrEmpty();
                return File.Exists(p);
            }
        }

        // TODO: move to Page_Config?
        public string GetDataSourceCheckReport()
        {
            StringBuilder sb = new StringBuilder();

            // Check for config page:
            var pc = Page_Config.GetConfigPageOrNull(_visDoc);
            if (pc == null)
            {
                sb.AppendLine("- Can't find 'config' page in this document!");
            }
            else
            {
                sb.AppendLine("+ 'config' page exists.");
            }

            // Check for file and folder:
            bool fileExists;
            string filepath, folderpath, filename;
            pc.GetDataFileInfo(out fileExists, out filepath, out folderpath, out filename);

            if (fileExists == false)
            {
                sb.AppendLine("- Could not find data file!");
            }
            else
            {
                sb.AppendLine("+ File exists: '" + filename + "' in folder:");
                sb.AppendLine("\t'" + folderpath + "'.");
            }

            // Check tables and columns:
            if (fileExists)
            {
                bool cogTableExists, cogColumnsExist, obsTableExists, obsColumnsExist;
                string missingCogCols, missingObsCols;
                var er = new ViewModel.ExcelReader();
                er.CheckTablesAndColumns(filepath,
                    out cogTableExists, out cogColumnsExist, out missingCogCols,
                    out obsTableExists, out obsColumnsExist, out missingObsCols);

                if (cogTableExists)
                {
                    sb.AppendLine("+ Cognitive Tasks table exists.");
                    if (cogColumnsExist)
                    {
                        sb.AppendLine("+ Cognitive Tasks columns exist.");
                    }
                    else
                    {
                        sb.AppendLine("- Couldn't find all Cognitive Tasks columns. Missing columns: ");
                        sb.AppendLine("\t" + missingCogCols);
                    }
                }
                else
                {
                    sb.AppendLine("- Can't find Cognitive Tasks table.");
                }

                if (obsTableExists)
                {
                    sb.AppendLine("+ Observable Tasks table exists.");
                    if (obsColumnsExist)
                    {
                        sb.AppendLine("+ Observable Tasks columns exist.");
                    }
                    else
                    {
                        sb.AppendLine("- Couldn't find all Observable Tasks columns. Missing columns: ");
                        sb.AppendLine("\t" + missingObsCols);
                    }
                }
                else
                {
                    sb.AppendLine("- Can't find Observable Tasks table.");
                }
            }

            return sb.ToString();
        }

        //public DocData GetData()
        //{
        //    // Get Excel data
        //    // ...last update?

        //    // Get page data
            
        //    // Put the two together...

        //    // Some sort of enum:
        //    // DataConflicts.
        //    //  OverwriteVisioDataWithExcelData 
        //    //  KeepVisioDataAsTheLiveData...

        //    return null;
        //}
        public string GetAbsoluteAndValidExcelFilePath_OrEmpty() // TODO: needed from the 'outside'?
        {
            var cpg = this.ConfigPage_OrNull;
            if (cpg == null) return string.Empty;
            return cpg.GetAbsoluteAndValidExcelFilePath_OrEmpty();
        }


        public bool SaveToExcel()
        {
            string pathToExcelFile = this.GetAbsoluteAndValidExcelFilePath_OrEmpty();
            if (String.IsNullOrEmpty(pathToExcelFile)) return false;

            _docData.Refresh();
            var tasks = _docData.Tasks;
            
            var xlwr = new ViewModel.ExcelWriter();
            xlwr.Write(pathToExcelFile, tasks);

            return true;
        }

        public void TrySwitchActiveWindowToDiagramPage()
        {
            var vpg = _getDiagramPageOrNull();
            if (vpg == null) return;
            Vis.Page visPg = vpg.VisioPage;
            visPg.TryActiveWindowGotoPage();
        }
        public void TrySwitchActiveWindowToConfigPage()
        {
            var vpg = _getConfigPageOrNull();
            if (vpg == null) return;
            Vis.Page visPg = vpg.VisioPage;
            visPg.TryActiveWindowGotoPage();
        }

        private bool _copyExcelFileToVisioFileFolder(string sourceFilepath, out string newFilepath)
        {
            // Copy the file, if possible:
            newFilepath = _copyExcelFile(sourceFilepath);

            // If the path is empty, return false:
            //if (String.IsNullOrEmpty(copiedPath)) return false;

            // Update the path in the config page's text box (if
            // there was an error, this could be blank, perhaps
            // that is actually good!)
            _updateConfigPageFilepath(newFilepath);

            return File.Exists(newFilepath);
        }

        /// <summary>
        /// Copies a file from a source directory to the directory
        /// of this object's Visio document, if it has been saved.
        /// </summary>
        /// <param name="sourceFilepath"></param>
        /// <returns>Returns the full path to the copied file or 
        /// String.Empty if there was a problem.</returns>
        private string _copyExcelFile(string sourceFilepath)
        {
            string targetFilepath = String.Empty;
            string targetFolder = _visDoc.Path;

            // Visio doc has no path = unsaved?
            if (!Directory.Exists(targetFolder)) return String.Empty;

            // Can't find source file?
            if (!File.Exists(sourceFilepath)) return String.Empty;

            // Copy the file!
            var fi = new FileInfo(sourceFilepath);
            targetFilepath = Path.Combine(targetFolder, fi.Name);

            // Might have files open or something:
            try
            {
                File.Copy(sourceFilepath, targetFilepath, true);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error in View.Doc._copyExcelFile:\n" + ex.Message);
                return String.Empty;
                //throw;
            }
            return targetFilepath;
        }
        private View.Page_Config _getConfigPageOrNull()
        {
            var pc = Page_Config.GetConfigPageOrNull(_visDoc);
            return pc;
        }
        private View.Page_Diagram _getDiagramPageOrNull()
        {
            //View.VisioSolutionHelpers.get
            Vis.Page pg = _visDoc.FirstPageOfClass(
                SolutionStrings.PageClass_MainDiagram, true, false);

            if (pg == null) return null;

            var pd = new Page_Diagram(pg);
            if (!pd.IsSolutionPage) return null;

            return pd;
        }
        private void _updateConfigPageFilepath(string newFilepath)
        {
            var cpg = this.ConfigPage_OrNull;
            if (cpg == null) return;

            var vshpPath = Shape_ExcelPath.GetExcelPathShapeOrNull(cpg.VisioPage);
            if (vshpPath == null) return;

            vshpPath.SetPath(newFilepath);
        }

    }
}
