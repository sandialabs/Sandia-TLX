﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Vis = Microsoft.Office.Interop.Visio;
using VL = Visguy.VisAddinLib;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    // This class handles the low-level subscription to Visio
    // events, and attaches to them one-to-one, whereas "WithEvents"
    // and IConnectionPoint(?) e.g.:
    //
    //    _visApp.BeforeDocumentClose += _visApp_BeforeDocumentClose
    // 
    // event handling will cause a LOT of events to be subscribed-to
    // in Visio. So yes, the EventSink/AddAdvise is more efficient, 
    // but it is a pain in the ass.
    //
    // So we will raise "easier to handle" events from this class that,
    // say, a VisSolutionEvents class can easily handle, process, and 
    // then re-raise events that have more specific meaning to a 
    // particular solution.

    // For this add-in, we'll need:
    //
    // - Selection changed
    // - Window changed
    // - Document changed or whatever, to test for solution document and ribbon UI
    // - Possibly marker event
    //
    // TODO: abstract this out to solution-specific events:
    // - Event: solution shape selected
    // - Event: no solution shapes selected
    // - Event: solution doc activated
    // - Event: no solution doc activated


    //User.Class = DTools.SystemIntegrator.Schematic.Visio in existing schematic shapes...
    //User.Class = "DTools.SystemIntegrator.Schematic.Visio.SchematicPOC.Schematic"

    // Define event-specific event-args classes:
    public class VisSelectionEvent_EventArgs : EventArgs
    {
        public Vis.Selection Selection { get; set; }
        public Vis.Window Window { get; set; }
    }
    public class VisWindowEvent_EventArgs : EventArgs
    {
        public Vis.Window Window { get; set;}
    }
    public class VisDocEvent_EventArgs : EventArgs
    {
        public Vis.Document Document { get; set; }
    }
    public class VisMarkerEvent_EventArgs : EventArgs
    {
        public string MarkerString { get; set; }
        public string MarkerArgs { get; set; }
    }

    [System.Runtime.InteropServices.ComVisible(true)]
    public class VisAppEventSink : Vis.IVisEventProc
    {
        // Microsoft says this AddAdvise is best for performance, but it is
        // a serious pain to implement, and I am having problems analyzing
        // BeforeSelectionDelete or QueryCancelSelectionDelete. Maybe it doesn't
        // work for out of process?

        // NO, this was a 1-based array problem, I think!

        // We need connections added, deleted,
        // Shape added and deleted
        // marker events
        //
        // Connections get created or deleted:
        // - connections added, deleted
        // - connectors deleted, devices deleted...

        // Raise events such as: "Process", "ConnectorDeleted", "ConnectorAdded"
        
        private Vis.Application _visApp = null;
        private Vis.EventList _visAppEvents = null;
        private List<Vis.Event> _subscribedEvents = null;

        #region Event Handler Objects

        public event EventHandler<VisDocEvent_EventArgs> OnBeforeDocClosed;
        public event EventHandler<VisSelectionEvent_EventArgs> OnSelectionChanged;
        public event EventHandler<VisDocEvent_EventArgs> OnDocumentOpened;
        public event EventHandler<VisWindowEvent_EventArgs> OnWindowActivated;
        public event EventHandler<VisWindowEvent_EventArgs> OnWindowTurnedToPage;
        public event EventHandler<VisWindowEvent_EventArgs> OnBeforeWindowClosed;
        public event EventHandler<VisMarkerEvent_EventArgs> OnMarkerEvent;
        //public event EventHandler NonSingleSolutionShapeSelected;
        //public event EventHandler SolutionPageActivated;
        //public event EventHandler NonSolutionPageActivated;

        #endregion Event Handler Objects

        #region Event Codes and Event Objects

        // Pair Visio event objects and their constants. Just leave
        // the commented-out stuff for the next time you have to
        // create one of these Event Sink Beasts.

        // visEvtAdd is declared as a 2-byte value to avoid a run-time overflow error.
        private const short visEvtAdd = -32768;
        private const short VisEvtConst_App = (short)Vis.VisEventCodes.visEvtApp;

        private Vis.Event _visEvt_BeforeDocClosed = null;
        private const short VisEvtConst_BeforeDocClosed = 
            (short)Vis.VisEventCodes.visEvtDel +
            (short)Vis.VisEventCodes.visEvtDoc;

        private Vis.Event _visEvt_DocOpened = null;        
        private const short VisEvtConst_DocOpened = 
            (short)Vis.VisEventCodes.visEvtCodeDocOpen;

        private Vis.Event _visEvt_SelChanged = null;
        private const short VisEvtConst_SelectionChanged = 
            (short)Vis.VisEventCodes.visEvtCodeWinSelChange;

        private Vis.Event _visEvt_WinActivated = null;
        private const short VisEvtConst_WinActivated = 
            VisEvtConst_App + (short)Vis.VisEventCodes.visEvtWinActivate;

        private Vis.Event _visEvt_WinTurnedToPage = null;
        private const short VisEvtConst_WinTurnedToPage = 
            (short)Vis.VisEventCodes.visEvtCodeWinPageTurn;

        private Vis.Event _visEvt_BeforeWindowClosed = null;
        private const short VisEvtConst_BefWinClosed = 
            (short)Vis.VisEventCodes.visEvtWindow +
            (short)Vis.VisEventCodes.visEvtDel;
        private Vis.Event _visEvt_MarkerEvent = null;
        private const short VisEvtConst_Marker = 
            (short)Vis.VisEventCodes.visEvtApp +
            (short)Vis.VisEventCodes.visEvtMarker;

        // TODO: _connsAdded, _connsDeleted, _queryCancelSelDel, _beforeSelectionDeleted for Phase 2 or 2+
        //private Vis.Event _connsAdded = null;
        //private const short evtConnsAdded = visEvtAdd +
        //                                (short)Vis.VisEventCodes.visEvtConnect;
        //
        //private Vis.Event _connsDeleted = null;
        //private const short evtConnsDeleted = (short)Vis.VisEventCodes.visEvtDel +
        //                                (short)Vis.VisEventCodes.visEvtConnect;
        //private Vis.Event _queryCancelSelDel = null;
        //private const short evtQueryCancelSelDel = (short)Vis.VisEventCodes.visEvtCodeQueryCancelSelDel;
        //
        //private Vis.Event _beforeSelectionDeleted = null;
        //private const short evtBefSelDel = (short)Vis.VisEventCodes.visEvtCodeBefSelDel;

        //private Vis.Event _docCreatedEvent = null;
        //private const short evtCodeDocCreated = (short)Vis.VisEventCodes.visEvtCodeDocCreate;

        //private Vis.Event _docOpenedEvent = null;
        //private const short evtCodeDocOpened = (short)Vis.VisEventCodes.visEvtCodeDocOpen;



        //private Vis.Event _windowActivated = null;
        //private const short evtWinActivated = (short)Vis.VisEventCodes.visEvtApp +
        //                                (short)Vis.VisEventCodes.visEvtWinActivate;

        #endregion Event Codes and Event Objects



        /// <summary>The constructor initializes the event descriptions
        /// dictionary.</summary>
        public VisAppEventSink(Vis.Application visApp)
        {
            _visApp = visApp;            
            _visAppEvents = _visApp.EventList;
            _subscribedEvents = new List<Vis.Event>();

            //  _visEvt_SelChanged = null;
            //VisEvtConst_SelectionChanged

            _visEvt_BeforeDocClosed = _visAppEvents.AddAdvise(
                VisEvtConst_BeforeDocClosed,
                this, string.Empty, "VisAppEventSink: Before Document Closed");
            _subscribedEvents.Add(_visEvt_BeforeDocClosed);

            _visEvt_DocOpened = _visAppEvents.AddAdvise(
                VisEvtConst_DocOpened,
                this, string.Empty, "VisAppEventSink: Document Opened");
            _subscribedEvents.Add(_visEvt_DocOpened);

            // Add the events you want to listen for here:      
            _visEvt_SelChanged = _visAppEvents.AddAdvise(
                VisEvtConst_SelectionChanged,
                this, string.Empty, "VisAppEventSink: Selection Changed");
            _subscribedEvents.Add(_visEvt_SelChanged);

            // Note: when a different window is activated, selection changed
            //       does NOT fire, although it probably should.
            _visEvt_WinActivated = _visAppEvents.AddAdvise(
                VisEvtConst_WinActivated,
                this, string.Empty, "VisAppEventSink: Window Activated");
            _subscribedEvents.Add(_visEvt_WinActivated);

            _visEvt_WinTurnedToPage = _visAppEvents.AddAdvise(
                VisEvtConst_WinTurnedToPage,
                this, string.Empty, "VisAppEventSink: Window Turned to Page");
            _subscribedEvents.Add(_visEvt_WinTurnedToPage);

            _visEvt_BeforeWindowClosed = _visAppEvents.AddAdvise(
                VisEvtConst_BefWinClosed,
                this, string.Empty, "VisAppEventSink: Before Window Closed");
            _subscribedEvents.Add(_visEvt_BeforeWindowClosed);

            _visEvt_MarkerEvent = _visAppEvents.AddAdvise(
                VisEvtConst_Marker,
                this, string.Empty, "VisAppEventSink: Marker Event");
            _subscribedEvents.Add(_visEvt_MarkerEvent);

            //_beforeSelectionDeleted = _visAppEvents.AddAdvise(
            //    evtBefSelDel,
            //    this, string.Empty, "dtBeforeSelectionDeleted");
            //_connsAdded = _visAppEvents.AddAdvise(
            //    VisConstEvtConnsAdded,
            //    this, string.Empty, "dtConnectionsAdded");
            //_connsDeleted = _visAppEvents.AddAdvise(
            //    evtConnsDeleted,
            //    this, string.Empty, "dtConnectionsDeleted");
            //_queryCancelSelDel = _visAppEvents.AddAdvise(
            //    evtQueryCancelSelDel,
            //    this, string.Empty, "dtQueryCancelSelDel");


            //_docCreatedEvent = _visAppEvents.AddAdvise(
            //    evtCodeDocCreated, 
            //    this, string.Empty, "dtDocumentCreated");

            //_docOpenedEvent = _visAppEvents.AddAdvise(
            //    evtCodeDocOpened, 
            //    this, string.Empty, "dtDocumentOpened");

            //_windowActivated = _visAppEvents.AddAdvise(
            //    evtWinActivated, 
            //    this, string.Empty, "dtWindowActivated");
        }

        public void UnsubscribeEvents()
        {
            // As long as the events subscribed to in visAppEventSink's
            // constructor are properly added to _subscribedEvents,
            // then this should effectively remove them all.
            for (int i = _subscribedEvents.Count-1; i <= 0; i--)
            {
                Vis.Event evt = _subscribedEvents[i];
                if (evt != null)
                {
                    evt.Delete();
                    evt = null;
                }
                _subscribedEvents.RemoveAt(i);
            }           
        }

        public object VisEventProc(
            short eventCode,
            object source,
            int eventId,
            int eventSequenceNumber,
            object subject,
            object moreInformation)
        {
            Vis.EventList evts = _visApp.EventList;
            Vis.Event evt = evts.get_ItemFromID(eventId);
            string args = evt.TargetArgs;
            Console.WriteLine("VisAppEventSink.VisEventProc: " + args + subject.GetType().ToString());

            if (source == null) return null;

            string message = String.Empty;
            object returnValue = true;            
            
            //_beforeSelectionDeleted = _visAppEvents.AddAdvise(
            //    evtBefSelDel,
            //    this, string.Empty, "dtBeforeSelectionDeleted");
            //_connectionsAdded = _visAppEvents.AddAdvise(
            //    evtConnectionsAdded,
            //    this, string.Empty, "dtConnectionsAdded");
            //_connectionsDeleted = _visAppEvents.AddAdvise(
            //    evtConnectionsDeleted,
            //    this, string.Empty, "dtConnectionsDeleted");
            //_markerEvent = _visAppEvents.AddAdvise(
            //    evtCodeMarker,
            //    this, string.Empty, "dtMarkerEvent");
            try
            {
                switch (eventCode)
                {
                    case VisEvtConst_BeforeDocClosed:
                        _handleBeforeDocClosed(subject);
                        break;
                    case VisEvtConst_DocOpened:
                        _handleDocOpened(subject);
                        break;
                    case VisEvtConst_SelectionChanged:
                        _handleSelectionChanged(subject);
                        break;
                    case VisEvtConst_WinActivated:
                        _handleWindowActivated(subject);
                        break;
                    case VisEvtConst_WinTurnedToPage:
                        _handleWindowTurnedToPage(subject);
                        break;
                    case VisEvtConst_BefWinClosed:
                        _handleBeforeWindowClosed(subject);
                        break;
                    case VisEvtConst_Marker:
                        _handleMarker(source, subject, eventId);
                        break;

                        //case evtBefSelDel:
                        //    //_handleBefSelDeleted(subject);
                        //    break;
                        //case VisConstEvtConnsAdded:
                        //    _handleConnsAdded(subject);
                        //    break;
                        //case evtConnsDeleted:
                        //    _handleConnsDeleted(subject);
                        //    break;
                        //case evtQueryCancelSelDel:
                        //Vis.Selection sel = subject as  Vis.Selection;
                        //if(sel != null)
                        //{
                        //    if(sel.Count > 0)
                        //    {
                        //        Vis.Shape shp = sel[0];
                        //    }
                        //}
                        //_handleBefSelDeleted(subject);
                        //break;
                        //case evtCodeDocCreated:
                        //    // subject is a Visio document:
                        //    _handleDocCreated(subject as Vis.Document);
                        //    break;
                        //case evtCodeDocOpened:
                        //    // subject is a Visio document:
                        //    _handleDocOpened(subject as Vis.Document);
                        //    break;


                }

                // TODO: what is this for?
                string eventInformation = _visApp.EventInfo[
                    (short)Vis.VisEventCodes.visEvtIdMostRecent];

                if (eventInformation != null)
                {
                    message += "\n" + eventInformation;
                }

                //// Write the event info to the output window
                System.Diagnostics.Debug.WriteLine(message);
            }
            catch (Exception err)
            {
                System.Diagnostics.Debug.WriteLine(err.Message);
                //throw;
            }

            return returnValue;
        }
        private void _handleBeforeDocClosed(object subject)
        {
            // Fire before doc closed event:
            Vis.Document doc = subject as Vis.Document;
            if (doc == null) return;

            var e = new VisDocEvent_EventArgs();
            e.Document = doc;
            OnBeforeDocClosed(_visApp, e);            
        }
        private void _handleDocOpened(object subject)
        {
            // Fire doc opened event:
            Vis.Document doc = subject as Vis.Document;
            if (doc == null) return;

            var e = new VisDocEvent_EventArgs();
            e.Document = doc;
            OnDocumentOpened(_visApp, e);            
        }

        private void _handleSelectionChanged(object subject)
        {
            // Fire selection changed event:
            Vis.Window win = subject as Vis.Window;
            if (win == null) return;

            Vis.Selection sel = win.Selection; 
            var e = new VisSelectionEvent_EventArgs();
            e.Selection = sel;
            e.Window = win;
            OnSelectionChanged(_visApp, e);
        }
        private void _handleWindowActivated(object subject)
        {
            // Fire window activated event:
            Vis.Window win = subject as Vis.Window;
            var e = new VisWindowEvent_EventArgs();
            e.Window = win;
            OnWindowActivated(_visApp, e);
        }
        private void _handleWindowTurnedToPage(object subject)
        {
            // Fire window turned to page event:
            Vis.Window win = subject as Vis.Window;
            var e = new VisWindowEvent_EventArgs();
            e.Window = win; ;
            OnWindowTurnedToPage(_visApp, e);
        }

        private void _handleBeforeWindowClosed(object subject)
        {
            // Fire window turned to page event:
            Vis.Window win = subject as Vis.Window;
            var e = new VisWindowEvent_EventArgs();
            e.Window = win; ;
            OnBeforeWindowClosed(_visApp, e);
        }
        private void _handleMarker(object source, object subject, int eventId)
        {
            // Subject object is an Application for a MarkerEvent. EventInfo
            // is empty for most of app events.  For the Marker event, the 
            // EnterScope event and the ExitScope event eventinfo contains 
            // the context string. 
            Vis.Application subjectApp = subject as Vis.Application;
            if (subjectApp == null) return; // Swallow the unlikely error

            var e = new VisMarkerEvent_EventArgs();

            // Get event info for the marker event:
            if (subjectApp != null)
            {
                e.MarkerString = subjectApp.EventInfo[
                    (short)Vis.VisEventCodes.visEvtIdMostRecent];
            }

            // Get the targetArgs string from the event object. The targetArgs
            // are added to the event object in the AddAdvise method
            Vis.EventList visEvtList = null;
            Vis.Event visEvtThis = null;
            string sSourceType = String.Empty;
            string sTargetArgs = String.Empty;

            const string AppClass = "Microsoft.Office.Interop.Visio.ApplicationClass";
            const string DocClass = "Microsoft.Office.Interop.Visio.DocumentClass";
            const string PageClass = "Microsoft.Office.Interop.Visio.PageClass";

            sSourceType = source.GetType().FullName;
            // TODO: InvisibleAppClass?
            //if (sSourceType == AppClass)
            //{
            //    visEvtList = ((Vis.Application)source).EventList;
            //}
            if (sSourceType == AppClass)
            {
                visEvtList = ((Vis.Application)source).EventList;
            }
            else if (sSourceType == DocClass)
            {
                visEvtList = ((Vis.Document)source).EventList;
            }
            else if (sSourceType == PageClass)
            {
                visEvtList = ((Vis.Page)source).EventList;
            }

            if (visEvtList != null)
            {
                visEvtThis = visEvtList.get_ItemFromID(eventId);
                sTargetArgs = visEvtThis.TargetArgs;

                // append targetArgs when it is available
                if (sTargetArgs.Length > 0)
                {
                    e.MarkerArgs += " " + sTargetArgs;
                }
            }

            // Fire marker event:
            OnMarkerEvent(_visApp, e);
        }

        #region Commented-out Code for Other Events
        //private void _handleBefSelDeleted(object subject)
        //{
        //    Vis.Selection sel = subject as Vis.Selection;
        //    if (sel == null) return;

        //    Vis.Shape shp = null;
        //    for (int i = 0; i < sel.Count; i++)
        //    {
        //        shp = sel[i];
        //        if (shp.Connects.Count > 0)
        //        {
        //            Debug.WriteLine("Shape being deleted is glued to something. Hmmm...");
        //        }
        //    }

        //    Vis.Connects cnncts = subject as Vis.Connects;
        //}
        //private void _handleSelAdded(object subject)
        //{
        //    Vis.Selection sel = subject as Vis.Selection;
        //    if (sel == null) return;

        //}
        //private void _handleConnsAdded(object subject)
        //{
        //    Vis.Connects cnns = subject as Vis.Connects;
        //    if (cnns == null) return;

        //    Vis.Connects cnncts = subject as Vis.Connects;
        //}
        //private void _handleConnsDeleted(object subject)
        //{
        //    Vis.Connects cnns = subject as Vis.Connects;
        //    if (cnns == null) return;

        //}

        //private void _handleDocCreated(Vis.Document visDoc)
        //{
        //    if (visDoc == null) return;
        //    if (_visApp == null) return;
        //    //_owApp.HandleDocOpenedOrCreated(visDoc);
        //}
        //private void _handleDocOpened(Vis.Document visDoc)
        //{
        //    if (visDoc == null) return;
        //    if (_visApp == null) return;
        //    //_owApp.HandleDocOpenedOrCreated(visDoc);            
        //}
        //private void _handleWinActivated(Vis.Window visWin)
        //{
        //    if (visWin == null) return;
        //    //_owApp.HandleWindowActivated(visWin);
        //}
        //private void _handleBeforeDocClosed()
        //{
        //    if (_owDoc == null) return;      
        //    _owDoc.RemoveDoc();           
        //}

        #endregion
    }

}
