﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class IssueHighlighter
    {
        private View.Doc _vdoc = null;

        public IssueHighlighter(View.Doc vdoc)
        {
            _vdoc = vdoc;            
        }
        public void ClearHighlights()
        {
            var vpg = _getDiagramPage_OrNull();
            if (vpg == null) return;

            _clearHighlights(vpg);
        }
        public void HighlightAllIssues()
        {
            var vpg = _getDiagramPage_OrNull();
            if (vpg == null) return;

            _clearHighlights(vpg);

            _highlightDisconnections(vpg);
            _highlightDuplicates(vpg);                  
        }
        public void HighlightDisconnections()
        {
            var vpg = _getDiagramPage_OrNull();
            if (vpg == null) return;

            _clearHighlights(vpg);

            _highlightDisconnections(vpg);            
        }
        public void HighlightTasksWithDuplicateDescriptions()
        {
            var vpg = _getDiagramPage_OrNull();
            if (vpg == null) return;

            _clearHighlights(vpg);

            _highlightDuplicates(vpg);
        }

        private void _clearHighlights(View.Page_Diagram vpg)
        {
            if (vpg == null) return;
            HighlightShape.ClearHighlightShapes(vpg.VisioPage); // TODO: by tag?
        }

        private void _highlightDisconnections(View.Page_Diagram vpg)
        {
            if (vpg == null) return;
            vpg.Highlight_Disconnections(); // TODO: move the code into this module?            
        }
        private void _highlightDuplicates(View.Page_Diagram vpg)
        {
            if (vpg == null) return;

            List<Shape_Cognitive> duplicateCogShapes = null;
            List<Shape_Observable> duplicateObsShapes = null;

            vpg.GetTasksWithDuplicateDescriptions(out duplicateCogShapes, out duplicateObsShapes);

            if (duplicateCogShapes.Count == 0 &&
               duplicateObsShapes.Count == 0) return;

            // Build a Visio selection out of all the shapes:
            Vis.Selection visSel = vpg.VisioPage.CreateEmptySelection();
            foreach (var tshp in duplicateCogShapes)
                visSel.Select(tshp.Shape);
            foreach (var tshp in duplicateObsShapes)
                visSel.Select(tshp.Shape);

            var highlighter =
                HighlightShape.HighlightTargets(
                visSel,
                HighlightShape.HighlightShapeStyle.Frame,
                HighlightShape.HighlightShapeColors.Purple,
                SolutionStrings.HighlightTag_Duplicate);

            Debug.WriteLine("Duplicate shapes highlighted: " + highlighter.Count);
        }

        //private static bool _highlightDuplicateTaskNames(Vis.Page visPg)
        //{
        //    var pd = new View.Page_Diagram(visPg);
        //    int iCt = pd.Highlight_DuplicateTaskNames_Cognitive();

        //    // TODO: this is only testing highlight Cog, and not Obs as well!

        //    // TODO: report the number of "issues highlighted"
        //    return true;
        //}

        //private static bool _highlightDisconnections(Vis.Page visPg)
        //{
        //    var pd = new View.Page_Diagram(visPg);
        //    int iCt = pd.Highlight_Disconnections();
        //    // TODO: report the number of "issues highlighted"
        //    return true;
        //}

        private View.Page_Diagram _getDiagramPage_OrNull()
        {
            if (_vdoc == null) return null;
            return _vdoc.DiagramPage_OrNull;
        }


    }
}
