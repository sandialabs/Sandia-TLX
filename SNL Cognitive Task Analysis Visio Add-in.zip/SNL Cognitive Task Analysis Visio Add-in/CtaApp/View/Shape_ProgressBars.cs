﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class Shape_ProgressBars : Shape_Base
    {       
        #region "Static procedures for updating Progress Bars shapes on a page"
        /// <summary>
        /// Updates all Progress Bars shapes on a page. If the page doesn't
        /// have any shapes, a Progress Report is dropped in the center of the
        /// view, then updated with the completed/total stats for each task type.
        /// </summary>
        /// <param name="visPg"></param>
        /// <returns>The number of progress bar shapes that were updated.</returns>
        public static int UpdateProgressReportsShapesOnPage(Vis.Page visPg)
        {
            // Get (or add a) progress bars on page:
            var pbs = _getPbShapesOnPage(visPg);
            if (pbs.Count == 0) return 0; //...this should hopefully not happen!

            // Get the stats:
            int countCog, completedCog;
            Shape_Cognitive.GetCompletedStats(visPg, out countCog, out completedCog);
            int countObs, completedObs;
            Shape_Observable.GetCompletedStats(visPg, out countObs, out completedObs);

            // Update the progress bar shapes:
            foreach(var pb in pbs)
            {
                pb.UpdateValues(countCog, completedCog, countObs, completedObs);
            }

            return pbs.Count;
        }
        private static List<Shape_ProgressBars> _getPbShapesOnPage(Vis.Page visPg)
        {
            // Get all of the Progress Bars shapes on the page:
            Vis.Selection selPbs =
                visPg.ShapesOfClass(SolutionStrings.ShapeClass_ProgressBars);

            // Create a collection:
            List<Shape_ProgressBars> pbs = new List<Shape_ProgressBars>();

            // Add a shape if there isn't one, otherwise wrap the Visio
            // shapes in Shape_ProgressBars objects:
            if (selPbs.Count == 0) //...not sure if selPbs could be null
            {
                var pb = DropNewAtPageCenter(visPg);
                pbs.Add(pb);
            }
            else
            {
                foreach (Vis.Shape shp in selPbs)
                {
                    var pb = new Shape_ProgressBars(shp);
                    if (pb.IsSolutionShape) pbs.Add(pb);
                }
            }
            return pbs;
        }

        public static Shape_ProgressBars DropNewAtPageCenter(Vis.Page visPg)
        {
            Vis.Master mst = visPg.MasterByName(SolutionStrings.MasterName_ProgressBars);
            if (mst == null) return null;

            Vis.Shape shp = visPg.Drop_PageCenter(mst);

            var pb = new Shape_ProgressBars(shp);
            if (!pb.IsSolutionShape) return null;

            return pb;
        }
        #endregion

        public static string UserClassConst = SolutionStrings.ShapeClass_ProgressBars;
        public const string RequiredCellsConst = "User.Class," + 
            "Prop.CognitiveCount,Prop.CognitiveComplete,Prop.ObservableCount,Prop.ObservableComplete";

        public override string RequiredCellsCSV { get { return RequiredCellsConst; } }
        public override string UserClassValue { get { return UserClassConst; } }

        public double CognitiveCount
        { set { _visShp.TrySetCellResultU("Prop.CognitiveCount", value); } }
        public double CognitiveComplete
        { set { _visShp.TrySetCellResultU("Prop.CognitiveComplete", value); } }
        public double ObservableCount
        { set { _visShp.TrySetCellResultU("Prop.ObservableCount", value); } }
        public double ObservableComplete
        { set { _visShp.TrySetCellResultU("Prop.ObservableComplete", value); } }

        public Shape_ProgressBars(Vis.Shape visShp) : base(visShp) { }

        public void UpdateValues(
            double cogCt, double cogComplete, 
            double obsCt, double obsComplete)
        {
            this.CognitiveCount = cogCt;
            this.CognitiveComplete = cogComplete;
            this.ObservableCount = obsCt;
            this.ObservableComplete = obsComplete;
        }
    }
}
