﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;
namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.View
{
    public class DataGraphicApplier
    {
        private View.Page_Diagram _vpgDiagram = null;
        private Vis.Document _visDoc = null;
        private Vis.Page _visPg = null;

        public string DataGraphicName_1{get; set;}
        public string DataGraphicName_2 { get; set; }
        public string DataGraphicName_3 { get; set; }
        public DataGraphicApplier(View.Page_Diagram vpgDiagram)
        {
            _vpgDiagram = vpgDiagram;
            _visPg = _vpgDiagram.VisioPage;
            _visDoc = _visPg.Document;

            this.DataGraphicName_1 = String.Empty;
            this.DataGraphicName_2 = String.Empty;
            this.DataGraphicName_3 = String.Empty;
        }

        public void ClearDataGraphics()
        {
            var cogs = _vpgDiagram.GetCognitiveShapes();
            foreach (var s in cogs)
                s.ClearDataGraphic();

            var obs = _vpgDiagram.GetObservableShapes();
            foreach (var s in obs)
                s.ClearDataGraphic();

            // Update the "current data graphic" status:
            _vpgDiagram.UpdateCurrentDataGraphicLabels(true, true, null);
        }

        /// <summary>
        /// Attempts to apply datagraphics to a solution diagram
        /// page, using data graphics that have the names specified
        /// in DataGraphicName_1, _2 and _3.
        /// </summary>
        public void TryApplyDataGraphics()
        {
            if (!String.IsNullOrEmpty(this.DataGraphicName_1))
                _tryApplyDataGraphic(this.DataGraphicName_1);
            if (!String.IsNullOrEmpty(this.DataGraphicName_2))
                _tryApplyDataGraphic(this.DataGraphicName_2);
            if (!String.IsNullOrEmpty(this.DataGraphicName_3))
                _tryApplyDataGraphic(this.DataGraphicName_3);
        }

        private void _tryApplyDataGraphic(string dataGraphicName)
        {
            // Try to get a datagraphic/master by name, then apply
            // it to Cognitive and/or Observable shapes.

            Vis.Master mstDg = _visDoc.MasterByName(dataGraphicName);
            if (mstDg == null) return;

            bool bApplyToCog = false;
            bool bApplyToObs = false;

            // We can implement some funny, name-based logic to
            // filter which shapes we apply the data graphics to.
            // If the name contains "Task" apply to both. If the
            // name contains "Cog" of "Cognitive", or "Obs" or 
            // "Observable", then...
            // If the name contains none of these things, then apply
            // to both - "inappropriate" datagraphics will fail 
            // gracefully anyway...


            string nameLC = dataGraphicName.ToLower();
            if (nameLC.Contains("cog") ||
                nameLC.Contains("cognitive"))
            {
                bApplyToCog = true;
            }
            if (nameLC.Contains("obs") ||
                nameLC.Contains("observable"))
            {
                bApplyToObs = true;
            }
            if (nameLC.Contains("task"))
            {
                bApplyToCog = true;
                bApplyToObs = true;
            }

            // This is maybe the weirdest one: if neither
            // flag is set, set both of them, ie: "what the heck,
            // go for it!":
            if (bApplyToCog == false &&
                bApplyToObs == false)
            {
                bApplyToCog = true;
                bApplyToObs = true;
            }

            // Now do it!
            if (bApplyToCog)
            {
                foreach (var s in _vpgDiagram.GetCognitiveShapes() ) //  _getAllTasks_Cognitive())
                    s.TryApplyDataGraphic(mstDg);
            }
            if (bApplyToObs)
            {
                foreach (var s in _vpgDiagram.GetObservableShapes() ) // _getAllTasks_Observable())
                    s.TryApplyDataGraphic(mstDg);
            }

            // Update the "current data graphic" status:
            _vpgDiagram.UpdateCurrentDataGraphicLabels(bApplyToCog, bApplyToObs, mstDg);
        }
    }
}
