﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class Task
    {
        public const string BlankDescription = "---";
        public static List<string> ColumnNames_ForWrite()
        {
            var l = new List<string>()
            {
                //nameof(TaskNumber),
                nameof(Description),
                //nameof(OldDescription),
                nameof(Category),
                nameof(Category_Layer),
                nameof(Category_Container)
            };
            return l;
        }

        // ID, Description, IsCurrent, CurrentDate, IsAccurate, AccurateDate
        public string TaskNumber { get; set; }
        public string Description { get; set; }
        public string OldDescription { get; set; } // <-- used by Visio shapes only?

        // Not sure if the categories need to be nullable. Not sure
        // why the others are - I think to indicate that they've never
        // been set. Since the categories aren't data-bound, and aren't
        // being filled out by experts, it might not matter for them.

        public string Category { get; set; }
        public string Category_Layer { get; set; }
        public string Category_Container { get; set; }

        // These are flags used to synch Visio and Excel while the user
        // is working. 

        // Having them at a different level of scope in the code (inherited 
        // from Task) wasn't worth the separation of concerns, so I've put 
        // them here, at a "low leve". They aren't read from/written to shapes 
        // nor the database, but are useful when trying to reconcile the two 
        // sources of data.
        public bool IsChanged { get; set; }
        public bool IsNew { get; set; }
        public bool IsRenamed { get; set; }
        public bool IsInExcel { get; set; }
        public  bool IsInVisio { get; set; }

        public static bool IsEmptyDescription(string desc)
        {
            if (String.IsNullOrEmpty(desc)) return true;
            if (String.Compare(desc, BlankDescription, true) == 0) return true;
            return false;         
        }


        // TODO: We might need a variety of Equals methods, depending on
        // when and what we are comparing.
        protected virtual bool Equals(Task other)
        {
            if (other.TaskNumber != TaskNumber) return false;
            if (other.Description != Description) return false;
            if (other.Category != Category) return false;
            if (other.Category_Container != Category_Container) return false;
            return true;
        }

        protected void _overwriteData(Task other) // TODO: _overwriteData -> protected virtual?
        {
            this.Category = other.Category;
            this.Category_Container = other.Category_Container;
            this.Category_Layer = other.Category_Layer;
            //this.Description = other.Description;
            //this.IsChanged
            //this.IsInExcel
            //this.IsInVisio
            //this.IsNew
            //this.IsRenamed
            this.TaskNumber = other.TaskNumber;          
        }

        public override string ToString()
        {
            return this.TaskNumber + ": " + this.Description;
        }

        // In original Excel spreadsheet, but apparently not needed
        // for the Visio add-in.
        //public bool IsCurrent { get; set; }
        //public DateTime CurrentDate { get; set; }
        //public bool IsAccurate { get; set; }
        //public DateTime AccurateDate { get; set; }
    }

    public class CognitiveTask : Task
    {
        public static new List<string> ColumnNames_ForWrite()
        {
            var l = Task.ColumnNames_ForWrite();

            l.Add(nameof(Category_NearestObservableTask));
            l.Add("Mental Demand"); // nameof(MentalDemand)); <-- no spaces for nameof...
            l.Add("Physical Demand"); // nameof(PhysicalDemand));
            l.Add("Temporal Demand"); // nameof(TemporalDemand));
            l.Add(nameof(Performance));
            l.Add(nameof(Effort));
            l.Add(nameof(Frustration));
            l.Add(nameof(Enjoyment));

            return l;
        }

        // MentalDemand, PhysicalDemand, TemporalDemand, Performance, Effort, Frustration
        
        //public short? MentalDemand { get; set; }
        //public short? PhysicalDemand { get; set; }
        //public short? TemporalDemand { get; set; }
        //public short? Performance { get; set; }
        //public short? Effort { get; set; }
        //public short? Frustration { get; set; }
        
        public Data.RatingCog MentalDemand { get; set; }
        public Data.RatingCog PhysicalDemand { get; set; }
        public Data.RatingCog TemporalDemand { get; set; }
        public Data.RatingCog Performance { get; set; }
        public Data.RatingCog Effort { get; set; }
        public Data.RatingCog Frustration { get; set; }
        public Data.RatingCog Enjoyment { get; set; }

        public string Category_NearestObservableTask { get; set; }

        public bool Equals(CognitiveTask other)
        {
            if (!base.Equals(other)) return false;

            if (other.MentalDemand != MentalDemand) return false;
            if (other.PhysicalDemand != PhysicalDemand) return false;
            if (other.TemporalDemand != TemporalDemand) return false;
            if (other.Performance != Performance) return false;
            if (other.Effort != Effort) return false;
            if (other.Frustration != Frustration) return false;
            if (other.Category_NearestObservableTask != Category_NearestObservableTask) return false;
            if (other.Enjoyment != Enjoyment) return false;

            return true;
        }

        public void OverwriteData(CognitiveTask other) // TODO: OverwriteData -> protected virtual?
        {
            // Take care of the common stuff:
            this._overwriteData(other);

            // Cog-specific stuff:
            this.Category_NearestObservableTask = other.Category_NearestObservableTask;
            this.Effort = other.Effort;
            this.Frustration = other.Frustration;
            this.MentalDemand = other.MentalDemand;
            this.Performance = other.Performance;
            this.PhysicalDemand = other.PhysicalDemand;
            this.TemporalDemand = other.TemporalDemand;
            this.Enjoyment = other.Enjoyment;

            // _overwriteData does this
            //   
            //this.Category = other.Category;
            //this.Category_Container = other.Category_Container;
            //this.Category_Layer = other.Category_Layer;
            ////this.Description = other.Description;
            ////this.IsChanged
            ////this.IsInExcel
            ////this.IsInVisio
            ////this.IsNew
            ////this.IsRenamed
            //this.TaskNumber = other.TaskNumber;
        }
    }

    public class ObservableTask : Task
    {
        public static new List<string> ColumnNames_ForWrite()
        {
            var l = Task.ColumnNames_ForWrite();

            l.Add(nameof(Importance));
            l.Add(nameof(Difficulty));
            l.Add(nameof(Duration));
            l.Add(nameof(Duration));
            l.Add(nameof(Frequency));
            l.Add(nameof(Complexity));
            l.Add(nameof(Enjoyment));

            return l;
        }

        // Importance, Difficulty, Duration, Frequency, Complexity
        //public short? Importance { get; set; }
        //public short? Difficulty { get; set; }
        //public short? Duration { get; set; }
        //public short? Frequency { get; set; }
        //public short? Complexity { get; set; }
        public Data.RatingObs Importance { get; set; }
        public Data.RatingObs Difficulty { get; set; }
        public Data.RatingObs Duration { get; set; }
        public Data.RatingObs Frequency { get; set; }
        public Data.RatingObs Complexity { get; set; }
        public Data.RatingObs Enjoyment { get; set; }

        public bool Equals(ObservableTask other)
        {
            if (!base.Equals(other)) return false;

            if (other.Importance != Importance) return false;
            if (other.Difficulty != Difficulty) return false;
            if (other.Duration != Duration) return false;
            if (other.Frequency != Frequency) return false;
            if (other.Complexity != Complexity) return false;
            if (other.Enjoyment != Enjoyment) return false;

            return true;
        }

        public void OverwriteData(ObservableTask other) // TODO: OverwriteData -> protected virtual?
        {
            // Take care of the common stuff:
            this._overwriteData(other);

            // Obs-specific stuff:
            this.Complexity = other.Complexity;
            this.Difficulty = other.Difficulty;
            this.Duration = other.Duration;
            this.Frequency = other.Frequency;
            this.Importance = other.Importance;
            this.Enjoyment = other.Enjoyment;

            // _overwriteData does this:
            //
            //this.Category = other.Category;
            //this.Category_Container = other.Category_Container;
            //this.Category_Layer = other.Category_Layer;
            ////this.Description = other.Description;
            ////this.IsChanged
            ////this.IsInExcel
            ////this.IsInVisio
            ////this.IsNew
            ////this.IsRenamed
            //this.TaskNumber = other.TaskNumber;
        }
    }


}
