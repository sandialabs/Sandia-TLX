﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class TaskNumberDescriptions : List<TaskNumberDescription>
    {
        private DateTime _lastQueryFromDataFile = DateTime.MinValue;

    }
    public class TaskNumberDescription
    {
        public string Number { get; set; }
        public string Description { get; set; }
        public bool UsedInDiagram { get; set; }
        public bool Completed { get; set; }
        public TaskNumberDescription(string number, string desc)
        {
            this.Number = number;
            this.Description = desc;
        }
    }
}
