﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
using VL = Visguy.VisAddinLib;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class ExcelUtils
    {
        // We need to attach the data source to the Doc object
        // so we can track when/how often the query happens...
        public static TaskNumberDescriptions Test_GetTaskIdDescriptions(
            Data.TaskTypes taskType)
        {
            var tnds = new TaskNumberDescriptions();

            string prefix = String.Empty;
            if(taskType == TaskTypes.CognitiveTask)
            {
                prefix = "Cog";
            }
            else if(taskType == TaskTypes.ObservableTask)
            {
                prefix = "Obs";
            }
            else
            {
                return tnds;
            }

            for (int i = 0; i < 10; i++)
            {
                string index = i.ToString("00");
                tnds.Add(new TaskNumberDescription(
                    prefix + index, prefix + " Task " + index));
            }

            return tnds;
        }

        public static TaskNumberDescriptions GetTaskIdDescriptions(
            Data.TaskTypes taskType)
        {
            var tnds = new TaskNumberDescriptions();

            View.Doc doc = Solution.GetActiveSolutionDocOrNull();
            if (doc == null) return tnds; //...empty
            
            return tnds;
        }
    }
}
