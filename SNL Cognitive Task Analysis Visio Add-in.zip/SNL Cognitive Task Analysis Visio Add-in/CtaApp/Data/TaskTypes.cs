﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public enum TaskTypes { Other, CognitiveTask, ObservableTask }    
}
