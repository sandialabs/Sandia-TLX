﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class DataSet
    {
        // What else...?
        public List<CognitiveTask> CognitiveTasks { get; private set; }
        public List<ObservableTask> ObservableTasks { get; private set; }
    }
}
