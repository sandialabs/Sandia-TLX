﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Visguy.VisAddinLib.Extensions;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class TaskList : List<Task>
    {
        public List<string> Categories_Unique_Sorted(string extraCategoryToInclude)
        {
            var list = this.Select(t => t.Category).Distinct().ToList<string>();
            if (!list.ContainsItem_CaseInsensitive(extraCategoryToInclude))
                list.Add(extraCategoryToInclude);

            list.Sort();
            return list;
        }
        public List<string> Descriptions_Unique_Sorted(
            bool includeInVisioItems)
        {
            var list = this.FindAll(t => (t.IsInVisio == includeInVisioItems))
                .Select(t => t.Description).Distinct().ToList<string>();
            list.Sort();
            return list;
        }

        public Task FirstByDescriptionOrNull(string description)
        {
            return this.FirstOrDefault(t => String.Compare(t.Description, description, true) == 0);
        }

        public List<Task> Items_WithDescripton(string description)
        {
            // Ok, I was having trouble with the lambda...so loop it!
            var matches = new List<Task>();
            foreach(var t in this)
            {
                if (String.Compare(t.Description, description, true) == 0)
                    matches.Add(t);
            }
            return matches;
            //var matches = this.TakeWhile(t => t.Description == description);
            //    //.Where(c => (String.Compare(description, c.Description, true) == 0).Select(c);
            //    //this.TakeWhile(c => (String.Compare(description, c.Description, true) == 0));
            //if (matches == null) return new List<Task>();
            //return matches.ToList<Task>();
        }
    }
}
