﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{
    public class Rating
    {
        // A "Rating" can be null/blank, "N/A" or a short value,
        // within bounds. We could probably also add allowable
        // steps to the short value.

        public const string NA_Value = "N/A";
        public const string NullValue = "";

        protected const short NullNumericValue = -1;
        protected const short NANumericValue = -2;

        protected short _minVal = 0;
        protected short _maxVal = 0;

        protected string _val = NullValue;
        protected short _valShort = 0;
        protected bool _isNumeric = false;
        protected bool _isNa = false;
        protected bool _isNull = true;

        public bool IsNull
        {
            get
            {
                return _isNull;
            }
        }
        public bool IsNA
        {
            get
            {
                return _isNa;
            }
        }
        public bool IsNumeric
        {
            get
            {
                return _isNumeric;
            }
        }
        public string Value
        {
            get
            {
                return _val;
            }
            set
            {
                // Parse the value to N/A, null or a short value.
                // If numeric but out of bounds, set null.
                _isNa = false;
                _isNull = false;
                _isNumeric = false;
                if(String.Compare(value, NA_Value, true) == 0)
                {
                    _isNa = true;
                }
                else if(String.Compare(value, NullValue, true) == 0)
                {
                    _isNull = true;
                }
                else
                {
                    double dVal; // Visio values can come over as "double-string" values, like 10.0000 instead of 10
                    if(Double.TryParse(value, out dVal))
                    {
                        if(dVal < _minVal || dVal > _maxVal)
                        {
                            _isNull = true;
                        }
                        else
                        {
                            _isNumeric = true;                            
                            _valShort = Convert.ToInt16(dVal);
                            _val = _valShort.ToString();
                        }
                    }
                    else
                    {
                        _isNull = true;
                    }
                }

                if(_isNull)
                {
                    _isNa = false;
                    _isNumeric = false;
                    _val = NullValue;
                    _valShort = NullNumericValue;
                }
                else if (_isNa)
                {
                    _isNull = false;
                    _isNumeric = false;
                    _val = NA_Value;
                    _valShort = NANumericValue;
                }
                else if (_isNumeric)
                {
                    _isNa = false;
                    _isNull = false;
                    // _val already set.
                    // _valShort already set.
                }
            }
        }
        public short ValueShort
        {
            get
            {
                return _valShort;
            }
        }

        public void ToValue(short value)
        {
            if (value < _minVal || value > _maxVal)
            {
                this.ToNull();
            }
            else
            {
                _val = value.ToString();
                _valShort = value;
                _isNa = false;
                _isNull = false;
                _isNumeric = true;
            }
        }
        public void ToNA()
        {
            _val = NA_Value;
            _valShort = NANumericValue;
            _isNa = true;
            _isNull = false;
            _isNumeric = false;
        }
        public void ToNull()
        {
            _val = NullValue;
            _valShort = NullNumericValue;
            _isNa = false;
            _isNull = true;
            _isNumeric = false;
        }

        public override string ToString()
        {
            return _val;
        }
    }

    public class RatingCog : Rating
    {
        public RatingCog()
        {
            _minVal = 0;
            _maxVal = 100;
            this.ToNull();
        }
    }

    public class RatingObs : Rating
    {
        public RatingObs()
        {
            _minVal = 0;
            _maxVal = 5;
            this.ToNull();
        }
    }

}
