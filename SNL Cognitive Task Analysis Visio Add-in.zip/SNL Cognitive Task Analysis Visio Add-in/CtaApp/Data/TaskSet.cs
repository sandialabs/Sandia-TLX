﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace SNL_Cognitive_Task_Analysis_Visio_Add_in.Data
{

    // Note: the "Vx" suffix is supposed to stand for Visio
    // and Excel. When the add-in is running, these two data
    // reservoirs have to be used in concert, on top of the
    // pure data of CognitiveTask and ObservableTask objects. 

    // A List/Collection would be nice...should it be a List or
    // a Dictionary...we could maintain a list of duplicate shape ids
    // and Excel ids or something...

    /// <summary>
    /// The data that we're dealing with concerns two similar collections of
    /// CognitiveTasks and Observable tasks, which both derive from Task objects.
    /// A TaskSet contains two TaskList collections, each containing items of
    /// each task type.
    /// </summary>
    public class TaskSet // Collections of CognitiveTask and ObservableTask objects
    {
        private TaskList _cogTasks = null;
        private TaskList _obsTasks = null;

        public TaskList CognitiveTasks { get { return _cogTasks; } }
        public TaskList ObservableTasks { get { return _obsTasks; } }

        public int CognitiveCount { get { return _cogTasks.Count; } }
        public int ObservableCount { get { return _obsTasks.Count; } }
        public int TotalCount { get { return this.CognitiveCount + this.ObservableCount; } }
        public TaskSet()
        {
            _cogTasks = new TaskList();
            _obsTasks = new TaskList();
        }
        public List<string> Categories_Cog_Unique_Sorted()
            {return Categories_Cog_Unique_Sorted(String.Empty); }
        public List<string> Categories_Cog_Unique_Sorted(string extraCategoryToInclude)
            { return _cogTasks.Categories_Unique_Sorted(extraCategoryToInclude); }
        public List<string> Categories_Obs_Unique_Sorted()
        { return Categories_Obs_Unique_Sorted(String.Empty); }
        public List<string> Categories_Obs_Unique_Sorted (string extraCategoryToInclude)
            { return _obsTasks.Categories_Unique_Sorted(extraCategoryToInclude); }

        public List<string> Descriptions_Cog_Unique_Sorted(bool includeInVisioItems)
            { return _cogTasks.Descriptions_Unique_Sorted(includeInVisioItems); }
        public List<string> Descriptions_Obs_Unique_Sorted(bool includeInVisioItems)
            { return _obsTasks.Descriptions_Unique_Sorted(includeInVisioItems); }

        public CognitiveTask FirstCognitiveTask_ByDescOrNull(string description)
            { return _cogTasks.FirstByDescriptionOrNull(description) as CognitiveTask; }
        public ObservableTask FirstObservableTask_ByDescOrNull(string description)
            { return _obsTasks.FirstByDescriptionOrNull(description) as ObservableTask; }


        // TODO: Add should overwrite?
        public void Add(Task item, bool fromExcel, bool fromVisio)
        {
            Type t = item.GetType();
            if (t == typeof(CognitiveTask))
            {
                var cog = item as CognitiveTask;
                this.Add(cog, fromExcel, fromVisio);
            }
            if (t == typeof(ObservableTask))
            {
                var obs = item as ObservableTask;
                this.Add(obs, fromExcel, fromVisio);
            }
        }
        public void Add(CognitiveTask task, bool fromExcel, bool fromVisio)
        {
            // We don't care about blank-description'd tasks, either in Excel
            // or in Visio.           
            string desc = task.Description;
            if (String.IsNullOrEmpty(desc)) return;

            // Another type of "blank" is "---" in the Visio shapes:
            string blank = View.Shape_Task.BlankDescription;
            if (String.Compare(desc, blank, true) == 0) return;

            // Find matches by description:
            // TODO: could matches be null?
            var matches = _cogTasks.Items_WithDescripton(desc); 

            if (fromExcel)
            {
                task.IsInExcel = true;
                                         
                if (matches.Count() > 0) 
                {
                    // Set the in-Excel flag:
                    foreach (var m in matches) m.IsInExcel = true;
                }
                else
                {
                    // Just add the item:
                    _cogTasks.Add(task);
                }
            }

            if (fromVisio)
            {                
                if (matches.Count() > 0)
                {
                    // TODO: Overwrite the Excel data with the Visio data...?
                    // We won't overwrite Task Number, Description or...?
                    foreach (var m in matches)
                    {
                        m.IsInExcel = true;
                        var cog = m as CognitiveTask;
                        cog.IsInVisio = true;
                        cog.OverwriteData(task);
                    }
                }
                else
                {
                    // Simply add the task to the collection:
                    task.IsInVisio = true;
                    _cogTasks.Add(task);
                }
            }
        }
        public void Add(ObservableTask task, bool fromExcel, bool fromVisio)
        {
            // We don't care about blank-description'd tasks, either in Excel
            // or in Visio.           
            string desc = task.Description;
            if (String.IsNullOrEmpty(desc)) return;

            // Another type of "blank" is "---" in the Visio shapes:
            string blank = View.Shape_Task.BlankDescription;
            if (String.Compare(desc, blank, true) == 0) return;

            // Find matches by description:
            // TODO: could matches be null?
            var matches = _obsTasks.Items_WithDescripton(desc);

            if (fromExcel)
            {
                task.IsInExcel = true;

                if (matches.Count() > 0)
                {
                    // Set the in-Excel flag:
                    foreach (var m in matches) m.IsInExcel = true;
                }
                else
                {
                    // Just add the item:
                    _obsTasks.Add(task);
                }
            }

            if (fromVisio)
            {                
                if (matches.Count() > 0)
                {
                    // TODO: Overwrite the Excel data with the Visio data...?
                    // We won't overwrite Task Number, Description or...?
                    foreach (var m in matches)
                    {
                        m.IsInExcel = true;
                        var obs = m as ObservableTask;
                        obs.IsInVisio = true;
                        obs.OverwriteData(task);
                    }
                }
                else
                {
                    // Simply add the task to the collection:
                    task.IsInVisio = true;
                    _obsTasks.Add(task);
                }
            }
        }

        public void DebugDump()
        {
            Debug.WriteLine("----- Cognitive Tasks --------------------");
            foreach (var c in _cogTasks)
                Debug.WriteLine(c.ToString());
            Debug.WriteLine("----- Observable Tasks -------------------");
            foreach (var o in _obsTasks)
                Debug.WriteLine(o.ToString());
        }


        // Get the new data:
        // TODO: create "Add" methods in TasksVx AddExcelTask...

        //public void AddTask_FromExcel(object task)
        //{
        //    // If a task already exists, just set the IsInExcel bit, otherwise add it...
        //    Type typ = task.GetType();
        //    if (typ == typeof(CogTaskVx))
        //    {
        //        CogTaskVx t = task as CogTaskVx;
        //        string desc = t.Description;
        //        if (String.IsNullOrEmpty(desc)) return;

        //        var matches = _cogTasks.TakeWhile(c => (String.Compare(desc, c.Description, true) == 0));
        //        if (matches.Count() > 0)
        //        {
        //            foreach (var m in matches) m.IsInExcel = true;
        //        }
        //        else
        //        {
        //            _cogTasks.Add(t);
        //        }
        //    }
        //    else if (typ == typeof(ObsTaskVx))
        //    {
        //        ObsTaskVx t = task as ObsTaskVx;
        //        string desc = t.Description;
        //        if (String.IsNullOrEmpty(desc)) return;

        //        var matches = _obsTasks.TakeWhile(o => (String.Compare(desc, o.Description, true) == 0));
        //        if (matches.Count() > 0)
        //        {
        //            foreach (var m in matches) m.IsInExcel = true;
        //        }
        //        else
        //        {
        //            _obsTasks.Add(t);
        //        }
        //    }
        //}

        //public void AddTask_FromVisio(object task)
        //{
        //    // If a task already exists, set the IsInVisio bit, and
        //    // overwrite the data with the Visio data

        //    // TODO Finish AddTask_FromVisio code below here:

        //    Type typ = task.GetType();
        //    if (typ == typeof(CogTaskVx))
        //    {
        //        CogTaskVx t = task as CogTaskVx;
        //        string desc = t.Description;
        //        if (String.IsNullOrEmpty(desc)) return;

        //        var matches = _cogTasks.TakeWhile(c => (String.Compare(desc, c.Description, true) == 0));
        //        if (matches.Count() > 0)
        //        {
        //            // TODO: Overwrite the Excel data with the Visio data...?
        //            // We won't overwrite Task Number, Description or...?
        //            foreach (var m in matches) m.IsInExcel = true;
        //        }
        //        else
        //        {
        //            // Simply add the task to the collection:
        //            _cogTasks.Add(t);
        //        }
        //    }
        //    else if (typ == typeof(ObsTaskVx))
        //    {
        //        ObsTaskVx t = task as ObsTaskVx;
        //        string desc = t.Description;
        //        if (String.IsNullOrEmpty(desc)) return;

        //        var matches = _obsTasks.TakeWhile(o => (String.Compare(desc, o.Description, true) == 0));
        //        if (matches.Count() > 0)
        //        {
        //            // TODO: Overwrite the Excel data with the Visio data...?
        //            foreach (var m in matches) m.IsInExcel = true;
        //        }
        //        else
        //        {
        //            // Simply add the task to the collection:
        //            _obsTasks.Add(t);
        //        }
        //    }
        //}

    }
}
