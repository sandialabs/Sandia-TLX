﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Visguy.VisAddinLib
{
    /// <summary>
    /// A class for holding the important data for a shape that
    /// calls a marker event. A marker string will hold some identifying
    /// "prefix" text, along with doc, page and shape ids. This class
    /// is only a data bag and string parser, and performs no automation 
    /// tasks.
    /// </summary>
    public class MarkerCommand
    {
        // The format of a shape marker event is:
        //
        // some.solution.specific.prefix.and.command|FileName|PageNem|ShapeID
        // 
        // If there is only one item after the |, then assume it is the
        // shape id for the active page in the active document.
        //
        // Which breaks down into these parts:
        //
        //  visguy.com.products.visio.cabling.cableshape.command
        //     Doc = 0
        //     Page = 0
        //     Shape = 2

        private static char Separator_DocPageShape = '|';

        public string Prefix { get; private set; }
        public string CommandName { get; private set; }
        public string FullCommandName { get; private set; }
        public string DocName { get; private set; }
        //public bool HasDocId { get { return DocID >= 0; } }
        public string PageName { get; private set; }
        //public bool HasPageId { get { return PageID >= 0; } }
        public short ShapeID { get; private set; }
        //public bool HasShapeId { get { return ShapeID >= 0; } }

        public static MarkerCommand CommandFromString(
            string markerEventString, string markerEventPrefix)
        {
            if (!markerEventString.StartsWith(markerEventPrefix, StringComparison.InvariantCultureIgnoreCase)) return null;

            MarkerCommand cs = new MarkerCommand();

            cs.Prefix = markerEventPrefix;

            // TODO: allow the prefix to be passed in, then
            // isolate the command name/name-parts, and save
            // the prefix. If command doesn't start with 
            // the prefix, return null...

            // Use the private parsing method to see if the marker string
            // is valid, then return a valid MarkerCommaned object
            cs._parseMarkerString(markerEventString);
            //if (!cs._parseMarkerString(markerEventString))
            //    return null;

            return cs;
        }

        private MarkerCommand() { }

        public bool FullCommandNameEquals_CaseInsensitive(string otherFullCommandName)
        {
            return (this.FullCommandName.Equals(
                        otherFullCommandName,
                        StringComparison.InvariantCultureIgnoreCase));
        }

        private void _parseMarkerString(string markerString)
        {
            //bool retval = false; //...assume failure is imminent :(

            // OK, this whole block parses a Cable Shape marker
            // event and gets the actual shape that called it, along
            // with the command, and leg identifier.
            //
            // Remember that the smart tags on a shape can be activated
            // without the shape being selected, so it is necessary for
            // the marker event to pass doc-page-shape identifiers, so 
            // that the code can go the long route and get at the calling
            // shape.

            //Debug.WriteLine("Parsing Marker Event: Visio Cabling Shape Add-in:\n\t" + markerString);

            // Break the marker string into all of its parts. Return
            // false if any of the lengths are wrong.

            // Up to 4 major parts:
            string[] parts = markerString.Split(Separator_DocPageShape);

            // Full command name includes the prefix:
            this.FullCommandName = parts[0]; //...always

            // Command name doesn't include the prefix:
            CommandName = FullCommandName.Substring(this.Prefix.Length);

            // If the prefix didn't include the a trailing dot, then the
            // name might have it as a leading dot:
            if(this.CommandName.StartsWith("."))
            {
                if(!this.Prefix.EndsWith("."))
                {
                    // Add a dot to the prefix, and remove it 
                    // from the command name:
                    this.Prefix += ".";
                    this.CommandName = this.CommandName.Substring(1);
                }
            }

            int iLen = parts.Length;

            if (iLen > 1) DocName = parts[1]; // _shortFromString(parts[1], -1);
            if (iLen > 2) PageName = parts[2]; //_shortFromString(parts[2], -1);
            if (iLen > 3) ShapeID = _shortFromString(parts[3], -1);

            //return true;
        }

        private short _shortFromString(string intString, short fallbackValue)
        {
            short iVal;
            if (short.TryParse(intString, out iVal))
            {
                return iVal;
            }
            else
            {
                return fallbackValue;
            }
        }

        public string ToStringDump(string indent1, string indent2)
        {
            string s1 = indent1;
            string s2 = indent1 + indent2;

            var sb = new StringBuilder();
            //sb.AppendLine(s1 + "Prefix: " + this.Prefix);
            sb.AppendLine(s2 + "Full Command: " + this.FullCommandName);
            sb.AppendLine(s2 + "Prefix: " + this.Prefix);
            sb.AppendLine(s2 + "Command: " + this.CommandName);
            sb.AppendLine(s2 + "Coords: (" + this.DocName + "," + this.PageName + "," + this.ShapeID + ")");

            return sb.ToString();
        }

    }
}
