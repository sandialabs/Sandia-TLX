﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Visguy.VisAddinLib.UI
{
    /// <summary>
    /// A convenient class for presenting frequently-used message
    /// boxes, with a default solution-specific caption and other
    /// common/global treatments.
    /// </summary>
    public class Msg
    {
        // TODO: change the caption to match the solution:
        public static string DefaultCaption = "Visio";

        public static void Show(string msg)
        {
            MessageBox.Show(msg, DefaultCaption);
        }

        public static bool ShowYesNo(string msg)
        {
            return (MessageBox.Show(msg, DefaultCaption, MessageBoxButtons.YesNo) == DialogResult.Yes);
        }

        public static void Show(IWin32Window owner, string msg)
        {
            MessageBox.Show(owner, msg, DefaultCaption);
        }

        public static bool ShowYesNo(IWin32Window owner, string msg)
        {
            return (MessageBox.Show(owner, msg, DefaultCaption, MessageBoxButtons.YesNo) == DialogResult.Yes);
        }

        public static void ShowError(string errorMessage, string moduleName, string procName)
        {
            string msg = "An unexpected error occurred in " +
                moduleName + "." + procName + ":\n" +
                errorMessage;

            MessageBox.Show(msg, DefaultCaption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        public static void ShowError(IWin32Window owner, string errorMessage, string moduleName, string procName)
        {
            string msg = "An unexpected error occurred in " +
                moduleName + "." + procName + ":\n" +
                errorMessage;

            MessageBox.Show(owner, msg, DefaultCaption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
    }
}


