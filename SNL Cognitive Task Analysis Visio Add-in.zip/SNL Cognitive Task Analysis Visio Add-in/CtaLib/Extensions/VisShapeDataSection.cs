﻿using System;
using System.Collections.Generic;
using System.Linq;
using Vis = Microsoft.Office.Interop.Visio;

namespace Visguy.VisAddinLib.Extensions
{
    // TODO: organization. Where does this belong? Extensions?

    public class VisShapeDataSection
    {
        private const short Sec_Prop = (short)Vis.VisSectionIndices.visSectionProp;

        private Vis.Shape _visShp;

        public int Count
        {
            get
            {
                int i = 0;
                foreach (ShapeDataRow sdr in _shapeDataRows()) i++;
                return i;
            }
        }
        public VisShapeDataSection(Vis.Shape visShp)
        {
            _visShp = visShp;
        }

        public ShapeDataRow GetSdRowByLabel(string shapeDataLabel)
        {
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr;
                }
            }
            return null;
        }

        public Vis.Cell TryGet_ValueCell_ByLabel(string shapeDataLabel)
        {
            // TODO: there could be multiple rows with the same label:
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr.ValueCell;
                }
            }
            return null;
        }

        public double TryGet_ValueDouble_ByLabel(string shapeDataLabel)
        {
            // TODO: there could be multiple rows with the same label:
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr.ValueCell.ResultIU;
                }
            }
            return double.NaN;
        }

        public List<ShapeDataRow> GetAll()
        {
            List<ShapeDataRow> sdrs = new List<ShapeDataRow>();
            foreach (var sdr in _shapeDataRows())
            {
                sdrs.Add(sdr);
            }
            return sdrs;
        }

        /// <summary>
        /// Attempts to get a string value of a Shape Data row that
        /// has a label that matches shapeDataLabel. Returns String.
        /// Empty if the row is not found.
        /// </summary>
        /// <param name="shapeDataLabel">The label for the target
        /// Shape Data row.</param>
        /// <returns>The string value of the matching Shape Data field,
        /// or String.Empty if the row is not found.</returns>
        public string TryGet_Value_ByLabel(string shapeDataLabel)
        {
            // TODO: there could be multiple rows with the same label:
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr.ResultStr;
                }
            }
            return String.Empty;
        }

        public bool TrySet_Value_ByLabel(string shapeDataLabel, string value)
        {
            // TODO: there could be multiple rows with the same label:
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr.TrySetValueResultStr(value);
                }
            }
            return false;
        }
        public bool TrySet_ValueDouble_ByLabel(string shapeDataLabel, double value)
        {
            // TODO: there could be multiple rows with the same label:
            foreach (ShapeDataRow sdr in _shapeDataRows())
            {
                if (sdr.Label == shapeDataLabel)
                {
                    return sdr.TrySetValueDouble(value);
                }
            }
            return false;
        }


        private IEnumerable<ShapeDataRow> _shapeDataRows()
        {
            if (_visShp.SectionExists(Sec_Prop) == false) yield break;

            Vis.Section sec = _visShp.Section[Sec_Prop];
            short iRowCt = sec.Count;
            for (short iRow = 0; iRow < iRowCt; iRow++)
            {
                ShapeDataRow sdr = new ShapeDataRow(sec[iRow]);
                yield return sdr;
            }
        }
    }

    public class ShapeDataRow : Vis.Row
    {
        private const short Sec_Prop = (short)Vis.VisSectionIndices.visSectionProp;

        private const short Cell_Label = (short)Vis.VisCellIndices.visCustPropsLabel;
        private const short Cell_Prompt = (short)Vis.VisCellIndices.visCustPropsPrompt;
        private const short Cell_Type = (short)Vis.VisCellIndices.visCustPropsType;
        private const short Cell_Format = (short)Vis.VisCellIndices.visCustPropsFormat;
        private const short Cell_Value = (short)Vis.VisCellIndices.visCustPropsValue;

        private const short Exists_Anywhere = (short)Vis.VisExistsFlags.visExistsAnywhere;

        private Vis.Row _visRow = null;

        public bool IsBool { get { return _type() == 3; } }
        public bool IsFixedList { get { return _type() == 1; } }
        public bool IsVariableList { get { return _type() == 4; } }

        public string Format { get { return _getCellResultStrNoCastU(Cell_Format); } }
        public string Prompt { get { return _getCellResultStrNoCastU(Cell_Prompt); } }

        public string Label
        {
            get { return _getCellResultStrNoCastU(Cell_Label); }
        }
        public string ResultStr
        {
            get { return _getCellResultStrNoCastU(Cell_Value); }
        }

        public Vis.Cell ValueCell { get { return this[Cell_Value]; } }


        public ShapeDataRow(Vis.Row visRow)
        {
            _visRow = visRow;
        }

        public List<String> GetItems(bool sortAlphabetically)
        {
            List<string> items = new List<string>();
            if (this.IsBool)
            {
                items.Add("FALSE");
                items.Add("TRUE");
            }
            else if (this.IsFixedList || this.IsVariableList)
            {
                items = _getCellResultStrNoCastU(Cell_Format).Split(';').ToList<string>();
            }

            if (sortAlphabetically) items.Sort();

            return items;
        }


        public bool TrySetValueResultStr(string value)
        {
            Vis.Cell c = _visRow[Cell_Value];
            try
            {
                c.FormulaForceU = "\"" + value + "\"";
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool TrySetValueDouble(double value)
        {
            Vis.Cell c = _visRow[Cell_Value];
            try
            {
                c.ResultIUForce = value;
                return true;
            }
            catch
            {
                return false;
            }
        }
        private string _getCellResultStrNoCastU(short iCellIndex)
        {
            Vis.Cell c = _visRow[iCellIndex];
            return c.ResultStrNoCastU();
        }

        private int _type()
        {
            Vis.Cell c = _visRow[Cell_Type];
            return (int)c.ResultIU;
        }

        #region Visio.Row Interface

        public Vis.Application Application { get { return _visRow.Application; } }
        public int ContainingMasterID { get { return _visRow.ContainingMasterID; } }
        public int ContainingPageID { get { return _visRow.ContainingPageID; } }
        public Vis.Section ContainingSection { get { return _visRow.ContainingSection; } }
        public short Count { get { return _visRow.Count; } }
        public Vis.EventList EventList { get { return _visRow.EventList; } }
        public void GetPolylineData(short Flags, out Array xyArray) { _visRow.GetPolylineData(Flags, out xyArray); }
        public short Index { get { return _visRow.Index; } }
        public string Name
        {
            get
            {
                return _visRow.Name;
            }
            set
            {
                _visRow.Name = value;
            }
        }
        public string NameU
        {
            get
            {
                return _visRow.NameU;
            }
            set
            {
                _visRow.NameU = value;
            }
        }
        public short ObjectType { get { return _visRow.ObjectType; } }
        public short PersistsEvents { get { return _visRow.PersistsEvents; } }
        public Vis.Shape Shape { get { return _visRow.Shape; } }
        public short Stat { get { return _visRow.Stat; } }
        public Vis.Style Style { get { return _visRow.Style; } }
        public Vis.Cell get_CellU(object NameOrIndex) { return _visRow.get_CellU(NameOrIndex); }
        public Vis.Cell this[object NameOrIndex] { get { return _visRow[NameOrIndex]; } }

        // Someday, maybe link to live Shape-data changes.
        // These are never used, but are here because we implemented the Vis.Row interface.          
        public event Vis.ERow_CellChangedEventHandler rCellChanged;
        public event Vis.ERow_FormulaChangedEventHandler FormulaChanged;
        public event Vis.ERow_CellChangedEventHandler CellChanged;

        #endregion

    }
    


}
