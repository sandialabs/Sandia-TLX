﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace Visguy.VisAddinLib.Extensions
{
    public static class VisDocExtensions
    {
        public static IEnumerable<Vis.Page> Pages(this Vis.Document visDoc)
        {
            foreach (Vis.Page pg in visDoc.Pages) yield return pg;
        }

        public static bool IsClass(this Vis.Document visDoc, string className)
        {
            Vis.Shape shpDoc = visDoc.DocumentSheet;
            return shpDoc.IsClass(className);
        }

        public static Vis.Page FirstPageOfClass(this Vis.Document visDoc, 
            string className, bool includeForegroundPages, bool includeBackgroundPages)
        {
            var pgs = visDoc.Pages;
            for (int i = 1; i <= pgs.Count; i++)
            {
                Vis.Page pg = pgs[i];
                if(pg.IsForegroundPage())
                {
                    if(includeForegroundPages)
                    {
                        if (pg.IsClass(className)) return pg;
                    }
                }
                else
                {
                    if (includeBackgroundPages)
                    {
                        if (pg.IsClass(className)) return pg;
                    }
                }
            }
            return null;
        }

        public static bool IsShownInActiveWindow(this Vis.Document visDoc)
        {
            Vis.Page pg = null;
            return visDoc.IsShownInActiveWindow(out pg);            
        }

        public static bool IsShownInActiveWindow(this Vis.Document visDoc, out Vis.Page visActivePage)
        {
            visActivePage = null;

            if (visDoc == null) return false;
            if (visDoc.Stat == (short)Vis.VisStatCodes.visStatClosed) return false;
            Vis.Application visApp = visDoc.Application;
            Vis.Window win = visApp.ActiveWindow;

            // Note: the active window could be a ShapeSheet window, but I
            // think that this should reflect that the active window is a
            // drawing page that belongs to visDoc:
            if (!win.IsDrawableWindow()) return false;

            Vis.Page pg = win.PageAsObj as Vis.Page;
            if (pg == null) return false;

            if (pg.Document != visDoc) return false;

            visActivePage = pg;

            return true;
        }



        public static Vis.Page PageFromIDorNull(this Vis.Document visDoc, int idPage)
        {
            foreach (Vis.Page pg in visDoc.Pages)
            {
                if (pg.ID == idPage) return pg;
            }
            return null;
        }

        public static Vis.Page PageFromNameOrNull(this Vis.Document visDoc, string pageName)
        {
            foreach (Vis.Page pg in visDoc.Pages)
            {
                if (String.Compare(pg.Name, pageName, true) == 0) return pg;
            }
            return null;
        }
        public static Vis.Master MasterByName(this Vis.Document visDoc, string masterName)
        {
            foreach (Vis.Master mst in visDoc.Masters)
            {
                if (String.Compare(mst.Name, masterName, true) == 0) return mst;
            }
            return null;
        }
    }
}
