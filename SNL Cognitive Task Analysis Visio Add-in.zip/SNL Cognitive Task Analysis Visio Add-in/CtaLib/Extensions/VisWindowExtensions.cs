﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using Vwt = Microsoft.Office.Interop.Visio.VisWinTypes;
//using System.Diagnostics;
namespace Visguy.VisAddinLib.Extensions
{
    public static class VisWindowExtensions
    {
        /// <summary>
        /// Tests whether the Visio window is a drawing page window and not a group 
        /// window or other type of non-drawing page window.
        /// </summary>
        /// <param name="visWin"></param>
        /// <returns></returns>
        public static bool IsDrawingPageWindow(this Vis.Window visWin)
        {
            if (visWin == null) return false;
            if (visWin.Type != (short)Vwt.visDrawing) return false;
            if (visWin.SubType != (short)Vwt.visPageWin) return false;
            return true;
            // 128 = visPageWin
        }

        public static bool IsDrawableWindow(this Vis.Window visWin)
        {
            if (visWin == null) return false;

            short wt = visWin.Type;

            if (wt == (short)Vwt.visDrawing ||
                wt == (short)Vwt.visDrawingAddon ||
                wt == (short)Vwt.visMasterWin ||
                wt == (short)Vwt.visPageGroupWin ||
                wt == (short)Vwt.visPageGroupWin ||
                wt == (short)Vwt.visPageWin)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
