﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace Visguy.VisAddinLib.Extensions
{
    public static class VisCellExtensions
    {
        public const string ParentToken = "{PARENT}";
        public const string TargetToken1 = "{TARGET1}";
        public const string TargetToken2 = "{TARGET2}";
        public const string TargetToken3 = "{TARGET3}";

        public static string ResultStrNoCastU(this Vis.Cell visCell)
        {
            return visCell.get_ResultStrU((short)Vis.VisUnitCodes.visNoCast);
        }
        public static string ResultStrNoCast(this Vis.Cell visCell)
        {
            if (visCell == null) return String.Empty;
            if (visCell.Stat == (short)Vis.VisStatCodes.visStatDeleted) return String.Empty;
            if (visCell.Stat == (short)Vis.VisStatCodes.visStatClosed) return String.Empty;

            // Special case when we have No Formula, the cell is 
            // completely blank, ResultStr will return "0.0000", 
            // which is not what we want.
            string formula = visCell.FormulaU;
            if (formula.Length == 0) return String.Empty;
                
            string val = visCell.get_ResultStr((short)Vis.VisUnitCodes.visNoCast);
            return val;
        }

        // TODO: use yield return for these Dependent methods?
        public static List<Vis.Cell> DependentCells(this Vis.Cell visCell)
        {
            Array deps = visCell.Dependents;
            List<Vis.Cell> cells = new List<Vis.Cell>();
            foreach (Vis.Cell c in deps)
            {
                if (!cells.Contains(c)) cells.Add(c);
            }
            return cells;
        }
        public static Vis.Cell[] DependentCellsFromOtherShapes(this Vis.Cell visCell)
        {
            Vis.Shape shpThis = visCell.Shape;

            Array deps = visCell.Dependents;
            List<Vis.Cell> cells = new List<Vis.Cell>();
            foreach (Vis.Cell c in deps)
            {
                Vis.Shape shp = c.Shape;
                if (shp != shpThis)
                {
                    if (!cells.Contains(c)) cells.Add(c);
                }
            }
            return cells.ToArray();
        }

        // TODO: choose between this and DependentShapes
        public static IEnumerable<Vis.Shape> GetOtherDependentShapes(this Vis.Cell visCell)
        {
            Vis.Shape shp = visCell.Shape;

            Array deps = visCell.Dependents;
            foreach (Vis.Cell c in deps)
            {
                if (c.Shape != shp)
                {
                    yield return c.Shape;
                }
            }
        }
        public static Vis.Shape[] DependentShapes(this Vis.Cell visCell)
        {
            List<Vis.Shape> shps = new List<Vis.Shape>();
            List<Vis.Cell> cells = visCell.DependentCells();
            foreach (Vis.Cell c in cells)
            {
                Vis.Shape shp = c.Shape;
                if (!shps.Contains(shp)) shps.Add(shp);
            }
            return shps.ToArray();
        }
        public static Vis.Shape[] DependentShapesNotThisShape(this Vis.Cell visCell)
        {
            List<Vis.Shape> shps = new List<Vis.Shape>();
            Vis.Cell[] cells = visCell.DependentCellsFromOtherShapes();
            foreach (Vis.Cell c in cells)
            {
                Vis.Shape shp = c.Shape;
                if (!shps.Contains(shp)) shps.Add(shp);
            }
            return shps.ToArray();
        }
        public static bool TryFormulaForceU(this Vis.Cell visCell, string formula)
        {
            if (visCell == null) return false;
            try
            {
                visCell.FormulaForceU = formula;                
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
