﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace  Visguy.VisAddinLib.Extensions
{
    public static class VisAppExtensions
    {
        public static bool ActiveWindowIsPage(this Vis.Application visApp, Vis.Page visPg)
        {
            Vis.Window win = visApp.ActiveWindow;
            if (win.Page == null) return false;
            return win.Page == visPg;
        }
        public static bool ActiveWindowIsDrawingPage(this Vis.Application visApp)
        {
            Vis.Window win = visApp.ActiveWindow;
            return win.IsDrawableWindow();
        }

        public static Vis.Page ActivePageOrNull(this Vis.Application visApp)
        {
            if (visApp == null) return null;
            if (visApp.Stat != (short)Vis.VisStatCodes.visStatNormal) return null;

            // Get the active page, ensuring that it is the active window:
            if ( ! visApp.ActiveWindowIsDrawingPage()) return null;
            Vis.Page visPg = visApp.ActivePage;
            if (visPg == null) return null;
            return visPg;
        }

        public static string ActivePageName(this Vis.Application visApp)
        {
            Vis.Page pg = visApp.ActivePage;
            if (pg == null) return String.Empty;
            return pg.Name;
        }

        public static Vis.Document DocFromIDorNull(this Vis.Application visApp, int idDoc)
        {
            foreach (Vis.Document doc in visApp.Documents)
            {
                if (doc.ID == idDoc) return doc;
            }
            return null;
        }

        public static Vis.Document DocFromNameOrNull(this Vis.Application visApp, string docName)
        {
            foreach (Vis.Document doc in visApp.Documents)
            {
                if (doc.Name == docName) return doc;
            }
            return null;
        }

        public static IEnumerable<Vis.Document> Documents(this Vis.Application visApp)
        {
            foreach (Vis.Document doc in visApp.Documents) yield return doc;
        }

        public static Vis.Shape FirstSelectedShape(this Vis.Application visApp)
        {
            Vis.Selection sel = visApp.GetSelectionOrNull();
            if (sel == null) return null;
            if (sel.Count == 0) return null;
            return sel[1];
        }
        public static Vis.Shape SingleSelectedShapeOrNull(this Vis.Application visApp)
        {
            Vis.Selection sel = visApp.GetSelectionOrNull();
            if (sel == null) return null;
            if (sel.Count != 1) return null;
            return sel[1];
        }

        public static void GetDocPageShape(this Vis.Application visApp,
            string docname, string pagename, int idShape, 
            out Vis.Document visDoc, out Vis.Page visPage, out Vis.Shape visShp)
        {
            visDoc = null;
            visPage = null;
            visShp = null;

            if (String.IsNullOrEmpty(docname))
            {
                visDoc = visApp.ActiveDocument;
            }
            else
            {
                visDoc = visApp.DocFromNameOrNull(docname);
            }

            if (String.IsNullOrEmpty(pagename))
            {
                visPage = visApp.ActivePage;
            }
            else
            {
                if(visDoc != null)
                {
                    visPage = visDoc.PageFromNameOrNull(pagename);
                }
                else
                {
                    visPage = visApp.ActivePage; //...might still be null...
                }
            }

            if (visPage == null) return;

            visShp = visPage.ShapeFromIDorNull(idShape);
        }
        public static void GetDocPageShape(this Vis.Application visApp,
            MarkerCommand mc,
            out Vis.Document visDoc, out Vis.Page visPage, out Vis.Shape visShp)
        {
            visApp.GetDocPageShape(mc.DocName, mc.PageName, mc.ShapeID,
                out visDoc, out visPage, out visShp);
        }

        public static Vis.Selection GetSelection_AllShapesOnActivePage(this Vis.Application visApp)
        {
            if (visApp == null) return null;

            Vis.Window visWin = visApp.ActiveWindow;

            if (visWin.IsDrawableWindow() == false) return null;

            Vis.Page pg = visWin.Page as Vis.Page;
            if (pg == null) return null;

            Vis.Selection sel = pg.CreateAllSelection();
            return sel;
        }
        //public static Vis.Selection GetSelection_ActivePage(
        //    this Vis.Application visApp,
        //    ShapeTest filter)
        //{
        //    Vis.Selection sel = visApp.GetSelection();
        //    sel.Filter(filter);
        //    return sel;
        //}

        public static Vis.Selection GetSelectionOrNull(this Vis.Application visApp)
        {
            if (visApp == null) return null;

            Vis.Window visWin = visApp.ActiveWindow;

            if (visWin.IsDrawableWindow() == false) return null;

            return visWin.Selection;
        }
        //public static Vis.Selection GetSelectionOfShapes(
        //    this Vis.Application visApp,
        //    ShapeTest shapeFilter)
        //{
        //    if (visApp == null) return null;

        //    Vis.Window visWin = visApp.ActiveWindow;

        //    if (visWin.IsDrawableWindow() == false) return null;

        //    Vis.Selection sel = visWin.Selection;
        //    sel.Filter(shapeFilter);

        //    return sel;
        //}
        /// <summary>
        /// Gets a subset of selected shapes that qualify according to the
        /// test specified in shapeFilter. If no shapes are selected, then
        /// all shapes on the page are examined.
        /// </summary>
        /// <param name="visApp"></param>
        /// <param name="shapeFilter"></param>
        /// <returns></returns>
        //public static Vis.Selection GetSelectedOrAllShapes(
        //    this Vis.Application visApp,
        //    ShapeTest shapeFilter)
        //{
        //    if (visApp == null) return null;

        //    Vis.Window visWin = visApp.ActiveWindow;

        //    if (visWin.IsDrawableWindow() == false) return null;

        //    Vis.Selection sel = visWin.Selection;
        //    if (sel == null) return null;

        //    if (sel.Count == 0)
        //    {
        //        // No shapes are selected, examine all shapes on the page:
        //        Vis.Page pg = sel.ContainingPage;
        //        sel = pg.CreateAllSelection();
        //    }

        //    // Now, filter the shape:
        //    sel.Filter(shapeFilter);

        //    return sel;
        //}


        public static Vis.Page PageFromIDsOrNull(this Vis.Application visApp, int idDoc, int idPage)
        {
            Vis.Document doc = visApp.DocFromIDorNull(idDoc);
            if (doc != null)
            {
                foreach (Vis.Page pg in doc.Pages)
                {
                    if (pg.ID == idPage) return pg;
                }
            }
            return null;
        }

        public static Vis.Page PageFromNames(this Vis.Application visApp, string docName, string pageName)
        {

            // TODO: use String.Compare?
            List<Vis.Page> pgs = new List<Vis.Page>();

            foreach (Vis.Document doc in visApp.Documents().Where(d => d.Name == docName))
            {
                foreach (Vis.Page pg in doc.Pages().Where(p => p.Name == pageName))
                {
                    pgs.Add(pg);
                }
            }

            if (pgs.Count == 0) return null;

            if (pgs.Count == 1)
            {
                return pgs[0];
            }
            else
            {
                // It's possible that there are several same-named docs with
                // page names that qualify. We'll bias towards the active document:
                foreach (Vis.Page pg in pgs)
                {
                    if (pg.Document == visApp.ActiveDocument) return pg;
                }

                // Otherwise, just return the first item:
                return pgs[0];
            }

        }

        public static Vis.Selection SelectionOrSubselection(this Vis.Application visApp)
        {
            // TODO: make a copy of this for Window and Selection extensions?

            // TODO: this returns the regular selection if there
            // are any shapes. If not, it checks the sub-selection. 
            // It DOESN'T however mix selected and subselected shapes.
            // The ultimate selection would be selected shapes and subselected 
            // shapes, where groups that contain subselected shapes would
            // be exempt - ie: only the directly selected shapes would be
            // returned, not their parents.
            //
            // I think this is what does this, according to my VisGuy article:
            // sel.IterationMode = Visio.VisSelectMode.visSelModeSkipSuper

            Vis.Window win = visApp.ActiveWindow;
            if (win.IsDrawableWindow() == false) return null;

            Vis.Selection sel = win.Selection;
            if (sel == null) return null;

            // Go for the 'normally' selected shapes:
            sel.IterationMode = (short)Vis.VisSelectMode.visSelModeSkipSub +
                                (short)Vis.VisSelectMode.visSelModeSkipSuper;

            if (sel.Count > 0) return sel;

            // Try to find sub-selected shapes:
            sel.IterationMode = (short)Vis.VisSelectMode.visSelModeOnlySub +
                                (short)Vis.VisSelectMode.visSelModeSkipSuper;

            return sel;
        }

        //public static int SelectShapesInActiveWindow(
        //    this Vis.Application visApp, ShapeTest filter)
        //{
        //    Vis.Window win = visApp.ActiveWindow;
        //    if (!win.IsDrawableWindow()) return 0;

        //    Vis.Page pg = win.Page;
        //    Vis.Selection sel = pg.CreateAllSelection();

        //    if (sel == null) return 0;
        //    if (sel.Count == 0) return 0;

        //    sel.Filter(filter);
        //    if (sel == null) return 0;
        //    if (sel.Count == 0) return 0;

        //    // Select the shapes:
        //    win.DeselectAll();
        //    win.Selection = sel;

        //    return sel.Count;
        //}

        public static Vis.Shape TopLevelShapesFromIdPageNameDocName(
            this Vis.Application visApp, int idShape, string pageName, string docName)
        {
            List<Vis.Shape> shps = new List<Vis.Shape>();

            foreach (Vis.Document doc in visApp.Documents().Where(d => d.Name == docName))
            {
                foreach (Vis.Page pg in doc.Pages().Where(p => p.Name == pageName))
                {
                    foreach (Vis.Shape shp in pg.ShapesAtTopLevel().Where(s => s.ID == idShape))
                        shps.Add(shp);
                }
            }

            // It's possible that we have more than one shape. This could
            // occur if there are similarly named documents with similar page
            // names.

            if (shps.Count == 0) return null;

            // Take item 0 if there is only one item:
            if (shps.Count == 1) return shps[0];

            // Otherwise, default to the active document:
            foreach (Vis.Shape shp in shps)
            {
                if (shp.Document == visApp.ActiveDocument) return shp;
            }

            // Otherwise, just take the first one:
            return shps[0];
        }


        public static bool TrySetPageForActiveWindow(
            this Vis.Application visApp, Vis.Page visPg)
        {
            Vis.Window win = visApp.ActiveWindow;
            if (win == null) return false;
            if (visPg == null) return false;

            if (!win.IsDrawableWindow()) return false;

            // Can't set the window's page if the document
            // is a different document:
            if (visApp.ActiveDocument != visPg.Document) return false;

            // TODO: I don't trust this code:
            try
            {
                win.Page = visPg;
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(
                    "An error occurred in ApplicationExtensions.TrySetPageForActiveWindow:\n" +
                    ex.Message);
                return false;
            }

        }

        public static void ShowExternalDataWindow(this Vis.Application visApp, bool bShowWindow)
        {
            try
            {
                Vis.Window winActive = visApp.ActiveWindow;
                if (winActive.Type == (short)Vis.VisWinTypes.visDrawing)
                {
                    Vis.Windows wins = winActive.Windows;
                    Vis.Window winExtData = wins.ItemFromID[(int)Vis.VisWinTypes.visWinIDExternalData];
                    winExtData.Visible = bShowWindow;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error in ApplicatonExtensions.ShowExternalDataWindow:\n" + ex.Message);
            }
        }
        public static double VersionNumber(this Vis.Application visApp)
        {
            string sVer = visApp.Version;
            double dVer;
            if (double.TryParse(sVer, out dVer))
            {
                return dVer;
            }
            else
            {
                return 0.0;
            }
        }
    }
}
