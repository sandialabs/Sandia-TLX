﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace Visguy.VisAddinLib.Extensions
{
    public static class VisPageExtensions
    {
        #region PageSheet Stuff

        private const short Sec_Object = (short)Vis.VisSectionIndices.visSectionObject;

        private const short Row_Page = (short)Vis.VisRowIndices.visRowPage;

        private const short Col_PageWidth = (short)Vis.VisCellIndices.visPageWidth;
        private const short Col_PageHeight = (short)Vis.VisCellIndices.visPageHeight;
        private const short Col_PageScale = (short)Vis.VisCellIndices.visPageScale;
        private const short Col_DrawingScale = (short)Vis.VisCellIndices.visPageDrawingScale;
        private const short Col_DrawingScaleType = (short)Vis.VisCellIndices.visPageDrawScaleType;

        // ----- For a normal drawing page -----
        public static double AntiScale(this Vis.Page visPage)
        {
            Vis.Shape shp = visPage.PageSheet;
            double ps, ds;

            ps = shp.CellsSRC[Sec_Object, Row_Page, Col_PageScale].ResultIU;
            ds = shp.CellsSRC[Sec_Object, Row_Page, Col_DrawingScale].ResultIU;

            return ds / ps;
        }
        public static double PageHeightIU(this Vis.Page visPage)
        {
            Vis.Shape shp = visPage.PageSheet;
            return shp.CellsSRC[Sec_Object, Row_Page, Col_PageHeight].ResultIU;
        }
        public static double PageWidthIU(this Vis.Page visPage)
        {
            Vis.Shape shp = visPage.PageSheet;
            return shp.CellsSRC[Sec_Object, Row_Page, Col_PageWidth].ResultIU;
        }
        /// <summary>
        /// Returns the "paper-size", or "antiscaled", height of the page
        /// in inches.
        /// </summary>
        /// <param name="visPage"></param>
        /// <returns></returns>
        public static double PageHeightIU_AntiScaled(this Vis.Page visPage)
        {
            Vis.Shape shp = visPage.PageSheet;
            double dAs = visPage.AntiScale(); //...DrawingScale/PageScale
            return shp.CellsSRC[Sec_Object, Row_Page, Col_PageHeight].ResultIU / dAs;
        }
        /// <summary>
        /// Returns the "paper-size", or "antiscaled", width of the page
        /// in inches.
        /// </summary>
        /// <param name="visPage"></param>
        /// <returns></returns>
        public static double PageWidthIU_AntiScaled(this Vis.Page visPage)
        {
            Vis.Shape shp = visPage.PageSheet;
            double dAs = visPage.AntiScale(); //...DrawingScale/PageScale
            return shp.CellsSRC[Sec_Object, Row_Page, Col_PageWidth].ResultIU / dAs;
        }

        // ----- For a master or page's PageSheet -----
        public static double AntiScale(this Vis.Shape visShpPageSheet)
        {
            if (!visShpPageSheet.IsPageSheet())
                throw new System.ArgumentException(
"visShpPageSheet is not a Page or Master Page.");

            double ps, ds;

            ps = visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_PageScale].ResultIU;
            ds = visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_DrawingScale].ResultIU;

            return ds / ps;
        }
        public static double PageHeightIU(this Vis.Shape visShpPageSheet)
        {
            if (!visShpPageSheet.IsPageSheet())
                throw new System.ArgumentException(
"visShpPageSheet is not a Page or Master Page.");

            return visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_PageHeight].ResultIU;
        }
        public static double PageWidthIU(this Vis.Shape visShpPageSheet)
        {
            if (!visShpPageSheet.IsPageSheet())
                throw new System.ArgumentException(
"visShpPageSheet is not a Page or Master Page.");

            return visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_PageWidth].ResultIU;
        }
        /// <summary>
        /// Returns the "paper-size", or "antiscaled", height of the page
        /// in inches.
        /// </summary>
        /// <param name="visPage"></param>
        /// <returns></returns>
        public static double PageHeightIU_AntiScaled(this Vis.Shape visShpPageSheet)
        {
            if (!visShpPageSheet.IsPageSheet())
                throw new System.ArgumentException(
"visShpPageSheet is not a Page or Master Page.");

            double dAs = visShpPageSheet.AntiScale(); //...DrawingScale/PageScale
            return visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_PageHeight].ResultIU / dAs;
        }
        /// <summary>
        /// Returns the "paper-size", or "antiscaled", width of the page
        /// in inches.
        /// </summary>
        /// <param name="visPage"></param>
        /// <returns></returns>
        public static double PageWidthIU_AntiScaled(this Vis.Shape visShpPageSheet)
        {
            if (!visShpPageSheet.IsPageSheet())
                throw new System.ArgumentException(
"visShpPageSheet is not a Page or Master Page.");

            double dAs = visShpPageSheet.AntiScale(); //...DrawingScale/PageScale
            return visShpPageSheet.CellsSRC[Sec_Object, Row_Page, Col_PageWidth].ResultIU / dAs;
        }

        public static bool IsPageSheet(this Vis.Shape visShp)
        {
            return visShp.Type == (short)Vis.VisShapeTypes.visTypePage;
        }

        #endregion PageSheet Stuff

        #region Selection Stuff

        public static Vis.Selection CreateSelectionTopLevel(this Vis.Page visPage, Predicate<Vis.Shape> filter)
        {
            Vis.Selection sel = visPage.CreateEmptySelection();
            foreach (Vis.Shape shp in visPage.Shapes)
            {
                if (filter(shp)) sel.Select(shp);
            }
            return sel;
        }

        public static Vis.Selection CreateSelection(this Vis.Page visPage, List<int> shapeIds)
        {
            Vis.Selection sel = visPage.CreateEmptySelection();
            foreach (int id in shapeIds)
            {
                Vis.Shape shp = visPage.GetShapeByIdSafe(id);
                if (shp != null) sel.Select(shp);
            }
            return sel;
        }
        public static Vis.Selection CreateSelection(this Vis.Page visPage, Array shapeIds)
        {
            Vis.Selection sel = visPage.CreateEmptySelection();
            foreach (int id in shapeIds)
            {
                Vis.Shape shp = visPage.GetShapeByIdSafe(id);
                if (shp != null) sel.Select(shp);
            }
            return sel;
        }

        public static Vis.Selection CreateEmptySelection(this Vis.Page visPage)
        {
            return visPage.CreateSelection(Vis.VisSelectionTypes.visSelTypeEmpty,
                                           Vis.VisSelectMode.visSelModeSkipSuper,
                                           Type.Missing);
        }

        public static Vis.Selection CreateAllSelection(this Vis.Page visPg)
        {
            return visPg.CreateSelection(Vis.VisSelectionTypes.visSelTypeAll,
                                         Vis.VisSelectMode.visSelModeSkipSuper,
                                         Type.Missing);
        }

        public static Vis.Selection CreateSelectedSelection(this Vis.Page visPg)
        {
            if (visPg.IsActiveWindow() == false) return visPg.CreateEmptySelection();

            Vis.Application visApp = visPg.Application;
            Vis.Window visWin = visApp.ActiveWindow;
            return visWin.Selection;
        }

        public static void DeselectAll(this Vis.Page visPg)
        {
            Vis.Application visApp = visPg.Application;
            if (visApp.ActiveWindowIsPage(visPg))
            {
                Vis.Window win = visApp.ActiveWindow;
                win.DeselectAll();
            }
        }

        //public static Vis.Selection CreateFilteredSelection(
        //    this Vis.Page visPage, ShapeTest shapeTest)
        //{
        //    Vis.Selection sel = visPage.CreateEmptySelection();
        //    foreach (Vis.Shape shp in visPage.Shapes)
        //    {
        //        // If the test is null, then select everything:
        //        if (shapeTest == null)
        //        {
        //            sel.Select(shp);
        //        }
        //        else
        //        {
        //            if (shapeTest(shp)) sel.Select(shp);
        //        }
        //    }
        //    return sel;
        //}

        #endregion Selection Stuff

        public static Vis.Shape Drop_PageCenter(this Vis.Page visPage, Vis.Master visMst)
        {
            double dx, dy;
            dx = visPage.PageSheet.CellsU["PageWidth"].ResultIU * 0.5;
            dy = visPage.PageSheet.CellsU["PageHeight"].ResultIU * 0.5;

            return visPage.Drop(visMst, dx, dy);
        }


        public static Vis.Shape Drop_ViewCenter_Rectangle(
            this Vis.Page visPg,
            double width, double height)
        {
            // Get the bounds of the current window:
            //double wl, wt, wr, wcx, wcy, wb, ww, wh;
            //Vis.Window win = visPg.GetViewBounds(
            //    out wl, out wt, out wr, out wb, out wcx, out wcy, out ww, out wh);

            double wcx, wcy;
            Vis.Window win = visPg.GetViewCenter(out wcx, out wcy);
            if (win == null) return null;

            // Drop the master in the center of the window:
            Vis.Shape shp = visPg.DrawRectangle(
                wcx - width * 0.5, wcy - height * 0.5,
                wcx + width * 0.5, wcy + height * 0.5);

            _centerShapeAndZoom(shp, win);
            return shp;
        }
        public static Vis.Shape Drop_ViewCenter_Rectangle_AutoSizeFromText(
            this Vis.Page visPg,
            string text,
            double pointSize)
        {
            // Get the center of the current window if it is
            // showing the Visio.Page:
            double wcx, wcy;
            Vis.Window win = visPg.GetViewCenter(out wcx, out wcy);
            if (win == null) return null;

            // Drop the master in the center of the window:
            Vis.Shape shp = visPg.DrawRectangle(
                wcx - 0.5, wcy - 0.5,
                wcx + 0.5, wcy + 0.5);

            shp.CellsU["Width"].FormulaForceU = "GUARD(TEXTWIDTH(TheText))";
            shp.CellsU["Height"].FormulaForceU = "GUARD(TEXTHEIGHT(TheText,Width))";
            // There is a bug in Visio, visUnitsPoint doesn't work:
            //shp.CellsU["Char.Size"].Result[Vis.VisUnitCodes.visUnitsPoint] = pointSize;
            double dPointsIU = pointSize / 72;
            shp.CellsU["Char.Size"].ResultIU = dPointsIU;
            shp.Text = text;

            _centerShapeAndZoom(shp, win);

            return shp;
        }
        public static Vis.Shape Drop_ViewCenter_Master(
            this Vis.Page visPg,
            Vis.Master visMst)
        {
            if (visMst == null) return null;

            // Get the bounds of the current window:
            double wl, wt, wr, wcx, wcy, wb, ww, wh;
            Vis.Window win = visPg.GetViewBounds(
                out wl, out wt, out wr, out wb, out wcx, out wcy, out ww, out wh);
            if (win == null) return null;

            // Drop the master in the center of the window:
            Vis.Shape shp = visPg.Drop(visMst, wcx, wcy);

            _centerShapeAndZoom(shp, win);
            return shp;
        }

        public static Vis.Shape Drop_ViewCenter_Master_ToRightOfSelectedShape(
            this Vis.Page visPg,
            Vis.Master visMst,
            Vis.Shape visShpSelected,
            double xOffset,
            bool bCenterZoomOnDroppedShape)
        {
            if (visMst == null) return null;

            // Get the right-middle of the selected shape:
            double xRight, yMiddle;
            visShpSelected.RightMiddleIU(out xRight, out yMiddle);

            // Get the size and locpin of the selected shape:
            Vis.Shape shpInMst = visMst.Shapes[1];
            double w, h, lpx, lpy;
            shpInMst.SizeAndLocPin(out w, out h, out lpx, out lpy);

            // Calculate the drop-position of the new shape:
            double px, py;
            px = xRight + xOffset + lpx;
            py = yMiddle - h * 0.5 + lpy;

            // Drop the shape:
            Vis.Shape shpDropped = visPg.Drop(visMst, px, py);

            // Center the view on the new shape and zoom:
            if (bCenterZoomOnDroppedShape)
            {
                Vis.Window win = visPg.ActiveWindowForPage();
                if (win != null)
                {      
                    var flags = Vis.VisCenterViewFlags.visCenterViewDefault; // .visCenterViewIfOffScreen;
                    win.CenterViewOnShape(shpDropped, flags);
                }
            }

            return shpDropped;

            // Get the bounds of the current window:
            //double wl, wt, wr, wcx, wcy, wb, ww, wh;
            //Vis.Window win = visPg.GetViewBounds(
            //    out wl, out wt, out wr, out wb, out wcx, out wcy, out ww, out wh);
            //if (win == null) return null;

            //// Drop the master in the center of the window:
            //Vis.Shape shp = visPg.Drop(visMst, wcx, wcy);
        }

        //public static Vis.Shape ShapeFromNameOrNull(this Vis.Page visPage, string shapename)
        //{
        //    foreach (Vis.Shape shp in visPage.Shapes)
        //    {
        //        if (shp.Name.Equals(shapename, 
        //            StringComparison.InvariantCultureIgnoreCase)) return shp;
        //    }
        //    return null;
        //}
        public static Vis.Shape ShapeFromIDorNull(this Vis.Page visPage, int idShape)
        {
            foreach (Vis.Shape shp in visPage.Shapes)
            {
                if (shp.ID == idShape) return shp;
            }
            return null;
        }


        public static Vis.Shape ShapeFromNameOrNull(this Vis.Page visPage, string shapeName)
        {
            foreach (Vis.Shape shp in visPage.Shapes)
            {
                if (shp.Name.Equals(shapeName, 
                    StringComparison.InvariantCultureIgnoreCase)) return shp;
            }
            return null;
        }

        // TODO: use shape extension: CenterAndZoom instead?
        private static void _centerShapeAndZoom(
            Vis.Shape visShp, Vis.Window visWin)
        {
            // The shape might be rotated, might have a non-centered
            // pin location, and thus might not be centered in the view.
            // We can adjust the shape location here. And since this
            // proc is likely called not-so-often, and operates in human
            // time scales, we can probably afford the extra analyses
            // and manipulation. I wouldn't call this proc often nor
            // rapidly.

            // TODO: code that calls this procedure has likely 
            // already called Window.GetViewRectangle, so this is
            // potentially wasteful.
            double wl, wt, wcx, wcy, ww, wh; //...wr, wb
            visWin.GetViewRect(out wl, out wt, out ww, out wh);
            wcx = wl + ww * 0.5;
            wcy = wt - wh * 0.5;

            // Get the shape's bounding box:
            double sl, st, sr, sb, scx, scy, sw, sh;
            short flags = (short)Vis.VisBoundingBoxArgs.visBBoxUprightWH;
            visShp.BoundingBox(flags, out sl, out sb, out sr, out st);

            // Calculate size and center:
            sw = sr - sl;
            sh = st - sb;
            scx = 0.5 * (sl + sr);
            scy = 0.5 * (sb + st);

            // Calculate the offset of the shape's center from the screen center:
            double dMoveX = wcx - scx;
            double dMoveY = wcy - scy;

            // Calculate a tolerance, then move the shape in x or y directions
            // if the difference exceeds the tolerance:
            double tol = Math.Abs(Math.Max(sw, sh)) * 0.01; //...1/100th of max shape width or height
            if (Math.Abs(dMoveX) > tol)
            {
                Vis.Cell c = visShp.CellsU["PinX"];
                c.ResultIUForce = c.ResultIU + dMoveX;
                sl += dMoveX;
                sr += dMoveX;
                scx += dMoveX;
            }
            if (Math.Abs(dMoveY) > tol)
            {
                Vis.Cell c = visShp.CellsU["PinY"];
                c.ResultIUForce = c.ResultIU + dMoveY;
                sb += dMoveY;
                st += dMoveY;
                scy += dMoveY;
            }

            // Ok, the shape should now be centered in the view.
            // First, compare the shape size to the window size:
            double dShpOverWinX = 1;
            if (sw != 0 && ww != 0) dShpOverWinX = sw / ww;

            double dShpOverWinY = 1;
            if (sh != 0 && wh != 0) dShpOverWinY = sh / wh;

            // Increase the factors by 25%, so that if we do zoom out,
            // we'll have a bit of extra space around the shape:
            dShpOverWinX = dShpOverWinX * 1.25;
            dShpOverWinY = dShpOverWinY * 1.25;

            double dZoom = Math.Max(dShpOverWinX, dShpOverWinY);

            Debug.WriteLine("Window zoom: " + visWin.Zoom + ", dZoom: " + dZoom);
            if (dZoom > 1)
            {
                // Zoom out:
                visWin.Zoom = visWin.Zoom / dZoom;
            }
            else if (dZoom < 0.25)
            {
                // TODO: calculate a factor to zoom in TO.
                // For now, win.Zoom = 1 really works quite well, but
                // it seems to lack any intelligence behind it.

                // Zoom in:
                visWin.Zoom = 1;
            }
        }

        public static Vis.Window ActiveWindowForPage(
            this Vis.Page visPg)
        {
            Vis.Application visApp = visPg.Application;
            Vis.Window visWin = visApp.ActiveWindow;

            Vis.Page pg = visWin.Page;

            if (!pg.IsActiveWindow()) return null;

            return visWin;
        }

        /// <summary>
        /// Attempts to turn the active window to the page object. If
        /// the active window contains a document that does not contain
        /// the page object, or the active window isn't a drawing window,
        /// then no action is taken.
        /// </summary>
        /// <param name="visPg"></param>
        public static void TryActiveWindowGotoPage(this Vis.Page visPg)
        {
            // Look for weird cases, where turning the active window
            // to visPg doesn't make sense\:
            if (visPg.StatNotNormal()) return;
            if (visPg.IsActiveWindow()) return;
           
            // Active window is not showing the document:
            Vis.Document visDoc = visPg.Document;
            if (visDoc.IsShownInActiveWindow() == false) return;
            
            Vis.Application visApp = visDoc.Application;
            Vis.Window win = visApp.ActiveWindow;
            if (win.IsDrawingPageWindow() == false) return; //...could be a group-edit window, or worse!

            win.Page = visPg;

        }


        public static Vis.Window GetViewBounds(
            this Vis.Page visPg,
            out double left, out double top,
            out double right, out double bottom,
            out double centerX, out double centerY,
            out double width, out double height)
        {
            // If you're calling this extension, start with this snippet:
            //double wl, wt, wr, wcx, wcy, wb, ww, wh;
            //Vis.Window win = visPg.GetViewBounds(
            //      out wl, out wt, out wr, out wb, out wcx, out wcy, out ww, out wh);

            // Initialize the outs:
            left = 0;
            top = 0;
            right = 0;
            bottom = 0;
            centerX = 0;
            centerY = 0;
            width = 0;
            height = 0;

            Vis.Window win = visPg.ActiveWindowForPage();
            if (win == null) return null;

            double l, t, w, h;
            win.GetViewRect(out l, out t, out w, out h);

            left = l;
            top = t;
            right = l + w;
            bottom = t - h;

            width = right - left;
            height = top - bottom;
            centerX = left + 0.5 * width;
            centerY = bottom + 0.5 * height;

            return win;
        }
        public static Vis.Window GetViewCenter(
            this Vis.Page visPg,
            out double xCenter, out double yCenter)
        {
            xCenter = 0;
            yCenter = 0;

            Vis.Window win = visPg.ActiveWindowForPage();
            if (win == null) return null;

            double l, t, w, h;
            win.GetViewRect(out l, out t, out w, out h);

            xCenter = l + w * 0.5;
            yCenter = t - h * 0.5;

            return win;
        }

        /// <summary>
        /// Returns true if the Visio.Page object in question is the
        /// same as the Visio application's active window.
        /// </summary>
        /// <param name="visPg"></param>
        /// <returns></returns>
        public static bool IsActiveWindow(this Vis.Page visPg)
        {
            Vis.Application visApp = visPg.Application;
            Vis.Window visWin = visApp.ActiveWindow;
            if (visWin.IsDrawableWindow())
            {
                Vis.Page pg = visWin.Page;
                return (pg == visPg);
            }
            return false;
        }

        public static bool IsBackgroundPage(this Vis.Page visPg)
        {
            return Convert.ToBoolean(visPg.Background);
        }
        public static bool IsForegroundPage(this Vis.Page visPg)
        {
            return ! Convert.ToBoolean(visPg.Background);
        }

        /// <summary> Wraps pg.Shapes.ItemFromID in a Try-Catch block, and returns null if 
        /// the shape isn't found.
        /// </summary>
        /// <param name="visPage"></param>
        /// <param name="shapeId"></param>
        /// <returns>A Visio shape object or null if no shape is found.</returns>
        public static Vis.Shape GetShapeByIdSafe(this Vis.Page visPage, int shapeId)
        {
            if (visPage.Shapes.Count == 0) return null;

            // TODO: some sort of manual loop if there's an error?
            try
            {
                return visPage.Shapes.ItemFromID[shapeId];
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static bool IsClass(this Vis.Page visPage, string classValue)
        {
            Vis.Shape shpPg = visPage.PageSheet;
            return shpPg.IsClass(classValue);
        }

        public static IEnumerable<Vis.Shape> ShapesAtTopLevel(this Vis.Page visPage)
        {
            // Top level means we don't go into groups:
            foreach (Vis.Shape shp in visPage.Shapes) yield return shp;
        }

        public static Vis.Selection ShapesOfClass(this Vis.Page visPage, string classValue)
        {
            Vis.Selection sel = visPage.CreateAllSelection();
            for (int i = sel.Count; i >= 1; i--)
            {
                Vis.Shape shp = sel[i];
                if (!shp.IsClass(classValue))
                    sel.Deselect(shp);
            }
            return sel;
        }

        public static void DeleteAllShapes(this Vis.Page visPage)
        {
            Vis.Application visApp = visPage.Application;
            visApp.ShowChanges = false;
            try
            {
                // Shapes can't be deleted if they are on locked layers
                // or if they have LockDelete != 0.
                for (int i = visPage.Shapes.Count; i > 0; i--)
                {
                    Vis.Shape shp = visPage.Shapes[i];
                    shp.DeleteSafe();
                }
            }
            catch
            {

            }
            if (visApp != null) visApp.ShowChanges = true;
        }

        public static void DeleteAllLayers(this Vis.Page visPage, bool keepShapes)
        {
            // Note: if a shape is on a layer, but is also locked against
            // deletion, the layer will be deleted, but the shape will
            // remain!

            short deleteShapes = Convert.ToInt16(!keepShapes);

            // Delete all layers, too:
            for (int i = visPage.Layers.Count; i > 0; i--)
            {
                Vis.Layer lyr = visPage.Layers[i];
                lyr.Unlock();
                lyr.Delete(deleteShapes);
            }
        }

        public static void HideAllLayers(this Vis.Page visPage)
        {
            for (int i = 1; i < visPage.Layers.Count; i++)
            {
                Vis.Layer lyr = visPage.Layers[i];
                lyr.Hide();
            }
        }
        public static void ShowAllLayers(this Vis.Page visPage)
        {
            for (int i = 1; i < visPage.Layers.Count; i++)
            {
                Vis.Layer lyr = visPage.Layers[i];
                lyr.Show();
            }
        }

        public static bool StatNotNormal(this Vis.Page visPg)
        {
            if (visPg == null) return true;
            var s = visPg.Stat;
            return (s != (short)Vis.VisStatCodes.visStatNormal);
        }

        public static Vis.Layer GetOrMakeLayer(this Vis.Page visPage, string layerName)
        {
            // TODO: check for semi-colons or other layer-illegal characters?

            Vis.Layer lyr = null;
            for (int i = 1; i <= visPage.Layers.Count; i++)
            {
                lyr = visPage.Layers[i];
                string s = lyr.Name.ToLower();
                if (s == layerName.ToLower()) return lyr;
            }

            lyr = visPage.Layers.Add(layerName);
            return lyr;
        }

        public static Vis.Master MasterByName(this Vis.Page visPage, string mastername)
        {
            Vis.Document visDoc = visPage.Document;
            foreach (Vis.Master mst in visDoc.Masters)
            {
                if (string.Compare(mst.Name, mastername, true) == 0) return mst;
            }
            return null;
        }

        public static void SelectInWindow(this Vis.Page visPage, Vis.Shape visShp)
        {
            List<int> ids = new List<int>() { visShp.ID };
            visPage.SelectInWindow(ids);
        }

        public static void SelectInWindow(this Vis.Page visPage, List<int> iShapeIds)
        {
            Vis.Window win = visPage.Application.ActiveWindow;

            if (win.IsDrawingPageWindow())
            {
                if (win.Page as Vis.Page == visPage)
                {
                    Vis.Selection sel = visPage.CreateSelection((short)Vis.VisSelectionTypes.visSelTypeEmpty);
                    foreach (int id in iShapeIds)
                    {
                        sel.Select(visPage.Shapes.ItemFromID[id], (short)Vis.VisSelectArgs.visSelect);
                    }
                    if (sel.Count > 0)
                    {
                        win.DeselectAll();
                        win.Selection = sel;
                    }
                }
            }

            //Sub X()

            //  Dim win As Visio.Window
            //  Set win = Visio.ActiveWindow

            //  win.DeselectAll

            //  Dim sel As Visio.Selection
            //  Set sel = Visio.ActivePage.CreateSelection(visSelTypeAll)

            //  win.Selection = sel


            //End Sub

        }

        public static void OrientLetterPortrait(this Vis.Page visPage)
        {
            _orientPage(visPage, 8.5, 11.0);
        }
        public static void OrientLetterLandscape(this Vis.Page visPage)
        {
            _orientPage(visPage, 11.0, 8.5);
        }
        public static void OrientA4Portrait(this Vis.Page visPage)
        {
            // 210mm = 8.2677in
            // 297mm = 11.6929
            _orientPage(visPage, 8.2677, 11.6929);
        }
        public static void OrientA4Landscape(this Vis.Page visPage)
        {
            _orientPage(visPage, 11.6929, 8.2677);
        }

        /// <summary>
        /// Sets the scale of a Visio page to a 'Custom' scale of 1 : SomeRatio. 
        /// Architectural, Engineering, Metric or other scales are not used. The
        /// unscaled size of the page (paper size) is preserved in the operation.
        /// </summary>
        /// <param name="visPage"></param>
        /// <param name="pageScale"></param>
        /// <param name="dwgScale"></param>
        public static bool SetPageScale_CustomOneToN(this Vis.Page visPage, double pageScale, double dwgScale)
        {
            // Bail for negative or zero:
            if (pageScale <= 0) return false;
            if (dwgScale <= 0) return false;

            // Shape for page:
            Vis.Shape shpPg = visPage.PageSheet;

            // Cells:
            Vis.Cell cPageWidth = shpPg.CellsSRC[Sec_Object, Row_Page, Col_PageWidth];
            Vis.Cell cPageHeight = shpPg.CellsSRC[Sec_Object, Row_Page, Col_PageHeight];
            Vis.Cell cPageScale = shpPg.CellsSRC[Sec_Object, Row_Page, Col_PageScale];
            Vis.Cell cDwgScale = shpPg.CellsSRC[Sec_Object, Row_Page, Col_DrawingScale];
            Vis.Cell cDwgScaleType = shpPg.CellsSRC[Sec_Object, Row_Page, Col_DrawingScaleType];

            // Examine page scale, drawing scale and scale ratios:
            double pageScale0 = cPageScale.ResultIU;
            double dwgScale0 = cDwgScale.ResultIU;
            double scaleRatio0 = pageScale0 / dwgScale0;

            // Compare new values to old:
            double scaleRatioNew = pageScale / dwgScale;
            if (scaleRatioNew == scaleRatio0) return false; //...nothing to do, really

            // Special case for 1:1:
            bool isOneToOne = (scaleRatioNew == 1);

            // Get initial page size values:
            double pageWidth0 = cPageWidth.ResultIU; // .TryGetCellResultIU("PageWidth");
            double pageHeight0 = cPageHeight.ResultIU;

            // Get the size of the paper:
            double unscaledWidth = pageWidth0 * scaleRatio0;
            double unscaledHeight = pageHeight0 * scaleRatio0;

            // Calculate new values:
            double pageWidthNew = unscaledWidth / scaleRatioNew;
            double pageHeightNew = unscaledHeight / scaleRatioNew;

            // Set the scales:
            cPageScale.ResultIUForce = 1.0;
            cDwgScale.ResultIUForce = 1 / scaleRatioNew;

            // Set the type cells:
            double sclType = isOneToOne ? (double)Vis.VisCellVals.visNoScale :
                                          (double)Vis.VisCellVals.visScaleCustom; // 0 or 3
            cDwgScaleType.ResultIUForce = sclType;

            // Set the page size:
            cPageWidth.ResultIUForce = pageWidthNew;
            cPageHeight.ResultIUForce = pageHeightNew;

            return true;

            // For "unscaled" drawing:
            //
            // PageWidth = 8.5 in
            // PageHeight = 11 in
            // PageScale = 1 in
            // DrawingScale = 1 in
            // DrawingSizeType = 0
            // DrawingScaleType = 0
            // DrawingResizeType = 1

            // For custom 1:6 drawing:
            //
            // PageWidth = 51 in
            // PageHeight = 66 in
            // PageScale = 1 in
            // DrawingScale = 6 in
            // DrawingSizeType = 0
            // DrawingScaleType = 3 //visScaleCustom
            // DrawingResizeType = 1
        }
        private static void _orientPage(Vis.Page visPage,
            double dUnscaledPageWidth, double dUnscaledPageHeight)
        {
            // Changes the size of the page, regardless of scale, and
            // manages the correct settings:
            Vis.Shape shp = visPage.PageSheet;

            // Turn off auto-size pages:

            // Get the scale ratio:
            double ps, ds;
            ps = shp.CellsU["PageScale"].ResultIU;
            ds = shp.CellsU["DrawingScale"].ResultIU;

            // Calculate new dimensions:
            double pwNew, phNew;
            pwNew = dUnscaledPageWidth * ds / ps;
            phNew = dUnscaledPageHeight * ds / ps;

            shp.CellsU["PageWidth"].ResultIUForce = pwNew;
            shp.CellsU["PageHeight"].ResultIUForce = phNew;
        }

    }
}
