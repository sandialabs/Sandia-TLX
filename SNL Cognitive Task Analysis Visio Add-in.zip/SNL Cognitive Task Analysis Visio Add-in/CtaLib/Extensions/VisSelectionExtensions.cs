﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
namespace Visguy.VisAddinLib.Extensions
{
    public static class VisSelectionExtensions
    {

        public static bool ContainsId(this Vis.Selection visSel, int idShape)
        {
            foreach (Vis.Shape shp in visSel)
            {
                if (shp.ID == idShape) return true;
            }
            return false;
        }


        public static void FilterByUserClasses(this Vis.Selection visSelection,
            string[] UserClassValues)
        {
            if (visSelection == null) return;
            if (visSelection.Count == 0) return;
            for(int i = visSelection.Count; i > 0; i-- )
            {
                Vis.Shape shp = visSelection[i];
                if (!shp.IsClass(UserClassValues))
                    visSelection.Deselect(shp);
            }
        }

        public static Vis.Selection Filter(this Vis.Selection visSelection,
                                           Predicate<Vis.Shape> acceptShapeTest)
        {
            // TODO: return a new seleciton or operate on the existing one?

            // TODO: might not work if we're inside a master or group
            Vis.Selection sel = visSelection.ContainingPage.CreateEmptySelection();

            if (visSelection.Count == 0) return sel;

            Vis.Shape shp;
            for (int i = visSelection.Count; i > 0; i--)
            {
                shp = visSelection[i];
                if (acceptShapeTest(shp))
                {
                    sel.Select(shp);
                }
            }

            return sel;
        }

        public static void DeleteSafe(this Vis.Selection visSelection)
        {
            if (visSelection == null) return;
            if (visSelection.Count == 0) return;

            for (int i = visSelection.Count; i > 0; i--)
            {
                Vis.Shape shp = visSelection[i];

                // Remove from selection if it's already gone (imagine
                // container members...
                if (shp.HasBeenDeleted()) visSelection.Deselect(shp);

                // Make sure it's not guarded against deletion:
                double dLockDelete = shp.CellsU["LockDelete"].ResultIU;
                if (dLockDelete != 0) shp.CellsU["LockDelete"].ResultIUForce = 0;

                // Erase the layer list. This allows a shape on a locked layer to be deleted:
                string fLayers = shp.CellsU["LayerMember"].FormulaU;
                if (fLayers.Length > 0) shp.CellsU["LayerMember"].FormulaForceU = "";
            }

            if (visSelection != null)
            {
                if (visSelection.Count > 0) visSelection.DeleteEx((short)Vis.VisDeleteFlags.visDeleteNormal);
            }
        }

        public static void Select(this Vis.Selection visSelection, Vis.Shape visShape)
        {
            // TODO: this gacks bigtime if visShape is a PageSheet 'shape'

            // Just add the shape to the selection, with all the 
            // stupid arguments conveniently hidden in this extension:
            visSelection.Select(visShape, (short)Vis.VisSelectArgs.visSelect);
        }

        public static void Deselect(this Vis.Selection visSelection, Vis.Shape visShape)
        {
            // Just remove the shape to the selection, with all the 
            // stupid arguments conveniently hidden in this extension:
            visSelection.Select(visShape, (short)Vis.VisSelectArgs.visDeselect);
        }

        /// <summary>
        /// Get a Visio.Selection object from an IEnumerable collection of Visio.Shape objects.
        /// </summary>
        /// <param name="visSel"></param>
        /// <param name="visShps"></param>
        public static void SelectCollection(this Vis.Selection visSel, IEnumerable<Vis.Shape> visShps)
        {
            visSel.DeselectAll();
            foreach (Vis.Shape shp in visShps)
            {
                visSel.Select(shp, (short)Vis.VisSelectArgs.visSelect);
            }
        }

        public static void SelectFromIds(this Vis.Selection visSel, IEnumerable<int> shapeIds)
        {
            Vis.Shapes shps = visSel.ContainingPage.Shapes;

            visSel.DeselectAll();
            foreach (int id in shapeIds)
            {
                visSel.Select(shps.get_ItemFromID(id), (short)Vis.VisSelectArgs.visSelect);
            }
        }

        public static void SelectFromIDsAdditive(this Vis.Selection visSel, IEnumerable<int> shapeIds)
        {
            Vis.Shapes shps = visSel.ContainingPage.Shapes;
            foreach (int id in shapeIds)
            {
                visSel.Select(shps.get_ItemFromID(id), (short)Vis.VisSelectArgs.visSelect);
            }
        }

        public static List<Vis.Shape> ToList(this Vis.Selection visSel)
        {
            // This has trouble with that cross-boundary blah blah generic blah blah
            // "Cannot be used across assembly boundaries because it has a generic 
            //  type parameter that is an embedded interop type"

            var shps = new List<Vis.Shape>();
            if ( visSel.IsNullOrGone() ) return shps;

            foreach (Vis.Shape shp in visSel)
                shps.Add(shp);

            return shps;
        }

        public static bool IsNullOrGone(this Vis.Selection visSel)
        {
            if (visSel == null) return true;
            var s = visSel.Stat;
            if (s == (short)Vis.VisStatCodes.visStatDeleted) return true;
            if (s == (short)Vis.VisStatCodes.visStatClosed) return true;
            if (s == (short)Vis.VisStatCodes.visStatAppHasShutdown) return true;

            // Note:
            //visStatNormal = 0,
            //visStatAppHasShutdown = 1,
            //visStatDeleted = 2,
            //visStatTouched = 4,
            //visStatClosed = 8,
            //visStatSuspended = 16

            return false;
        }

    }
}
