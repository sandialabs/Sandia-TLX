﻿using System;
using System.Collections.Generic;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;

namespace Visguy.VisAddinLib.Extensions
{
    public static class VisShapeExtensions
    {
        // Section constants:
        private const short Sec_Object = (short)Vis.VisSectionIndices.visSectionObject;
        private const short Sec_User = (short)Vis.VisSectionIndices.visSectionUser;
        private const short Sec_Prop = (short)Vis.VisSectionIndices.visSectionProp;

        // Row constants:
        private const short Row_ShapeTform = (short)Vis.VisRowIndices.visRowXFormOut;
        private const short Row_TextTform = (short)Vis.VisRowIndices.visRowTextXForm;
        private const short Row_Lock = (short)Vis.VisRowIndices.visRowLock;

        // Cell constants:
        const short Cell_LockDelete = (short)Vis.VisCellIndices.visLockDelete;

        // Other constants:
        private const short RowTag_Default = (short)Vis.VisRowTags.visTagDefault;
        private const short Exists_Anywhere = (short)Vis.VisExistsFlags.visExistsAnywhere;


        #region Shape Transform Stuff
        public static double HeightIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormHeight].ResultIU;
        }
        public static double WidthIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormWidth].ResultIU;
        }
        public static double PinXIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormPinX].ResultIU;
        }
        public static double PinYIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormPinY].ResultIU;
        }
        public static double LocPinXIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormLocPinX].ResultIU;
        }
        public static double LocPinYIU(this Vis.Shape visShp)
        {
            return visShp.CellsSRC[Sec_Object, Row_ShapeTform,
                (short)Vis.VisCellIndices.visXFormLocPinY].ResultIU;
        }

        public static double TopIU_Upright(this Vis.Shape visShp)
        {
            return visShp.PinYIU() -
                    visShp.HeightIU() +
                    visShp.LocPinYIU();
        }
        public static double LeftIU_Upright(this Vis.Shape visShp)
        {
            return visShp.PinXIU() -
                    visShp.LocPinXIU();
        }

        public static void RightMiddleIU(this Vis.Shape visShp, out double x, out double y)
        {
            short flags = (short)Vis.VisBoundingBoxArgs.visBBoxUprightWH;
            double l, t, r, b;
            visShp.BoundingBox(flags, out l, out b, out r, out t);

            x = r;
            y = (b + t) * 0.5;
        }
        public static void LeftTopIU_Upright(this Vis.Shape visShp, out double left, out double top)
        {
            short flags = (short)Vis.VisBoundingBoxArgs.visBBoxUprightWH;
            double l, t, r, b;
            visShp.BoundingBox(flags, out l, out b, out r, out t);

            left = l;
            top = t;
        }

        /// <summary>
        /// Returns the width and height of a shape in "upright" coordinates,
        /// as well as the offset of the pin of the shape from the "upright"
        /// left and bottom of the shape.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        /// <param name="lpx"></param>
        /// <param name="lpy"></param>
        public static void SizeAndLocPin(this Vis.Shape visShp, 
            out double w, out double h, out double lpx, out double lpy)
        {
            short flags = (short)Vis.VisBoundingBoxArgs.visBBoxUprightWH;
            double l, t, r, b;
            visShp.BoundingBox(flags, out l, out b, out r, out t);

            w = r - l;
            h = t - b;

            // Shape might be rotated, so translate locpin to parent coords,
            // then calculate the offset from the sides:
            double px, py;
            px = visShp.PinXIU();
            py = visShp.PinYIU();

            lpx = px - l;
            lpy = py - b;
        }

        #endregion Shape Transform Stuff


        public static void AddAntiScaleUserCell(this Vis.Shape visShp)
        {
            visShp.SetUserCellFormulaU("User.AntiScale", "ThePage!DrawingScale/ThePage!PageScale", true);
        }

        public static void AddShapeDataRows(this Vis.Shape visShp, string csvRowNames)
        {
            var rowNames = csvRowNames.Split(',');
            foreach (var rowName in rowNames)
            {
                if (!visShp.CellExistsAnywhere("Prop." + rowName))
                {
                    visShp.AddNamedRow(
                        (short)Vis.VisSectionIndices.visSectionProp,
                        rowName,
                        (short)Vis.VisRowTags.visTagDefault);

                }
            }
        }
        public static void AddShapeDataRows(this Vis.Shape visShp,
            string csvRowNames, string csvRowLabels)
        {
            var rowNames = csvRowNames.Split(',');
            var rowLabels = csvRowLabels.Split(',');

            if (rowNames.Length != rowLabels.Length)
            {
                Debug.WriteLine("ShapeExtensions.AddShapeDataRows:\n\tRow name and label array lengths do not match!");
                return;
            }

            // TODO: a ManySetter version of this could be concocted...
            int i = 0;
            foreach (var rowName in rowNames)
            {
                if (!visShp.CellExistsAnywhere("Prop." + rowName))
                {
                    visShp.AddNamedRow(
                        (short)Vis.VisSectionIndices.visSectionProp,
                        rowName,
                        (short)Vis.VisRowTags.visTagDefault);

                }

                // Set the label:
                var lbl = rowLabels[i];
                visShp.Cells["Prop." + rowName + ".Label"].FormulaForceU = "\"" + "" + "\"";
                i++;
            }
        }

        public static bool IsNullOrGone(this Vis.Shape visShp)
        {
            if (visShp == null) return true;
            var s = visShp.Stat;
            if (s == (short)Vis.VisStatCodes.visStatDeleted) return true;
            if (s == (short)Vis.VisStatCodes.visStatClosed) return true;
            if (s == (short)Vis.VisStatCodes.visStatAppHasShutdown) return true;

            // Note:
            //visStatNormal = 0,
            //visStatAppHasShutdown = 1,
            //visStatDeleted = 2,
            //visStatTouched = 4,
            //visStatClosed = 8,
            //visStatSuspended = 16

            return false;
        }
        public static bool StatNotNormal(this Vis.Shape visShp)
        {
            if (visShp == null) return true;
            var s = visShp.Stat;
            return (s != (short)Vis.VisStatCodes.visStatNormal);
        }

        /// <summary>
        /// Adds a named connection point row.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="rowName"></param>
        /// <param name="widthFraction">The X location of the point, in terms of width.</param>
        /// <param name="heightFraction">The Y location of the point, in terms of height.</param>
        /// <param name="xDir">An X vector component for the direction of the connection.</param>
        /// <param name="yDir">A Y vector component for the direction of the connection.</param>
        /// <param name="cpType">0 = Inward, 1 = Outward, 2 = Inward/Outward</param>
        public static void AddConnectionPoint(this Vis.Shape visShp, string rowName,
            double widthFraction, double heightFraction, double xDir, double yDir, double cpType)
        {

            if (!visShp.CellExistsAnywhere("Connections." + rowName))
            {
                visShp.AddNamedRow(
                    (short)Vis.VisSectionIndices.visSectionConnectionPts,
                    rowName,
                    (short)Vis.VisRowTags.visTagDefault);
            }

            string cellNameBase = "Connections." + rowName;
            visShp.Cells[cellNameBase + ".X"].FormulaForceU = "Width*" + widthFraction;
            visShp.Cells[cellNameBase + ".Y"].FormulaForceU = "Height*" + heightFraction;
            visShp.Cells[cellNameBase + ".DirX"].ResultIUForce = xDir;
            visShp.Cells[cellNameBase + ".DirY"].ResultIUForce = yDir;

            // 0 = Inward, 1 = Outward, 2 = Inward/Outward
            visShp.Cells[cellNameBase + ".Type"].ResultIUForce = cpType;
        }


        /// <summary>
        /// Checks if a shape has the User.Class value specified.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="userClassValue"></param>
        /// <returns></returns>
        public static bool IsClass(this Vis.Shape visShp, string userClassValue)
        {
            if (visShp.CellExistsAnywhere("User.Class"))
            {
                string val = visShp.ResultString("User.Class");
                //Debug.WriteLine(String.Compare(userClassValue, val, true));
                return (String.Compare(userClassValue, val, true) == 0);
            }

            return false;
        }

        public static string UserClassValue(this Vis.Shape visShp)
        {
            if (visShp.CellExistsAnywhere("User.Class"))
            {
                string val = visShp.ResultString("User.Class");
                return val;
            }
            return String.Empty;
        }

        public static bool IsClass(this Vis.Shape visShp, string[] userClassValues)
        {
            if (visShp.CellExistsAnywhere("User.Class"))
            {
                string val = visShp.ResultString("User.Class");

                foreach(string cn in userClassValues)
                {
                    if(String.Compare(cn, val, true) == 0) return true;
                }
            }

            return false;
        }

        public static bool Is1D(this Vis.Shape visShp)
        {
            return (Convert.ToBoolean(visShp.OneD));
        }
        public static bool Is2D(this Vis.Shape visShp)
        {
            return (Convert.ToBoolean(visShp.OneD) == false);
        }
        /// <summary>
        /// Checks if a shape has a particular ShapeSheet cell 'anywhere', 
        /// ie: inherited from the master, or locally added.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="cellName"></param>
        /// <returns></returns>
        //public static bool CellExists(this Vis.Shape visShp, string cellName)
        //{
        //    return Convert.ToBoolean(
        //        visShp.CellExists[cellName,Exists_Anywhere]);
        //}
        public static bool CellExistsAnywhere(this Vis.Shape visShp, string cellname)
        {
            return Convert.ToBoolean(
                visShp.CellExists[cellname, Exists_Anywhere]);
        }
        public static bool CellsExistsAnywhere(this Vis.Shape visShp, string csvCellList)
        {
            string[] cellnames = csvCellList.Split(',');
            foreach (string cellname in cellnames)
            {
                if (visShp.CellExistsAnywhere(cellname) == false) return false;
            }
            return true;
        }

        public static void CenterAndZoom(
            this Vis.Shape visShp)
        {
            Vis.Page pgShp = visShp.ContainingPage;

            Vis.Window visWin = pgShp.ActiveWindowForPage();
            if (visWin == null) return;

            // Get the bounds of the window:
            double wl, wt, wcx, wcy, ww, wh; //...wr, wb
            visWin.GetViewRect(out wl, out wt, out ww, out wh);
            wcx = wl + ww * 0.5;
            wcy = wt - wh * 0.5;

            // Get the shape's bounding box:
            double sl, st, sr, sb, scx, scy, sw, sh;
            short flags = (short)Vis.VisBoundingBoxArgs.visBBoxUprightWH;
            visShp.BoundingBox(flags, out sl, out sb, out sr, out st);

            // Calculate size and center:
            sw = sr - sl;
            sh = st - sb;
            scx = 0.5 * (sl + sr);
            scy = 0.5 * (sb + st);

            // Calculate the offset of the shape's center from the screen center:
            double dMoveX = wcx - scx;
            double dMoveY = wcy - scy;

            // Calculate a tolerance, then move the shape in x or y directions
            // if the difference exceeds the tolerance:
            double tol = Math.Abs(Math.Max(sw, sh)) * 0.01; //...1/100th of max shape width or height
            if (Math.Abs(dMoveX) > tol)
            {
                Vis.Cell c = visShp.CellsU["PinX"];
                c.ResultIUForce = c.ResultIU + dMoveX;
                sl += dMoveX;
                sr += dMoveX;
                scx += dMoveX;
            }
            if (Math.Abs(dMoveY) > tol)
            {
                Vis.Cell c = visShp.CellsU["PinY"];
                c.ResultIUForce = c.ResultIU + dMoveY;
                sb += dMoveY;
                st += dMoveY;
                scy += dMoveY;
            }

            // Ok, the shape should now be centered in the view.
            // First, compare the shape size to the window size:
            double dShpOverWinX = 1;
            if (sw != 0 && ww != 0) dShpOverWinX = sw / ww;

            double dShpOverWinY = 1;
            if (sh != 0 && wh != 0) dShpOverWinY = sh / wh;

            // Increase the factors by 25%, so that if we do zoom out,
            // we'll have a bit of extra space around the shape:
            dShpOverWinX = dShpOverWinX * 1.25;
            dShpOverWinY = dShpOverWinY * 1.25;

            double dZoom = Math.Max(dShpOverWinX, dShpOverWinY);

            if (dZoom > 1)
            {
                // Zoom out:
                visWin.Zoom = visWin.Zoom / dZoom;
            }
            else if (dZoom < 0.25)
            {
                // TODO: calculate a factor to zoom in TO.
                // For now, win.Zoom = 1 really works quite well, but
                // it seems to lack any intelligence behind it.

                // Zoom in:
                visWin.Zoom = 1;
            }
        }

        public static Vis.Selection CreateEmptySelection(this Vis.Shape visShape)
        {
            return visShape.CreateSelection(Vis.VisSelectionTypes.visSelTypeEmpty,
                                            Vis.VisSelectMode.visSelModeSkipSuper,
                                            Type.Missing);
        }

        /// <summary>
        /// Deletes a shape after unlocking protection against deletion
        /// and unlocking layers that it might belong to.
        /// </summary>
        /// <param name="visShp"></param>
        public static void DeleteSafe(this Vis.Shape visShp)
        {
            if (visShp.HasBeenDeleted()) return;

            visShp.UnlockDelete();
            visShp.UnlockLayers();
            visShp.Delete();
        }

        public static bool HasBeenDeleted(this Vis.Shape visShp)
        {
            if (visShp.Stat == (short)Vis.VisStatCodes.visStatDeleted) return true;
            return false;
        }

        public static bool HasCellWithValue_Str(this Vis.Shape visShp, string cellname, string value)
        {
            if (!visShp.CellExistsAnywhere(cellname)) return false;
            Vis.Cell visCell = visShp.Cells[cellname];
            string valueInCell = visCell.ResultStr[Vis.VisUnitCodes.visUnitsString];

            // TODO: case (in)sensitivity?
            return (valueInCell == value);
        }

        public static double Left_UprightSimple(this Vis.Shape visShp)
        {
            return visShp.PinXIU() - visShp.LocPinXIU();
        }
        public static double Bottom_UprightSimple(this Vis.Shape visShp)
        {
            return visShp.PinYIU() - visShp.LocPinYIU();
        }

        public static void LinkToDataSafe(
            this Vis.Shape visShp,
            int idDataRecordset, int idDataRow)
        {
            // Link to Data:
            if (idDataRecordset > 0 && idDataRow >= 0)
            {
                visShp.LinkToData(idDataRecordset, idDataRow, false);
            }
        }

        public static Vis.Selection NeighboringShapes(
            this Vis.Shape visShp,
            double tolerance_maxWidthOrHeightFraction)
        {
            short rel = (short)Vis.VisSpatialRelationCodes.visSpatialOverlap +
                        (short)Vis.VisSpatialRelationCodes.visSpatialTouching;// +
                                                                                //(short)Vis.VisSpatialRelationCodes.visSpatialContainedIn +
                                                                                //(short)Vis.VisSpatialRelationCodes.visSpatialContainedIn;

            short flags = (short)Vis.VisSpatialRelationFlags.visSpatialBackToFront;

            // Find shapes with a fraction of width, or height, whichever is greater:
            double w, h;
            w = visShp.WidthIU();
            h = visShp.HeightIU();

            double tol = Math.Max(w, h) * tolerance_maxWidthOrHeightFraction;
            Vis.Selection sel = visShp.SpatialNeighbors[rel, tol, flags, Type.Missing];

            return sel;
        }

        /// <summary>
        /// Determines if a shape's pin is at the center of the shape,
        /// which is the case for the vast majority of shapes.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        /// <param name="tol">A percentage of the maximum of the width and height.
        /// An offset from center that is less than this calculation is considered
        /// an offset of zero.</param>
        public static bool IsPinCentered(
            this Vis.Shape visShp,
            out double dx, out double dy, double tol)
        {
            double w, h, lpx, lpy;
            w = visShp.WidthIU();
            h = visShp.HeightIU();
            lpx = visShp.LocPinXIU();
            lpy = visShp.LocPinYIU();

            double dTol = Math.Abs(Math.Max(w, h) * tol);

            dx = w * 0.5 - lpx;
            dy = h * 0.5 - lpy;

            if (Math.Abs(dx) > dTol) return false;
            if (Math.Abs(dy) > dTol) return false;

            return true;
        }

        public static void SetTextSafe(this Vis.Shape visShp, string text)
        {
            // TODO: check locked layer?
            bool bWasTextLocked = (visShp.CellsU["LockTextEdit"].ResultIU != 0);

            string f = String.Empty;
            if (bWasTextLocked)
            {
                f = visShp.CellsU["LockTextEdit"].FormulaU;
                visShp.CellsU["LockTextEdit"].ResultIUForce = 1;
            }

            visShp.Text = text;

            if (bWasTextLocked)
                visShp.CellsU["LockTextEdit"].FormulaForceU = f;
        }

        public static double? TryGetCellResultIU(
            this Vis.Shape visShp,
            string cellname)
        {
            if (visShp == null) return null;
            if (visShp.CellExistsAnywhere(cellname))
                return visShp.Cells[cellname].ResultIU;
            return 0;
        }
        public static short? TryGetCellResultShortOrNull(
            this Vis.Shape visShp,
            string cellname)
        {
            if (visShp.IsNullOrGone()) return null;
            if (visShp.CellExistsAnywhere(cellname) == false) return null;

            Vis.Cell c = visShp.Cells[cellname];
            string f = c.FormulaU;
            f = f.Trim();
            if (String.IsNullOrEmpty(f)) return null;

            // Check for a result that is an empty string, such
            // as "" or a lookup that returns nothing:
            var s = c.ResultStrNoCastU();
            if (String.IsNullOrEmpty(s)) return null;

            return (short)c.ResultIU;
        }
        public static bool TrySetCellResultShort(
            this Vis.Shape visShp,
            string cellname,
            short? valueOrNull)
        {
            if (visShp.IsNullOrGone()) return false;
            if (visShp.CellExistsAnywhere(cellname) == false) return false;

            Vis.Cell c = visShp.Cells[cellname];
            if (valueOrNull == null)
            {
                c.FormulaForceU = String.Empty; // TODO: this could restore an inherited formula...
            }
            else
            {
                c.ResultIUForce = (double)valueOrNull;
            }
            return true;
        }
        public static string TryGetCellResultStr(
            this Vis.Shape visShp,
            string cellname)
        {
            if (visShp == null) return String.Empty;
            if (!visShp.CellExistsAnywhere(cellname)) return String.Empty;
            return visShp.Cells[cellname].ResultStr[Vis.VisUnitCodes.visUnitsString];
        }
        public static bool? TryGetCellResultBool_Nullable(
            this Vis.Shape visShp,
            string cellname)
        {
            if (visShp == null) return null;
            if (!visShp.CellExistsAnywhere(cellname)) return null;

            double val = visShp.Cells[cellname].ResultIU;
            if (val == 0) return false;
            return true;
        }

        public static Vis.Cell CellOrNull(
            this Vis.Shape visShp,
            string cellname)
        {
            if (visShp == null) return null;
            if (!visShp.CellExistsAnywhere(cellname)) return null;
            return visShp.Cells[cellname];
        }


        //public static bool TrySetCellFormulaU(this Vis.Shape shp, string cellname, string formulaU)
        //{
        //    if (_cellExistsAnywhere(shp, cellname))
        //    {
        //        try
        //        {
        //            shp.Cells[cellname].FormulaForceU = formulaU;
        //        }
        //        catch (Exception ex)
        //        {
        //            Console.WriteLine("Error setting formula in _trySetCellFormulaU:\nCell: "
        //                + cellname + "\nFormulaU: " + formulaU + "\n\n" + ex.Message);
        //        }
        //    }
        //}
        public static bool TrySetCellResultU(this Vis.Shape visShp, string cellname, double resultU)
        {
            if (!visShp.CellExistsAnywhere(cellname)) return false;

            try
            {
                visShp.Cells[cellname].ResultIUForce = resultU;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error setting formula in TrySetCellResultU:\nCell: "
                    + cellname + "\nResultU: " + resultU + "\n\n" + ex.Message);
                return false;
            }
        }
        public static bool TrySetCellResultStrU(this Vis.Shape visShp, string cellname, string value, bool wrapInQuotes)
        {
            if (!visShp.CellExistsAnywhere(cellname)) return false;

            string f = value;
            f = f.Replace("\"", "\"\""); // ...in the ShapeSheet, " need to be ""
            if (wrapInQuotes) f = "\"" + f + "\"";

            try
            {
                visShp.Cells[cellname].FormulaForceU = f;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error setting formula in TrySetCellResultStUr:\nCell: "
                    + cellname + "\nResultU: " + value + "\n\n" + ex.Message);
                return false;
            }

        }



        public static bool SectionExists(this Vis.Shape visShp, short sectionIndex)
        {
            return Convert.ToBoolean(
                visShp.SectionExists[sectionIndex, Exists_Anywhere]);
        }

        public static Vis.Section GeometrySectionFirst(this Vis.Shape visShp)
        {
            if (visShp.GeometryCount == 0) return null;
            return visShp.Section[(short)Vis.VisSectionIndices.visSectionFirstComponent];
        }
        public static Vis.Section GeometrySectionLast(this Vis.Shape visShp)
        {
            if (visShp.GeometryCount == 0) return null;
            return visShp.Section[(short)Vis.VisSectionIndices.visSectionLastComponent];
        }

        /// <summary> Wraps visShp.Shapes.ItemFromID in a Try-Catch block, and  
        /// returns null if the shape isn't found.
        /// </summary>
        /// <param name="visShape"></param>
        /// <param name="shapeId"></param>
        /// <returns>A Visio shape object or null if no shape is found.</returns>
        public static Vis.Shape GetShapeByIdSafe(this Vis.Shape visShape, int shapeId)
        {
            if (visShape.Shapes.Count == 0) return null;

            // TODO: some sort of manual loop if there's an error?
            try
            {
                return visShape.Shapes.ItemFromID[shapeId];
            }
            catch (Exception)
            {
                return null;
            }
        }


        public static Vis.Selection ShapesContained(this Vis.Shape visShp)
        {
            short rel = (short)Vis.VisSpatialRelationCodes.visSpatialContain;//.visSpatialContainedIn;
            double tol = 0;
            short flags = (short)Vis.VisSpatialRelationFlags.visSpatialBackToFront;

            Vis.Selection sel = _getSpatialRelatedShapes(visShp, rel, tol, flags);
            return sel;
        }

        public static int TrySetFormulasU(this Vis.Shape shp, string[] cellsAndFormulas)
        {
            return shp.TrySetFormulasU(cellsAndFormulas, string.Empty, string.Empty, string.Empty, string.Empty);
        }
        public static int TrySetFormulasU(this Vis.Shape shp,
            string[] cellsAndFormulas,
            string sParentSheetID)
        {
            return shp.TrySetFormulasU(cellsAndFormulas, sParentSheetID, string.Empty, string.Empty, string.Empty);
        }
        public static int TrySetFormulasU(this Vis.Shape shp,
            string[] cellsAndFormulas,
            string sParentSheetID,
            string sTarget1_SheetID)
        {
            return shp.TrySetFormulasU(cellsAndFormulas, sParentSheetID, sTarget1_SheetID, string.Empty, string.Empty);
        }
        public static int TrySetFormulasU(this Vis.Shape shp,
            string[] cellsAndFormulas,
            string sParentSheetID,
            string sTarget1_SheetID, string sTarget2_SheetID)
        {
            return shp.TrySetFormulasU(cellsAndFormulas, sParentSheetID, sTarget1_SheetID, sTarget2_SheetID, string.Empty);
        }
        public static int TrySetFormulasU(this Vis.Shape shp,
            string[] cellsAndFormulas,
            string sParentSheetID,
            string sTarget1_SheetID, string sTarget2_SheetID, string sTarget3_SheetID)
        {
            // cellsAndFormulas is a one-dimensional array, which alternates
            // between cellname, formula, cellname, formula, etc.
            string c, f;
            int iSuccessfulSets = 0;
            for (int i = 0; i < cellsAndFormulas.Length; i += 2)
            {
                c = cellsAndFormulas[i];
                f = cellsAndFormulas[i + 1];
                f = f.Replace(VisCellExtensions.ParentToken, sParentSheetID);
                f = f.Replace(VisCellExtensions.TargetToken1, sTarget1_SheetID);
                f = f.Replace(VisCellExtensions.TargetToken2, sTarget2_SheetID);
                f = f.Replace(VisCellExtensions.TargetToken3, sTarget3_SheetID);

                if (shp.TryFormulaForceU(c, f))
                {
                    iSuccessfulSets++;
                }
                else
                {
                    Console.WriteLine("Failed to set cell '" + c + "' with formula '" + f + "' in shape '" + shp.ID + "'");
                }
            }
            return iSuccessfulSets;
        }

        // TODO: determine the cause of the failure and return that?
        /// <summary>
        /// Attempts to set a cell with a formulaU in a shape. If it succeeds
        /// then true is returned, otherwise false. The failure could be due
        /// to a non-existent cell or a bad formula.
        /// </summary>
        /// <param name="shp"></param>
        /// <param name="cellname"></param>
        /// <param name="formula"></param>
        /// <returns></returns>
        public static bool TryFormulaForceU(this Vis.Shape shp, string cellname, string formula)
        {
            try
            {
                if (shp.CellExistsAnywhere(cellname))
                {
                    shp.Cells[cellname].FormulaForceU = formula;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        //public static ShapeData ShapeData(this Vis.Shape visShp)
        //{

        //}

        //public static IEnumerable<Vis.Row> ShapeDataRows(this Vis.Shape visShp)
        //{
        //    if (visShp.SectionExists(Sec_Prop) == false) yield break;

        //    Vis.Section sec = visShp.Section[Sec_Prop];
        //    short iRowCt = sec.Count;
        //    for (short iRow = 0; iRow < iRowCt; iRow++)
        //    {
        //        yield return sec[iRow];
        //    }
        //}
        public static VisShapeDataSection ShapeData(this Vis.Shape visShp)
        {
            return new VisShapeDataSection(visShp);
        }
        public static IEnumerable<ShapeDataRow> ShapeDataRows(this Vis.Shape visShp)
        {
            if (visShp.SectionExists(Sec_Prop) == false) yield break;

            Vis.Section sec = visShp.Section[Sec_Prop];
            short iRowCt = sec.Count;
            for (short iRow = 0; iRow < iRowCt; iRow++)
            {
                ShapeDataRow sdr = new ShapeDataRow(sec[iRow]);
                yield return sdr;
            }
        }

        private static Vis.Selection _getSpatialRelatedShapes(Vis.Shape visShp,
                                                                short rel,
                                                                double tol,
                                                                short flags)//TODO: rename
        {
            Vis.Selection sel = visShp.SpatialNeighbors[rel, tol, flags];
            return sel;
        }
        //public static IEnumerable<Vis.Shape> AsEnumerable(this Vis.Shapes shapes)
        //{
        //    int iCt = shapes.Count;
        //    for (int i = 0; i < iCt; i++)
        //    {
        //        yield return shapes[i + 1];
        //    }
        //}

        /// <summary>
        /// Returns the string value of a cell if it exists in the shape.
        /// Otherwise String.Empty is returned.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="cellName"></param>
        public static string ResultString(this Vis.Shape visShp, string cellName)
        {
            if (visShp.CellExistsAnywhere(cellName))
            {
                return visShp.Cells[cellName].ResultStr[Vis.VisUnitCodes.visUnitsString];
            }
            else
            {
                return String.Empty;
            }
        }

        public static double ResultDouble(this Vis.Shape visShp, string cellName)
        {
            if (visShp.CellExistsAnywhere(cellName))
            {
                return visShp.Cells[cellName].ResultIU;
            }
            else
            {
                return double.NaN;
            }
        }

        public static void SetCellInt(this Vis.Shape visShp, string cellName, int value)
        {
            if (visShp.CellExistsAnywhere(cellName))
            {
                visShp.Cells[cellName].ResultIU = value;
            }
        }

        public static void SetUserCellResultIU(this Vis.Shape visShp, string cellName, double value, bool addIfMissing)
        {
            Vis.Cell c = _getUserCell(visShp, cellName, addIfMissing);
            if (c != null)
            {
                c.ResultIU = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="cellName">Cellname with 'User.'</param>
        /// <param name="formulaU">A valid ShapeSheet formula. Supply extra quotes if the
        /// formula is a textual string.</param>
        /// <param name="addIfMissing">Adds a new User-defined row if the shape does not
        /// already have it.</param>
        public static void SetUserCellFormulaU(this Vis.Shape visShp, string cellName, string formulaU, bool addIfMissing)
        {
            Vis.Cell c = _getUserCell(visShp, cellName, addIfMissing);
            if (c != null)
            {
                c.FormulaU = formulaU;
            }
        }

        private static Vis.Cell _getUserCell(Vis.Shape visShp, string cellName, bool addIfMissing)
        {
            // Return the cell if it exists:
            if (visShp.CellExistsAnywhere(cellName))
            {
                return visShp.Cells[cellName];
            }

            if (addIfMissing == false) return null;

            // TODO: alternative method for rowname:
            // Strip anything after the second period (ie: Actions.Bob.SortKey
            // Strip the prefix
            // Return the cell by name after adding the row

            // Analyze cellName, try to add the row, and return the new cell:

            // If the cellname doesn't start with "User.", we're hosed:
            string s = cellName.ToLower();
            if (!s.StartsWith("user.")) return null;

            string rowName = cellName.Substring(5);

            short iCellIndex;
            if (s.EndsWith(".prompt"))
            {
                iCellIndex = (short)Vis.VisCellIndices.visUserPrompt;
                rowName = rowName.Substring(0, rowName.Length - 7);
            }
            else
            {
                iCellIndex = (short)Vis.VisCellIndices.visUserValue;
            }

            // Add the new row:
            short iRow = visShp.AddNamedRow(Sec_User, rowName, RowTag_Default);

            // Return teh cell by S,R,C:
            return visShp.CellsSRC[Sec_User, iRow, iCellIndex];
        }

        #region "Lock and Unlock Methods"

        public static void LockDelete(this Vis.Shape visShp)
        {
            Vis.Cell c = visShp.CellsSRC[Sec_Object, Row_Lock, Cell_LockDelete];
            double v = c.ResultIU;
            if (v == 0) c.ResultIUForce = 1;
        }
        public static void UnlockDelete(this Vis.Shape visShp)
        {
            Vis.Cell c = visShp.CellsSRC[Sec_Object, Row_Lock, Cell_LockDelete];
            double v = c.ResultIU;
            if (v != 0) c.ResultIUForce = 0;
        }

        public static void UnlockLayers(this Vis.Shape visShp)
        {
            for (int i = visShp.LayerCount; i > 0; i--)
            {
                Vis.Layer lyr = visShp.Layer[(short)i];
                lyr.Unlock();
            }
        }

        #endregion


    } // end class



    //    private const short Exists_Anywhere = (short)Vis.VisExistsFlags.visExistsAnywhere;

    //    #region Shape Transform Cells

    //    public static Vis.Cell CellAngle(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormAngle);
    //    }
    //    public static Vis.Cell CellHeight(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormHeight);
    //    }
    //    public static Vis.Cell CellWidth(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormWidth);
    //    }
    //    public static Vis.Cell CellLocPinX(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormLocPinX);
    //    }
    //    public static Vis.Cell CellLocPinY(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormLocPinY);
    //    }
    //    public static Vis.Cell CellPinX(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormPinX);
    //    }
    //    public static Vis.Cell CellPinY(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_ShapeTform,
    //                                (short)Vis.VisCellIndices.visXFormPinY);
    //    }

    //    public static Vis.Cell CellTxtWidth(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_TextTform,
    //                                (short)Vis.VisCellIndices.visXFormWidth);
    //    }
    //    public static Vis.Cell CellTxtHeight(this Vis.Shape shp)
    //    {
    //        return shp.get_CellsSRC(Sec_Object, Row_TextTform,
    //                                (short)Vis.VisCellIndices.visXFormHeight);
    //    }




    //    /// <summary>
    //    /// Returns the value of a Visio cell as a universal Visio string, with 
    //    /// no casting. If the cell doesn't exist string.Empty is returned. Intended
    //    /// for getting string information, not numeric or formularic data.
    //    /// </summary>
    //    /// <param name="shp"></param>
    //    /// <param name="cellname"></param>
    //    /// <returns></returns>
    //    public static string GetCellResultStrU(this Vis.Shape shp, string cellname)
    //    {
    //        // TODO: CellExists vs. CellExistsU
    //        if(shp.get_CellExists(cellname, (short)Vis.VisExistsFlags.visExistsAnywhere) == 0 )
    //        {
    //            return string.Empty;
    //        }
    //        else
    //        {
    //            return shp.get_Cells(cellname).get_ResultStrU((short)Vis.VisUnitCodes.visNoCast);
    //        }
    //    }

    //    public static bool GetCellResultBool(this Vis.Shape shp, string cellname)
    //    {
    //        // TODO: CellExists vs. CellExistsU
    //        if (shp.get_CellExists(cellname, (short)Vis.VisExistsFlags.visExistsLocally) != 0)
    //        {
    //            return false;
    //        }
    //        else
    //        {
    //            double val = shp.get_Cells(cellname).ResultIU;
    //            return (val != 0);
    //        }
    //    }

    //    #endregion

    //    #region Text Block Cells

    //    public enum TextBlockCells
    //    {
    //        LeftMargin, RightMargin, TopMargin, BottomMargin, TextDirection, VerticalAlign, DefaultTabStop, TextBkgndTrans, TextBkgnd
    //    }

    //    public static Vis.Cell CellsTextBlock(this Vis.Shape shp, TextBlockCells textBlockCell)
    //    {
    //        return shp.get_CellsSRC(Sec_Object,
    //                                (short)Vis.VisRowIndices.visRowText,
    //                                (short)textBlockCell);
    //    }

    //    #endregion

    //    #region Sections

    //    public static string[] UserRowNames(this Vis.Shape shp)
    //    {
    //        List<string> s = new List<string>();
    //        for (short i = 0; i < shp.RowCount[Sec_User]; i++)
    //        {
    //            s.Add(shp.get_Section(Sec_User)[i].Name);
    //        }
    //        return s.ToArray();
    //    }
    //    public static string[] UserRowNamesU(this Vis.Shape shp)
    //    {
    //        List<string> s = new List<string>();
    //        for (short i = 0; i < shp.RowCount[Sec_User]; i++)
    //        {
    //            s.Add(shp.get_Section(Sec_User)[i].NameU);
    //        }
    //        return s.ToArray();
    //    }

    //    public static ShapeSheetSections.UserSection CellsUser(this Vis.Shape shp)
    //    {
    //        const int SEC = (short)Vis.VisSectionIndices.visSectionUser;
    //        const int COL_VAL = (short)Vis.VisCellIndices.visUserValue;
    //        const int COL_PROMPT = (short)Vis.VisCellIndices.visUserPrompt;

    //        ShapeSheetSections.UserSection rows = new ShapeSheetSections.UserSection();
    //        //List<Sections.UserRow> rows = new List<Sections.UserRow>();

    //        for(short i = 0; i < shp.RowCount[SEC]; i++)
    //        {
    //            Vis.Cell cVal = shp.get_CellsSRC(SEC, i, COL_VAL);
    //            Vis.Cell cPrompt = shp.get_CellsSRC(SEC, i, COL_PROMPT);

    //            ShapeSheetSections.UserRow r;

    //            r.CellName = cVal.Name;
    //            r.ValueFormula = cVal.Formula;
    //            r.ValueResultStr = cVal.get_ResultStr(Vis.VisUnitCodes.visNoCast);
    //            r.PromptFormula = cPrompt.Formula;
    //            r.PromptResultStr = cPrompt.get_ResultStr(Vis.VisUnitCodes.visNoCast);

    //            rows.Add(r);
    //        }

    //        return rows;            
    //    }

    //    #endregion

    //    #region User Cells

    //    public static void AddUserRow(this Vis.Shape shp,
    //                                  string rowOrCellName)
    //    {
    //        // Check if the row already exists:
    //        if (shp.UserCellExists(rowOrCellName)) return;

    //        shp.AddNamedRow(Sec_User, rowOrCellName._trimUserPrefix(), (short)Vis.VisRowTags.visTagDefault);
    //    }
    //    public static void DeleteUserCellRow(this Vis.Shape shp,
    //                                         string rowOrCellName)
    //    {
    //        if (shp.UserCellExists(rowOrCellName))
    //        {
    //            Vis.Cell c = shp.get_Cells(rowOrCellName);
    //            shp.DeleteRow(c.Section, c.Row);
    //        }
    //    }

    //    /// <summary>
    //    /// Sets a string value to a User row's value cell in a shape. If the cell
    //    /// doesn't exist, it will be created.
    //    /// </summary>
    //    /// <param name="shp"></param>
    //    /// <param name="rowName">Name of user row to set, without the "User." prefix.</param>
    //    /// <param name="formula"></param>
    //    public static void SetUserCell(this Vis.Shape shp, 
    //                                   string rowName,
    //                                   string formula)
    //    {
    //        Vis.Cell userCell = _getOrAddUserCell(shp, rowName);
    //        userCell.FormulaForceU = formula;
    //    }
    //    public static bool UserCellExists(this Vis.Shape shp,
    //                                      string rowOrCellName)
    //    {
    //        string cellName = rowOrCellName._appendUserPrefix();
    //        // TODO: this will work if they pass in User.Cost or Cost, but not User.Cost.Prompt.

    //        if (shp.get_CellExists(cellName, Exists_Anywhere) != 0)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }

    //    private static Vis.Cell _getOrAddUserCell(Vis.Shape shp, string rowOrCellName)
    //    {
    //        // Note: Cell.Name    = "User.Bob"
    //        //       Cell.RowName = "Bob"

    //        string cellName = rowOrCellName._appendUserPrefix();
    //        // TODO: this will work if they pass in User.Cost or Cost, but not User.Cost.Prompt.

    //        if (shp.UserCellExists(rowOrCellName))
    //        {
    //            return shp.get_Cells(cellName);
    //        }
    //        else
    //        {
    //            // Add the non-existent cell:
    //            string rowname = rowOrCellName._trimPrefix("User.");
    //            short newRowIndex = shp.AddNamedRow(Sec_User, rowname, 
    //                (short)Vis.VisRowTags.visTagDefault);

    //            // Return the new cell using SRC:
    //            return shp.get_CellsSRC(Sec_User, newRowIndex, 
    //                (short)Vis.VisRowIndices.visRowUser);
    //        }
    //    }

    //    #endregion


    //    /// <summary>
    //    /// Removes a particular geometry section from a shape.
    //    /// </summary>
    //    /// <param name="shp"></param>
    //    /// <param name="geoSectionIndex">The one-based geometry section to remove.</param>
    //    public static void DeleteGeometry(this Vis.Shape shp, short geoSectionIndex)
    //    {
    //        // Check geoSectionIndex for limiting cases.

    //        // geoSectionIndex is 1-based, so 0 or less is bad:
    //        if (geoSectionIndex < 1) return;

    //        // geoSectionIndex can't be bigger than the number of 
    //        // geometry sections!
    //        if (shp.GeometryCount < geoSectionIndex) return;

    //        short section = (short)(Vis.VisSectionIndices.visSectionFirstComponent + geoSectionIndex - 1);
    //        shp.DeleteSection(section);
    //    }

    //    #region "Group"
    //    public static Vis.Shape ContainingShape_TopMost(this Vis.Shape shp)
    //    {
    //        return _getTopmostContainingShape(shp);
    //    }
    //    private static Vis.Shape _getTopmostContainingShape(Vis.Shape shp)
    //    {
    //        if (shp.ContainingShape != shp.ContainingPage.PageSheet)
    //        {
    //            return _getTopmostContainingShape(shp.ContainingShape);
    //        }
    //        else
    //        {
    //            return shp;
    //        }
    //    }

    //    public static bool IsGroup(this Vis.Shape shp)
    //    {
    //        if (shp.Type == (short)Vis.VisShapeTypes.visTypeGroup)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }

    //    #endregion

    //    #region TextUtils

    //    private static string _appendPrefix(this string value, string prefix)
    //    {
    //        if (value.IndexOf(prefix, StringComparison.InvariantCultureIgnoreCase) != 0)
    //        {
    //            return prefix + value;
    //        }
    //        else
    //        {
    //            return value;
    //        }
    //    }
    //    private static string _appendUserPrefix(this string value)
    //    {
    //        return _appendPrefix(value, "User.");
    //    }
    //    private static string _appendPropPrefix(this string value)
    //    {
    //        return _appendPrefix(value, "Prop.");
    //    }

    //    private static string _trimPrefix(this string value, string prefix)
    //    {
    //        if (value.IndexOf(prefix, StringComparison.InvariantCultureIgnoreCase) == 0)
    //        {
    //            return value.Substring(prefix.Length);
    //        }
    //        else
    //        {
    //            return value;
    //        }
    //    }
    //    private static string _trimPropPrefix(this string value)
    //    {
    //        return value._trimPrefix("Prop.");
    //    }
    //    private static string _trimUserPrefix(this string value)
    //    {
    //        return value._trimPrefix("User.");
    //    }

    //    #endregion
    //}

}
