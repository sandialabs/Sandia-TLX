﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visguy.VisAddinLib.Extensions
{
    public static class StringExtensions
    {
        public static bool StartsWith_CaseInsensitiveInvariant(
            this string thisText, string value)
        {
            string t = thisText.ToLower();
            string v = value.ToLower();
            return t.StartsWith(v, StringComparison.InvariantCultureIgnoreCase);
        }

        public static List<string> MissingItemsFromCsvList_CaseInsensitive(
            this List<string> stringList, string csvList)
        {
            var missingItems = new List<string>();

            string[] csvItems = csvList.Split(',');
            foreach (string csvItem in csvItems)
            {
                if (stringList.ContainsItem_CaseInsensitive(csvItem) == false)
                    missingItems.Add(csvItem);
            }
            return missingItems;
        }

        public static bool ContainsAllCsvItems_CaseInsensitive(
            this List<string> stringList, string csvList)
        {
            string[] csvItems = csvList.Split(',');
            foreach(string csvItem in csvItems)
            {
                if (stringList.ContainsItem_CaseInsensitive(csvItem) == false) return false;
            }
            return true;
        }

        public static bool ContainsItem_CaseInsensitive(
            this List<string> stringList, string itemSought)
        {
            return (stringList.FindIndex(s => s.Equals(itemSought,
                        StringComparison.OrdinalIgnoreCase)) != -1);
        }

        public static void AddUnique_CaseInsensitive(
            this List<string> stringList, 
            string item)
        {
            if (!stringList.ContainsItem_CaseInsensitive(item))
                stringList.Add(item);
        }

        public static string ToStringCsv(
            this List<string> stringList, 
            string prefix, string suffix,
            string itemPrefix, string itemSuffix,
            bool trimItems)
        {
            var sb = new StringBuilder(prefix);
            for (int i = 0; i < stringList.Count; i++)
            {
                string s = stringList[i];

                // Trim it:
                if (trimItems) s = s.Trim();
                
                // Prefix/suffix it:
                s = itemPrefix + s + itemSuffix;

                // Prepend a comma:
                if (i > 0) s = "," + s;

                sb.Append(s);
            }
            sb.Append(suffix);

            return sb.ToString();
        }
    }
}
