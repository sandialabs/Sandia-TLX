﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;


namespace Visguy.VisAddinLib.Extensions
{
    public static class VisLayerExtensions
    {
        private const short LyrCell_Lock = (short)Vis.VisCellIndices.visLayerLock;
        private const short LyrCell_Visible = (short)Vis.VisCellIndices.visLayerVisible;


        public static bool IsLocked(this Vis.Layer visLyr)
        {
            double v = visLyr.CellsC[LyrCell_Lock].ResultIU;
            return (v != 0);
        }
        public static void Unlock(this Vis.Layer visLyr)
        {
            double v = visLyr.CellsC[LyrCell_Lock].ResultIU;
            if (v != 0)
                visLyr.CellsC[LyrCell_Lock].ResultIUForce = 0;
        }
        public static void Lock(this Vis.Layer visLyr)
        {
            double v = visLyr.CellsC[LyrCell_Lock].ResultIU;
            if (v == 0)
                visLyr.CellsC[LyrCell_Lock].ResultIUForce = 1;
        }

        public static void Show(this Vis.Layer visLyr)
        {
            double v = visLyr.CellsC[LyrCell_Visible].ResultIU;
            if (v == 0)
                visLyr.CellsC[LyrCell_Visible].ResultIUForce = 1;
        }
        public static void Hide(this Vis.Layer visLyr)
        {
            double v = visLyr.CellsC[LyrCell_Visible].ResultIU;
            if (v != 0)
                visLyr.CellsC[LyrCell_Visible].ResultIUForce = 0;
        }
    }
}
