﻿using Vis = Microsoft.Office.Interop.Visio;

namespace Visguy.VisAddinLib.Extensions
{
    public static class VisConnectExtensions
    {
        /// <summary>
        /// Finds the shapes at other ends of connectors attached
        /// to a shape, and satisfying various connector and shape
        /// filters.
        /// </summary>
        /// <param name="visShp"></param>
        /// <param name="connectorUserClassValues"></param>
        /// <param name="incomingUserClassValues"></param>
        /// <param name="outgoingUserClassValues"></param>
        /// <param name="visSelIncoming"></param>
        /// <param name="visSelOutgoing"></param>
        public static void ConnectedShapes(
            this Vis.Shape visShp, 
            string[] connectorUserClassValues,
            string[] incomingUserClassValues,
            string[] outgoingUserClassValues,
            out Vis.Selection visSelIncoming,
            out Vis.Selection visSelOutgoing)
        {
            // TODO: refactor to get rid of the duplicate code...

            // Initialize the selections:
            visSelIncoming = visShp.CreateEmptySelection();
            visSelOutgoing = visShp.CreateEmptySelection();

            // Get incoming connectors that qualify:
            Vis.Selection selIncConns = visShp.IncomingConnectors();
            selIncConns.FilterByUserClasses(connectorUserClassValues);
            foreach(Vis.Shape shpConnInc in selIncConns)
            {
                // Get the shape at the other end:
                Vis.Shape shpFrom = shpConnInc.ShapeGluedTo_1dBegin();
                if(shpFrom != null)
                {
                    // Select it if it qualifies:
                    if (shpFrom.IsClass(incomingUserClassValues))
                        visSelIncoming.Select(shpFrom);
                }
            }

            // Get outgoing connectors that qualify:
            Vis.Selection selOutConns = visShp.OutgoingConnectors();
            selOutConns.FilterByUserClasses(connectorUserClassValues);
            foreach (Vis.Shape shpConnOut in selOutConns)
            {
                // Get the shape at the other end:
                Vis.Shape shpTo = shpConnOut.ShapeGluedTo_1dEnd();
                if (shpTo != null)
                {
                    // Select it if it qualifies:
                    if (shpTo.IsClass(incomingUserClassValues))
                        visSelOutgoing.Select(shpTo);
                }
            }
        }

        public static Vis.Selection IncomingConnectors(this Vis.Shape visShp)
        {
            return visShp.ConnectorsByFromPart(Vis.VisFromParts.visEnd);
        }
        public static Vis.Selection OutgoingConnectors(this Vis.Shape visShp)
        {
            return visShp.ConnectorsByFromPart(Vis.VisFromParts.visBegin);
        }

        public static Vis.Selection ConnectorsByFromPart(
            this Vis.Shape visShp, Vis.VisFromParts fromPart)
        {
            Vis.Selection sel = visShp.CreateEmptySelection();
            Vis.Connects conns = visShp.FromConnects;
            foreach (Vis.Connect conn in conns)
            {
                if (conn.FromPart == (short)fromPart)
                {
                    sel.Select(conn.FromSheet);
                }
            }
            return sel;
        }

        /// <summary>
        /// Gets the shape to which a 1D shape's Begin is glued to.
        /// </summary>
        /// <param name="visShpConnector"></param>
        /// <returns></returns>
        public static Vis.Shape ShapeGluedTo_1dBegin(
            this Vis.Shape visShpConnector)
        {
            if (visShpConnector.Is1D() == false) return null;

            Vis.Connects conns = visShpConnector.Connects;
            if (conns.Count == 0) return null;

            foreach (Vis.Connect conn in conns)
            {
                if (conn.FromPart == (short)Vis.VisFromParts.visBegin)
                {
                    return conn.ToSheet;
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the shape to which a 1D shape's End is glued to.
        /// </summary>
        /// <param name="visShpConnector"></param>
        /// <returns></returns>
        public static Vis.Shape ShapeGluedTo_1dEnd(
            this Vis.Shape visShpConnector)
        {
            if (visShpConnector.Is1D() == false) return null;

            Vis.Connects conns = visShpConnector.Connects;
            if (conns.Count == 0) return null;

            foreach (Vis.Connect conn in conns)
            {
                if (conn.FromPart == (short)Vis.VisFromParts.visEnd)
                {
                    return conn.ToSheet;
                }
            }
            return null;
        }
    }
}
