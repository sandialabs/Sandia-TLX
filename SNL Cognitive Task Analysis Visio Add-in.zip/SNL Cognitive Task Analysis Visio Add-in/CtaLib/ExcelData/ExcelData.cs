﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

//using Vis = Microsoft.Office.Interop.Visio;
using System.Diagnostics;
//using VisioSolution.App.Extensions;
using ODB = System.Data.OleDb;
using Visguy.VisAddinLib.Extensions;


// TODO: what does System.Data get us instead?
// Reference: Microsoft ActiveX Data Objects 6.1 Library 
//using ADODB; 

// Microsoft Access Database Engine 2010 Redistributable
// http://www.microsoft.com/en-us/download/details.aspx?id=13255
//
// RE: this error:
// "Additional information: The 'Microsoft.ACE.OLEDB.12.0' provider is not registered on the local machine."
// http://social.msdn.microsoft.com/Forums/en-US/1d5c04c7-157f-4955-a14b-41d912d50a64/how-to-fix-error-the-microsoftaceoledb120-provider-is-not-registered-on-the-local-machine

namespace Visguy.VisAddinLib.ExcelData
{
    // TODO: make one that gets initialized with the file, and
    // doesn't have static functions.
    // Maybe "ExcelDatabase" vs "ExcelDataFunctions


    // Note: read code works with Excel file open, seems a bit slower, though.

    // TODO: rename this puppy
    public class ExcelData
    {
        // TODO: add functions to get other bits of data...
        // TODO: add functions to write data...

        public static string LastError = String.Empty;

        // Connection string template:

        private const string ConnStringToken_DataFile = "[DATAFILENAME]";

        private const string connectionstringOleDb_Read = 
            "Provider=Microsoft.ACE.OLEDB.12.0;" +
            "User ID=Admin;" +
            "Data Source=[DATAFILENAME];" + 
            "Mode=Read;" +
            "Extended Properties=\"HDR=YES;IMEX=1;MaxScanRows=0;Excel 12.0;\";" +
            "Jet OLEDB:Engine Type=34;";
        //ReadOnly=True/False...?

        //Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Book1.xls;Extended Properties="Excel 8.0;HDR=YES;"

        // Solution for avoiding the "Operation must use an updateable query." error:
        // http://stackoverflow.com/questions/7622492/operation-must-use-an-updateable-query-when-updating-excel-sheet
        // Removed the IMEX and MaxScanRows stuff, plus added ReadOnly=False.
        //;MaxScanRows=0
        private const string connectionstringOleDb_Write =
            "Provider=Microsoft.ACE.OLEDB.12.0;" +
            "Data Source=[DATAFILENAME];" +
            "Extended Properties=\"HDR=YES;ReadOnly=False;Excel 12.0;\";" +
            "Jet OLEDB:Engine Type=34;";
        // Removed ;IMEX=1


        // Error: "Operation must use an updateable query"
        // http://stackoverflow.com/questions/7622492/operation-must-use-an-updateable-query-when-updating-excel-sheet
        private const string connectionstringOldDb_NoImex =
            "Provider=Microsoft.ACE.OLEDB.12.0;" +
            "User ID=Admin;" +
            "Data Source=[DATAFILENAME];" +
            "Mode=Read;" +
            "Extended Properties=\"HDR=YES;MaxScanRows=0;Excel 12.0;\";" +
            "Jet OLEDB:Engine Type=34;";

        //private const string connectionstringAdoNet =
        //      "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=[DATAFILENAME];Extended Properties='Excel 12.0 Xml;HDR=[HDR]';";
        //Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Book1.xls;Extended Properties="Excel 8.0;HDR=YES;"

        private const string ignoreTableName1 = "_FilterDatabase";

        public static string GetExcelConnectionString(string excelFilepath)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);
            return sConn;
        }


        public static List<String> GetColumnNames(string excelFilepath, string tableName)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            List<String> cols = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {
                conn.Open();

                DataTable tableColumns = conn.GetOleDbSchemaTable(
                    ODB.OleDbSchemaGuid.Columns, new object[] { null, null, tableName, null });
                foreach (DataRow row in tableColumns.Rows)
                {
                    cols.Add( row["COLUMN_NAME"].ToString());             
                } 

                conn.Close();
            }

            return cols;


            //// Query Excel for the tables:
            //string sConn = "Provider=Microsoft.ACE.OLEDB.12.0;" +
            //               "User ID=Admin;" +
            //               "Data Source=" + excelFilepath + ";" +
            //               "Mode=Read;" +
            //               "Extended Properties=\"HDR=YES;IMEX=1;MaxScanRows=0;Excel 12.0;\";" +
            //               "Jet OLEDB:Engine Type=34;";

            //ADODB.Connection conn = new ADODB.Connection();
            //conn.Open(sConn);
            //ADODB.Recordset rsTableNames = conn.OpenSchema(ADODB.SchemaEnum.adSchemaTables, Type.Missing, Type.Missing);
            //do
            //{
            //    string sTableName = rsTableNames.Fields["table_name"].Value;
            //    sTableNames.Add(sTableName);
            //    rsTableNames.MoveNext();

            //} while (!rsTableNames.EOF);

            //rsTableNames.Close();
            //conn.Close();
        }

        public static DataTable GetDataTable(string excelFilepath, string tableName)
            //out bool bFileNotFound, out bool bTableNotFound)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            string sql = "SELECT * FROM [" + tableName + "]"; // \n" +
                         //"WHERE [" + columnName + "]='" + columnValue + "'";

            //List<String> vals = new List<string>();

            
            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {

                ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);

                conn.Open();

                // TODO: make a data-table version of this proc, using this:
                var adptr = new ODB.OleDbDataAdapter(sql, conn);
                DataTable dtbl = new DataTable();
                adptr.Fill(dtbl);
                adptr.Dispose();

                return dtbl;
            }
         
        }


        public static List<string> GetRowsCSV(string excelFilepath, string tableName, string columnName, string columnValue)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            string sql = "SELECT * FROM [" + tableName + "] \n" +
                         "WHERE [" + columnName + "]='" + columnValue + "'";

            List<String> vals = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {

                ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);

                conn.Open();


                // TODO: make a data-table version of this proc, using this:
                //ODB.OleDbDataAdapter a = new ODB.OleDbDataAdapter(cmd); // "Select * from " + tableName, conn);
                //DataTable dt = new DataTable();
                //a.Fill(dt);

                var reader = cmd.ExecuteReader();
                int iFieldCt = reader.FieldCount;
                while (reader.Read())
                {

                    string csv = String.Empty; // String.Join(",", reader);
                    for (int i = 0; i < iFieldCt; i++)
                    {
                        if (csv.Length > 0) csv += ",";
                        csv += reader[i].ToString();
                    }
                    //Console.WriteLine(reader[0].ToString());
                    //vals.Add(reader[0].ToString());
                    vals.Add(csv);
                }
                reader.Close();
            }

            return vals;
        }

        public static List<string> GetRowsLikeCSV(string excelFilepath, string tableName, string columnName, string columnValue)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            string sql = "SELECT * FROM [" + tableName + "] \n" +
                         "WHERE [" + columnName + "] LIKE '" + columnValue + "'";

            List<String> vals = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {

                ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);

                conn.Open();

                var reader = cmd.ExecuteReader();
                int iFieldCt = reader.FieldCount;
                while (reader.Read())
                {

                    string csv = String.Empty; // String.Join(",", reader);
                    for (int i = 0; i < iFieldCt; i++)
                    {
                        if (csv.Length > 0) csv += ",";
                        csv += reader[i].ToString();
                    }
                    vals.Add(csv);
                }
                reader.Close();
            }

            return vals;
        }

        public static List<String>GetDistinctColumnValues(
            string excelFilepath, string tableName, string columnName)
        {
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            string sql = "SELECT DISTINCT [" + columnName + "] FROM [" + tableName + "]";
            //string sql = "SELECT * FROM [" + tableName + "]";

            List<String> vals = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {

                ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);

                conn.Open();
                
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine(reader[0].ToString());
                    vals.Add(reader[0].ToString());
                }
                reader.Close();
            }

            return vals;

            // VBA:
            //Set m_dbconn = m_getExcelConnection(m_pathToExcelFile, True)

            //Dim sql As String
            //sql = "Select * from [" & tableName & "]"

            //Set m_rsQuery = New ADODB.Recordset
            //m_rsQuery.Source = sql
            //m_rsQuery.ActiveConnection = m_dbconn
            //m_rsQuery.CursorType = ADODB.CursorTypeEnum.adOpenStatic
            //m_rsQuery.Open

            //Set GetData = m_rsQuery
        }

        public static Dictionary<string, List<string>>GetTableAndColumnNames(
            string excelFilepath)
        {
            Dictionary<string, List<string>> tblscols = new Dictionary<string, List<string>>();

            List<string> sTableNames = new List<string>();
            if (System.IO.File.Exists(excelFilepath) == false) return tblscols;

            // Query Excel for the tables:
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            // Connect to data:
            ODB.OleDbConnection conn = new ODB.OleDbConnection();
            conn.ConnectionString = sConn;
            conn.Open();
            
            // Get the tables:
            System.Data.DataTable dtSchemaTable =
                conn.GetOleDbSchemaTable(ODB.OleDbSchemaGuid.Tables,
                    new Object[] { null, null, null, "TABLE" });
            // See: http://support.microsoft.com/kb/309681 for the explanation of the new Object[] stuff above.


            // Create dict entries using the table names:
            for (int i = 0; i < dtSchemaTable.Rows.Count; i++)
            {
                // Add the key, and a new, empty string collection:
                string sTableName = dtSchemaTable.Rows[i].ItemArray[2].ToString();
                if (_ignoreTable(sTableName) == false)
                    tblscols.Add(sTableName, new List<string>());

                // For Excel, we could trim leading/trailing apostrophes,
                // and trailing $. Sample table names = 
                // Customer$ 'Invoice Generator$', which correspond to worksheets.
                // Named ranges don't have $. Although there is one exception:
                // 'Invoice Generator'$Print_Area
            }

            // Now get the columns for each table:
            foreach(string key in tblscols.Keys)
            {
                DataTable tableColumns = conn.GetOleDbSchemaTable(
                    ODB.OleDbSchemaGuid.Columns, new object[] { null, null, key, null });
                
                foreach (DataRow row in tableColumns.Rows)
                {
                    string sColName = row["COLUMN_NAME"].ToString();
                    tblscols[key].Add(sColName);               
                }
            }

            conn.Close();
            
            return tblscols;
        }

        public static string GetTableAndColumnNames_TextBlock(
            string excelFilePath, string indent1, string indent2)
        {
            Dictionary<string, List<string>> tablesColumnNames = 
                GetTableAndColumnNames(excelFilePath);

            // Dump the table and column names:
            StringBuilder sb = new StringBuilder();
            foreach (string tbl in tablesColumnNames.Keys)
            {
                sb.AppendLine(indent1 + "Table: " + tbl);
                var cols = tablesColumnNames[tbl];
                foreach (string col in cols)
                    sb.AppendLine(indent1 + indent2 + col);

            }
            return sb.ToString();
        }
        public static List<String> GetTableNames(string excelFilepath )
        {            
            List<string> sTableNames = new List<string>();
            if (System.IO.File.Exists(excelFilepath) == false) return sTableNames;

            // Query Excel for the tables:
            string sConn = connectionstringOleDb_Read.Replace(ConnStringToken_DataFile, excelFilepath);

            //string sConn = "Provider=Microsoft.ACE.OLEDB.12.0;" +
            //               "User ID=Admin;" +
            //               "Data Source=" + excelFilepath + ";" +
            //               "Mode=Read;" +
            //               "Extended Properties=\"HDR=YES;IMEX=1;MaxScanRows=0;Excel 12.0;\";" +
            //               "Jet OLEDB:Engine Type=34;";

            //sConn = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excelFilepath + ";Extended Properties=\"Excel 12.0 Xml;HDR=YES\""; 

            ODB.OleDbConnection conn = new ODB.OleDbConnection();
            conn.ConnectionString = sConn;
            conn.Open();
            
            System.Data.DataTable dtSchemaTable = 
                conn.GetOleDbSchemaTable(ODB.OleDbSchemaGuid.Tables, 
                    new Object[] { null, null, null, "TABLE" });
            // See: http://support.microsoft.com/kb/309681 for the explanation of the new Object[] stuff above.


            for (int i = 0; i < dtSchemaTable.Rows.Count; i++)
            {
                string sTableName = dtSchemaTable.Rows[i].ItemArray[2].ToString();
                
                if (_ignoreTable(sTableName) == false)
                    sTableNames.Add(sTableName);

                // For Excel, we could trim leading/trailing apostrophes,
                // and trailing $. Sample table names = 
                // Customer$ 'Invoice Generator$', which correspond to worksheets.
                // Named ranges don't have $. Although there is one exception:
                // 'Invoice Generator'$Print_Area

            }

            //System.Data.DataSet rsTableNames = conn.OpenSchema(ADODB.SchemaEnum.adSchemaTables, Type.Missing, Type.Missing);
            //do
            //{
            //    string sTableName = dtSchemaTable. .Fields["table_name"].Value;
            //    string sTableName = rsTableNames.Fields["table_name"].Value;
            //    sTableNames.Add(sTableName);
            //    rsTableNames.MoveNext();

            //} while (!rsTableNames.EOF);

            //rsTableNames.Close();
            conn.Close();

            return sTableNames;
        }
        public static List<string> GetQualifyingExcelTables(
            string excelFilepath, List<string> requiredColumnNames)
        {
            List<string> tableNames = new List<string>();

            // Get the batch of table names and column names:
            Dictionary<string, List<string>> tblscols = GetTableAndColumnNames(excelFilepath);

            // Search each table for a match:
            foreach (string key in tblscols.Keys)
            {
                bool bTableQualifies = true;

                List<string> cols = tblscols[key];
                if(cols.Count < requiredColumnNames.Count)
                {
                    bTableQualifies = false;
                }
                else
                {
                    foreach (string col in requiredColumnNames)
                    {
                        if ( ! cols.Contains(col) )
                        {
                            bTableQualifies = false;
                            break;
                        }
                    }
                }

                if (bTableQualifies) tableNames.Add(key);
            }

            return tableNames;
        }

        public static List<string> GetQualifyingExcelTables(
            string excelFilepath, List<string> requiredColumnNames,
            out string nonqualifyingDetails)
        {
            // This method exhaustively looks at every column
            // in every table, and lists the missing columns for
            // each table.

            nonqualifyingDetails = string.Empty;

            List<string> tableNames = new List<string>();

            // Get the batch of table names and column names:
            Dictionary<string, List<string>> tblscols = GetTableAndColumnNames(excelFilepath);

            // Search each table for a match:
            foreach (string key in tblscols.Keys)
            {
                bool bTableQualifies = true;

                // Create a copy of the required fields:
                //List<string> rcs = requiredColumnNames.ToList();

                List<string> cols = tblscols[key];
                Debug.WriteLine("Check table '" + key + "'");

                // Find out which names aren't in cols:
                //IEnumerable<string> differenceQuery = requiredColumnNames.Except<string>(cols); // .Except(cols);
                IEnumerable<string> differenceQuery = requiredColumnNames.Except(cols);

                // Report the missing column information:
                List<string> missingCols = new List<string>();
                foreach (string missingCol in differenceQuery)
                {
                    missingCols.Add("'" + missingCol + "'");
                    bTableQualifies = false;
                }

                if (missingCols.Count > 0)
                {
                    if (nonqualifyingDetails.Length > 0) nonqualifyingDetails += "\n";
                    nonqualifyingDetails += "Table '" + key + "' missing " + missingCols.Count + " columns: \n" +
                        string.Join(", ", missingCols) + "\n";
                }

                if (bTableQualifies) tableNames.Add(key);
            }

            Debug.WriteLine(nonqualifyingDetails);

            return tableNames;
        }


        public static void InsertRow(
            string excelFilepath, string tableName, 
            List<string> columnNames, List<string> columnValues)
        {
            LastError = String.Empty;
            
            // Note: this works when Excel is open!
            string sConn = connectionstringOleDb_Write.Replace(ConnStringToken_DataFile, excelFilepath);

            // Also, since we've got no primary key, duplicate rows can be
            // added, so the consumer needs to know to check before hand
            // if a row exists or not.

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            //string sql = "SELECT DISTINCT [" + columnName + "] FROM [" + tableName + "]";
            //string sql = "SELECT * FROM [" + tableName + "]";

            // Make comma-separated lists of the column names and values,
            // wrapped with single quote marks:
            string colNamesCsv = columnNames.ToStringCsv("[", "]", "'", "'", true);
            string colValsCsv = columnValues.ToStringCsv("[", "]", "'", "'", true);

            Debug.WriteLine(colNamesCsv);
            Debug.WriteLine(colValsCsv);

            //string colNames = String.Empty;
            //foreach(string cn in columnNames)
            //{
            //    if (colNames.Length > 0) colNames += ",";
            //    colNames += "[" + cn + "]";
            //}
            //string colVals = String.Empty;
            //foreach (string cv in columnValues)
            //{
            //    if (colVals.Length > 0) colVals += ",";
            //    colVals += "'" + cv + "'";
            //}

            string sql = "INSERT INTO [" + tableName + "] \n" + 
                         "(" + colNamesCsv + ") \n" +
                         "VALUES(" + colValsCsv + ")";

            // TODO: make an update procedure that takes 'where key = value' as parameters.
            // Side experiment to do updates:
            // This works:
            //sql = "UPDATE [" + tableName + "] SET [Physical Demand]='Phys Demand 501' WHERE [Task Number]='Test 501'";
            //"UPDATE [Sheet1$] "+"SET [Number]=" +s.Trim()+ " WHERE [Number]=" + s2.Trim() ;

            List<String> vals = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {
               
                Debug.WriteLine(sql);
                ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);

                conn.Open();

                cmd.ExecuteNonQuery();
             
            }
        }


        // TODO: some notes about brackets and trailing $ signs and single quotes

        public static bool WriteDataToExcel(
            string excelFilepath,
            string tablename,
            ExcelWriteData ewdData)
        {
            string procname = nameof(ExcelData) + "." + nameof(WriteDataToExcel);

            LastError = String.Empty;

            // Note: this works when Excel is open, which
            // is pretty durn cool.
            string sConn = connectionstringOleDb_Write.Replace(ConnStringToken_DataFile, excelFilepath);
            //string sConn = connectionstringOldDb_NoImex.Replace(ConnStringToken_DataFile, excelFilepath);

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {
                try
                {
                    conn.Open();

                    List<string> sqls = null;

                    // Inserts:
                    sqls = ewdData.InsertStatementBlock(tablename);
                    foreach (var sql in sqls)
                    {
                        var cmd = conn.CreateCommand();
                        cmd.CommandText = sql;

                        
                        //cmd.Parameters.Add("columnname", System.Data.OleDb.OleDbType.BSTR);
                        //cmd.Parameters["columnname"].Value = "value";
                        //OleDbCommand cmd = new OleDbCommand(qry, cnn);
                        //cmd.Parameters.Add("datenow", OleDbType.Date);
                        //cmd.Parameters["datenow"].Value = DateTime.Now;

                        Debug.WriteLine(sql);

                        cmd.ExecuteNonQuery();
                    }

                    // Updates:
                    sqls = ewdData.UpdateStatementBlock(tablename);
                    foreach (var sql in sqls)
                    {
                        var cmd = conn.CreateCommand();
                        cmd.CommandText = sql;

                        Debug.WriteLine(sql);

                        cmd.ExecuteNonQuery();
                    }

                    // Deletes:
                    // TODO:

                }
                catch (Exception ex)
                {                    
                    LastError = procname + ": " + ex.Message;
                    return false;
                }
            }

            return true;
        }

        public static bool UpdateSingleRow(
            string excelFilepath, string tableName,
            string keyName, string keyValue,
            List<string> columnNames, List<string> columnValues)
        {
            LastError = String.Empty;

            // Note: it is ok if the keyName is part
            // of columnNames. In this case you are 
            // renaming the key. This could be dangerous,
            // but hey, this is Excel...

            // Note: this works when Excel is open, which
            // is pretty durn cool.
            string sConn = connectionstringOleDb_Write.Replace(ConnStringToken_DataFile, excelFilepath);

            // Also, since we've got no primary key, duplicate rows can be
            // added, so the consumer needs to know to check before hand
            // if a row exists or not.

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            //string sql = "SELECT DISTINCT [" + columnName + "] FROM [" + tableName + "]";
            //string sql = "SELECT * FROM [" + tableName + "]";

            // Make comma-separated lists of the column names and values,
            // wrapped with single quote marks:

            if(columnNames.Count != columnValues.Count)
            {
                LastError = "ExcelData.UpdateSingleRow: Column name and value arrays are not the same size!";
                Debug.WriteLine(LastError);
                return false;
            }

            string sql = _getUpdateStatement(tableName, keyName, keyValue, columnNames, columnValues);

            Debug.WriteLine("ExcelData.UpdateSingleRow, execute sql command:");
            Debug.WriteLine(sql);

            // The WHERE clause will cause all duplicates to be updated, which is good, I suppose!

            List<String> vals = new List<string>();

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {
                try
                {
                    ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    LastError = "ExcelData.UpdateRow: " + ex.Message;
                    return false;
                    //throw;
                }
            }

            return true;
        }

        public static bool UpdateMultipleRows(
            string excelFilepath, string tableName,
            List<string> keyNames, List<string> keyValues,
            List<List<string>> columnNameArrays, List<List<string>> columnValueArrays)
        {
            string procname = nameof(ExcelData) + "." + nameof(UpdateMultipleRows);

            LastError = String.Empty;

            // Note: it is ok if the keyName is part
            // of columnNames. In this case you are 
            // renaming the key. This could be dangerous,
            // but hey, this is Excel...

            // Note: this works when Excel is open, which
            // is pretty durn cool.
            string sConn = connectionstringOleDb_Write.Replace(ConnStringToken_DataFile, excelFilepath);

            // Also, since we've got no primary key, duplicate rows can be
            // added, so the consumer needs to know to check before hand
            // if a row exists or not.

            // Without the brackets around the column name, the query
            // will fail (at least for columns with spaces...?)
            //string sql = "SELECT DISTINCT [" + columnName + "] FROM [" + tableName + "]";
            //string sql = "SELECT * FROM [" + tableName + "]";

            // Make comma-separated lists of the column names and values,
            // wrapped with single quote marks:

            int iCt = keyNames.Count;
            if ( (iCt != keyValues.Count ||
                  iCt != columnNameArrays.Count ||
                  iCt != columnValueArrays.Count) )
            {
                LastError = procname + ": key, key-value, column-name and value arrays are not all the same size!";
                Debug.WriteLine(LastError);
                return false;
            }

            //var sbSqlBlock = new StringBuilder();
            //string sqlBlock = String.Empty;
            var sqls = new List<string>();
            for (int i = 0; i < iCt; i++)
            {
                // Get an individual "UPDATE" row
                var keyName = keyNames[i];
                var keyValue = keyValues[i];
                var columnNames = columnNameArrays[i];
                var columnValues = columnValueArrays[i];

                string sqlRow = 
                    _getUpdateStatement(tableName, keyName, keyValue, columnNames, columnValues);

                if( ! String.IsNullOrEmpty(sqlRow)) // TODO: we are swallowing failed sql rows...
                {
                    //if ( ! String.IsNullOrEmpty(sqlBlock))
                      //  sqlBlock += "\n";
                    //sbSqlBlock.AppendLine(sqlRow);
                    //sqlBlock += sqlRow;
                    sqls.Add(sqlRow);
                }
            }

            //string sqlBlock = sbSqlBlock.ToString().Trim();

            //Debug.WriteLine(procname + ", execute sql command:");
            //Debug.WriteLine(sqlBlock);

            // The WHERE clause will cause all duplicates to be updated, which is good, I suppose!

            using (ODB.OleDbConnection conn = new ODB.OleDbConnection(sConn))
            {
                try
                {
                    conn.Open();
                    foreach(var sql in sqls)
                    {
                        var cmd = conn.CreateCommand();
                        cmd.CommandText = sql;
                        //ODB.OleDbCommand cmd = new ODB.OleDbCommand(sql, conn);                    
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    LastError = procname + ": " + ex.Message;
                    return false;
                }
            }

            return true;
        }

        private static string _getUpdateStatement(
            string tableName,
            string keyName, string keyValue,
            List<string> columnNames, List<string> columnValues)
        {
            if (columnNames.Count != columnValues.Count)
            {
                LastError = "ExcelData._getUpdateStatement: Column name and value arrays are not the same size!";
                Debug.WriteLine(LastError);
                return String.Empty;
            }

            // Syntax:
            //  UPDATE table_name
            //  SET column1 = value1, column2 = value2,...
            //  WHERE some_column = some_value;
            //
            // Example:
            //  UPDATE Customers
            //  SET ContactName = 'Alfred Schmidt', City = 'Hamburg'
            //  WHERE CustomerName = 'Alfreds Futterkiste';

            // Build a "name=value" list. Put braces around the names
            // in case they are multi-word/space-containing. Put
            // single-quotes around the values:
            string nameValueList = String.Empty;
            for (int i = 0; i < columnNames.Count; i++)
            {
                if (i > 0) nameValueList += ", ";

                string n = "[" + columnNames[i] + "]";

                //string v;
                //if(string.IsNullOrEmpty(columnValues[i]))
                //{
                //    v = "=" + System.DBNull.Value;
                //}
                //else
                //{
                //    v = "='" + columnValues[i] + "'";
                //}
                string v = "='" + columnValues[i] + "'";                
                nameValueList += n + v;
            }

            string sql = "UPDATE [" + tableName + "] " +
                         "SET " + nameValueList + " " +
                         "WHERE " + keyName + "='" + keyValue + "';";

            return sql;
        }

        private static bool _ignoreTable(string tableName)
        {
            return tableName.ToLower().Contains(ignoreTableName1.ToLower());
        }


#region "Old database test code"
        // Sample info from an existing datarecordset:
        //

        //?visio.ActiveDocument.DataRecordsets(1).CommandString
        //select * from `Sheet4$`

        //?visio.ActiveDocument.DataRecordsets(1).ID
        // 3 
        //?visio.ActiveDocument.DataRecordsets(1).Name
        //Sheet4
        //?visio.ActiveDocument.DataRecordsets(1).Document
        //Netaphor POC Demonstration v02_Chris 25k.vsd



        //?visio.ActiveDocument.DataRecordsets(1).DataConnection.ConnectionString
        //Provider=Microsoft.ACE.OLEDB.12.0;User ID=Admin;Data Source=D:\Work\2012 Projects\Netaphor\Test Data\Indexed-25000.xlsx;Mode=Read;Extended Properties="HDR=YES;IMEX=1;MaxScanRows=0;Excel 12.0;";Jet OLEDB:System database="";Jet OLEDB:Registry Path="";Jet OLEDB:Engine Type=37;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False;Jet OLEDB:Support Complex Data=False;Jet OLEDB:Bypass UserInfo Validation=False

        //?visio.ActiveDocument.DataRecordsets(1).DataConnection.ID
        // 3 

        //?visio.ActiveDocument.DataRecordsets(1).DataConnection.FileName
        //D:\Work\2012 Projects\Netaphor\Test Data\Indexed-25000.xlsx

        //?visio.ActiveDocument.DataRecordsets(1).DataConnection.Document
        //Netaphor POC Demonstration v02_Chris 25k.vsd
#endregion
    }
}
