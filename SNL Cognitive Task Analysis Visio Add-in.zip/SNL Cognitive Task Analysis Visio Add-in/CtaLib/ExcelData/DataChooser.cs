﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.Diagnostics;

namespace Visguy.VisAddinLib.ExcelData
{
    public class DataChooser
    {
        const string ExcelFilter =
            "All Excel Files (*.xl;*.xlsx;*.lsm;*.xlsb;*.xlam;*.xltx;*.xltm;*.xls;*.xlt;*.htm;*.html;*.mhg;*.mhtml;*.xml;*.xla;*.xlm;*.xlw;*.odc;*.uxdc;*.ods)|*.xl;*.xlsx;*.lsm;*.xlsb;*.xlam;*.xltx;*.xltm;*.xls;*.xlt;*.htm;*.html;*.mhg;*.mhtml;*.xml;*.xla;*.xlm;*.xlw;*.odc;*.uxdc;*.ods";

        public static string GetExcelFileFromOpenFileDialog()
        {
            // TODO: manage recent paths, etc?

            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = ExcelFilter;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                return ofd.FileName;
            }
            else
            {
                return string.Empty;
            }  
        }
        public static string GetExcelFileFromOpenFileDialog(string initialDirectory)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = ExcelFilter;
            ofd.InitialDirectory = initialDirectory;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                return ofd.FileName;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
