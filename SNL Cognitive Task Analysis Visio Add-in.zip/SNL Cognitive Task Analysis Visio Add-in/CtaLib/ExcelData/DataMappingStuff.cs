﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace Visguy.VisAddinLib.ExcelData
{
    // TODO: rename to something like Excel Data Definition.cs
    // TODO: alter the configuration XML to only have required
    //       tables and required columns per table.
    // 
    // The Sandia solution doesn't require imported data, so we
    // only need to specify table and column names, and perhaps
    // map them to code object names.
    //
    // This is a revised version of mapping configurations
    // I've used before that map Excel-based data columns
    // to Visio external data. This is just for specifying
    // required tables and columns for an Excel file.
    // Probably need some better naming.

    // The idea is to provide some sort of generic configuration
    // file so that different solutions can get the same functions:
    // 
    // - Browsing-to data file
    // - Opening as external data
    // - Checking for required tables
    // - Checking for key columns
    // - Checking for required key columns
    // - Storing column name mappings (to shape data labels)
    // - Default columns to hide


    public class DataMappings 
    {
        [XmlElement("mapping")]
        public List<DataMapping> Mappings { get; set; }

        public static DataMappings FromFile(string filepath)
        {           
            XmlSerializer xs;
            StreamReader sr = null;

            try
            {
                xs = new XmlSerializer(typeof(DataMappings));
                sr = new StreamReader(filepath);
                DataMappings m = (DataMappings)xs.Deserialize(sr);

                return m;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                    sr.Dispose();
                }
            }
        }

        public void SerializeToFile(string fullfilepath)
        {
            XmlSerializer xs;
            StreamWriter sw = null;

            try
            {
                xs = new XmlSerializer(typeof(DataMappings));
                sw = new StreamWriter(fullfilepath);
                xs.Serialize(sw, this);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                    sw.Dispose();
                }
            }
        }

        public DataMappings FilterByPrefix(string mappingNamePrefix)
        {
            DataMappings dms = new DataMappings();
            foreach(DataMapping dm in this.Mappings)
            {
                if(dm.Name.StartsWith(mappingNamePrefix, 
                        StringComparison.InvariantCultureIgnoreCase))
                {
                    dms.Add(dm);
                }
            }
            return dms;
        }

        public void Add(DataMapping m)
        {
            if (Mappings == null) Mappings = new List<DataMapping>();
            Mappings.Add(m);
        }
    }


    public class DataMapping
    {
        [XmlAttribute("name")]
        public string Name { get; set; }
        //public List<string> RequiredColumns { get; set; }

        [XmlElement("requiredtable")]
        public List<string> RequiredTableNames { get; set; }

        [XmlElement("column")]
        public List<DataColumn> Columns { get; set; }

        public void AddRequiredTable(string tablename)
        {
            if (RequiredTableNames == null) RequiredTableNames = new List<string>();
            RequiredTableNames.Add(tablename);
        }
        public void AddColumn(DataColumn c)
        {
            if (Columns == null) Columns = new List<DataColumn>();
            Columns.Add(c);
        }

        public string GetDataName(string displayName)
        {
            foreach (var c in this.Columns)
            {
                if (string.Compare(c.DisplayName, displayName, true) == 0)
                {
                    return c.DataName;
                }
            }
            return string.Empty;
        }
        public string GetDisplayName(string dataName)
        {
            foreach (var c in this.Columns)
            {
                if(string.Compare(c.DataName, dataName, true) == 0)
                {
                    return c.DisplayName;
                }
            }
            return string.Empty;
        }

        public DataColumn ItemFromDisplayName(string displayName)
        {
            foreach (var c in this.Columns)
            {
                if (string.Compare(c.DisplayName, displayName, true) == 0)
                {
                    return c;
                }
            }
            return new DataColumn(); // TODO: check that an empty DataColumn is better than null.
            //return null;
        }

        public List<string> RequiredColumnDataNames
        {
            get
            {
                List<string> cols = new List<string>();
                foreach(var c in this.Columns)
                    if (c.Required || c.IsKey) cols.Add(c.DataName);
                return cols;
            }
        }
        public List<string> RequiredColumnDisplayNames
        {
            get
            {
                List<string> cols = new List<string>();
                foreach (var c in this.Columns)
                    if (c.Required || c.IsKey) cols.Add(c.DisplayName);
                return cols;
            }
        }

        public List<string> KeyDataNames
        {
            get
            {
                List<string> cols = new List<string>();
                foreach (var c in this.Columns)
                    if (c.IsKey) cols.Add(c.DataName);
                return cols;
            }
        }
        public List<string> KeyDisplayNames
        {
            get
            {
                List<string> cols = new List<string>();
                foreach (var c in this.Columns)
                    if (c.IsKey) cols.Add(c.DisplayName);
                return cols;
            }
        }
    }

    
    public class DataColumn
    {
        [XmlAttribute("dbname")]
        public string DataName { get; set; }

        [XmlAttribute("visname")]        
        public string DisplayName { get; set; } //...same as shape data label too

        [XmlAttribute("iskey")]
        public bool IsKey { get; set; }

        [XmlAttribute("required")]
        public bool Required { get; set; }

        [XmlAttribute("hidden")]
        public bool Hidden { get; set; }                
    }

}
