﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Visguy.VisAddinLib.Extensions;

namespace Visguy.VisAddinLib.ExcelData
{
    public class ExcelWriteData
    {
        private string _keyColName = String.Empty;

        //private Dictionary<string, int> _colNames_colIndices = null;

        private Dictionary<string,List<string>> _colNames_UpdateValueLists = null;
        private Dictionary<string, List<string>> _colNames_InsertValueLists = null;
        //private List<string> _deleteKeys = null;

        public List<string> UpdateStatementBlock(string tableName)
        {
            return _getUpdateStatementBlock(tableName, _colNames_UpdateValueLists);
        }
        public List<string> InsertStatementBlock(string tableName)
        {
            return _getInsertStatementBlock(tableName, _colNames_InsertValueLists);
        }

        public ExcelWriteData(string keyColumnName, List<string> columnNames)
        {
            _keyColName = keyColumnName;

            //_colNames_colIndices = new Dictionary<string, int>();

            List<string> colNames = columnNames;
            if (colNames == null)
                colNames = new List<string>();

            // Initialize the Dictionary-List<string> dictionaries:
            _colNames_UpdateValueLists = new Dictionary<string, List<string>>();
            _colNames_InsertValueLists = new Dictionary<string, List<string>>();

            // Add keys and initialize empty List<string> collections
            // for each key:
            foreach(string cn in columnNames)
            {
                if( ! _colNames_InsertValueLists.ContainsKey(cn))
                {
                    _colNames_InsertValueLists.Add(cn, new List<string>());
                }
                if (!_colNames_UpdateValueLists.ContainsKey(cn))
                {
                    _colNames_UpdateValueLists.Add(cn, new List<string>());
                }
            }

        }

        public void AddDataRow_Insert(Dictionary<string,string> columnNames_Values) 
        {
            _addDataRow(_colNames_InsertValueLists, columnNames_Values);
        }

        public void AddDataRow_Update(Dictionary<string, string> columnNames_Values)
        {
            _addDataRow(_colNames_UpdateValueLists, columnNames_Values);
        }

        private void _addDataRow(
            Dictionary<string, List<string>> colNames_ValueLists,
            Dictionary<string, string> columnNames_Values)
        {
            // Run through each key in _colNames_ValueLists.
            // If columnNames_Values contains this key, then add
            // the value, otherwise add an empty string.
            foreach (string cn in colNames_ValueLists.Keys)
            {
                if (columnNames_Values.ContainsKey(cn))
                {
                    colNames_ValueLists[cn].Add(columnNames_Values[cn]);
                }
                else
                {
                    colNames_ValueLists[cn].Add(String.Empty);
                }
            }
        }

        //public void AddData_DeleteKey(string keyvalue_to_delete)
        //{
        //    _keysToDelete.AddUnique_CaseInsensitive(keyvalue_to_delete);                
        //}


        private List<string> _getUpdateStatementBlock(
            string tableName,
            Dictionary<string,List<string>> colNames_ValueLists)
        {
            //if (columnNames.Count != columnValues.Count)
            //{
            //    LastError = "ExcelData._getUpdateStatement: Column name and value arrays are not the same size!";
            //    Debug.WriteLine(LastError);
            //    return String.Empty;
            //}

            // Syntax:
            //  UPDATE table_name
            //  SET column1 = value1, column2 = value2,...
            //  WHERE some_column = some_value;
            //
            // Example:
            //  UPDATE Customers
            //  SET ContactName = 'Alfred Schmidt', City = 'Hamburg'
            //  WHERE CustomerName = 'Alfreds Futterkiste';

            
            //sb.AppendLine("UPDATE [" + tableName + "] ");
            //sb.AppendLine("SET " + nameValueList + " " +
            //sb.AppendLine("WHERE " + keyName + "='" + keyValue + "';";

            var sqls = new List<string>();

            // Remember each key in the dictionary contains a list of values
            // for each row, so we have to go down and across for each
            // row of data:
            int iRowCt = colNames_ValueLists.Values.First().Count;
            for (int iRow = 0; iRow < iRowCt; iRow++)
            {
                var sb = new StringBuilder();
                sb.AppendLine("UPDATE [" + tableName + "] ");

                string keyVal = String.Empty;
                var sbNamesVals = new StringBuilder();
                foreach (var colName in colNames_ValueLists.Keys)
                {
                    string rowVal = colNames_ValueLists[colName][iRow];

                    if (String.Compare(colName, _keyColName, true) == 0)
                        keyVal = rowVal;

                    if (sbNamesVals.Length > 0) sbNamesVals.Append(", ");
                    sbNamesVals.Append("[" + colName + "]"); //...column
                    sbNamesVals.Append("='" + rowVal + "'"); //...value
                }
                sb.AppendLine("SET " + sbNamesVals.ToString() +  " ");
                sb.AppendLine("WHERE [" + _keyColName + "]='" + keyVal + "';");

                sqls.Add(sb.ToString());
            }

            return sqls;            
        }

        private List<string> _getInsertStatementBlock(
            string tableName,
            Dictionary<string, List<string>> colNames_ValueLists)
        {            
            //string sql = "INSERT INTO [" + tableName + "] \n" +
            //             "(" + colNamesCsv + ") \n" +
            //             "VALUES(" + colValsCsv + ")";

            var sqls = new List<string>();

            string colNamesCsv = colNames_ValueLists.Keys.ToList().ToStringCsv("(",")", "[", "]", true);
            //String.Join(", ", colNames_ValueLists.Keys);

            // Remember each key in the dictionary contains a list of values
            // for each row, so we have to go down and across for each
            // row of data:
            int iRowCt = colNames_ValueLists.Values.First().Count;
            for (int iRow = 0; iRow < iRowCt; iRow++)
            {
                var sb = new StringBuilder();
                sb.Append("INSERT INTO [" + tableName + "] ");
                sb.Append(colNamesCsv + " ");
                
                // Now build the values list:
                var sbValList = new StringBuilder();
                foreach (var colName in colNames_ValueLists.Keys)
                {
                    string rowVal = colNames_ValueLists[colName][iRow];
                    if (sbValList.Length > 0) sbValList.Append(",");
                    sbValList.Append("'" + rowVal + "'"); //...value                    
                }

                // Append the values list, and close the statement:
                sb.AppendLine("VALUES (" + sbValList.ToString() + ");");                

                sqls.Add(sb.ToString());
            }

            return sqls;

        }


    }

    

    
}
