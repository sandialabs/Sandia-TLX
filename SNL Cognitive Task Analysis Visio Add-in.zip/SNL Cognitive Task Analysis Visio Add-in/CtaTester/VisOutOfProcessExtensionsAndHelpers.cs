﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vis = Microsoft.Office.Interop.Visio;
using Vwt = Microsoft.Office.Interop.Visio.VisWinTypes;

namespace CtaTester
{
    // Since this is a "tester" project, we want it to get a
    // running instance of Visio and work with that. This isn't
    // called from the add-in that runs in Visio's memory space.
    public static class VisOutOfProcessExtensionsAndHelpers
    {
        private const string VisioAppString = "visio.application";

        public static Vis.Application GetVisio()
        {
            Object objVis = null;

            try
            {
                objVis = System.Runtime.InteropServices.Marshal.GetActiveObject(VisioAppString);
                return (objVis as Vis.Application);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public static Vis.Shape GetFirstSelectedShape()
        {
            return GetSelectedShape(1);
        }
        public static Vis.Shape GetSelectedShape(int indexOneBased)
        {
            Vis.Selection visSel = GetSelection();
            if (visSel == null) return null;
            if (visSel.Count < indexOneBased) return null;
            return visSel[indexOneBased];
        }
        public static Vis.Selection GetSelection()
        {
            Vis.Application visApp = GetVisio();
            if (visApp == null) return null;

            Vis.Window visWin = visApp.ActiveWindow;

            if (visWin.IsDrawableWindow() == false) return null;

            return visWin.Selection;
        }

        /// <summary>
        /// Checks if Visio's active window is a drawing window--
        /// where actual shapes are manipulated, and not something
        /// odd, like a ShapeSheet window.
        /// </summary>
        /// <param name="visWin"></param>
        /// <returns></returns>
        public static bool IsDrawableWindow(this Vis.Window visWin)
        {
            if (visWin == null) return false;

            short wt = visWin.Type;

            if (wt == (short)Vwt.visDrawing ||
                wt == (short)Vwt.visDrawingAddon ||
                wt == (short)Vwt.visMasterWin ||
                wt == (short)Vwt.visPageGroupWin ||
                wt == (short)Vwt.visPageGroupWin ||
                wt == (short)Vwt.visPageWin)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
