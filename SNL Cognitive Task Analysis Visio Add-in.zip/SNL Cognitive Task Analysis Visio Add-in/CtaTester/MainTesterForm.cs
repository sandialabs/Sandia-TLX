﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Vis = Microsoft.Office.Interop.Visio;
using Visguy.VisAddinLib.Extensions;
using VALEX = Visguy.VisAddinLib.ExcelData.ExcelData;
using VALX = Visguy.VisAddinLib.ExcelData;
using SNL = SNL_Cognitive_Task_Analysis_Visio_Add_in;

namespace CtaTester
{
    public partial class MainTesterForm : Form
    {
        public MainTesterForm()
        {
            InitializeComponent();
        }

        private void button_TestExcelData_Click(object sender, EventArgs e)
        {
            // ----- Filepath stuff -------------------------------------------
            var filename = "Cognitive and Observable Tasks (500).xlsx";
            //var filename = "Cognitive and Observable Tasks (Empty).xlsx";
            //var filename = "Cognitive and Observable Tasks (Simple).xlsx";

            // This dll's folder:
            string folderDebug = Helpers.GetExecutingAssemblyFolderPath();
            DirectoryInfo diDebug = new DirectoryInfo(folderDebug);

            Debug.WriteLine(diDebug.FullName);
            var filepath = Path.Combine(diDebug.Parent.Parent.FullName, @"Excel Test Files\" + filename);

            Debug.WriteLine(filepath);
            Debug.WriteLine(File.Exists(filepath));
            // ----------------------------------------------------------------


            // 2016.04.11 -----------------------------------------------------
            // Test the block write statements 
            var d = new SNL.DataAccess.OdbExcel(filepath);
            // Task Number	Description	Category	Category_Layer	Category_Container	Category_NearestObservableTask	
            // (1-100) Mental Demand	Physical Demand	Temporal Demand	Performance	Effort	Frustration
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC001", "Mental Demand", "11");
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC001", "Temporal Demand", "11");
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC001", "Frustration", "11");
                                      
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC002", "Mental Demand", "22");
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC002", "Temporal Demand", "22");
            d.AddDataField_ForUpdate("'Cognitive Tasks$'", "Description", "DESC002", "Frustration", "22");

            // TODO: should Inset automatically add it's key/value? Probably.
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Description", "Cog600");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Mental Demand", "60");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Physical Demand", "60");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Temporal Demand", "60");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Performance", "60");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Effort", "60");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog600", "Frustration", "60");

            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Description", "Cog601");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Mental Demand", "N/A");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Physical Demand", "N/A");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Temporal Demand", "");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Performance", "");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Effort", "");
            d.AddDataField_ForInsert("'Cognitive Tasks$'", "Description", "Cog601", "Frustration", "N/A");

            // Task Number	Description	Category	Category_Layer	Category_Container	
            // (1-5) Importance	Difficulty	Duration	Frequency	Complexity

            //foreach(var s in d.)

            Debug.WriteLine(d.GetPendingWriteSql());

            d.Write();

            if(d.WriteErrorsCount > 0)
            {
                Debug.WriteLine(d.WriteErrorsCount + " errors out of " + d.WriteAttemptsCount + " attempts.");
                foreach(var s in d.LastWriteErrors)
                {
                    Debug.WriteLine("\t" + s);
                }
            }
         
        }

        private void _updateMultipleRows(string filepath, string tablename)
        {
            var colNames = new List<string>() { "Description", "Category", "Category_Layer", "Physical Demand", "Effort" };

            var d = new VALX.ExcelWriteData("Description", colNames);

            for (int i = 0; i < 3; i++)
            {
                var dict = new Dictionary<string, string>(){
                    { "Description", "desc-" + i },
                    { "Category", "cat " + i },
                    { "Category_Layer", "cat lyr " + i },
                    { "Physical Demand", "phys demand " + i },
                    { "Effort", "effort " + i }
                };

                d.AddDataRow_Insert(dict);
            }

            for (int i = 3; i < 8; i++)
            {
                var dict = new Dictionary<string, string>(){
                    { "Description", "desc-" + i },
                    { "Category", "cat-" + (i * 10).ToString() },
                    { "Category_Layer", "cat-layer-" + i },
                    { "Physical Demand", (i * 10).ToString() },
                    { "Effort", (i * 10).ToString() }
                };

                d.AddDataRow_Update(dict);
            }


            var sqlsInsert = d.InsertStatementBlock(tablename);
            var sqlsUpdate = d.UpdateStatementBlock(tablename);

            bool success = VALEX.WriteDataToExcel(filepath, tablename, d);

            //bool success = VALEX.UpdateMultipleRows(filepath, tablename,
            //    keys, keyVals, colNameArrays, colValArrays);

            if (success == false)
            {
                Debug.WriteLine("An error occurred!");
                Debug.WriteLine(VALEX.LastError);
            }


        }

        private void button_visDuJour_Click(object sender, EventArgs e)
        {
            Vis.Shape shp = VisOutOfProcessExtensionsAndHelpers.GetFirstSelectedShape();
            if (shp == null) return;

            Debug.WriteLine("Incoming connectors: " + shp.IncomingConnectors().Count);
            Debug.WriteLine("Outgoing connectors: " + shp.OutgoingConnectors().Count);

            string[] connClasses = new string[] { SNL.SolutionStrings.ShapeClass_CtaConnector };
            string[] shpClasses = new string[] { SNL.SolutionStrings.ShapeClass_Cognitive,
                                                 SNL.SolutionStrings.ShapeClass_Observable};

            Vis.Selection visSelIncomingShapes, visSelOutgoingShapes;

            shp.ConnectedShapes(connClasses, shpClasses, shpClasses,
                out visSelIncomingShapes, out visSelOutgoingShapes);

            int iSnlIn, iSnlOut;

            iSnlIn = visSelIncomingShapes != null ? visSelIncomingShapes.Count : 0;
            iSnlOut = visSelOutgoingShapes != null ? visSelOutgoingShapes.Count : 0;

            Debug.WriteLine("Incoming SNL shapes: " + iSnlIn);
            Debug.WriteLine("Outgoing SNL shapes: " + iSnlOut);

            // Now highlight the disconnected shapes and unconnected connector ends:
            Vis.Page visPg = shp.ContainingPage;
            var pg = new SNL.View.Page_Diagram(visPg);
            pg.Highlight_Disconnections();
        }

        private void button_testForms_Click(object sender, EventArgs e)
        {
            var frm = new SNL.UI.PanelForm();
            frm.Show();
        }

        private void button_testDescCatForm_Click(object sender, EventArgs e)
        {
            //var d = new SortedDictionary<string, string>();
            //d.Add("1", "One");
            //d.Add("2", "One");
            
            var frm = new SNL.UI.DescriptionAndCategoryForm(
                "Woohoo", null, null, "Ralf", "Category 004");
            //frm.ShowDialog();

            if(frm.ShowDialog() == DialogResult.OK)
            {
                Debug.WriteLine("Desc key: " + frm.SelectedDescriptionKey);
                Debug.WriteLine("Desc value: " + frm.SelectedDescriptionValue);
                Debug.WriteLine("Desc added: " + frm.SelectedDescriptionIsAdded);
                Debug.WriteLine("Desc changed: " + frm.SelectedDescriptionIsChanged);

                Debug.WriteLine("Cat key: " + frm.SelectedCategoryKey);
                Debug.WriteLine("Cat value: " + frm.SelectedCategoryValue);
                Debug.WriteLine("Cat added: " + frm.SelectedCategoryIsAdded);
                Debug.WriteLine("Cat changed: " + frm.SelectedCategoryIsChanged);
            }
            else
            {
                Debug.WriteLine("Dialog cancelled.");
            }
        }
    }
}
