﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CtaTester
{
    public static class Helpers
    {
        public static string GetExecutingAssemblyFolderPath()
        {
            // Get the assembly information
            System.Reflection.Assembly assemblyInfo =
                System.Reflection.Assembly.GetExecutingAssembly();

            // Location is where the assembly is run from 
            string assemblyLocation = assemblyInfo.Location;

            // CodeBase is the location of the ClickOnce deployment files
            Uri uriCodeBase = new Uri(assemblyInfo.CodeBase);
            //string ClickOnceLocation = ...

            string path = System.IO.Path.GetDirectoryName(uriCodeBase.LocalPath.ToString());

            return path;
        }
    }
}
