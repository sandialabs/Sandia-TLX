﻿namespace CtaTester
{
    partial class MainTesterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button9 = new System.Windows.Forms.Button();
            this.button_addConn = new System.Windows.Forms.Button();
            this.button_testForms = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button_addObs = new System.Windows.Forms.Button();
            this.button_visDuJour = new System.Windows.Forms.Button();
            this.button_testDescCatForm = new System.Windows.Forms.Button();
            this.button_AddCog = new System.Windows.Forms.Button();
            this.button_TestExcelData = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.button9, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button_addConn, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button_testForms, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_addObs, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_visDuJour, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_testDescCatForm, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_AddCog, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button_TestExcelData, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(500, 110);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Location = new System.Drawing.Point(336, 76);
            this.button9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(160, 30);
            this.button9.TabIndex = 9;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button_addConn
            // 
            this.button_addConn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_addConn.Location = new System.Drawing.Point(170, 76);
            this.button_addConn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_addConn.Name = "button_addConn";
            this.button_addConn.Size = new System.Drawing.Size(158, 30);
            this.button_addConn.TabIndex = 8;
            this.button_addConn.Text = "Add Connector";
            this.button_addConn.UseVisualStyleBackColor = true;
            // 
            // button_testForms
            // 
            this.button_testForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_testForms.Location = new System.Drawing.Point(4, 76);
            this.button_testForms.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_testForms.Name = "button_testForms";
            this.button_testForms.Size = new System.Drawing.Size(158, 30);
            this.button_testForms.TabIndex = 7;
            this.button_testForms.Text = "Test Forms";
            this.button_testForms.UseVisualStyleBackColor = true;
            this.button_testForms.Click += new System.EventHandler(this.button_testForms_Click);
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Location = new System.Drawing.Point(336, 40);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(160, 28);
            this.button6.TabIndex = 6;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button_addObs
            // 
            this.button_addObs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_addObs.Location = new System.Drawing.Point(170, 40);
            this.button_addObs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_addObs.Name = "button_addObs";
            this.button_addObs.Size = new System.Drawing.Size(158, 28);
            this.button_addObs.TabIndex = 5;
            this.button_addObs.Text = "Add Observable Task";
            this.button_addObs.UseVisualStyleBackColor = true;
            // 
            // button_visDuJour
            // 
            this.button_visDuJour.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_visDuJour.Location = new System.Drawing.Point(4, 40);
            this.button_visDuJour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_visDuJour.Name = "button_visDuJour";
            this.button_visDuJour.Size = new System.Drawing.Size(158, 28);
            this.button_visDuJour.TabIndex = 4;
            this.button_visDuJour.Text = "Vis du Jour";
            this.button_visDuJour.UseVisualStyleBackColor = true;
            this.button_visDuJour.Click += new System.EventHandler(this.button_visDuJour_Click);
            // 
            // button_testDescCatForm
            // 
            this.button_testDescCatForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_testDescCatForm.Location = new System.Drawing.Point(336, 4);
            this.button_testDescCatForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_testDescCatForm.Name = "button_testDescCatForm";
            this.button_testDescCatForm.Size = new System.Drawing.Size(160, 28);
            this.button_testDescCatForm.TabIndex = 3;
            this.button_testDescCatForm.Text = "Test Desc/Cat Form";
            this.button_testDescCatForm.UseVisualStyleBackColor = true;
            this.button_testDescCatForm.Click += new System.EventHandler(this.button_testDescCatForm_Click);
            // 
            // button_AddCog
            // 
            this.button_AddCog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_AddCog.Location = new System.Drawing.Point(170, 4);
            this.button_AddCog.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_AddCog.Name = "button_AddCog";
            this.button_AddCog.Size = new System.Drawing.Size(158, 28);
            this.button_AddCog.TabIndex = 2;
            this.button_AddCog.Text = "Add Cognitive Task";
            this.button_AddCog.UseVisualStyleBackColor = true;
            // 
            // button_TestExcelData
            // 
            this.button_TestExcelData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_TestExcelData.Location = new System.Drawing.Point(4, 4);
            this.button_TestExcelData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_TestExcelData.Name = "button_TestExcelData";
            this.button_TestExcelData.Size = new System.Drawing.Size(158, 28);
            this.button_TestExcelData.TabIndex = 1;
            this.button_TestExcelData.Text = "Test Excel Data";
            this.button_TestExcelData.UseVisualStyleBackColor = true;
            this.button_TestExcelData.Click += new System.EventHandler(this.button_TestExcelData_Click);
            // 
            // MainTesterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(500, 112);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainTesterForm";
            this.Text = "SNL CTA Tester";
            this.TopMost = true;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button_TestExcelData;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button_addConn;
        private System.Windows.Forms.Button button_testForms;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button_addObs;
        private System.Windows.Forms.Button button_visDuJour;
        private System.Windows.Forms.Button button_testDescCatForm;
        private System.Windows.Forms.Button button_AddCog;
    }
}

